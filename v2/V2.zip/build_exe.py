"""PyInstaller packaging for the Computer Use Agent Web console.

Usage:
    python build_exe.py                      # full build -> dist/ComputerUseAgentWeb/
    python build_exe.py --slim               # no torch/ultralytics (~60 MB, cloud YOLO only)
    python build_exe.py --onefile            # single executable instead of a directory
    python build_exe.py --include-model X.pt # bundle YOLO weights for offline detection
    python build_exe.py --no-paddle          # skip the OCR stack entirely

The full build ships every dependency: torch + torchvision (CPU), ultralytics,
PaddleOCR with its PP-OCR weights, OpenCV, the OpenAI SDK, Flask and pyautogui.
The point is that the result runs on a machine with no Python installed and no
network access — OCR included.

Why --slim exists: bundling CPU PyTorch alone is well over a gigabyte. If YOLO
detection runs remotely (YOLO_INFERENCE_MODE=cloud) nothing needs torch at
import time, because executors/screen_capture.py imports ultralytics lazily
inside _get_yolo(). Slim keeps every other skill working.

Two non-obvious traps handled here:

1. torchvision renames its C extension every release (`_C_stable.pyd`,
   `image_stable.pyd`, ...). PyInstaller's bundled hook does not see them, so
   torchvision imports happily and then every YOLO detection fails with
   "operator torchvision::nms does not exist". They are added explicitly.
2. PaddleOCR is version-coupled: paddlepaddle 3.0.0 + paddlex 3.7.2 blows up
   in PIR with "Type of attribute: strides is not right". The working pair is
   paddle 3.2.2 + paddlex 3.7.2, which on this machine lives in its own
   directory rather than site-packages. It is posted last in --paths so it
   wins over the mismatched copy, and the collected version is verified after
   the build by check_paddle_version().
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Vendored dependencies: the build must bundle exactly what the runtime will
# pick (see cua/ocr_engine.py::paddle_env_candidates), and both now come from
# inside this project rather than from a machine-specific directory.
PADDLE_ENV_ORDER = [
    ROOT / "vendor" / "paddle_env",
    ROOT / "_internal" / "paddle_env",
]

# PP-OCR weights. Vendored copies win; the PaddleOCR download cache is only a
# fallback for machines that never ran scripts/bootstrap_vendor.py.
PADDLE_MODEL_ORDER = [
    ROOT / "vendor" / "ocr_models",
    Path.home() / ".paddlex" / "official_models",
]
PROMPT_JSON = ROOT / "prompt-content-json"
STATIC_DIR = ROOT / "webui" / "static"

#: The vendored token counter and its tokenizers (~31MB). Data, not a module
#: graph entry: tokencalc is imported from this directory by path at runtime
#: (see cua/tokencalc_bridge.py), so bundling it as data keeps its two
#: third-party deps — tokenizers, jinja2 — from being pulled in as modules
#: and duplicated.
TOKENCALC_DIR = ROOT / "vendor" / "tokencalc"

TARGETS = {"AgentSkillWeb": {"script": "run_web.py", "windowed": False}}

ENTRY_SCRIPT = "run_web.py"
OUT_NAME = "ComputerUseAgentWeb"

SEP = ";" if sys.platform == "win32" else ":"

# Modules reached through dynamic imports (the executors use importlib), so
# PyInstaller's static analysis cannot see them.
HIDDEN_IMPORTS = [
    "cua.config", "cua.tool_loader", "cua.llm_client", "cua.engine",
    "cua.runtime", "cua.context", "cua.events", "cua.multimodal",
    "cua.inline_vision", "cua.ocr_engine", "cua.desktop", "cua.security_check",
    "cua.executors.keyboard", "cua.executors.mouse", "cua.executors.shell",
    "cua.executors.screen_capture", "cua.executors.vlm", "cua.executors.basic",
    "webui.server",
    "openai", "httpx", "requests", "flask", "numpy", "PIL", "PIL.Image",
    "pyperclip", "pyautogui",
]

# Full builds keep local YOLO, so only genuinely unrelated tooling is trimmed.
# Worth knowing: ultralytics reaches for matplotlib/scipy at import time, so
# excluding them here would break detection rather than slim anything down.
FULL_EXCLUDES = ["IPython", "jupyter", "notebook", "pytest", "tkinter.test"]

SLIM_EXCLUDES = FULL_EXCLUDES + [
    "torch", "torchvision", "torchaudio", "ultralytics", "cv2",
    "matplotlib", "scipy", "pandas",
]

NO_PADDLE_EXCLUDES = ["paddle", "paddleocr", "paddlex"]


def native_extensions(package: str) -> list[Path]:
    """Collect compiled extension modules of an installed package."""
    try:
        import importlib

        module = importlib.import_module(package)
        pkg_dir = Path(module.__file__ or "").resolve().parent
    except Exception:
        return []

    found: list[Path] = []
    for pattern in ("*.pyd", "*.so", "*.dylib"):
        found.extend(pkg_dir.glob(pattern))
    return found


def resolve_paddle_env() -> Path | None:
    for candidate in PADDLE_ENV_ORDER:
        if candidate.is_dir():
            return candidate
    return None


def retire_old_dist(dist_root: Path) -> None:
    """Move an existing bundle aside instead of deleting it.

    Safety guards on this host can block large recursive deletes, so nothing
    here ever calls rmtree on the previous artefact.
    """
    old = dist_root / OUT_NAME
    if not old.is_dir():
        return
    # Archived next to the build output; CUA_OLD_BUILDS_DIR can point at a
    # larger disk instead.
    archive = Path(
        os.environ.get("CUA_OLD_BUILDS_DIR") or (dist_root / "_old_builds")
    )
    stamp = time.strftime("%Y%m%d-%H%M%S")
    archive.mkdir(parents=True, exist_ok=True)
    target = archive / f"{OUT_NAME}_{stamp}"
    try:
        shutil.move(str(old), str(target))
        print(f"[build] previous bundle moved to {target}")
    except OSError as e:
        print(f"[build] could not move old bundle ({e}) - building anyway")


# Stdlib modules never worth pulling into the bundle even if referenced.
_STDLIB_DENY = {
    "tkinter", "idlelib", "lib2to3", "distutils", "site", "__main__", "this",
    "antigravity", "turtle", "turtledemo", "test", "pty", "tty", "termios",
    "fcntl", "pwd", "grp", "curses", "readline", "dbm", "gdbm", "audioop",
    "crypt", "nis", "ossaudiodev", "spwd", "sunau", "wave", "aifc", "chunk",
    "sndhdr", "xdrlib", "asynchat", "asyncore", "smtpd", "nntplib",
    "telnetlib", "cgitb", "mhlib", "msilib", "ensurepip", "venv",
}


def vendored_stdlib_imports(paddle_env: Path) -> list[str]:
    """Stdlib modules the vendored Paddle tree needs at runtime.

    The Paddle stack ships as data and is excluded from the module graph, so
    PyInstaller never analyses its imports — which means the stdlib modules it
    reaches for at runtime (``symtable`` via aistudio_sdk, ``ast``, ...) are
    silently missing from the bundle and only surface as ModuleNotFoundError
    on the target machine, after the app has already started fine.

    Deriving the list from the tree itself keeps it correct as Paddle changes,
    instead of relying on someone remembering to hand-maintain it.
    """
    import re
    import sys

    pattern = re.compile(r"^\s*(?:from|import)\s+([A-Za-z_]\w*)", re.M)
    names: set[str] = set()
    for path in paddle_env.rglob("*.py"):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for match in pattern.finditer(text):
            names.add(match.group(1))

    return sorted(
        name for name in names
        if name in sys.stdlib_module_names and name not in _STDLIB_DENY
    )


# Top-level packages whose submodules are deliberately NOT pulled in: the
# Paddle stack ships as data, so collecting these would defeat that.
_THIRDPARTY_DENY_ROOTS = {
    "paddle", "paddleocr", "paddlex", "modelscope", "numpy", "PIL", "cv2",
    "torch", "torchvision", "ultralytics", "scipy", "pandas",
}


def vendored_thirdparty_imports(paddle_env: Path, limit: int = 250) -> list[str]:
    """Dotted third-party modules the vendored tree reaches for.

    Same blind spot as the stdlib case, one level down: PyInstaller bundles
    ``setuptools`` because something else imports it, but never analyses
    Paddle's imports, so the submodule Paddle actually wants
    (``setuptools.command.easy_install``, used by
    ``paddle/utils/cpp_extension``) is absent from the bundle — and the
    vendored copy that has it is shadowed by the already-imported package.

    Only names importable in the build environment are emitted, so a stale
    reference cannot turn into a hard build failure.
    """
    import importlib.util
    import re
    import sys

    pattern = re.compile(
        r"^\s*(?:from\s+([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+)\s+import"
        r"|import\s+([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+))",
        re.M,
    )
    names: set[str] = set()
    for path in paddle_env.rglob("*.py"):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for match in pattern.finditer(text):
            names.add(match.group(1) or match.group(2))

    resolved: list[str] = []
    for name in sorted(names):
        root = name.split(".")[0]
        if root in _THIRDPARTY_DENY_ROOTS or root in sys.stdlib_module_names:
            continue
        try:
            if importlib.util.find_spec(name) is None:
                continue
        except Exception:
            continue
        resolved.append(name)
        if len(resolved) >= limit:
            break
    return resolved


def resolve_model_source() -> Path | None:
    """Where the PP-OCR weights for packaging come from."""
    for source in PADDLE_MODEL_ORDER:
        if source.is_dir():
            return source
    return None


def stage_paddle_models(cmd: list[str]) -> None:
    """Ship PP-OCR weights so OCR works with no network on the target."""
    source = resolve_model_source()
    if source is None:
        print("[build] no PP-OCR weights found - packaged OCR would download "
              "them on first run. Run scripts/bootstrap_vendor.py first.")
        return

    if all((source / kind).is_dir() for kind in ("det", "rec")):
        # Already laid out as det/ + rec/ (the vendored form): ship it directly,
        # no staging copy needed.
        print(f"[build] OCR weights from {source}")
        for kind in ("det", "rec"):
            cmd.append(f"--add-data={source / kind}{SEP}models/ocr/{kind}")
        return

    # Otherwise it is the PaddleOCR download cache: pull out the newest pair.
    stamp = time.strftime("%Y%m%d-%H%M%S")
    staging = ROOT / "_build" / f"ocr_models_{stamp}"
    staging.mkdir(parents=True, exist_ok=True)

    for kind in ("det", "rec"):
        candidates = sorted(
            d for d in source.iterdir()
            if d.is_dir() and d.name.endswith(f"_{kind}")
        )
        if not candidates:
            print(f"[build] no PP-OCR {kind} model in {source} - skipping")
            continue
        src = candidates[-1]
        shutil.copytree(
            src, staging / kind,
            ignore=shutil.ignore_patterns("*.onnx_shape.txt"),
        )
        print(f"[build] staged OCR {kind} weights: {src.name}")

    if any(staging.iterdir()):
        cmd.append(f"--add-data={staging}{SEP}models/ocr")
    else:
        staging.rmdir()


def build(args: argparse.Namespace) -> Path:
    paddle_env = None if args.no_paddle else resolve_paddle_env()
    slim = args.slim or args.no_paddle

    work_dir = (
        Path(args.work_dir) / OUT_NAME / time.strftime("%Y%m%d-%H%M%S")
        if args.work_dir
        else Path(tempfile.gettempdir()) / "cua_build" / OUT_NAME
             / time.strftime("%Y%m%d-%H%M%S")
    )
    work_dir.mkdir(parents=True, exist_ok=True)

    dist_root = Path(args.dist_dir) if args.dist_dir else ROOT / "dist"
    dist_root.mkdir(parents=True, exist_ok=True)
    if not args.dist_dir:
        retire_old_dist(dist_root)

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
    ] + (["--clean"] if args.clean else []) + [
        "--onefile" if args.onefile else "--onedir",
        # The console panel prints its startup banner and shut-down errors.
        "--console",
        f"--name={OUT_NAME}",
        f"--distpath={dist_root}",
        f"--workpath={work_dir}",
        f"--specpath={work_dir}",
        f"--paths={ROOT}",
        # Runtime data read through config.PROMPT_JSON_DIR / STATIC_DIR.
        f"--add-data={PROMPT_JSON}{SEP}prompt-content-json",
        f"--add-data={STATIC_DIR}{SEP}webui/static",
    ]

    # The token counter is shipped as a directory: both the tokencalc package
    # and the tokenizers it reads live under vendor/tokencalc, and the bridge
    # resolves them relative to its own location under sys._MEIPASS.
    if TOKENCALC_DIR.is_dir():
        cmd.append(f"--add-data={TOKENCALC_DIR}{SEP}vendor/tokencalc")
        size_mb = sum(f.stat().st_size for f in TOKENCALC_DIR.rglob("*") if f.is_file()) / 1e6
        print(f"[build] bundling token calculator: {size_mb:.0f} MB")
    else:
        # Not fatal — the panel starts and simply reports the feature as
        # unavailable (see tokencalc_bridge.available()). Loud, though: a
        # silent omission here is a shipped build without token statistics.
        print(f"[build] WARNING: {TOKENCALC_DIR} missing — 构建产物将不含 token 统计。"
              f"先运行：python scripts/embed_tokencalc.py")

    # torchvision's detection kernels (nms) live in version-named .pyd files
    # that the bundled hook misses.
    if not slim:
        for package in ("torchvision",):
            for ext in native_extensions(package):
                cmd.append(f"--add-binary={ext}{SEP}{package}")

    if args.include_model:
        model_path = Path(args.include_model)
        if not model_path.exists():
            raise SystemExit(f"[build] YOLO model not found: {model_path}")
        cmd.append(f"--add-data={model_path}{SEP}models")
        print(f"[build] bundling YOLO weights: {model_path.name}")

    if paddle_env:
        print(f"[build] PaddleOCR stack: {paddle_env}")
        # Ship the Paddle tree as DATA and keep it OUT of the module graph.
        #
        # Two reasons, both learned the hard way:
        #
        # 1. --collect-all=paddle resolved against this interpreter's
        #    site-packages, which holds the mismatched paddlepaddle 3.0.0. In a
        #    frozen app PyInstaller's importer beats sys.path, so the runtime
        #    would have used the broken pair no matter what ocr_engine.py puts
        #    on sys.path. Data-only collection removes that override.
        # 2. The env directory is a full `pip install --target` tree carrying
        #    its own numpy/Pillow/cv2. Collecting it would mix two versions of
        #    them into one bundle.
        cmd.append(f"--add-data={paddle_env}{SEP}paddle_env")
        for package in ("paddle", "paddleocr", "paddlex", "modelscope"):
            cmd.append(f"--exclude-module={package}")

        # The tree is data, so its stdlib dependencies are invisible to the
        # analysis pass — declare them explicitly.
        stdlib_modules = vendored_stdlib_imports(paddle_env)
        print(f"[build] stdlib modules for the Paddle runtime: {len(stdlib_modules)}")
        for module in stdlib_modules:
            cmd.append(f"--hidden-import={module}")

        third_party = vendored_thirdparty_imports(paddle_env)
        print(f"[build] third-party modules for the Paddle runtime: {len(third_party)}")
        for module in third_party:
            cmd.append(f"--hidden-import={module}")

        stage_paddle_models(cmd)

    for module in HIDDEN_IMPORTS:
        cmd.append(f"--hidden-import={module}")

    excludes = list(SLIM_EXCLUDES if slim else FULL_EXCLUDES)
    if args.no_paddle:
        excludes += NO_PADDLE_EXCLUDES
    for module in excludes:
        cmd.append(f"--exclude-module={module}")

    cmd.append(str(ROOT / ENTRY_SCRIPT))

    print("=" * 70)
    print(f"  Packaging {ENTRY_SCRIPT} -> {OUT_NAME}")
    print(f"  mode: {'slim' if slim else 'full'}"
          f"{' | paddle: ' + paddle_env.name if paddle_env else ' | paddle: excluded'}")
    print("=" * 70)

    started = time.time()
    result = subprocess.run(cmd, cwd=str(ROOT))
    if result.returncode != 0:
        raise SystemExit(f"[build] PyInstaller failed (exit {result.returncode})")

    bundle = dist_root / OUT_NAME
    print(f"\n[build] done in {int(time.time() - started)}s -> {bundle}")
    return bundle


def check_paddle_version(bundle: Path) -> None:
    """Verify the bundled Paddle is the pair that works with paddlex.

    A silent mismatch is far worse than a build error: the app starts, OCR is
    reported as ready, and the first real screenshot dies in PIR.
    """
    import re

    internal = bundle / "_internal"
    base = internal if internal.is_dir() else bundle

    # The Paddle stack must arrive as data only. If a top-level paddle/ landed
    # in _internal it came from site-packages via --collect-all, and the frozen
    # importer prefers it over paddle_env/ no matter what ocr_engine.py does
    # with sys.path.
    if (base / "paddle").is_dir():
        print("[check] WARNING - paddle was collected into the module graph; "
              "the frozen importer will prefer it over paddle_env/")
    else:
        print("[check] ok  paddle is data-only (not in the module graph)")

    version_file = base / "paddle_env" / "paddle" / "version" / "__init__.py"
    if not version_file.is_file():
        print("[check] paddle_env not found in the bundle "
              "(expected only for --slim/--no-paddle)")
        return

    text = version_file.read_text(encoding="utf-8", errors="replace")
    versions = re.findall(r"['\"](\d+\.\d+\.\d+)['\"]", text)
    print(f"[check] bundled paddle (paddle_env) declares: {versions[:1]}")
    if versions and versions[0].startswith("3.0."):
        print(
            "[check] WARNING - paddle 3.0.x paired with paddlex 3.7.x is a known\n"
            "        broken combination (PIR 'Type of attribute: strides is not\n"
            "        right'). OCR will fail at runtime on the target machine."
        )


def report_size(bundle: Path) -> None:
    try:
        total = sum(f.stat().st_size for f in bundle.rglob("*") if f.is_file())
        print(f"[build] bundle size: {total / 1024 ** 3:.2f} GB")
    except OSError:
        pass


def main() -> None:
    parser = argparse.ArgumentParser(description="Package the Computer Use Agent Web console.")
    parser.add_argument("--slim", action="store_true",
                        help="exclude torch/ultralytics and cv2 (much smaller; cloud YOLO only)")
    parser.add_argument("--no-paddle", action="store_true",
                        help="exclude the whole PaddleOCR stack (no offline OCR)")
    parser.add_argument("--onefile", action="store_true", help="single executable instead of a directory")
    parser.add_argument("--clean", action="store_true", help="wipe the PyInstaller cache first")
    parser.add_argument("--work-dir", default="", help="intermediate build directory")
    parser.add_argument("--dist-dir", default="", help="output directory (default: ./dist)")
    parser.add_argument("--include-model", default="", help="YOLO .pt/.onnx weights to bundle")
    args = parser.parse_args()

    missing = [p for p in (PROMPT_JSON, STATIC_DIR, ROOT / ENTRY_SCRIPT) if not p.exists()]
    if missing:
        raise SystemExit(f"[build] missing from project root: {missing}")

    try:
        import PyInstaller  # noqa: F401
    except ImportError:
        raise SystemExit("[build] PyInstaller is not installed. Run: pip install pyinstaller>=6.0")

    bundle = build(args)
    report_size(bundle)
    if not (args.slim or args.no_paddle):
        check_paddle_version(bundle)


if __name__ == "__main__":
    main()
