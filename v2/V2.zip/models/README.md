# models/ — 模型权重放置目录

权重体积较大，**不随仓库分发**，请从项目托管位置下载后放到这里：

```
models/
├── best.pt          # YOLO 目标检测权重（本地检测模式必需）
└── ocr/             # （可选）PP-OCR 权重的另一种摆放方式
    ├── det/
    └── rec/
```

## YOLO 检测（`YOLO_INFERENCE_MODE=bundled`）

把权重保存为 `models/best.pt`，或在设置页 / 环境变量里指向任意现存文件：

```
CUA_YOLO_MODEL=D:/path/to/best.pt
```

不需要本地检测时，把 `YOLO_INFERENCE_MODE` 设为 `off`（或 `cloud` 走远端）
即可，`DetectObjects` 会返回可读的说明而不是报错。

## OCR（`OCR_ENGINE=builtin`）

- 默认情况下 PaddleOCR 首次运行会自动把 PP-OCR 权重下载到 `~/.paddlex/`；
- 需要离线可用时，把权重放到 `vendor/ocr_models/{det,rec}/`（见
  `vendor/README.md`），`cua/ocr_engine.py` 会优先使用它们。
