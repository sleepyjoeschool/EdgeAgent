"""Launcher for the Web control panel.

    python run_web.py                 # host/port from config override or env
    python run_web.py --host 0.0.0.0 --port 8080 --lan
    python run_web.py --open          # also open the browser

Binding to anything other than 127.0.0.1 exposes a machine-controlling
endpoint to your network; ``--lan`` additionally installs the LAN-only IP
filter so public addresses are refused.
"""

from __future__ import annotations

import argparse
import ipaddress
import socket
import sys
import traceback
from pathlib import Path

# Keep imports working no matter where this script is invoked from.
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from cua import config  # noqa: E402


def _lan_ip() -> str:
    """Best-effort LAN address of this machine."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(0.1)
            sock.connect(("10.255.255.255", 1))
            return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def _is_private_ip(value: str) -> bool:
    try:
        return ipaddress.ip_address(value).is_private
    except ValueError:
        return False


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Computer Use Agent — Web control panel")
    parser.add_argument("--host", default=None, help="bind address (default: config.WEB_HOST)")
    parser.add_argument("--port", type=int, default=None, help="listen port (default: config.WEB_PORT)")
    parser.add_argument("--lan", action="store_true", help="reject clients outside private IP ranges")
    parser.add_argument("--open", action="store_true", help="open the panel in the default browser")
    parser.add_argument("--debug", action="store_true", help="Flask debug mode")
    return parser


def main() -> int:
    args = _build_parser().parse_args()

    from webui import server

    if args.lan:
        @server.app.before_request
        def _lan_only_filter():
            from flask import abort, request as flask_request

            client_ip = flask_request.remote_addr or "127.0.0.1"
            if client_ip in ("127.0.0.1", "::1") or _is_private_ip(client_ip):
                return None
            abort(403)

    host = args.host or config.WEB_HOST
    port = int(args.port or config.WEB_PORT)

    if args.open:
        import threading
        import webbrowser

        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()

    if host not in ("127.0.0.1", "localhost"):
        print()
        print("  !! Binding beyond loopback exposes control of this desktop.")
        print(f"  !! Serving on {host}:{port} — accounts are required, but the")
        print("     first-run setup page is reachable by anyone who gets here first.")
        print("     Consider --lan so only private-IP clients are accepted.")

    server.run_server(host=host, port=port, debug=args.debug)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException:  # noqa: BLE001 - startup failures land in a log file
        log = ROOT_DIR / "web_crash.log"
        try:
            log.write_text(
                f"Computer Use Agent crashed at {__import__('datetime').datetime.now()}\n"
                f"Python {sys.version}\n\n{traceback.format_exc()}",
                encoding="utf-8",
            )
        except OSError:
            pass
        traceback.print_exc()
        print(f"Details written to {log}", file=sys.stderr)
        raise
