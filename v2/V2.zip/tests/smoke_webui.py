"""Full-stack smoke test: mission -> SSE -> approval round-trip -> result.

Runs the real Flask app and the real agent loop. Only the LLM transport is
faked, so the test proves the wiring between the engine, the approval bridge
and the HTTP API without touching the network or an existing desktop session
(the scripted command is deliberately inert).

The panel now requires an account, so the test performs the first-run setup
and drives every request with the resulting session cookie and CSRF token —
which also means the auth layer is exercised on every mission call.
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cua import config, llm_client, security_check
from tests.smoke_engine import Chunk, Delta, FnBody, FnDelta, MockClient, tool_delta  # noqa: E402
from webui import server  # noqa: E402

config.LLM_API_KEY = "test-key"
config.SHELL_AUDIT_FAILURE_POLICY = "ask"

# Never touch the operator's real accounts file from a test run.
_SCRATCH = Path(tempfile.mkdtemp(prefix="cua-smoke-auth-"))
config.user_store_path = lambda: _SCRATCH / "users.json"
config.audit_log_path = lambda: _SCRATCH / "audit.log"

# Rebuild the module-level store against the scratch directory.
server.store = __import__("cua.auth", fromlist=["create_store"]).create_store()

# Session history goes to the same scratch directory: every mission now
# creates a session, so a smoke run would otherwise leave conversations
# behind in the project's own sessions folder.
from cua.sessions import SessionStore  # noqa: E402

server.hub.sessions = SessionStore(_SCRATCH / "sessions")

ADMIN_PASSWORD = "Smoke-Admin-9271"


class BlindAudit:
    """The audit endpoint is unreachable — the case that forces a decision."""

    @staticmethod
    def run_audit(code, explanation):
        return security_check.AuditVerdict(
            dangerous=False,
            unavailable=True,
            audit_error="RuntimeError: audit endpoint unreachable",
        )


security_check.run_audit = BlindAudit.run_audit


def make_client(script):
    def factory(*_args, **_kwargs):
        return MockClient(script)
    return factory


def wait_for(predicate, timeout=15.0, interval=0.05):
    deadline = time.time() + timeout
    while time.time() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(interval)
    return None


def sign_in(client) -> dict:
    """Run the first-run wizard and return the headers carrying auth."""
    res = client.post("/api/setup/account", json={
        "username": "smoke-admin",
        "password": ADMIN_PASSWORD,
    })
    if res.status_code != 200:
        raise SystemExit(f"setup failed: {res.status_code} {res.data[:300]}")
    return {"X-CSRF-Token": res.get_json()["csrf"]}


def main() -> int:
    failures: list[str] = []
    app = server.app
    app.config["TESTING"] = True
    http = app.test_client()
    auth = sign_in(http)

    script = [
        [
            tool_delta(0, "call-1", "ShellAction_RunShell",
                       '{"ShellCode":"echo cua-smoke-ok","Explanation":"verify the shell path"}'),
            Chunk(Delta(content="Ran the echo command.")),
        ],
        [Chunk(Delta(content="TASK_COMPLETE The shell round trip works."))],
    ]
    llm_client.build_llm_client = make_client(script)

    # ── 1. Credentials gate must reject an empty task ───────────────────
    res = http.post("/api/mission", json={"task": "   "}, headers=auth)
    if res.status_code != 400:
        failures.append(f"empty task should be 400, got {res.status_code}")

    # An anonymous caller must not be able to start anything at all.
    anon = app.test_client()
    res = anon.post("/api/mission", json={"task": "run echo"})
    if res.status_code != 401:
        failures.append(f"anonymous mission should be 401, got {res.status_code}")
    # A *logged-in* session that omits the CSRF header must still be refused —
    # this is the case a cookie alone cannot cover.
    res = http.post("/api/mission", json={"task": "run echo"})
    if res.status_code != 403:
        failures.append(f"mission without csrf should be 403, got {res.status_code}")

    # ── 2. Start a mission ──────────────────────────────────────────────
    res = http.post("/api/mission", json={"task": "run echo", "max_steps": 6}, headers=auth)
    if res.status_code != 200:
        failures.append(f"mission start failed: {res.status_code} {res.data[:200]}")
        return _report(failures)

    print(f"=== mission started (actor={server.hub.actor}) ===")

    # ── 3. It must park on an approval rather than executing blindly ────
    pending = wait_for(lambda: server.hub.pending)
    if not pending:
        failures.append("the shell tool never requested operator approval")
        return _report(failures)
    print(f"  parked on approval: kind={pending['kind']} risk={pending.get('risk','')[:60]}")

    status = http.get("/api/status").get_json()
    if not status["pending"]:
        failures.append("pending approval not visible through /api/status")

    # ── 4. Deny first: nothing must execute ─────────────────────────────
    server.hub.pending = pending
    res = http.post("/api/control", json={"action": "answer", "approved": False}, headers=auth)
    if res.status_code != 200:
        failures.append(f"deny answer rejected: {res.status_code} {res.data[:200]}")

    outcome = wait_for(lambda: server.hub.outcome, timeout=20)
    if not outcome:
        failures.append("mission did not finish after the denial")
        return _report(failures)

    denied_results = [
        e for e in server.hub.transcript
        if e.get("type") == "tool_result" and e.get("name") == "ShellAction_RunShell"
    ]
    print(f"  after denial  -> steps={outcome['steps']} reason={outcome['reason']}")
    if denied_results and denied_results[0]["ok"]:
        failures.append("command executed even though the operator denied it")
    if denied_results and "SAFETY BLOCK" not in denied_results[0]["result"]:
        failures.append("denial was not reported back to the model as SAFETY BLOCK")

    # ── 5. Approve: the command should actually run ─────────────────────
    # Wait for the worker thread itself, not for hub.busy: the hub stops
    # reporting busy as soon as the outcome is posted, but the thread is still
    # flushing the session to disk, and clearing the outcome below would make
    # it look busy again.
    if not wait_for(lambda: not (server.hub.thread and server.hub.thread.is_alive()),
                    timeout=10):
        failures.append("first mission's worker never finished")

    security_check.reset_failure_state()
    llm_client.build_llm_client = make_client([
        [
            tool_delta(0, "c1", "ShellAction_RunShell",
                       '{"ShellCode":"echo cua-smoke-ok","Explanation":"verify the shell path"}'),
            Chunk(Delta(content="Ran the echo command.")),
        ],
        [Chunk(Delta(content="TASK_COMPLETE The shell round trip works."))],
    ])
    server.hub.transcript.clear()
    server.hub.outcome = None

    res = http.post("/api/mission", json={"task": "run echo again"}, headers=auth)
    if res.status_code != 200:
        failures.append(f"second mission failed to start: {res.status_code} {res.data[:200]}")
        return _report(failures)

    pending = wait_for(lambda: server.hub.pending)
    if not pending:
        failures.append("second mission never asked for approval")
        return _report(failures)

    http.post("/api/control", json={"action": "answer", "approved": True}, headers=auth)
    outcome = wait_for(lambda: server.hub.outcome, timeout=20)
    if not outcome:
        failures.append("second mission did not finish after approval")
        return _report(failures)

    approved_results = [
        e for e in server.hub.transcript
        if e.get("type") == "tool_result" and e.get("name") == "ShellAction_RunShell"
    ]
    print(f"  after approval -> steps={outcome['steps']} reason={outcome['reason']}")
    if not approved_results:
        failures.append("no shell tool result recorded after approval")
    else:
        payload = approved_results[0]["result"]
        print(f"  shell output   -> {payload.strip().splitlines()[-1][:80]}")
        if "cua-smoke-ok" not in payload:
            failures.append(f"approved command did not run correctly: {payload[:160]}")
        if not approved_results[0]["ok"]:
            failures.append("approved command was reported as failed")

    # ── 6. Event transcript shape ───────────────────────────────────────
    kinds = [e["type"] for e in server.hub.transcript]
    for required in ("run_start", "step_start", "tool_call", "tool_result", "run_done"):
        if required not in kinds:
            failures.append(f"missing '{required}' event in the transcript")
    print(f"  event kinds    -> {sorted(set(kinds))}")

    # ── 7. Sessions: persisted context, and continued on the next mission ──
    test_sessions(failures, http, auth)

    return _report(failures)


def test_sessions(failures: list[str], http, auth: dict) -> None:
    """A session persists its context to disk and continues it next run.

    The two properties that are easy to break and invisible until they bite:
    a freshly created session must still get a system prompt (an empty
    message list reads like "continue with nothing"), and a second mission in
    the same session must *extend* the stored context rather than replace it.
    """
    # hub.sessions already points at the scratch directory; see the top of
    # this file. Writing here would leave conversations in the project.
    sid = http.post("/api/sessions", json={}, headers=auth).get_json()["session"]["id"]
    print(f"\n=== sessions ===\n  created {sid}")

    def scripted(answer):
        return make_client([[
            tool_delta(0, "c1", "BasicFunction_ReadFromClipboard", "{}"),
            Chunk(Delta(content=answer)),
        ]])

    def run_once(task: str, answer: str):
        llm_client.build_llm_client = scripted(answer)
        res = http.post("/api/mission", json={"task": task, "session_id": sid},
                        headers=auth)
        if res.status_code != 200:
            failures.append(f"session: mission rejected {res.status_code} {res.data[:200]}")
            return None
        # Join on the worker thread rather than on hub.busy: the session file
        # is written *after* the outcome is posted, so anything read before the
        # thread exits would be the previous version of the file.
        return wait_for(
            lambda: server.hub.outcome
            if not (server.hub.thread and server.hub.thread.is_alive()) else None,
            timeout=20)

    if not run_once("open notepad", "TASK_COMPLETE first run"):
        return

    path = server.hub.sessions.dir / f"{sid}.json"
    if not path.is_file():
        failures.append("session: nothing was written to the session folder")
        return

    first = json.loads(path.read_text(encoding="utf-8"))
    roles = [m["role"] for m in first["messages"]]
    if roles[:2] != ["system", "user"]:
        failures.append(f"session: context lost its system prompt: {roles}")
    if not first["transcript"]:
        failures.append("session: transcript was never persisted")

    got = http.get(f"/api/sessions/{sid}", headers=auth).get_json()["session"]
    print(f"  run 1 -> runs={got['runs']} steps={got['steps']} "
          f"events={got['events']} title={got['title']!r}")
    if got["runs"] != 1:
        failures.append(f"session: expected 1 run, got {got['runs']}")
    if not got["title"]:
        failures.append("session: title was not derived from the first task")

    if not run_once("now type hello", "TASK_COMPLETE second run"):
        return

    second = json.loads(path.read_text(encoding="utf-8"))
    requests = [m["content"] for m in second["messages"]
                if m["role"] == "user" and isinstance(m.get("content"), str)]
    print(f"  run 2 -> messages={len(second['messages'])} requests={requests}")
    if "open notepad" not in requests:
        failures.append("session: the first task fell out of the context")
    if "now type hello" not in requests:
        failures.append("session: the second task never entered the context")
    if len(second["messages"]) <= len(first["messages"]):
        failures.append("session: the second run did not extend the context")

    res = http.delete(f"/api/sessions/{sid}", headers=auth)
    if res.status_code != 200:
        failures.append(f"session: delete failed {res.status_code} {res.data[:160]}")
    # Other sessions may exist: the missions earlier in this file run without
    # a session id and each gets one. Only this one has to be gone.
    remaining = [s["id"] for s in
                 http.get("/api/sessions", headers=auth).get_json()["sessions"]]
    if sid in remaining:
        failures.append("session: deleted session is still listed")


def _report(failures: list[str]) -> int:
    print()
    if failures:
        print("FAILURES:")
        for item in failures:
            print("  ✗", item)
        return 1
    print("Full-stack smoke test passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
