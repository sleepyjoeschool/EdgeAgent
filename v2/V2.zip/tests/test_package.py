"""Full end-to-end test of the packaged executable.

Everything runs against ``dist/ComputerUseAgentWeb/ComputerUseAgentWeb.exe`` —
the real frozen binary, not the source tree. The agent is steered by pointing
``CUA_LLM_BASE_URL`` at a scripted OpenAI-compatible server, so the test
exercises the real HTTP path and the real streaming parser without needing a
model or a key.

Coverage, in order:

1. static assets and read-only APIs
2. desktop preview (screenshot taken inside the frozen binary)
3. SSE stream
4. mission A — perception + mouse + shell inside the frozen environment:
   YOLO detection (where the torchvision::nms trap would surface), OCR with
   the bundled weights, cursor position, a real command, and a command the
   static rules must refuse
5. mission B — a command the auditor flags; operator denies, nothing runs
6. mission C — the same command; operator approves, it runs
7. settings persistence next to the executable

Usage:
    python tests/test_package.py
    python tests/test_package.py --bundle D:/path/to/ComputerUseAgentWeb
    python tests/test_package.py --skip-ocr       # OCR takes ~2-3 min
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tests.mock_llm import MockLLMServer  # noqa: E402

DEFAULT_BUNDLE = ROOT / "dist" / "ComputerUseAgentWeb"
EXE_NAME = "ComputerUseAgentWeb.exe"
WEB_PORT = 5211

_SERVER: MockLLMServer | None = None


# ── HTTP helpers ────────────────────────────────────────────────────────

# The panel is account-gated, so every call needs the session cookie plus the
# CSRF header. A tiny cookie jar keeps the phases below unchanged.
_SESSION_COOKIE: str | None = None
_CSRF_TOKEN: str | None = None


def _capture_auth(headers) -> None:
    """Remember the Set-Cookie and the CSRF token the server hands out."""
    global _SESSION_COOKIE, _CSRF_TOKEN
    raw = headers.get("Set-Cookie") or ""
    for part in raw.split(";"):
        part = part.strip()
        if part.startswith("cua_session="):
            value = part[len("cua_session="):]
            _SESSION_COOKIE = None if not value else value


def _auth_headers(extra: dict | None = None) -> dict:
    headers = dict(extra or {})
    if _SESSION_COOKIE:
        headers["Cookie"] = f"cua_session={_SESSION_COOKIE}"
    if _CSRF_TOKEN:
        headers["X-CSRF-Token"] = _CSRF_TOKEN
    return headers


def sign_in(base: str) -> None:
    """Run the first-run wizard and remember the resulting session."""
    global _CSRF_TOKEN
    status, body = post_json(base + "/api/setup/account", {
        "username": "package-admin",
        "password": "Package-Admin-9271",
    })
    if status != 200:
        raise SystemExit(f"setup failed: {status} {body}")
    _CSRF_TOKEN = body.get("csrf")
    print(f"  ok  signed in as {body.get('user', {}).get('name')}")


def get_json(url: str, timeout: float = 15.0) -> dict:
    req = urllib.request.Request(url, headers=_auth_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        # Surfacing the status keeps a phase failure readable instead of
        # turning every auth problem into an opaque exception.
        raise RuntimeError(f"GET {url} -> {e.code}") from e


def get_bytes(url: str, timeout: float = 30.0) -> bytes:
    req = urllib.request.Request(url, headers=_auth_headers())
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def post_json(url: str, payload: dict, timeout: float = 20.0) -> tuple[int, dict]:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers=_auth_headers({"Content-Type": "application/json"}),
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            _capture_auth(r.headers)
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        _capture_auth(e.headers)
        body = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(body)
        except ValueError:
            return e.code, {"error": body[:300]}


def wait_until_ready(base: str, proc: subprocess.Popen, timeout: float = 120.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            get_json(base + "/api/hello", timeout=3)
            return True
        except Exception:
            if proc.poll() is not None:
                return False
            time.sleep(0.8)
    return False


# ── SSE client ──────────────────────────────────────────────────────────

class EventStream:
    """Collects events from /api/events in a background thread."""

    def __init__(self, base: str) -> None:
        self.base = base
        self.events: list[dict] = []
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def start(self) -> None:
        def pump() -> None:
            try:
                req = urllib.request.Request(
                    self.base + "/api/events",
                    headers=_auth_headers({"Accept": "text/event-stream"}),
                )
                with urllib.request.urlopen(req, timeout=400) as r:
                    buffer = b""
                    while not self._stop.is_set():
                        chunk = r.read(1)
                        if not chunk:
                            break
                        buffer += chunk
                        if buffer.endswith(b"\n\n"):
                            line = buffer.decode("utf-8", "replace").strip()
                            buffer = b""
                            if line.startswith("data: "):
                                try:
                                    self.events.append(json.loads(line[6:]))
                                except ValueError:
                                    pass
            except Exception:
                pass

        self._thread = threading.Thread(target=pump, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def wait_for(self, predicate, timeout: float = 60.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            for event in self.events:
                if predicate(event):
                    return event
            time.sleep(0.2)
        return None

    def of(self, kind: str) -> list[dict]:
        return [e for e in self.events if e.get("type") == kind]


# ── Phases ──────────────────────────────────────────────────────────────

def reset_mission(base: str) -> None:
    """Abort any running mission so the next phase starts from idle."""
    try:
        post_json(base + "/api/control", {"action": "abort"})
    except Exception:
        pass


def phase_assets(base: str, fail: list[str]) -> None:
    print("\n── 1. static assets & read-only APIs ───────────────────────")
    for path, check in (
        ("/", lambda b: b"CUA WebUI" in b),
        ("/app.js", lambda b: b"EventSource" in b),
        ("/style.css", lambda b: b"--accent" in b),
    ):
        try:
            body = get_bytes(base + path)
            ok = check(body)
            print(f"  {'ok ' if ok else 'MISS'} {path:16} {len(body)} B")
            if not ok:
                fail.append(f"{path} served unexpected content")
        except Exception as e:
            fail.append(f"{path} failed: {e}")
            print(f"  MISS {path:16} {e}")

    # /api/hello stays reachable without a session so the SPA can learn which
    # screen to show; every other endpoint must now demand one.
    hello = get_json(base + "/api/hello")
    if hello.get("needs_setup") is not None:
        print("  ok  /api/hello reports setup state")
    else:
        fail.append("/api/hello missing needs_setup")

    for path in ("/api/status", "/api/tools", "/api/settings", "/api/screen",
                 "/api/users", "/api/audit"):
        try:
            body = get_json(base + path)
            print(f"  ok  {path:16} [{', '.join(list(body)[:4])}]")
        except Exception as e:
            fail.append(f"{path} failed: {e}")
            print(f"  MISS {path:16} {e}")

    try:
        tools = get_json(base + "/api/tools")
        total = sum(len(v["tools"]) for v in tools.get("categories", {}).values())
        count = len(tools.get("categories", {}))
        print(f"  ok  tool inventory     {total} tools in {count} categories")
        if total < 24:
            fail.append(f"tool inventory looks short: {total}")
    except Exception:
        pass


def phase_desktop(base: str, fail: list[str]) -> None:
    print("\n── 2. desktop preview ──────────────────────────────────────")
    try:
        frame = get_bytes(base + "/api/desktop.jpg", timeout=60)
        is_jpeg = frame[:2] == b"\xff\xd8"
        print(f"  {'ok ' if is_jpeg else 'MISS'} /api/desktop.jpg  {len(frame)} B")
        if not is_jpeg:
            fail.append("desktop preview did not return a JPEG")
    except Exception as e:
        fail.append(f"/api/desktop.jpg failed: {e}")
        print(f"  MISS /api/desktop.jpg  {e}")


def phase_sse(stream: EventStream, fail: list[str]) -> None:
    print("\n── 3. SSE stream ───────────────────────────────────────────")
    event = stream.wait_for(lambda e: e.get("type") == "status", timeout=25)
    print(f"  {'ok ' if event else 'MISS'} status event over /api/events")
    if not event:
        fail.append("no events received over SSE")


def phase_mission(base: str, stream: EventStream, fail: list[str], use_ocr: bool) -> None:
    print("\n── 4. mission: perception + mouse + shell (frozen) ─────────")
    marker = Path(tempfile.gettempdir()) / "cua_pkg_echo.txt"
    if marker.exists():
        marker.unlink()

    steps = [
        # Object detection — where a missing torchvision kernel would show up
        # as "operator torchvision::nms does not exist".
        {"tool_calls": [
            {"name": "LoadSkillCategory", "arguments": {"category": "screen_capture"}},
            {"name": "ScreenCaptureAction_DetectObjects",
             "arguments": {"confidence_threshold": 0.4}},
        ]},
        {"content": "Detected objects on screen."},
        # Cursor position — pyautogui imported inside the bundle.
        {"tool_calls": [
            {"name": "LoadSkillCategory", "arguments": {"category": "mouse"}},
            {"name": "MouseAction_GetPosition", "arguments": {}},
        ]},
        {"content": "Read the cursor position."},
    ]
    if use_ocr:
        steps += [
            {"tool_calls": [
                {"name": "LoadSkillCategory", "arguments": {"category": "screen_capture"}},
                {"name": "ScreenCaptureAction_CaptureScreen", "arguments": {}},
            ]},
            {"content": "Read the screen text."},
        ]
    steps += [
        # A real command; the mock auditor passes it.
        {"tool_calls": [
            {"name": "LoadSkillCategory", "arguments": {"category": "shell"}},
            {"name": "ShellAction_RunShell", "arguments": {
                "ShellCode": f'echo package-ok > "{marker}"',
                "Explanation": "write a marker file to prove the shell path works",
            }},
        ]},
        {"content": "Ran the marker command."},
        # Statically blocked — must never reach the auditor.
        {"tool_calls": [
            {"name": "LoadSkillCategory", "arguments": {"category": "shell"}},
            {"name": "ShellAction_RunShell", "arguments": {
                "ShellCode": "rm -rf /",
                "Explanation": "this must be refused by the static rules",
            }},
        ]},
        {"content": "The destructive command was refused."},
        {"content": "TASK_COMPLETE packaged mission finished."},
    ]

    stream.events.clear()
    status, body = post_json(
        base + "/api/mission",
        {"task": "verify the packaged runtime", "max_steps": 12},
    )
    if status != 200:
        fail.append(f"mission start failed: {status} {body}")
        print(f"  MISS mission start {status}")
        return

    _SERVER.script.queue_steps(steps)
    _SERVER.script.queue_audits([{"dangerous": False, "risk": "safe"}])

    done = stream.wait_for(lambda e: e.get("type") == "run_done", timeout=600)
    if not done:
        fail.append("mission did not finish (no run_done event)")
        print("  MISS run_done never arrived")
        log_file.flush()
        print("  --- exe log tail ---")
        print(log_path.read_text(encoding="utf-8", errors="replace")[-1200:])
        reset_mission(base)
        return
    print(f"  ok  run_done           reason={done.get('reason')} steps={done.get('steps')}")

    results = {e.get("name"): e for e in stream.of("tool_result")}
    for name in ("LoadSkillCategory", "ScreenCaptureAction_DetectObjects",
                 "MouseAction_GetPosition", "ShellAction_RunShell"):
        entry = results.get(name)
        if entry is None:
            fail.append(f"tool_result missing for {name}")
            print(f"  MISS {name}")
            continue
        print(f"  ok  {name:38} ok={entry.get('ok')}  {str(entry.get('result'))[:70]}")

    yolo = results.get("ScreenCaptureAction_DetectObjects")
    if yolo is not None:
        raw = str(yolo.get("result", ""))
        if "nms" in raw or raw.startswith("Error:"):
            fail.append(f"YOLO detection failed inside the bundle: {raw[:200]}")
            print(f"  MISS YOLO: {raw[:150]}")
        else:
            print("  ok  YOLO ran inside the frozen bundle (torchvision kernels present)")

    if use_ocr:
        ocr = results.get("ScreenCaptureAction_CaptureScreen")
        if ocr is None:
            fail.append("no OCR tool result")
        elif not ocr.get("ok"):
            fail.append(f"packaged OCR failed: {str(ocr.get('result'))[:200]}")
            print(f"  MISS OCR: {str(ocr.get('result'))[:150]}")
        else:
            print("  ok  OCR ran inside the frozen bundle (bundled PP-OCR weights)")

    shell_results = [e for e in stream.of("tool_result")
                     if e.get("name") == "ShellAction_RunShell"]
    good = [e for e in shell_results if "SAFETY BLOCK" not in str(e.get("result", ""))]
    blocked = [e for e in shell_results if "SAFETY BLOCK" in str(e.get("result", ""))]

    if good and not marker.exists():
        fail.append("marker file was not created — the shell path is broken")
        print("  MISS marker file missing")
    elif good:
        print(f"  ok  shell executed      {marker.read_text().strip()!r}")

    if not blocked:
        fail.append("'rm -rf /' was not blocked by the static rules")
        print("  MISS destructive command not blocked")
    else:
        print(f"  ok  static block        {str(blocked[0]['result'])[:58]}")


def phase_approval(base: str, stream: EventStream, fail: list[str], approve: bool) -> None:
    label = "approve" if approve else "deny"
    print(f"\n── 5/6. approval bridge ({label}) ─────────────────────────")
    marker = Path(tempfile.gettempdir()) / f"cua_pkg_approval_{label}.txt"
    if marker.exists():
        marker.unlink()

    _SERVER.script.queue_steps([
        {"tool_calls": [
            {"name": "LoadSkillCategory", "arguments": {"category": "shell"}},
            {"name": "ShellAction_RunShell", "arguments": {
                "ShellCode": f'echo approved > "{marker}"',
                "Explanation": "verify the operator approval path",
            }},
        ]},
        {"content": "Handled the approval."},
        {"content": "TASK_COMPLETE approval path checked."},
    ])
    # Flagging it is what puts the question to the operator.
    _SERVER.script.queue_audits([{
        "dangerous": True,
        "risk": "flagged by the test auditor",
        "parts": [{"part": "echo approved", "why": "test fixture"}],
    }])

    reset_mission(base)
    time.sleep(0.5)
    stream.events.clear()
    status, body = post_json(base + "/api/mission", {"task": "approval path", "max_steps": 6})
    if status != 200:
        fail.append(f"approval mission failed to start: {body}")
        print(f"  MISS start {status}")
        return

    pending = None
    deadline = time.time() + 90
    while time.time() < deadline:
        try:
            snap = get_json(base + "/api/status")
            if snap.get("pending"):
                pending = snap["pending"]
                break
        except Exception:
            pass
        time.sleep(0.4)

    if not pending:
        fail.append("the flagged command never asked the operator for a decision")
        print("  MISS no approval request surfaced")
        return
    print(f"  ok  parked on approval  kind={pending.get('kind')}")

    status, _ = post_json(base + "/api/control", {"action": "answer", "approved": approve})
    if status != 200:
        fail.append(f"answering the approval failed: {status}")

    done = stream.wait_for(lambda e: e.get("type") == "run_done", timeout=150)
    if not done:
        fail.append("approval mission did not finish")
        print("  MISS no run_done")
        return

    results = [e for e in stream.of("tool_result") if e.get("name") == "ShellAction_RunShell"]
    if not results:
        fail.append("no shell result in the approval mission")
        return
    result = str(results[0].get("result", ""))

    if approve:
        if "SAFETY BLOCK" in result:
            fail.append(f"approved command was still refused: {result[:160]}")
            print(f"  MISS {result[:110]}")
        elif not marker.exists():
            fail.append("approved command did not actually run")
            print("  MISS marker file missing after approval")
        else:
            print(f"  ok  approved -> ran      {marker.read_text().strip()!r}")
    else:
        if "SAFETY BLOCK" not in result:
            fail.append(f"denied command was not reported as blocked: {result[:160]}")
            print(f"  MISS {result[:110]}")
        elif marker.exists():
            fail.append("denied command executed anyway")
            print("  MISS marker file exists despite denial")
        else:
            print("  ok  denied -> blocked    no marker file created")


def phase_settings(bundle: Path, base: str, fail: list[str]) -> None:
    print("\n── 7. settings persistence ─────────────────────────────────")
    override = bundle / "config_override.json"
    backup = override.read_text(encoding="utf-8") if override.exists() else None

    try:
        status, body = post_json(
            base + "/api/settings",
            {"MAX_STEPS": 33, "LLM_MODEL": "packaged-test-model"},
        )
        if status != 200:
            fail.append(f"settings save failed: {body}")
            print(f"  MISS save {status}")
            return
        if not override.exists():
            fail.append("config_override.json was not written next to the executable")
            print("  MISS override file missing")
            return
        saved = json.loads(override.read_text(encoding="utf-8"))
        print(f"  ok  wrote {override.name}: {saved}")
        if saved.get("MAX_STEPS") != 33:
            fail.append(f"MAX_STEPS not persisted: {saved}")
        if saved.get("LLM_MODEL") != "packaged-test-model":
            fail.append(f"LLM_MODEL not persisted: {saved}")
    finally:
        # Leave the bundle exactly as we found it.
        if backup is not None:
            override.write_text(backup, encoding="utf-8")
        elif override.exists():
            override.unlink()


# ── Runner ──────────────────────────────────────────────────────────────

def main() -> int:
    global _SERVER

    parser = argparse.ArgumentParser(description="Full test of the packaged Computer Use Agent.")
    parser.add_argument("--bundle", default=str(DEFAULT_BUNDLE))
    parser.add_argument("--skip-ocr", action="store_true",
                        help="skip the OCR tool call (saves ~2-3 minutes)")
    args = parser.parse_args()

    bundle = Path(args.bundle)
    exe = bundle / EXE_NAME
    if not exe.is_file():
        print(f"executable not found: {exe}")
        return 1

    size = sum(f.stat().st_size for f in bundle.rglob("*") if f.is_file())
    print(f"bundle: {bundle}  ({size / 1024 ** 3:.2f} GB)")

    _SERVER = MockLLMServer(port=0)
    _SERVER.start()
    print(f"scripted LLM on {_SERVER.base_url}")

    env = dict(os.environ)
    env.update({
        "CUA_LLM_BASE_URL": _SERVER.base_url,
        "CUA_LLM_API_KEY": "test-key",
        "CUA_LLM_MODEL": "mock-model",
        "CUA_WEB_HOST": "127.0.0.1",
        "CUA_WEB_PORT": str(WEB_PORT),
        "CUA_APPROVAL_TIMEOUT": "60",
    })
    base = f"http://127.0.0.1:{WEB_PORT}"

    # Log to a file rather than a pipe. Paddle writes thousands of lines
    # (ReduceMeanCheckIfOneDNNSupport and friends) while loading; an unread
    # pipe fills up and blocks the child, which looks exactly like a hang.
    log_path = Path(tempfile.gettempdir()) / "cua_package_test.log"
    log_file = open(log_path, "w", encoding="utf-8", errors="replace")

    proc = subprocess.Popen(
        [str(exe)], cwd=str(bundle), env=env,
        stdout=log_file, stderr=subprocess.STDOUT,
    )

    failures: list[str] = []
    stream = EventStream(base)
    try:
        if not wait_until_ready(base, proc):
            log_file.flush()
            tail = log_path.read_text(encoding="utf-8", errors="replace")[-2500:]
            print(f"packaged server did not start.\n{tail}")
            return 1
        print("  ok  packaged server up")

        # Everything below is account-gated, so authenticate before the phases.
        sign_in(base)

        stream.start()
        time.sleep(1.0)

        phase_assets(base, failures)
        phase_desktop(base, failures)
        phase_sse(stream, failures)
        phase_mission(base, stream, failures, use_ocr=not args.skip_ocr)
        phase_approval(base, stream, failures, approve=False)
        phase_approval(base, stream, failures, approve=True)
        phase_settings(bundle, base, failures)
    finally:
        stream.stop()
        proc.terminate()
        log_file.close()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
        _SERVER.stop()

    print()
    if failures:
        print("FAILURES:")
        for item in failures:
            print("  x", item)
        return 1
    print("Packaged executable: all checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
