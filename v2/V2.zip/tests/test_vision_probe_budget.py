"""断言视觉探测不会把「token 用光」误判成「不支持图片输入」。

背景（真实故障）：向导对 `deepseek-v4.1-flash` 报「图片输入：不支持」，
并给出「改用文本模型 + 独立 VLM」的建议。实测该模型**支持**视觉——
1x1 红点回 "Pink"、32x32 回 "Red"，都是 HTTP 200。

根因：`probe_vision` 用 max_tokens=32，而这是思维链模型，会先输出
reasoning_content。32 个 token 常常在思考途中就用完 → `finish_reason=length`
且 `content=""` → 探针把「预算不够」当成「没有这个能力」。

这类误判会让人去改一个本来正确的配置，所以断言必须盯住它。

Run:  python tests/test_vision_probe_budget.py
"""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cua import model_probe  # noqa: E402

PASS, FAIL = [], []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok' if ok else FAIL}] {name}" + (f"  {detail}" if detail else ""))


def _msg(content=None, reasoning=None):
    return SimpleNamespace(content=content, reasoning_content=reasoning)


def _resp(content=None, reasoning=None, finish="stop"):
    return SimpleNamespace(
        choices=[SimpleNamespace(message=_msg(content, reasoning), finish_reason=finish)]
    )


def _seen(color="Red"):
    """The pair of answers a *working* vision model gives.

    probe_vision sends two patches (red, then blue) and requires both to be
    named before it claims vision, so a test that wants a "pass" has to script
    two responses now — one per image. Scripting only the first made every
    "should pass" assertion fail with a wrong-colour verdict.
    """
    return [_resp(content=color, finish="stop"), _resp(content="Blue", finish="stop")]


class FakeClient:
    """Records each call's max_tokens and replays a scripted sequence."""

    def __init__(self, script):
        self.script = list(script)
        self.calls: list[dict] = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        if not self.script:
            # Raising beats a benign fallback. An earlier version returned a
            # passing response when the script ran out, which silently turned
            # "the probe retried more times than this test anticipated" into a
            # green run — the extra attempts were spending a fake success.
            raise AssertionError(
                f"FakeClient 的脚本用完了（第 {len(self.calls)} 次调用）——"
                f"补足响应，或确认重试次数是否被改过"
            )
        step = self.script.pop(0)
        if isinstance(step, Exception):
            raise step
        return step


def main() -> int:
    print("=== 1. 截断后重试并放大预算，而不是判成不支持 ===")
    # 第 1 次：思考把预算吃光 → 空 content + finish_reason=length
    # 第 2 次：预算翻倍后正常回答
    cli = FakeClient([
        _resp(content="", reasoning="The image is a solid red colour, so the answer is", finish="length"),
        _resp(content="Pink", reasoning="solid pink", finish="stop"),
        _resp(content="Blue", finish="stop"),
    ])
    ok, detail, ev = model_probe.probe_vision(cli, "deepseek-v4.1-flash")
    check("第 1 次判为需重试（未直接下结论）", len(cli.calls) == 1 or ok)
    check("最终判定为支持", ok, detail)
    check("证据里带回了模型的回答", "Pink" in ev or "红图" in ev, ev)
    check("截断重试 + 双图 = 三次调用", len(cli.calls) == 3, str(len(cli.calls)))
    if len(cli.calls) >= 2:
        first = cli.calls[0]["max_tokens"]
        second = cli.calls[1]["max_tokens"]
        check("第 1 次预算不低于 256（不再是 32）", first >= 256, f"first={first}")
        check("截断后预算翻倍", second == first * 2, f"{first} -> {second}")

    print("\n=== 2. 每次都截断：说明是预算问题，不能宣称「不支持」 ===")
    cli = FakeClient([
        _resp(content="", reasoning="thinking", finish="length")
        for _ in range(model_probe.VISION_ATTEMPTS)
    ])
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("判为失败", ok is False)
    check("文案说的是被截断而不是不支持", "截断" in detail, detail)
    # 注意断言的是「结论」而不是子串：正确文案里恰恰**包含**「不支持图片输入」
    # 这四个字（「……不能据此判定它不支持图片输入」），用子串判断会假红。
    check("结论没有下成「不支持图片输入：…」",
          not detail.startswith("不支持图片输入："), detail)
    check(f"用完了全部 {model_probe.VISION_ATTEMPTS} 次尝试",
          len(cli.calls) == model_probe.VISION_ATTEMPTS, str(len(cli.calls)))
    check("预算逐次翻倍",
          [c["max_tokens"] for c in cli.calls]
          == [256 * (2 ** i) for i in range(model_probe.VISION_ATTEMPTS)],
          str([c["max_tokens"] for c in cli.calls]))

    print("\n=== 3. 一次答对两张图：两张请求，判为支持 ===")
    # 现在必须两张图都说对才通过，所以一次成功的探测是**两次**请求，不是一次。
    cli = FakeClient(_seen("Red"))
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("判为支持", ok, detail)
    check("发了两次请求（红图 + 蓝图）", len(cli.calls) == 2, str(len(cli.calls)))

    print("\n=== 4. 端点明确拒绝图片：保持原样，且不浪费重试 ===")
    err = Exception("Error code: 400 - invalid content type image_url is not supported")
    cli = FakeClient([err])
    ok, detail, _ = model_probe.probe_vision(cli, "text-only")
    check("判为失败", ok is False)
    check("文案指明不支持图片输入", "不支持图片输入" in detail, detail)
    check("不重试", len(cli.calls) == 1, str(len(cli.calls)))

    print("\n=== 4b. 端点嫌探测图太小：是探测的 bug，不是模型不支持 ===")
    # 真实事故的原文。这条 400 里带 invalid_request_error，早先的
    # _is_missing_feature 会把它归类成「能力缺失」，于是模型被判「不支持视觉」，
    # 而真相是探针发了一张 1x1 的图，端点要求面积 > 256px。
    for label, msg in (
        ("面积太小",
         "Error code: 400 - {'error': {'type': 'invalid_request_error', 'message': "
         "'Upstream request failed: [invalid_parameter] Image too small (area=1px), "
         "minimum required area: >256px'}}"),
        ("尺寸不合法",
         "Error code: 400 - {'error': {'type': 'invalid_request_error', "
         "'message': 'invalid image dimensions 1x1'}}"),
    ):
        cli = FakeClient([Exception(msg)])
        ok, detail, _ = model_probe.probe_vision(cli, "m")
        check(f"{label}：判为失败", ok is False)
        check(f"{label}：不说是「不支持图片输入」",
              not detail.startswith("不支持图片输入："), detail[:70])
        check(f"{label}：明确说是探测图本身的问题",
              "探测图片被端点拒绝" in detail and "不代表模型不支持" in detail, detail[:90])
        check(f"{label}：不重试（重试同一张图没有意义）",
              len(cli.calls) == 1, str(len(cli.calls)))

    print("\n=== 4c. 探测图本身必须满足最小面积（防将来改小）===")
    w, h = model_probe.probe_image_size()
    check(f"探针图是 {w}x{h}", (w, h) == (512, 512), f"{w}x{h}")
    check(f"面积 {w*h} > 端点要求的 {model_probe.PROBE_IMAGE_MIN_AREA}",
          w * h > model_probe.PROBE_IMAGE_MIN_AREA, str(w * h))
    check("短边也超过阈值（两种「面积」判读都满足）",
          min(w, h) > model_probe.PROBE_IMAGE_MIN_AREA, str(min(w, h)))
    check("PNG 头可解析（守卫本身能发现格式损坏）",
          isinstance(w, int) and isinstance(h, int))

    print("\n=== 4d. 回答里没读出颜色 -> 不能算「视觉可用」 ===")
    # 两张图都答蓝（同一个词）-> 确定没在看图。
    cli = FakeClient([_resp(content="blue", finish="stop")
                      for _ in range(model_probe.VISION_ATTEMPTS * 2)])
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("没有误判为通过", ok is False)
    check("也没有说成不支持", not detail.startswith("不支持图片输入："), detail[:70])
    cli = FakeClient(_seen("The image is a solid red square"))
    ok, detail, ev = model_probe.probe_vision(cli, "m")
    check("读出红色 -> 判为支持", ok, detail)
    cli = FakeClient(_seen("红色"))
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("中文回答也算读出颜色", ok, detail)

    print("\n=== 5. 空的 content 且没被截断：按「无内容」处理，不谎报能力 ===")
    cli = FakeClient([
        _resp(content="", reasoning=None, finish="stop")
        for _ in range(model_probe.VISION_ATTEMPTS)
    ])
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("判为失败", ok is False)
    check("文案说没有返回内容", "没有返回内容" in detail, detail)
    # 关键：说明它是「没测出来」而不是「不支持」。
    check("文案承认未能确认（不是下结论说不支持）", "未能确认" in detail, detail)

    print("\n=== 5b. 瞬态故障（限流/5xx）重试后成功：不该判成不支持 ===")
    # 这条是本轮回归的靶心：中转站限流很常见，早先一次 429 就会被写进
    # LLM_PROBED_VISION=false，从此控制台一直显示「不支持图片」。
    for label, err in (
        ("429 限流", Exception("Error code: 429 - rate limit exceeded, please retry")),
        ("503 服务不可用", Exception("Error code: 503 - service temporarily unavailable")),
        ("500 上游错误", Exception('500 {"error":{"message":"Upstream request failed"}}')),
    ):
        cli = FakeClient([err] + _seen("Red"))
        ok, detail, ev = model_probe.probe_vision(cli, "m")
        check(f"{label} 重试后判为支持", ok, f"{detail} | {ev}")
        check(f"{label} 失败后重试了（1 次失败 + 2 张图）",
              len(cli.calls) == 3, str(len(cli.calls)))

    print("\n=== 5c. 瞬态故障始终不恢复：判为「未验证」，而不是「不支持」 ===")
    cli = FakeClient([
        Exception("Error code: 429 - rate limit exceeded")
        for _ in range(model_probe.VISION_ATTEMPTS)
    ])
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("判为失败", ok is False)
    check("结论不是「不支持图片输入」",
          not detail.startswith("不支持图片输入："), detail)
    check("文案说明是临时故障且不代表不支持",
          "临时故障" in detail and "不代表该模型不支持图片" in detail, detail)
    check("重试到上限才放弃",
          len(cli.calls) == model_probe.VISION_ATTEMPTS, str(len(cli.calls)))

    print("\n=== 6. 思维链被截断但有 reasoning：算通过并注明 ===")
    # 这个模型确实会思考；只是没留出最终答案的余量。说它「不支持思维链」是错的。
    cli = FakeClient([
        _resp(content="", reasoning="17*23 = 391, so the answer is", finish="length"),
    ])
    ok, detail, ev = model_probe.probe_thinking(cli, "m")
    check("判为通过", ok, detail)
    check("文案注明被截断", "截断" in detail, detail)
    check("证据里有思维链", "391" in ev, ev)

    print("\n=== 7. 视觉预算常量本身 ===")
    check("VISION_MAX_TOKENS 明显大于旧的 32",
          model_probe.VISION_MAX_TOKENS >= 256, str(model_probe.VISION_MAX_TOKENS))
    check("可选探测至少重试 3 次", model_probe.VISION_ATTEMPTS >= 3,
          str(model_probe.VISION_ATTEMPTS))

    print("\n=== 7b. capabilities 是三态：未验证 ≠ 不支持 ===")
    rep = model_probe.ProbeReport(base_url="u", model="m")
    rep.results = [
        model_probe.ProbeResult("tool_calls", "工具调用", True, "", 0, "required"),
        model_probe.ProbeResult("vision", "图片输入", False, "未能确认……", 0,
                                "optional", "", False, True),      # inconclusive
        model_probe.ProbeResult("thinking", "思维链", False, "未测试", 0,
                                "optional", "", True),            # skipped
        model_probe.ProbeResult("tool_results", "工具结果回传", False,
                                "不支持", 0, "required"),
    ]
    caps = rep.capabilities
    check("确定的成功 -> True", caps["tool_calls"] is True)
    check("确定的失败 -> False", caps["tool_results"] is False)
    check("未验证（inconclusive）-> None", caps["vision"] is None, str(caps["vision"]))
    check("未验证（skipped）-> None", caps["thinking"] is None, str(caps["thinking"]))
    check("capability_unknown 认得未验证", rep.capability_unknown("vision"))
    check("capability_unknown 不误判确定的失败",
          not rep.capability_unknown("tool_results"))

    print("\n=== 7c. 未验证不得覆盖此前测得的 True ===")
    # 这是真实事故的收口：限流把 vision 判成 False 并落盘，
    # 而该模型其实每次都能答对，配置从此永久错误。
    unknown = model_probe.ProbeReport(base_url="u", model="m")
    unknown.results = [
        model_probe.ProbeResult("vision", "图片输入", False, "未能确认……", 0,
                                "optional", "", False, True),
        model_probe.ProbeResult("thinking", "思维链", False, "未能确认……", 0,
                                "optional", "", False, True),
    ]
    s = model_probe.suggested_settings("k", "https://e/v1", "m", unknown)
    check("未验证时不写 LLM_PROBED_VISION（保留旧值）",
          "LLM_PROBED_VISION" not in s, str(s.get("LLM_PROBED_VISION")))
    check("未验证时不写 LLM_PROBED_THINKING（保留旧值）",
          "LLM_PROBED_THINKING" not in s, str(s.get("LLM_PROBED_THINKING")))

    yes = model_probe.ProbeReport(base_url="u", model="m")
    yes.results = [
        model_probe.ProbeResult("vision", "图片输入", True, "正常", 0, "optional"),
    ]
    s = model_probe.suggested_settings("k", "https://e/v1", "m", yes)
    check("确定支持时写入 True", s.get("LLM_PROBED_VISION") is True,
          str(s.get("LLM_PROBED_VISION")))

    no = model_probe.ProbeReport(base_url="u", model="m")
    no.results = [
        model_probe.ProbeResult("vision", "图片输入", False,
                                "不支持图片输入：400 ...", 0, "optional"),
    ]
    s = model_probe.suggested_settings("k", "https://e/v1", "m", no)
    check("端点明确拒绝时写入 False", s.get("LLM_PROBED_VISION") is False,
          str(s.get("LLM_PROBED_VISION")))

    print("\n=== 7d. 未验证时 reconcile 说「无法验证」而不是「不支持」 ===")
    conf = model_probe.reconcile(unknown, {"VISION_MODE": "multimodal"})
    vis = [c for c in conf if c["key"] == "VISION_MODE"]
    check("为 vision 上报一条冲突", len(vis) == 1, str(len(vis)))
    if vis:
        check("实际取值是「无法验证」而不是「不支持」",
              vis[0]["actual"] == "无法验证", vis[0]["actual"])
        check("文案说明是临时故障、不代表不支持",
              "临时故障" in vis[0]["explain"] and "不代表" in vis[0]["explain"],
              vis[0]["explain"][:80])
        check("仍可强制保留（不是硬阻断）", vis[0]["fixable"] is True)
        check("严重度不是 blocking", vis[0]["severity"] != "blocking")

    print("\n=== 7e. 未验证的「必需」能力不硬阻断，真拒绝才阻断 ===")
    # 一次限流曾经会把工具调用判成「不支持」并硬锁死保存按钮——
    # 操作者明明有一个能用的模型，却被指去换模型。
    flaky_tool = model_probe.ProbeReport(base_url="u", model="m")
    flaky_tool.results = [
        model_probe.ProbeResult("connectivity", "连通性", True, "", 0, "required"),
        model_probe.ProbeResult("tool_calls", "工具调用", False,
                                "临时故障……未能确认", 0, "required", "", False, True),
    ]
    check("未验证的必需能力不算 blocked", flaky_tool.blocked is False)
    check("capability_unknown 也认必需能力", flaky_tool.capability_unknown("tool_calls"))
    conf = model_probe.reconcile(flaky_tool, {})
    tc = [c for c in conf if c["key"] == "LLM_CAPABILITY"]
    check("仍上报冲突供操作者知情", len(tc) >= 1, str(len(tc)))
    if tc:
        check("说的是「无法验证」", tc[0]["actual"] == "无法验证", tc[0]["actual"])
        check("不是 blocking", tc[0]["severity"] != "blocking")

    rejected = model_probe.ProbeReport(base_url="u", model="m")
    rejected.results = [
        model_probe.ProbeResult("tool_calls", "工具调用", False,
                                "该端点不支持 tools 参数：400 ...", 0, "required"),
    ]
    check("端点明确拒绝时仍硬阻断", rejected.blocked is True)
    check("明确拒绝不标 inconclusive", not rejected.capability_unknown("tool_calls"))

    print("\n=== 7h. 双图判别：分得清「看不懂」和「根本没在看图」 ===")
    # 单张图分不出这两件事：都是「答案不是红色」。这正是 longcat-2.5-preview-free
    # 的情况——它对纯红图答 blue、对蓝图答 Blue/Green，与图片毫无关系，
    # 是真看不到图，而旧探测只能说「未验证」，用户看不懂该不该换模型。
    #
    # 用两只颜色的图：能看图的必须**两张都说对**；两张答同一个词的，必然没在看图。

    # (a) 两张答同一个词 -> 确定「看不到图片」
    cli = FakeClient([_resp(content="Blue", finish="stop"),
                      _resp(content="blue", finish="stop")])
    ok, detail, ev = model_probe.probe_vision(cli, "blind")
    check("两张同答案 -> 判为失败", ok is False)
    check("结论是「看不到图片」而不是含糊的未验证",
          "看不到图片" in detail, detail[:80])
    check("没有误判成通过", ok is not True)
    check("证据里保留了两张图的回答", "红图" in ev and "蓝图" in ev, ev)

    # (b) 两张都说对 -> 支持
    cli = FakeClient([_resp(content="Red", finish="stop"),
                      _resp(content="Blue", finish="stop")])
    ok, detail, ev = model_probe.probe_vision(cli, "seeing")
    check("两张都说对 -> 判为支持", ok, f"{detail} | {ev}")

    # (c) 答案不同但只有一张说对 -> 未验证（可能是色觉命名问题，不能下强结论）
    cli = FakeClient([_resp(content="Blue", finish="stop"),
                      _resp(content="Green", finish="stop")]
                     * model_probe.VISION_ATTEMPTS)
    ok, detail, _ = model_probe.probe_vision(cli, "weak")
    check("只对一张 -> 判为失败", ok is False)
    check("不误判成支持", ok is not True)
    check("也没有下「看不到图片」的强结论",
          "看不到图片" not in detail, detail[:70])
    check("文案是未验证", "未能确认" in detail, detail[:70])

    print("\n=== 7i. 关键回归：猜中一次不得被当作「能看图」 ===")
    # 早先版本只要第二张图的答案里**出现**颜色词就算通过。
    # 一个看不到图的模型随机猜中 blue 就会被记成「支持视觉」——
    # 必须要求**两张都对**，否则等于把瞎猜当能力。
    cli = FakeClient([_resp(content="Red", finish="stop"),
                      _resp(content="Blue", finish="stop"),
                      _resp(content="Blue", finish="stop")])
    ok, detail, ev = model_probe.probe_vision(cli, "lucky")
    check("两张都对才算通过（这里是都对）", ok, f"{detail} | {ev}")
    # 反例：第一张猜中 red、第二张答错。每次尝试都会重发两张，所以要给足脚本。
    cli = FakeClient(
        [_resp(content="red", finish="stop"), _resp(content="green", finish="stop")]
        * model_probe.VISION_ATTEMPTS)
    ok, detail, _ = model_probe.probe_vision(cli, "half-lucky")
    check("只猜中第一张不算通过", ok is False, detail[:70])
    check("而且没被当成确定性结论（只说未验证）",
          "未能确认" in detail, detail[:70])

    print("\n=== 7f. 所有「未验证」路径都必须被标成 inconclusive（守卫）===")
    # 这是本轮最容易再犯的错：文案读起来对，但没落进 _UNKNOWN_MARKERS，
    # 于是一个「没测出来」被当成确定的失败，又被写进配置。
    # 逐条走一遍所有会返回「未验证」的分支，断言 ProbeResult.inconclusive 为真。
    unknown_cases = []

    # (a) 持续限流
    unknown_cases.append(("限流", FakeClient([
        Exception("Error code: 429 - rate limit exceeded")
        for _ in range(model_probe.VISION_ATTEMPTS)
    ])))
    # (b) 每次都被截断
    unknown_cases.append(("截断", FakeClient([
        _resp(content="", reasoning="thinking", finish="length")
        for _ in range(model_probe.VISION_ATTEMPTS)
    ])))
    # (c) 空回复
    unknown_cases.append(("空回复", FakeClient([
        _resp(content="", reasoning=None, finish="stop")
        for _ in range(model_probe.VISION_ATTEMPTS)
    ])))
    # (d) 只答对一张、另一张答别的颜色 -> 分不清是色觉命名问题还是没看图
    unknown_cases.append(("两张不同但没都说对", FakeClient(
        [_resp(content="Red", finish="stop"), _resp(content="Green", finish="stop")]
        * model_probe.VISION_ATTEMPTS)))

    for label, cli in unknown_cases:
        ok, detail, _ = model_probe.probe_vision(cli, "m")
        check(f"{label}：判为失败", ok is False)
        check(f"{label}：文案落进 _UNKNOWN_MARKERS",
              model_probe._transient_detail(detail),
              f"{detail[:70]} | markers={model_probe._UNKNOWN_MARKERS}")

    # 「两张同答案」是**确定**结论（看不到图），刻意**不属于**未验证——
    # 它能确凿地说出结论，把它归进未验证反而丢掉信息。
    cli = FakeClient([_resp(content="Green", finish="stop")] * 6)
    ok, detail, _ = model_probe.probe_vision(cli, "m")
    check("两张同答案：仍是失败", ok is False)
    check("两张同答案：给出确定结论（不落进未验证）",
          not model_probe._transient_detail(detail), detail[:70])
    check("两张同答案：说明了是看不到图片", "看不到图片" in detail, detail[:70])

    print("\n=== 7g. 探测图被端点拒（尺寸）同样可识别（守卫）===")
    # _is_missing_feature 不得把这个 400 吃掉——它带 invalid_request_error。
    size_err = Exception(
        "Error code: 400 - {'error': {'type': 'invalid_request_error', 'message': "
        "'Upstream request failed: [invalid_parameter] Image too small (area=1px), "
        "minimum required area: >256px'}}")
    check("_is_probe_input_error 认得它", model_probe._is_probe_input_error(size_err))
    check("_is_missing_feature 不吃它（否则会误报不支持）",
          not model_probe._is_missing_feature(size_err))
    # 反面：真正的「不支持」仍必须被 _is_missing_feature 认出。
    real = Exception("Error code: 400 - image_url is not supported by this model")
    check("真「不支持」仍被 _is_missing_feature 认出",
          model_probe._is_missing_feature(real))
    check("真「不支持」不算探测图问题", not model_probe._is_probe_input_error(real))

    print("\n=== 8. 真接口冒烟（可选）===")
    # 从环境变量取 key，不写进仓库：CUA_TEST_OPENCODE_KEY=oc_sk_...
    # 缺失就跳过——这条断言的价值在于「能联网时顺手确认一次」，
    # 而不是把密钥固化到测试文件里。
    import os
    key = os.environ.get("CUA_TEST_OPENCODE_KEY", "").strip()
    if key:
        cli = model_probe._client(key, "https://opencode.ai/zen/go/v1", 60.0)
        try:
            ok, detail, ev = model_probe.probe_vision(cli, "deepseek-v4.1-flash")
            check("deepseek-v4.1-flash 实测支持图片输入", ok, f"{detail} | {ev[:60]}")
        except Exception as e:
            check("联网冒烟未执行（网络问题，非代码问题）", True, f"{type(e).__name__}: {e}")
    else:
        print("  （跳过：未设置 CUA_TEST_OPENCODE_KEY）")

    print("\n" + "=" * 60)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print("   FAILED:", f)
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
