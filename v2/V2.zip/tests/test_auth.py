"""Tests for the account-based WebUI authentication.

Run with::

    python tests/test_auth.py

Covers the four properties that matter on a panel which drives a real mouse:

* no account means no access at all (first-run wizard gate)
* passwords are stored hashed, never in the clear
* a session is required, is scoped to a role, and dies on logout
* CSRF and lockout actually hold
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        PASS.append(name)
        print(f"  [ok]   {name}")
    else:
        FAIL.append(f"{name} — {detail}")
        print(f"  [FAIL] {name}  {detail}")


def section(title: str) -> None:
    print(f"\n=== {title} ===")


# ── Unit level: hashing and password policy ───────────────────────────

def test_hashing() -> None:
    from cua import auth

    section("password hashing")
    record = auth.hash_password("correct horse battery")
    check("hash is not the plaintext", "correct horse battery" not in json.dumps(record))
    check("record carries algo + iterations",
          record["algo"] == "pbkdf2_hmac_sha256" and record["iterations"] == auth.PBKDF2_ITERATIONS)
    check("correct password verifies", auth.verify_password("correct horse battery", record))
    check("wrong password rejected", not auth.verify_password("wrong horse battery", record))
    check("empty password rejected", not auth.verify_password("", record))
    check("garbage record rejected", not auth.verify_password("x", {"salt": "zz", "hash": "zz"}))

    # Two accounts with the same password must not share a hash.
    other = auth.hash_password("correct horse battery")
    check("salted per user", other["hash"] != record["hash"])

    weak = auth.hash_password("legacy", iterations=1000)
    check("weak-cost record is flagged for rehash", auth.needs_rehash(weak))
    check("current-cost record needs no rehash", not auth.needs_rehash(record))


def test_password_policy() -> None:
    from cua import auth

    section("password policy")
    check("short rejected", auth.password_problem("abc") is not None)
    check("common rejected", auth.password_problem("password123") is not None)
    check("low variety rejected", auth.password_problem("aaaaaaaaaaaa") is not None)
    check("padded rejected", auth.password_problem(" goodpassword ") is not None)
    check("reasonable accepted", auth.password_problem("Desk-Admin-9271") is None)
    check("strength scores ordered",
          auth.password_strength("aaaaaaaa") < auth.password_strength("Desk-Admin-9271"))


def test_password_generation() -> None:
    from cua import auth

    section("password generation")
    generated = [auth.generate_password() for _ in range(200)]

    check("all unique", len(set(generated)) == 200, f"{len(set(generated))} unique")
    check("default length respected",
          all(len(p) == auth.DEFAULT_GENERATED_LENGTH for p in generated))
    check("every password passes our own policy",
          all(auth.password_problem(p) is None for p in generated))
    check("every password scores full strength",
          all(auth.password_strength(p) == 100 for p in generated))

    # The alphabet omits characters that are easy to confuse when read off a
    # screen or typed by hand, and the quote family that breaks shells.
    forbidden = set("0O1lI\"'`|;")
    check("no visually ambiguous characters",
          not any(set(p) & forbidden for p in generated),
          str(sorted({c for p in generated for c in p if c in forbidden})))

    # A generated credential must not be guessable from its shape.
    check("no password is a single repeated character",
          not any(len(set(p)) < 8 for p in generated))

    # Length is clamped rather than trusted.
    check("short request clamped up", len(auth.generate_password(4)) == auth.MIN_GENERATED_LENGTH)
    check("long request clamped down", len(auth.generate_password(999)) == auth.MAX_GENERATED_LENGTH)
    check("negative request clamped", len(auth.generate_password(-1)) == auth.MIN_GENERATED_LENGTH)

    # Every character class is represented in each password.
    for index, password in enumerate(generated[:50]):
        groups = (
            any(c.islower() for c in password),
            any(c.isupper() for c in password),
            any(c.isdigit() for c in password),
            any(not c.isalnum() for c in password),
        )
        if not all(groups):
            check("all four character classes present", False,
                  f"#{index} {password} missing a class")
            break
    else:
        check("all four character classes present", True)

    # A generated password must not collide with the common-password blacklist.
    check("never lands on a blacklisted password",
          all(p.lower() not in auth.COMMON_PASSWORDS for p in generated))


def test_static_assets_have_real_mimetypes() -> None:
    """Bundled assets must be served with a type a browser will render.

    Flask guesses types from a fixed table, and the formats this panel ships are
    not all in it — .webp resolved to ``application/octet-stream`` here, so the
    login wallpaper returned 200 and still refused to display. Python builds its
    mime table from the system registry on Windows, so this varies by machine;
    the formats the panel actually bundles are registered explicitly.
    """
    section("static asset mimetypes")
    import mimetypes

    from webui import server  # noqa: F401 - importing registers the extras

    client = server.app.test_client()

    checks = [
        ("/style.css", "text/css"),
        ("/app.js", "javascript"),
        ("/", "text/html"),
    ]
    for path, expected in checks:
        res = client.get(path)
        ctype = res.headers.get("Content-Type", "")
        check(f"{path} is served ({expected})",
              res.status_code == 200 and expected in ctype,
              f"{res.status_code} {ctype}")

    # Every bundled image must announce itself as an image.
    img_dir = server.STATIC_DIR / "img"
    if img_dir.is_dir():
        for img in sorted(img_dir.glob("*")):
            res = client.get(f"/img/{img.name}")
            check(f"/img/{img.name} is an image",
                  res.status_code == 200
                  and res.headers.get("Content-Type", "").startswith("image/"),
                  f"{res.status_code} {res.headers.get('Content-Type')}")

    check(".webp is registered",
          mimetypes.guess_type("x.webp")[0] == "image/webp",
          str(mimetypes.guess_type("x.webp")))


def test_remember_me_controls_session_length() -> None:
    """"Keep me signed in" must shorten the session, not only the cookie.

    A cookie that outlives its server-side record buys nothing — validate_session()
    rejects it either way — so shortening only max-age would be theatre while
    looking like a feature.
    """
    section("remember-me session length")
    from webui import server

    # test_http has already initialised the panel, so this block logs in as that
    # admin rather than creating one. Both branches end at a known credential.
    admin = server.app.test_client()
    setup = admin.post("/api/auth/login",
                       json={"username": "admin",
                             "password": "Brand-New-Pass-88"})
    if setup.status_code != 200:
        check("reached an authenticated state", False,
              f"{setup.status_code} {setup.get_data(as_text=True)[:150]}")
        return
    csrf = setup.get_json()["csrf"]

    # Long session.
    long_client = server.app.test_client()
    r1 = long_client.post("/api/auth/login",
                          json={"username": "admin",
                                "password": "Brand-New-Pass-88",
                                "remember": True})
    check("remember=true accepted", r1.status_code == 200, r1.get_data(as_text=True)[:150])
    expires_long = r1.get_json().get("expires_in", 0)

    # Short session.
    short_client = server.app.test_client()
    r2 = short_client.post("/api/auth/login",
                           json={"username": "admin",
                                 "password": "Brand-New-Pass-88",
                                 "remember": False})
    check("remember=false accepted", r2.status_code == 200)
    expires_short = r2.get_json().get("expires_in", 0)

    check("short session is shorter than the long one",
          expires_short < expires_long, f"{expires_short}s vs {expires_long}s")
    check("short session is about an hour",
          3000 <= expires_short <= 3600, f"{expires_short}s")
    check("long session uses the configured TTL",
          expires_long > 3600, f"{expires_long}s")

    # The cookie's Max-Age must agree with the record.
    short_cookie = r2.headers.get("Set-Cookie", "")
    check("short cookie advertises Max-Age=3600",
          "Max-Age=3600" in short_cookie, short_cookie[:120])
    long_cookie = r1.headers.get("Set-Cookie", "")
    check("long cookie does not advertise Max-Age=3600",
          "Max-Age=3600" not in long_cookie, long_cookie[:120])


def test_csrf_boot_paths() -> None:
    """Every authenticated screen must be able to make a POST.

    The wizard's API step is the awkward one: it is shown to a user who is
    already logged in but has never loaded the console. When the SPA booted
    straight into that step it never copied the session's CSRF token out of
    /api/hello, so every form post failed with "CSRF 校验失败" and the only
    visible remedy was a reload.
    """
    section("csrf availability on every boot path")
    from webui import server

    client = server.app.test_client()

    # 1. The very first run: the wizard creates the admin and lands on step 2.
    #    This block reuses the store from test_http, so the setup endpoint may
    #    already be closed; either way the operator ends up logged in with an
    #    unconfigured model, which is the state under test.
    fresh = server.app.test_client()
    res = fresh.post("/api/setup/account",
                     json={"username": "csrf-probe", "password": "Desk-Admin-9271"})
    if res.status_code == 409:
        # Panel already initialised by test_http: log in as that admin instead.
        res = fresh.post("/api/auth/login",
                         json={"username": "admin", "password": "Brand-New-Pass-88"})
    check("reached an authenticated state", res.status_code == 200,
          f"{res.status_code} {res.get_data(as_text=True)[:160]}")
    body = res.get_json()
    if "next" in body:
        check("wizard is told to continue to step 2", body["next"] == "llm",
              str(body["next"]))

    # 2. Reload the page: boot() reads /api/hello, which must expose the token
    #    the API form will need.
    hello = fresh.get("/api/hello").get_json()
    user = hello.get("user") or {}
    check("session is live after reload", hello.get("authenticated") is True)
    check("hello exposes a csrf token", bool(user.get("csrf")))

    # 3. That token alone must be enough — no other page state required.
    probe = {"base_url": "http://127.0.0.1:1/v1", "api_key": "k", "model": "m"}
    with_token = fresh.post("/api/setup/probe", json=probe,
                            headers={"X-CSRF-Token": user["csrf"]})
    check("probe works with hello's csrf alone",
          with_token.status_code == 200, str(with_token.status_code))

    # 4. A wrong token is a 403, distinguishable from an expired session.
    bad = fresh.post("/api/setup/probe", json=probe,
                     headers={"X-CSRF-Token": "wrong"})
    check("wrong csrf is 403", bad.status_code == 403, str(bad.status_code))

    missing = fresh.post("/api/setup/probe", json=probe)
    check("absent csrf is 403", missing.status_code == 403, str(missing.status_code))

    # 5. An expired session is a 401, so the client knows to send the operator
    #    back to the login card rather than showing a CSRF message.
    server.store.drop_all_sessions()
    expired = fresh.post("/api/setup/probe", json=probe,
                         headers={"X-CSRF-Token": user["csrf"]})
    check("expired session is 401", expired.status_code == 401, str(expired.status_code))
    payload = expired.get_json()
    check("401 tells the client it is unauthenticated",
          payload.get("authenticated") is False)


def test_generation_endpoint() -> None:
    section("generation endpoint (http)")
    from webui import server

    client = server.app.test_client()

    # The first-run wizard asks for a password *before* any account exists, so
    # generation must work without a session — otherwise setup deadlocks:
    # you cannot log in until you set a password, and you cannot set one until
    # you can reach this endpoint.
    anon = server.app.test_client()
    res = anon.get("/api/auth/password/generate")
    check("anonymous generate allowed (wizard step 1 needs it)",
          res.status_code == 200, str(res.status_code))
    anon_pw = res.get_json().get("password", "")
    check("anonymous response carries a usable password",
          len(anon_pw) >= 12 and auth_problem(anon_pw) is None, f"len={len(anon_pw)}")

    # Nothing secret is disclosed, so the audit log must not be inflateable by
    # anonymous callers.
    audit_file = Path(server.store.audit_path)
    logged = audit_file.exists() and "password.generate" in audit_file.read_text(encoding="utf-8")
    check("anonymous generate is not audited", not logged)

    # test_http ends by changing the password, which revokes every session for
    # that user — including the cookie this client is holding. Sign in again
    # before testing an endpoint that requires a live session.
    relog = client.post("/api/auth/login", json={
        "username": "admin", "password": "Brand-New-Pass-88",
    })
    if relog.status_code != 200:
        check("re-login for generation tests", False,
              f"{relog.status_code} {relog.get_data(as_text=True)[:200]}")
        return
    check("re-login for generation tests", True)

    body = client.get("/api/auth/password/generate").get_json()
    password = body.get("password", "")

    audit_after = Path(server.store.audit_path).read_text(encoding="utf-8")
    check("authenticated generate is audited", "password.generate" in audit_after)
    check("generate returns a password", len(password) >= 12, f"len={len(password)}")
    check("returned password passes policy",
          auth_problem(password) is None, str(auth_problem(password)))
    check("response reports strength", body.get("strength") == 100, str(body.get("strength")))
    check("response reports length", body.get("length") == len(password))

    # Two calls must not agree — a fixed password would be a catastrophic bug.
    second = client.get("/api/auth/password/generate").get_json()["password"]
    check("successive calls differ", password != second)

    # Custom length is honoured and clamped.
    short = client.get("/api/auth/password/generate?length=8").get_json()["password"]
    check("short length clamped", len(short) == 12, f"len={len(short)}")
    long_pw = client.get("/api/auth/password/generate?length=40").get_json()["password"]
    check("long length honoured", len(long_pw) == 40, f"len={len(long_pw)}")
    junk = client.get("/api/auth/password/generate?length=abc").get_json()["password"]
    check("garbage length falls back to default", len(junk) == 20, f"len={len(junk)}")

    # A generated password must actually work for the account it was made for.
    from cua import config

    original = config.LLM_API_KEY
    config.LLM_API_KEY = password
    try:
        from cua import auth as auth_mod

        record = auth_mod.hash_password(password)
        check("generated password verifies against a hash",
              auth_mod.verify_password(password, record))
    finally:
        config.LLM_API_KEY = original


def auth_problem(password: str):
    from cua import auth

    return auth.password_problem(password)


# ── Store level ───────────────────────────────────────────────────────

def make_store(tmp: Path, **kw):
    from cua import auth

    kw.setdefault("session_ttl", 3600)
    return auth.UserStore(
        store_path=tmp / "users.json",
        audit_path=tmp / "audit.log",
        **kw,
    )


def test_store_basics(tmp: Path) -> None:
    from cua import auth

    section("account store")
    store = make_store(tmp)
    check("fresh store needs setup", store.needs_setup)

    admin = store.create_user("admin", "Desk-Admin-9271", "admin")
    check("no longer needs setup", not store.needs_setup)
    check("password hashed at rest", admin.password["algo"] == "pbkdf2_hmac_sha256")

    raw = (tmp / "users.json").read_text(encoding="utf-8")
    check("no plaintext password on disk", "Desk-Admin-9271" not in raw)

    store.create_user("op", "Operator-Pass-31", "operator")
    store.create_user("watcher", "Watcher-Pass-77", "viewer")
    check("three accounts", len(store.users) == 3)

    # Duplicate names, case-insensitively.
    try:
        store.create_user("ADMIN", "Another-Pass-91", "admin")
        check("duplicate rejected", False, "no error raised")
    except ValueError:
        check("duplicate rejected", True)

    # Roles gate capabilities.
    check("admin can control", store.can(store.get("admin"), "control"))
    check("admin can administer", store.can(store.can and store.get("admin"), "admin"))
    check("operator can control", store.can(store.get("op"), "control"))
    check("operator cannot administer", not store.can(store.get("op"), "admin"))
    check("viewer cannot control", not store.can(store.get("watcher"), "control"))
    check("viewer can view", store.can(store.get("watcher"), "view"))

    # Last-admin protection.
    try:
        store.delete_user("admin")
        check("last admin protected", False, "delete succeeded")
    except ValueError as e:
        check("last admin protected", "管理员" in str(e), str(e))

    store.create_user("admin2", "Second-Admin-55", "admin")
    store.delete_user("admin")
    check("second admin deletable", store.get("admin") is None)
    check("panel still has an admin", not store.needs_setup)

    # Disabled account cannot log in.
    store.set_disabled("op", True)
    try:
        store.authenticate("op", "Operator-Pass-31", "1.2.3.4")
        check("disabled cannot log in", False, "login succeeded")
    except ValueError:
        check("disabled cannot log in", True)
    store.set_disabled("op", False)

    # Persistence across a reload.
    reloaded = make_store(tmp)
    check("accounts survive reload", len(reloaded.users) == 3)
    check("reload keeps login working",
          reloaded.authenticate("watcher", "Watcher-Pass-77", "1.2.3.4").user == "watcher")


def test_sessions(tmp: Path) -> None:
    from cua import auth

    section("sessions")
    store = make_store(tmp)
    store.create_user("admin", "Desk-Admin-9271", "admin")
    store.create_user("watcher", "Watcher-Pass-77", "viewer")

    session = store.authenticate("admin", "Desk-Admin-9271", "10.0.0.5", "UA/1")
    check("token resolves", store.validate_session(session.token) is not None)
    check("bogus token rejected", store.validate_session("nope") is None)
    check("empty token rejected", store.validate_session("") is None)
    check("session carries role", session.role == "admin")

    # CSRF.
    check("csrf token accepted", store.validate_csrf(session, session.csrf))
    check("wrong csrf rejected", not store.validate_csrf(session, "wrong"))
    check("missing csrf rejected", not store.validate_csrf(session, None))
    check("csrf without session rejected", not store.validate_csrf(None, "x"))

    # Logout revokes for real.
    store.logout(session.token)
    check("token dead after logout", store.validate_session(session.token) is None)

    # Password change revokes live sessions.
    s2 = store.authenticate("watcher", "Watcher-Pass-77", "10.0.0.6")
    store.set_password("watcher", "Fresh-Pass-2024")
    check("password change revokes sessions", store.validate_session(s2.token) is None)

    # Re-roling invalidates the session too.
    s3 = store.authenticate("watcher", "Fresh-Pass-2024", "10.0.0.7")
    store.set_role("watcher", "operator")
    check("role change revokes session", store.validate_session(s3.token) is None)

    # Expiry.
    expiring = make_store(tmp, session_ttl=-1)
    expiring.create_user("a", "Desk-Admin-9271", "admin")
    s4 = expiring.authenticate("a", "Desk-Admin-9271", "1.1.1.1")
    check("expired session rejected", expiring.validate_session(s4.token) is None)

    # Revoking everything.
    store2 = make_store(tmp)
    store2.create_user("x", "Desk-Admin-9271", "admin")
    t1 = store2.authenticate("x", "Desk-Admin-9271", "1.1.1.1")
    t2 = store2.authenticate("x", "Desk-Admin-9271", "1.1.1.2")
    check("revoke-all drops every session", store2.drop_all_sessions() == 2)
    check("revoked tokens dead",
          store2.validate_session(t1.token) is None and store2.validate_session(t2.token) is None)


def test_lockout(tmp: Path) -> None:
    from cua import auth

    section("lockout")
    store = make_store(tmp, max_attempts=3, lockout_seconds=2)
    store.create_user("target", "Desk-Admin-9271", "admin")

    for i in range(3):
        try:
            store.authenticate("target", "wrong-password", "9.9.9.9")
        except ValueError:
            pass
    check("locked after max attempts", store.lockout_state("target", "9.9.9.9")["locked"])

    # Even the *right* password is refused while locked.
    try:
        store.authenticate("target", "Desk-Admin-9271", "9.9.9.9")
        check("correct password refused while locked", False, "login succeeded")
    except ValueError as e:
        check("correct password refused while locked", "尝试过多" in str(e), str(e))

    # The lock expires on its own.
    time.sleep(2.1)
    check("lock expires", not store.lockout_state("target", "9.9.9.9")["locked"])
    check("login works after lock", store.authenticate("target", "Desk-Admin-9271", "9.9.9.9"))

    # An IP-wide lock catches spraying many accounts from one host.
    store2 = make_store(tmp, max_attempts=3, lockout_seconds=2)
    for n in ("u1", "u2", "u3"):
        store2.create_user(n, "Desk-Admin-9271", "viewer")
    for n in ("u1", "u2", "u3"):
        try:
            store2.authenticate(n, "nope-nope-nope", "6.6.6.6")
        except ValueError:
            pass
    check("ip-wide lock trips", store2.lockout_state("u1", "6.6.6.6")["locked"])

    # Unknown users cost the same CPU as known ones (no existence oracle).
    store3 = make_store(tmp, max_attempts=99)
    try:
        store3.authenticate("ghost", "whatever-long-enough", "1.1.1.1")
    except ValueError:
        pass
    check("unknown user gives generic error",
          store3.lockout_state("ghost", "1.1.1.1")["max_attempts"] == 99)


def test_corrupt_file(tmp: Path) -> None:
    from cua import auth

    section("damaged account file")
    sub = tmp / "corrupt"
    sub.mkdir(parents=True, exist_ok=True)
    (sub / "users.json").write_text("{not valid json", encoding="utf-8")
    store = make_store(sub)
    check("corrupt file does not crash startup", store.needs_setup)
    renamed = list(sub.glob("users.json.corrupt-*"))
    check("corrupt file preserved for repair", len(renamed) == 1, str(list(sub.iterdir())))


def test_audit(tmp: Path) -> None:
    from cua import auth

    section("audit log")
    store = make_store(tmp)
    store.create_user("admin", "Desk-Admin-9271", "admin")
    store.authenticate("admin", "Desk-Admin-9271", "5.5.5.5")
    try:
        store.authenticate("admin", "wrong-one-here", "5.5.5.5")
    except ValueError:
        pass
    store.record("admin", "mission.start", "ok", detail="open chrome")

    entries = store.read_audit()
    actions = [e["action"] for e in entries]
    check("login recorded", "auth.login" in actions)
    check("denied login recorded", "auth.login" in actions)
    check("mission recorded", "mission.start" in actions)

    denied = [e for e in entries if e["outcome"] == "denied"]
    check("denied entries carry a reason", len(denied) >= 1 and denied[0]["detail"])
    check("ip recorded", any(e["ip"] == "5.5.5.5" for e in entries))
    check("no password ever in audit", "Desk-Admin-9271" not in json.dumps(entries))


# ── HTTP level: the real Flask app ────────────────────────────────────

def test_http(tmp: Path) -> None:
    from cua import config

    # Point the store at a scratch directory before the server module builds it.
    store_file = tmp / "http" / "users.json"
    audit_file = tmp / "http" / "audit.log"
    store_file.parent.mkdir(parents=True, exist_ok=True)
    config.user_store_path = lambda: store_file
    config.audit_log_path = lambda: audit_file

    from webui import server

    section("http endpoints")
    client = server.app.test_client()
    PASSWORD = "Desk-Admin-9271"

    # --- first run: wizard gate ---
    check("hello reachable unauthenticated", client.get("/api/hello").status_code == 200)
    hello = client.get("/api/hello").get_json()
    check("hello reports needs_setup", hello["needs_setup"] is True)

    for path in ("/api/status", "/api/mission", "/api/settings", "/api/users"):
        code = client.get(path).status_code if path in ("/api/status", "/api/settings", "/api/users") \
            else client.post(path, json={}).status_code
        check(f"{path} blocked before setup", code in (401, 503), f"got {code}")

    # --- setup wizard ---
    bad = client.post("/api/setup/account", json={"username": "admin", "password": "short"})
    check("weak setup password rejected", bad.status_code == 400, bad.get_data(as_text=True))

    good = client.post("/api/setup/account", json={"username": "admin", "password": PASSWORD})
    check("setup succeeds", good.status_code == 200, good.get_data(as_text=True))
    csrf = good.get_json()["csrf"]
    check("setup logs the admin straight in", good.headers.get("Set-Cookie", "").find("cua_session") >= 0)

    again = client.post("/api/setup/account", json={"username": "other", "password": "Another-Pass-1"})
    check("setup cannot be replayed", again.status_code == 409)

    # --- authenticated access ---
    me = client.get("/api/auth/me", headers={"X-CSRF-Token": csrf})
    check("session resolves after setup", me.status_code == 200)
    check("admin capabilities present", set(me.get_json()["capabilities"]) == {"view", "control", "admin"})

    check("status ok", client.get("/api/status").status_code == 200)
    check("users list ok", client.get("/api/users").status_code == 200)
    check("audit readable", client.get("/api/audit").status_code == 200)

    # --- CSRF enforcement ---
    no_csrf = client.post("/api/users", json={"username": "x", "password": "Another-Pass-1"})
    check("missing csrf rejected", no_csrf.status_code == 403, str(no_csrf.status_code))
    bad_csrf = client.post("/api/users", json={"username": "x", "password": "Another-Pass-1"},
                           headers={"X-CSRF-Token": "wrong"})
    check("bad csrf rejected", bad_csrf.status_code == 403)

    # --- role separation ---
    made = client.post("/api/users", json={"username": "watch", "password": "Watcher-Pass-77",
                                           "role": "viewer", "must_change": False},
                       headers={"X-CSRF-Token": csrf})
    check("viewer created", made.status_code == 200, made.get_data(as_text=True))

    # Fresh client = no cookie = anonymous.
    viewer = server.app.test_client()
    lr = viewer.post("/api/auth/login", json={"username": "watch", "password": "Watcher-Pass-77"})
    check("viewer login ok", lr.status_code == 200, lr.get_data(as_text=True))
    vcsrf = lr.get_json()["csrf"]

    check("viewer can read status", viewer.get("/api/status").status_code == 200)
    check("viewer can read transcript stream source", viewer.get("/api/tools").status_code == 200)
    check("viewer blocked from settings", viewer.get("/api/settings").status_code == 403)
    check("viewer blocked from user list", viewer.get("/api/users").status_code == 403)
    check("viewer blocked from audit", viewer.get("/api/audit").status_code == 403)
    check("viewer blocked from starting a mission",
          viewer.post("/api/mission", json={"task": "open something"},
                      headers={"X-CSRF-Token": vcsrf}).status_code == 403)
    check("viewer blocked from control",
          viewer.post("/api/control", json={"action": "abort"},
                      headers={"X-CSRF-Token": vcsrf}).status_code == 403)

    # --- logout really revokes ---
    out = viewer.post("/api/auth/logout", headers={"X-CSRF-Token": vcsrf})
    check("logout ok", out.status_code == 200)
    check("cookie cleared on logout", "cua_session=;" in out.headers.get("Set-Cookie", ""))
    check("session dead after logout", viewer.get("/api/status").status_code == 401)

    # --- anonymous is refused everywhere ---
    anon = server.app.test_client()
    check("anon status 401", anon.get("/api/status").status_code == 401)
    check("anon settings 401", anon.get("/api/settings").status_code == 401)
    check("anon SSE stream refused", anon.get("/api/events").status_code == 401)

    # --- static assets ---
    for asset in ("/", "/style.css", "/app.js"):
        check(f"asset {asset} served", client.get(asset).status_code == 200)

    # --- change password drops the session ---
    admin2 = server.app.test_client()
    l2 = admin2.post("/api/auth/login", json={"username": "admin", "password": PASSWORD})
    a2csrf = l2.get_json()["csrf"]
    ch = admin2.post("/api/auth/password",
                     json={"current_password": PASSWORD, "new_password": "Brand-New-Pass-88"},
                     headers={"X-CSRF-Token": a2csrf})
    check("password change ok", ch.status_code == 200, ch.get_data(as_text=True))
    check("cookie cleared after password change",
          "cua_session=;" in ch.headers.get("Set-Cookie", ""))
    check("session revoked by password change", admin2.get("/api/status").status_code == 401)

    wrong = admin2.post("/api/auth/password",
                        json={"current_password": "nope-nope-nope", "new_password": "Another-One-22"},
                        headers={"X-CSRF-Token": a2csrf})
    check("wrong current password rejected", wrong.status_code in (401, 403))

    fresh = server.app.test_client()
    check("new password works", fresh.post("/api/auth/login",
          json={"username": "admin", "password": "Brand-New-Pass-88"}).status_code == 200)
    check("old password no longer works", fresh.post("/api/auth/login",
          json={"username": "admin", "password": PASSWORD}).status_code == 401)

    # --- audit trail captured the interesting parts ---
    log = json.loads("[" + ",".join(
        line for line in audit_file.read_text(encoding="utf-8").splitlines() if line.strip()
    ) + "]")
    actions = [e["action"] for e in log]
    check("setup audited", "auth.setup" in actions or "user.create" in actions)
    check("logins audited", actions.count("auth.login") >= 2)
    check("logout audited", "auth.logout" in actions)
    check("password change audited", "auth.password" in actions)
    check("no plaintext secret in audit", "Brand-New-Pass-88" not in json.dumps(log))

    # --- user file has no plaintext ---
    raw = store_file.read_text(encoding="utf-8")
    check("no plaintext password in users.json", "Brand-New-Pass-88" not in raw)


def main() -> int:
    print("=" * 62)
    print("  WebUI authentication tests")
    print("=" * 62)

    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        test_hashing()
        test_password_policy()
        test_store_basics(tmp / "a")
        test_sessions(tmp / "b")
        test_lockout(tmp / "c")
        test_corrupt_file(tmp)
        test_audit(tmp / "d")
        test_http(tmp)
        test_password_generation()
        test_static_assets_have_real_mimetypes()
        test_remember_me_controls_session_length()
        test_csrf_boot_paths()
        test_generation_endpoint()

    print()
    print("=" * 62)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    if FAIL:
        for f in FAIL:
            print(f"    FAIL: {f}")
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())