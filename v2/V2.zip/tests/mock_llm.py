"""A scripted OpenAI-compatible server for driving the agent without a real model.

The packaged executable talks to whatever endpoint ``CUA_LLM_BASE_URL`` points
at, so tests can steer it by standing up a fake one. Nothing in the product has
to know about it, which means the test exercises the real HTTP path, the real
OpenAI SDK and the real streaming parser rather than a mocked client.

Two kinds of request are served:

* streaming completions — emitted as SSE with tool-call deltas deliberately
  fragmented across chunks, the way real providers send them
* non-streaming completions — used by the shell security audit, which asks for
  a JSON verdict
"""

from __future__ import annotations

import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

AUDIT_MARKER = "security auditor"


class ScriptedLLM:
    """Holds the scripted replies and answers HTTP requests."""

    def __init__(self) -> None:
        self.steps: list[dict] = []          # streaming completions
        self.audits: list[dict] = []         # security-audit verdicts
        self.requests: list[dict] = []       # everything received, for asserts
        self.lock = threading.Lock()

    # ── Script control ────────────────────────────────────────────────
    def queue_steps(self, steps: list[dict]) -> None:
        with self.lock:
            self.steps = list(steps)

    def queue_audits(self, audits: list[dict]) -> None:
        with self.lock:
            self.audits = list(audits)

    def reset(self) -> None:
        with self.lock:
            self.steps = []
            self.audits = []
            self.requests = []

    # ── Request handling ──────────────────────────────────────────────
    def handle(self, body: dict) -> dict:
        """Return the response payload for one request."""
        with self.lock:
            self.requests.append(body)

        messages = body.get("messages") or []
        first_content = ""
        if messages and isinstance(messages[0], dict):
            first_content = str(messages[0].get("content") or "")

        if AUDIT_MARKER in first_content:
            with self.lock:
                audit = self.audits.pop(0) if self.audits else {"dangerous": False}
            return {"kind": "audit", "verdict": audit}

        with self.lock:
            step = self.steps.pop(0) if self.steps else None
        if step is None:
            # Nothing scripted left: end the mission rather than looping.
            step = {"content": "TASK_COMPLETE script exhausted"}
        return {"kind": "chat", "step": step}


def _chunk(model: str, delta: dict, finish_reason: str | None = None) -> str:
    payload = {
        "id": "chatcmpl-mock",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}],
    }
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _split_arguments(arguments: str, size: int = 12) -> list[str]:
    return [arguments[i:i + size] for i in range(0, len(arguments), size)] or [""]


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args: Any) -> None:
        return  # keep test output clean

    def do_POST(self) -> None:  # noqa: N802 - http.server naming
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            body = {}

        try:
            result = self.server.script.handle(body)
        except Exception as exc:  # noqa: BLE001 - surface as a 500 to the client
            self._send_json(500, {"error": f"{type(exc).__name__}: {exc}"})
            return

        if result["kind"] == "audit":
            self._send_json(200, _audit_response(body.get("model", "mock"), result["verdict"]))
            return

        if body.get("stream"):
            self._send_stream(body.get("model", "mock"), result["step"])
            return

        self._send_json(200, _plain_response(body.get("model", "mock"), result["step"]))

    # ── helpers ──────────────────────────────────────────────────────
    def _send_json(self, status: int, payload: dict) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_stream(self, model: str, step: dict) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        def write(text: str) -> None:
            self.wfile.write(text.encode("utf-8"))
            self.wfile.flush()

        tool_calls = step.get("tool_calls") or []
        if step.get("reasoning"):
            write(_chunk(model, {"role": "assistant", "reasoning_content": step["reasoning"]}))

        for index, call in enumerate(tool_calls):
            name = call.get("name", "")
            arguments = json.dumps(call.get("arguments", {}), ensure_ascii=False)
            # First chunk carries id + name, subsequent ones append arguments —
            # mirroring how providers actually fragment these.
            write(_chunk(model, {"role": "assistant", "tool_calls": [
                {"index": index, "id": call.get("id", f"call_{index}"),
                 "type": "function",
                 "function": {"name": name[:4], "arguments": ""}},
            ]}))
            write(_chunk(model, {"tool_calls": [
                {"index": index, "function": {"name": name[4:], "arguments": ""}},
            ]}))
            for piece in _split_arguments(arguments):
                write(_chunk(model, {"tool_calls": [
                    {"index": index, "function": {"arguments": piece}},
                ]}))

        finish = "tool_calls" if tool_calls else "stop"
        if step.get("content"):
            write(_chunk(model, {"role": "assistant", "content": step["content"]}, "stop"))
            write("data: [DONE]\n\n")
            return

        write(_chunk(model, {}, finish))
        write("data: [DONE]\n\n")


def _audit_response(model: str, verdict: dict) -> dict:
    payload = {
        "is_dangerous": bool(verdict.get("dangerous", False)),
        "overall_risk": verdict.get("risk", "safe"),
        "parts": verdict.get("parts", []),
    }
    return {
        "id": "chatcmpl-audit",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": json.dumps(payload)},
            "finish_reason": "stop",
        }],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }


def _plain_response(model: str, step: dict) -> dict:
    message: dict[str, Any] = {"role": "assistant", "content": step.get("content") or ""}
    if step.get("tool_calls"):
        message["tool_calls"] = [
            {
                "id": call.get("id", f"call_{i}"),
                "type": "function",
                "function": {
                    "name": call.get("name", ""),
                    "arguments": json.dumps(call.get("arguments", {}), ensure_ascii=False),
                },
            }
            for i, call in enumerate(step["tool_calls"])
        ]
        message["content"] = None
    return {
        "id": "chatcmpl-mock",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [{"index": 0, "message": message, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }


class MockLLMServer:
    """Runs a ScriptedLLM on a real port."""

    def __init__(self, host: str = "127.0.0.1", port: int = 0) -> None:
        self.script = ScriptedLLM()
        self._http = ThreadingHTTPServer((host, port), _Handler)
        self._http.daemon_threads = True
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)
        # Handlers reach the script through self.server.script.
        self._http.script = self.script  # type: ignore[attr-defined]

    @property
    def port(self) -> int:
        return self._http.server_address[1]

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}/v1"

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._http.shutdown()
        self._http.server_close()
