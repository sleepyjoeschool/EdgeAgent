"""文件夹选择：选择结果不能被 stdout 噪音污染。

真实故障：选完目录后，字段里出现的不是路径，而是一大串
``client connect to port 51053, connfd=4176 ...`` 之类的启动器日志。

根因：子进程把结果写 stdout，而该进程由启动器拉起、**启动器自己的日志也在写
继承来的 stdout**，于是这些行排在路径前面被一起 capture 回来。

修法：结果改走临时文件，stdout 只在文件为空时兜底。
这个测试盯住的就是「有噪音时也必须只拿到路径」。

Run:  python tests/test_pick_folder_result.py
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from webui import server  # noqa: E402

PASS, FAIL = [], []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok' if ok else FAIL}] {name}" + (f"  {detail}" if detail else ""))


def main() -> int:
    print("=== 1. _clean_picked_path：常规路径原样保留 ===")
    for raw, want in [
        ("D:\\Projects\\project", "D:\\Projects\\project"),
        ("D:\\Projects\\with space", "D:\\Projects\\with space"),
        ("D:\\Trail\\", "D:\\Trail\\"),          # 尾部分隔符不该被改写
        ("/home/user/proj", "/home/user/proj"),
        ("C:/ok", "C:/ok"),
        ("  D:\\Padded  ", "D:\\Padded"),        # 只去首尾空白
        ("C:/ok\n", "C:/ok"),
    ]:
        got = server._clean_picked_path(raw)
        check(f"{raw!r} 原样", got == want, f"得到 {got!r}")

    print("\n=== 2. 空值与取消 ===")
    for raw in ["", "   ", "\n", "\t"]:
        check(f"{raw!r} → 空", server._clean_picked_path(raw) == "")

    print("\n=== 3. 噪音必须被拒，而不是当成路径传下去 ===")
    noisy = "client connect to port 51053, connfd=4144\r\nD:\\real\\path"
    check("含 CR/LF 的噪音被拒", server._clean_picked_path(noisy) == "",
          repr(server._clean_picked_path(noisy)))
    check("含 NUL 被拒", server._clean_picked_path("D:\\a\x00b") == "")
    check("含其它控制字符被拒", server._clean_picked_path("D:\\a\x07b") == "")

    print("\n=== 4. 超长输入被截断（不能把整页塞进字段）===")
    long = server._clean_picked_path("x" * 5000)
    check("截断到 4096", len(long) == 4096, str(len(long)))

    print("\n=== 5. 端到端：子进程在 stdout 里刷噪音，仍只能拿到文件里的路径 ===")
    # 复刻真实场景：子进程先往 stdout 写一堆启动器日志，再把真实结果写进
    # CUA_PICK_OUT。产出必须只有路径。
    fd, out_path = tempfile.mkstemp(prefix="cua-pick-test-", suffix=".txt")
    os.close(fd)
    child = (
        "import os, sys\n"
        "sys.stdout.write('client connect to port 51053, connfd=4176 ...' * 5)\n"
        "sys.stdout.write('more launcher noise\\n')\n"
        "with open(os.environ['CUA_PICK_OUT'], 'w', encoding='utf-8') as fh:\n"
        "    fh.write('D:\\\\Projects\\\\my project')\n"
    )
    env = dict(os.environ)
    env["CUA_PICK_OUT"] = out_path
    done = subprocess.run([sys.executable, "-c", child], capture_output=True,
                          text=True, timeout=60, errors="replace", env=env)
    raw_stdout = done.stdout or ""
    from_file = server._read_text_quietly(out_path)
    server._unlink_quietly(out_path)

    check("stdout 确实被污染了（前提成立）", "client connect" in raw_stdout,
          raw_stdout[:60])
    check("从文件读到的是干净路径", from_file == "D:\\Projects\\my project", repr(from_file))
    check("路径里不含噪音", "client connect" not in from_file)

    print("\n=== 6. 文件缺失时 stdout 兜底仍然工作 ===")
    missing = os.path.join(tempfile.gettempdir(), "cua-definitely-absent-9f3a.txt")
    server._unlink_quietly(missing)
    check("缺失文件读成空串（不抛）", server._read_text_quietly(missing) == "")
    done2 = subprocess.run([sys.executable, "-c", "import sys; sys.stdout.write('D:/fallback')"],
                           capture_output=True, text=True, timeout=60, errors="replace")
    check("兜底路径可清洗", server._clean_picked_path(done2.stdout) == "D:/fallback")

    print("\n=== 7. 清理函数不抛异常 ===")
    server._unlink_quietly(missing)          # 不存在
    server._unlink_quietly("")               # 空串
    check("_unlink_quietly 静默", True)

    print("\n" + "=" * 60)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print("   FAILED:", f)
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
