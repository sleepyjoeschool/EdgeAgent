"""Capability-probing tests for the setup wizard.

The wizard's whole value is telling the truth about an endpoint. A probe that
reports a capability the model does not have is worse than no probe at all: the
operator configures a multimodal setup against a text-only model and the failure
only surfaces mid-mission, with a screenshot attached.

So these tests stand up fake servers with *deliberately different* abilities and
assert the probe draws exactly the right conclusion for each:

* a full-featured endpoint      -> everything passes
* no tool calling               -> blocked, and not overridable
* no vision                     -> a fixable conflict, overridable
* vision but no reasoning trace -> a fixable conflict on the thinking flag
* a broken endpoint             -> everything skipped, not silently "failed"

Usage:
    python tests/test_probe.py
"""

from __future__ import annotations

import json
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        PASS.append(name)
        print(f"  [ok]   {name}")
    else:
        FAIL.append(f"{name} — {detail}")
        print(f"  [FAIL] {name}  {detail}")


def section(title: str) -> None:
    print(f"\n=== {title} ===")


# ──────────────────────────────────────────────────────────────────────────

class FakeCapabilities:
    """What the fake model can and cannot do."""

    def __init__(
        self,
        *,
        reachable: bool = True,
        tools: bool = True,
        tool_results: bool = True,
        streaming: bool = True,
        vision: bool = True,
        thinking: bool = True,
        reject_pinned_tool_choice: bool = False,
    ) -> None:
        self.reject_pinned_tool_choice = reject_pinned_tool_choice
        self.reachable = reachable
        self.tools = tools
        self.tool_results = tool_results
        self.streaming = streaming
        self.vision = vision
        self.thinking = thinking
        self.seen: list[dict] = []


def _image_colour(body: dict) -> str:
    """Answer the colour of the image in *body*, like a real vision model.

    The probe discriminates "read the image" from "guessed" by sending two
    patches of different colours and requiring both to be named. A stub that
    returns one fixed colour for any image cannot satisfy that — and that is
    exactly the behaviour of a model which is not looking, so the probe now
    reports "cannot see". Identifying the patch by its bytes keeps the stub
    honest without hardcoding which image is which.
    """
    from cua import model_probe as _mp

    for message in body.get("messages") or []:
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if not isinstance(part, dict) or part.get("type") != "image_url":
                continue
            url = (part.get("image_url") or {}).get("url", "")
            payload = url.split(",", 1)[-1]
            if payload == _mp._PROBE_IMAGE_B64:
                return "Red"
            if payload == _mp._PROBE_IMAGE_B64_ALT:
                return "Blue"
            return "Green"
    return "Red"


def _completion(model: str, content: str, tool_calls: list | None = None,
                reasoning: str | None = None) -> dict:
    message: dict = {"role": "assistant", "content": content}
    if tool_calls:
        message["tool_calls"] = [
            {
                "id": c.get("id", "call_1"),
                "type": "function",
                "function": {
                    "name": c["name"],
                    "arguments": json.dumps(c.get("arguments", {}), ensure_ascii=False),
                },
            }
            for c in tool_calls
        ]
        message["content"] = None
    if reasoning:
        message["reasoning_content"] = reasoning
    return {
        "id": "chatcmpl-fake",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [{"index": 0, "message": message, "finish_reason": "tool_calls" if tool_calls else "stop"}],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args) -> None:
        return

    def do_POST(self) -> None:  # noqa: N802
        caps: FakeCapabilities = self.server.caps
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeError):
            body = {}
        caps.seen.append(body)

        if not caps.reachable:
            self._send(503, {"error": {"message": "service unavailable"}})
            return

        messages = body.get("messages") or []
        has_image = any(
            isinstance(m.get("content"), list)
            and any(p.get("type") == "image_url" for p in m["content"] if isinstance(p, dict))
            for m in messages if isinstance(m, dict)
        )
        has_tool_msg = any(m.get("role") == "tool" for m in messages if isinstance(m, dict))
        wants_tools = bool(body.get("tools"))

        if has_image and not caps.vision:
            self._send(400, {"error": {
                "message": "Invalid_request_error: this model does not support image input",
                "type": "invalid_request_error",
            }})
            return

        if wants_tools and not caps.tools:
            self._send(400, {"error": {
                "message": "Invalid_request_error: 'tools' is not supported by this model",
                "type": "invalid_request_error",
            }})
            return

        # DeepSeek's thinking mode rejects a pinned tool_choice while still
        # supporting tools. Simulated so the probe cannot regress into pinning
        # one and reporting a working model as incapable.
        choice = body.get("tool_choice")
        pinned = isinstance(choice, dict) and choice.get("type") == "function"
        if pinned and caps.thinking and caps.reject_pinned_tool_choice:
            self._send(400, {"error": {
                "message": ("Thinking mode does not support this tool_choice "
                            "(request_id: test)"),
                "type": "invalid_request_error",
            }})
            return

        if has_tool_msg and not caps.tool_results:
            self._send(400, {"error": {
                "message": "Invalid_request_error: role 'tool' is not supported",
                "type": "invalid_request_error",
            }})
            return

        model = body.get("model", "fake")
        stream = bool(body.get("stream"))

        if wants_tools:
            payload = _completion(model, None, tool_calls=[
                {"name": "probe_echo", "arguments": {"value": "p42"}}])
        elif has_image:
            # A vision-capable model must answer the *image*, and the probe
            # sends two different colours and requires both to be named.
            # Replying "Red" to every image (as this stub used to) is exactly
            # the behaviour of a model that is NOT looking — the probe now
            # catches that and reports "cannot see", which turned four
            # assertions red for the right reason. Compare the payload so the
            # stub behaves like a model that reads what it is sent.
            payload = _completion(model, _image_colour(body))
        elif has_tool_msg:
            payload = _completion(model, "The result was echo:x")
        else:
            payload = _completion(
                model, "pong",
                reasoning="Let me think about this carefully." if caps.thinking else None,
            )

        if stream:
            if not caps.streaming:
                self._send(400, {"error": {
                    "message": "Invalid_request_error: streaming is not supported",
                    "type": "invalid_request_error",
                }})
                return
            self._send_stream(model, payload)
            return
        self._send(200, payload)

    def _send(self, status: int, payload: dict) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_stream(self, model: str, payload: dict) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        def chunk(delta: dict, finish: str | None = None) -> str:
            return "data: " + json.dumps({
                "id": "chatcmpl-fake",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
                "choices": [{"index": 0, "delta": delta, "finish_reason": finish}],
            }) + "\n\n"

        message = payload["choices"][0]["message"]
        reasoning = message.get("reasoning_content")
        if reasoning:
            self.wfile.write(chunk({"role": "assistant", "reasoning_content": reasoning}).encode())
        if message.get("content"):
            self.wfile.write(chunk({"role": "assistant", "content": message["content"]}).encode())
        self.wfile.write(chunk({}, "stop").encode())
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


class FakeEndpoint:
    """Runs a FakeCapabilities model on a real port."""

    def __init__(self, caps: FakeCapabilities) -> None:
        self.caps = caps
        self._http = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self._http.daemons = True
        self._http.caps = caps  # type: ignore[attr-defined]
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self._http.server_address[1]}/v1"

    def __enter__(self) -> "FakeEndpoint":
        self._thread.start()
        return self

    def __exit__(self, *_exc) -> None:
        _stop_server(self._http)


def _stop_server(httpd) -> None:
    """Shut a stub server down without waiting on lingering connections.

    ``ThreadingHTTPServer.shutdown()`` blocks until every handler thread
    finishes, and a client that kept its connection alive is enough to hang it.
    The probe client deliberately sends ``Connection: close``, but a socket can
    still be mid-response when the next case tears its server down, so the
    thread pool is drained forcefully afterwards.
    """
    httpd.shutdown()
    httpd.server_close()
    # Anything still running belongs to a socket nobody is waiting on.
    #
    # Guarded by type: ThreadingHTTPServer sets daemon_threads = True, and for
    # that mode socketserver stores the sentinel _NoThreads rather than a list
    # — iterating it raises TypeError and takes the whole suite down at
    # teardown, after the assertions had already run. There is nothing to
    # drain in that mode; the threads are the interpreter's problem now.
    threads = getattr(httpd, "_threads", None)
    if isinstance(threads, list):
        for thread in list(threads):
            if thread.is_alive():
                thread.join(timeout=1.0)


# ── Endpoints that answer 200 with the wrong thing ──────────────────────
#
# The most common real-world failure is not a connection error: it is a proxy
# or gateway that returns HTTP 200 while serving something that is not a
# chat.completion at all. The SDK's parse error then hides the only detail that
# would tell the operator what to fix, so these cases get their own server.

BAD_SHAPE = {"mode": "openai"}


class _BadShapeHandler(BaseHTTPRequestHandler):
    def log_message(self, *_args) -> None:
        return

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length") or 0)
        self.rfile.read(length) if length else None
        mode = BAD_SHAPE["mode"]

        if mode == "html200":
            # A reverse proxy or auth portal answering with a web page.
            body = "<html><head><title>401 Unauthorized</title></head></html>"
            ctype = "text/html; charset=utf-8"
        elif mode == "wrapped":
            # one-api / new-api style envelope.
            self._json(200, {"code": 0, "msg": "ok", "data": {
                "id": "x", "object": "chat.completion",
                "choices": [{"index": 0, "message": {"content": "pong"}}],
            }})
            return
        elif mode == "nochoices":
            self._json(200, {"id": "x", "object": "chat.completion", "model": "m"})
            return
        elif mode == "emptyobject":
            self._json(200, {})
            return
        elif mode == "nullcontent":
            self._json(200, {"id": "x", "object": "chat.completion", "model": "m",
                             "choices": [{"index": 0, "message": {"content": None},
                                          "finish_reason": "stop"}]})
            return
        elif mode == "notjson":
            body = "this is not json at all"
            ctype = "text/plain"
        else:
            self._json(200, {"id": "x", "object": "chat.completion", "model": "m",
                             "choices": [{"index": 0,
                                          "message": {"content": "pong"},
                                          "finish_reason": "stop"}]})
            return

        data = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status: int, payload: dict) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


class BadShapeEndpoint:
    def __init__(self) -> None:
        self._http = ThreadingHTTPServer(("127.0.0.1", 0), _BadShapeHandler)
        self._http.daemon_threads = True
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self._http.server_address[1]}/v1"

    def __enter__(self) -> "BadShapeEndpoint":
        self._thread.start()
        return self

    def __exit__(self, *_exc) -> None:
        _stop_server(self._http)


def test_wrong_shapes_are_explained() -> None:
    """A 200 with the wrong body must name the actual problem.

    The regression this guards: every one of these used to report the same
    useless "响应中没有 message.content", leaving the operator no way to tell a
    proxy login page from an incompatible gateway.
    """
    from cua import model_probe

    section("200-with-wrong-body responses")
    expectations = [
        ("html200", ["网页", "Base URL"]),
        ("wrapped", ["包装", "不兼容"]),
        ("nochoices", ["不是 chat.completion"]),
        ("emptyobject", ["不是 chat.completion"]),
        ("notjson", ["不是合法 JSON"]),
        ("nullcontent", ["content"]),
    ]

    with BadShapeEndpoint() as ep:
        for mode, needles in expectations:
            BAD_SHAPE["mode"] = mode
            report = model_probe.run_probes(ep.base_url, "k", "m",
                                            include_optional=False, timeout=15)
            conn = report.get("connectivity")
            detail = (conn.detail if conn else "")
            check(f"{mode} reported as a failure", conn is not None and not conn.ok, detail)
            missing = [n for n in needles if n not in detail]
            check(f"{mode} names the real problem", not missing,
                  f"missing {missing} in {detail!r}")
            check(f"{mode} says nothing about message.content being absent"
                  if mode != "nullcontent" else f"{mode} is specific",
                  ("响应中没有 message.content" not in detail) or mode == "nullcontent",
                  detail)

        # The genuine standard response must still pass — the fixes must not
        # have broken the happy path.
        BAD_SHAPE["mode"] = "openai"
        report = model_probe.run_probes(ep.base_url, "k", "m",
                                        include_optional=False, timeout=15)
        check("a correct response still passes", report.get("connectivity").ok,
              report.get("connectivity").detail)


class _ReuseHostileHandler(BaseHTTPRequestHandler):
    """A gateway that breaks on HTTP/1.1 connection reuse.

    Reproduces a real local-gateway bug: the first request on a fresh socket is
    answered correctly, and every subsequent request *on the same socket* is
    rejected with `404 Cannot POST /v1/chat/completions` and an HTML body.

    Against such a server a probe run that reuses one persistent client reports
    "no tool calling, no vision, no thinking" — a complete fabrication caused by
    a transport defect. Requests on separate sockets always succeed.
    """

    def log_message(self, *_args) -> None:
        return

    def setup(self) -> None:
        # Tag the socket, not the request. Counting requests cannot detect
        # reuse, and using id() is a trap: CPython recycles the address of a
        # closed connection, so a brand new socket can inherit the id of a dead
        # one and be misreported as a reuse. Holding a reference to the socket
        # object in a set keeps it alive and makes identity reliable.
        super().setup()
        self.server.sockets_seen.add(self.connection)
        self.server.requests_total = getattr(self.server, "requests_total", 0) + 1

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeError):
            body = {}

        count = self.server.hits_on_socket.get(self.connection, 0)
        self.server.hits_on_socket[self.connection] = count + 1

        if count:
            # Second and later requests on the same socket: this is the bug
            # being simulated.
            html = (b"<!DOCTYPE html>\n<html lang=\"en\"><head><title>Error</title>"
                    b"</head><body><pre>Cannot POST /v1/chat/completions</pre>"
                    b"</body></html>")
            self.send_response(404)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)
            return

        if body.get("stream"):
            # The probe checks stream framing as well as content, so the stub
            # has to emit a well-formed SSE sequence rather than a JSON body.
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            base_chunk = {"id": "x", "object": "chat.completion.chunk", "model": "m"}
            first = dict(base_chunk, choices=[{"index": 0, "delta": {
                "role": "assistant", "content": "pong"}, "finish_reason": None}])
            last = dict(base_chunk, choices=[{"index": 0, "delta": {},
                                              "finish_reason": "stop"}])
            self.wfile.write(f"data: {json.dumps(first)}\n\n".encode())
            self.wfile.write(f"data: {json.dumps(last)}\n\n".encode())
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
            self.close_connection = True
            return

        message = {"role": "assistant", "content": "pong"}
        finish = "stop"
        if body.get("tools"):
            message = {
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": "call_1", "type": "function",
                    "function": {"name": "probe_echo",
                                 "arguments": '{"value": "p42"}'},
                }],
            }
            finish = "tool_calls"

        payload = json.dumps({
            "id": "x", "object": "chat.completion", "model": "m",
            "choices": [{"index": 0, "message": message, "finish_reason": finish}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


class ReuseHostileEndpoint:
    def __init__(self) -> None:
        self._http = ThreadingHTTPServer(("127.0.0.1", 0), _ReuseHostileHandler)
        self._http.daemon_threads = True
        self._http.sockets_seen = set()
        self._http.hits_on_socket = {}
        self._http.requests_total = 0
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self._http.server_address[1]}/v1"

    @property
    def distinct_sockets(self) -> int:
        return len(self._http.sockets_seen)

    @property
    def requests_total(self) -> int:
        return self._http.requests_total

    def __enter__(self) -> "ReuseHostileEndpoint":
        self._thread.start()
        return self

    def __exit__(self, *_exc) -> None:
        _stop_server(self._http)


def test_keepalive_hostile_gateway() -> None:
    """Probing must survive a gateway that 404s on connection reuse.

    The regression: probes 2..N reported missing capabilities because the
    transport silently fell back to reusing one socket. All of them must now
    pass, and the server must confirm each probe arrived on a fresh socket.
    """
    from cua import model_probe

    section("gateway that rejects connection reuse")
    with ReuseHostileEndpoint() as ep:
        report = model_probe.run_probes(ep.base_url, "k", "m",
                                        include_optional=False, timeout=20)
        # Read the counters while the server is still running; the connection
        # log is only meaningful before shutdown clears it.
        distinct = ep.distinct_sockets
        requests_total = ep.requests_total

    conn = report.get("connectivity")
    check("connectivity survives", conn is not None and conn.ok,
          conn.detail if conn else "missing")
    for key in ("response_shape", "tool_calls", "tool_results"):
        r = report.get(key)
        check(f"{key} not falsified by reuse", r is not None and r.ok,
              r.detail if r else "missing")
    check("report not blocked", not report.blocked)

    # Every probe must have opened its own socket, which is the whole point.
    check("each probe used a fresh socket", distinct >= 4,
          f"{distinct} sockets for {requests_total} requests")


def test_blocked_always_yields_a_conflict() -> None:
    """A blocked report must always carry an actionable conflict.

    Otherwise the wizard renders "无法继续" with nothing to act on — the
    operator is told the endpoint is unusable but not which capability broke,
    and no setting can change the outcome. This happened for real when
    `response_shape` failed but reconcile() only inspected tool calls.
    """
    from cua import model_probe

    section("blocked reports are always actionable")
    caps = report.capabilities if False else None  # placeholder for clarity

    cases = [
        ("no tool calls", FakeCapabilities(tools=False), "LLM_CAPABILITY"),
        ("cannot stream", FakeCapabilities(streaming=False), "RESPONSE_SHAPE"),
        ("rejects tool messages", FakeCapabilities(tool_results=False), "TOOL_RESULTS"),
    ]

    for label, fakecaps, expect_key in cases:
        with FakeEndpoint(fakecaps) as ep:
            rep = model_probe.run_probes(ep.base_url, "k", "m", timeout=30)
        conflicts = model_probe.reconcile(
            rep, {"VISION_MODE": "auto", "LLM_CAPABILITY": "auto"}
        )
        if not rep.blocked:
            check(f"{label}: blocked", False, "report was not blocked")
            continue
        check(f"{label}: blocked", True)
        keys = {c["key"] for c in conflicts}
        check(f"{label}: has an actionable conflict", bool(conflicts),
              f"blocked with {len(conflicts)} conflicts")
        check(f"{label}: names the failing capability ({expect_key})",
              expect_key in keys, f"got {sorted(keys)}")
        check(f"{label}: conflict explains itself",
              all(c["explain"] and len(c["explain"]) > 20 for c in conflicts))


def test_blocked_without_conflicts_is_impossible() -> None:
    """Directly assert the invariant across every shape the fakes can produce."""
    from cua import model_probe

    section("invariant: blocked => at least one conflict")
    shapes = [
        ("all capable", FakeCapabilities()),
        ("no tools", FakeCapabilities(tools=False)),
        ("no stream", FakeCapabilities(streaming=False)),
        ("no tool results", FakeCapabilities(tool_results=False)),
        ("no vision", FakeCapabilities(vision=False)),
        ("unreachable", FakeCapabilities(reachable=False)),
    ]
    for label, fakecaps in shapes:
        with FakeEndpoint(fakecaps) as ep:
            rep = model_probe.run_probes(ep.base_url, "k", "m", timeout=15)
        conflicts = model_probe.reconcile(
            rep, {"VISION_MODE": "auto", "LLM_CAPABILITY": "auto"}
        )
        # Asserted unconditionally, not only when the report happens to be
        # blocked. The conditional form made the assertion count drift with the
        # implementation: when the vision probe stopped treating a missing
        # optional capability as blocking, two of these silently stopped
        # running, so the suite went 131 → 130 with nothing failing — coverage
        # disappearing while the run stayed green.
        check(f"{label}: every report is actionable", len(conflicts) > 0 or not rep.blocked,
              f"blocked with {len(conflicts)} conflicts — wizard dead-ends")


def test_probed_capabilities_are_persisted() -> None:
    """A measured capability must outrank the model-name hint tables.

    The tables can only recognise models somebody thought to list. A gateway
    serving "big-pickle" was reported as vision-capable=False right after the
    wizard had proved it accepts images by sending one — so the console showed
    a capability that contradicted its own probe.
    """
    from cua import config
    from cua import model_probe

    section("probe results feed capability reporting")

    original = (config.LLM_MODEL, config.LLM_CAPABILITY,
                config.LLM_PROBED_VISION, config.LLM_PROBED_THINKING)
    try:
        config.LLM_MODEL = "big-pickle"
        config.LLM_CAPABILITY = "auto"
        config.LLM_PROBED_VISION = None
        config.LLM_PROBED_THINKING = None

        check("unknown model with no measurement is not guessed as vision",
              config.supports_vision_input() is False)

        # A report where vision worked must produce settings that record it.
        caps = FakeCapabilities(vision=True, thinking=True)
        with FakeEndpoint(caps) as ep:
            report = model_probe.run_probes(ep.base_url, "k", "m",
                                            include_optional=True, timeout=30)
        settings = model_probe.suggested_settings("k", ep.base_url, "m", report)
        check("settings record the measured vision support",
              settings.get("LLM_PROBED_VISION") is True, str(settings.get("LLM_PROBED_VISION")))
        check("settings record the measured thinking support",
              settings.get("LLM_PROBED_THINKING") is True)

        # Applying them must flip the reporters.
        for key in ("LLM_PROBED_VISION", "LLM_PROBED_THINKING"):
            config.set_setting(key, settings[key])
        check("vision is reported after the measurement",
              config.supports_vision_input() is True)
        check("thinking is reported after the measurement",
              config.supports_thinking() is True)

        # A negative measurement must stick too.
        caps = FakeCapabilities(vision=False, thinking=False)
        with FakeEndpoint(caps) as ep:
            report = model_probe.run_probes(ep.base_url, "k", "m", timeout=30)
        settings = model_probe.suggested_settings("k", ep.base_url, "m", report)
        for key in ("LLM_PROBED_VISION", "LLM_PROBED_THINKING"):
            config.set_setting(key, settings[key])
        check("a negative vision measurement is honoured",
              config.supports_vision_input() is False)

        # An explicit operator choice still wins over the measurement.
        config.LLM_PROBED_VISION = True
        config.LLM_CAPABILITY = "plain"
        check("explicit LLM_CAPABILITY overrides the measurement",
              config.supports_vision_input() is False)

        # Reasoning and vision are independent. The wizard sets
        # LLM_CAPABILITY=thinking whenever it measures a reasoning trace, so
        # treating that as "no vision" erased a measured capability for every
        # model that does both.
        config.LLM_CAPABILITY = "thinking"
        check("thinking does not erase a measured vision capability",
              config.supports_vision_input() is True)
        config.LLM_PROBED_VISION = True
        config.LLM_PROBED_THINKING = True
        check("a model can be both thinking and vision capable",
              config.supports_thinking() is True
              and config.supports_vision_input() is True)

        config.LLM_CAPABILITY = "vision"
        check("vision does not erase a measured thinking capability",
              config.supports_thinking() is True)
    finally:
        (config.LLM_MODEL, config.LLM_CAPABILITY,
         config.LLM_PROBED_VISION, config.LLM_PROBED_THINKING) = original


def test_tool_choice_is_never_pinned() -> None:
    """The probe must not pin tool_choice, and must survive a server that bans it.

    DeepSeek's thinking mode rejects a pinned function choice outright, even
    though it supports tools perfectly well. The probe used to pin one, so a
    fully capable model was reported as having no tool support at all.
    """
    from cua import model_probe

    section("tool_choice is not pinned")
    caps = FakeCapabilities(thinking=True, reject_pinned_tool_choice=True)
    with FakeEndpoint(caps) as ep:
        client = model_probe._client("k", ep.base_url, 30)

        ok, detail, evidence = model_probe.probe_tool_calls(client, "m")
        check("tool_calls succeeds against a server that bans pinned choices",
              ok, detail)
        check("the dictated argument came back", evidence == '{"value": "p42"}',
              str(evidence))

        # And the report as a whole must not be blocked.
        report = model_probe.run_probes(ep.base_url, "k", "m", timeout=30)
    check("report not blocked", not report.blocked)
    check("tool_calls recorded as working",
          report.capabilities.get("tool_calls") is True)

    conflicts = model_probe.reconcile(report, {"VISION_MODE": "auto",
                                               "LLM_CAPABILITY": "auto"})
    check("no blocking conflict raised", not conflicts,
          str([(c["key"], c["severity"]) for c in conflicts]))


def test_pinned_tool_choice_error_is_not_called_unsupported() -> None:
    """A tool_choice rejection must not be reported as "no tool support"."""
    from cua import model_probe

    section("tool_choice rejection wording")
    check("recognised as a tool_choice problem",
          model_probe._is_tool_choice_error(
              "Thinking mode does not support this tool_choice (request_id: x)"))
    check("plain tools rejection is not",
          not model_probe._is_tool_choice_error(
              "Invalid_request_error: 'tools' is not supported by this model"))


def test_budgets_survive_reasoning_models() -> None:
    """Probe requests need enough tokens for a model that thinks first.

    A 24- or 32-token allowance was fully consumed by big-pickle's reasoning,
    leaving content empty and reading as a broken endpoint.
    """
    from cua import model_probe

    section("token budgets")
    check("connectivity budget is generous",
          model_probe.CONNECTIVITY_MAX_TOKENS >= 1024,
          str(model_probe.CONNECTIVITY_MAX_TOKENS))
    check("general probe budget is non-trivial",
          model_probe.PROBE_MAX_TOKENS >= 256, str(model_probe.PROBE_MAX_TOKENS))
    check("connectivity is retried", model_probe.CONNECTIVITY_RETRIES >= 2)


def test_ocr_availability_has_one_source_of_truth() -> None:
    """The status card and the perception view must agree about OCR.

    PaddleOCR ships in ``vendor/paddle_env`` and is only importable once that
    directory is on ``sys.path``. The status card used to do a bare
    ``import paddleocr`` and therefore reported "missing" on a fully working
    install, while the perception view — which asks ocr_engine, and does the
    path bootstrap — reported ready. Two checks for one fact, disagreeing in
    front of the operator.
    """
    from cua import desktop
    from cua import ocr_engine

    section("ocr availability is consistent")
    backend = desktop.ocr_backend()
    available = ocr_engine.paddle_available()

    check("both checks agree", (backend == "paddleocr") == available,
          f"desktop={backend!r} ocr_engine={available!s}")
    check("dependency_report matches", desktop.dependency_report()["paddleocr"] == available,
          str(desktop.dependency_report()["paddleocr"]))

    # And the perception payload must not contradict the card.
    from cua.executors import describe_perception

    perception = describe_perception()
    ready = perception.get("ocr_ready") == "True"
    if available:
        check("perception reports ready when the library is importable",
              ready or perception.get("ocr_engine") == "http",
              str(perception))


def test_status_specific_hints() -> None:
    from cua import model_probe

    section("HTTP status diagnosis")
    cases = [
        (401, ["API Key"]),
        (404, ["/v1"]),
        (429, ["额度"]),
    ]
    for status, needles in cases:
        detail = model_probe.describe_bad_response(
            json.dumps({"error": {"message": "nope"}}), status, "application/json"
        )
        # describe_bad_response itself does not add provider hints; the caller
        # does. Verify it at least surfaces the body and the status.
        check(f"{status} surfaces the status", str(status) in detail, detail)
        check(f"{status} surfaces the body", "nope" in detail, detail)


def test_network_error_hints() -> None:
    from cua import model_probe

    section("network-level diagnosis")
    # A host that cannot resolve must not look like a model problem.
    report = model_probe.run_probes("http://this-host-does-not-exist.invalid/v1",
                                     "k", "m", include_optional=False, timeout=12)
    conn = report.get("connectivity")
    check("unresolvable host fails", conn is not None and not conn.ok)
    check("unresolvable host is blocked", report.blocked)
    detail = conn.detail if conn else ""
    # Depending on whether a local proxy is present, the failure surfaces either
    # as a transport error or as a 502 the proxy reports on our behalf. Both
    # must name the network rather than blaming the model.
    check("unresolvable host blames the network, not the model",
          any(w in detail for w in ("解析", "无法连接", "resolve", "getaddrinfo",
                                    "Name or service", "网关", "上游")),
          detail)
    check("unresolvable host does not suggest the key is wrong",
          "API Key" not in detail, detail)


# ── Tests ──────────────────────────────────────────────────────────────

def test_url_normalisation() -> None:
    from cua import model_probe

    section("base URL normalisation")
    cases = [
        ("https://api.deepseek.com", "https://api.deepseek.com/v1"),
        ("https://api.deepseek.com/", "https://api.deepseek.com/v1"),
        ("https://api.deepseek.com/v1", "https://api.deepseek.com/v1"),
        ("https://x.co/v1/", "https://x.co/v1"),
        # Someone pastes the full endpoint from the docs.
        ("https://x.co/v1/chat/completions", "https://x.co/v1"),
        ("  ", ""),
    ]
    for raw, expected in cases:
        got = model_probe.normalise_base_url(raw)
        check(f"normalise {raw!r}", got == expected, f"got {got!r}")


def test_full_capability() -> None:
    from cua import model_probe

    section("fully capable endpoint")
    caps = FakeCapabilities()
    with FakeEndpoint(caps) as ep:
        base_url = ep.base_url
        report = model_probe.run_probes(base_url, "key", "smart-model")

    for key in ("connectivity", "response_shape", "tool_calls", "tool_results",
                "vision", "thinking"):
        result = report.get(key)
        check(f"{key} passes", result is not None and result.ok,
              result.detail if result else "missing")

    check("not blocked", not report.blocked)
    check("base url normalised in report", report.base_url.endswith("/v1"))

    conflicts = model_probe.reconcile(report, {"VISION_MODE": "auto", "LLM_CAPABILITY": "auto"})
    check("auto settings raise no conflict", not conflicts, json.dumps(conflicts, ensure_ascii=False))

    suggestion = model_probe.suggested_settings("key", base_url, "smart-model", report)
    check("vision suggested for a vision model", suggestion["VISION_MODE"] == "multimodal",
          str(suggestion))
    check("thinking suggested for a reasoning model",
          suggestion["LLM_CAPABILITY"] == "thinking", str(suggestion))


def test_no_tool_calls_is_blocking() -> None:
    from cua import model_probe

    section("endpoint without tool calling")
    caps = FakeCapabilities(tools=False)
    with FakeEndpoint(caps) as ep:
        report = model_probe.run_probes(ep.base_url, "key", "plain-model")

        tc = report.get("tool_calls")
        check("tool_calls fails", tc is not None and not tc.ok, tc.detail if tc else "missing")
        check("tool_results skipped, not failed",
              "未测试" in (report.get("tool_results").detail or ""))
        check("report blocked", report.blocked)

        conflicts = model_probe.reconcile(report, {"VISION_MODE": "auto",
                                                   "LLM_CAPABILITY": "auto"})
        blocking = [c for c in conflicts if c["severity"] == "blocking"]
        check("a blocking conflict is raised", len(blocking) == 1,
              json.dumps(conflicts, ensure_ascii=False))
        check("blocking conflict is not fixable", blocking and not blocking[0]["fixable"])
        check("blocking conflict names tool calling",
              blocking and blocking[0]["key"] == "LLM_CAPABILITY")

        # Even a forced override must not produce a working-looking config. The
        # endpoint has to change; a setting cannot conjure tool calling.
        try:
            forced = model_probe.apply_intent("key", ep.base_url, "plain-model", report,
                                              {"LLM_CAPABILITY": True})
            check("forcing cannot bypass a missing capability", False,
                  f"apply_intent returned {forced}")
        except ValueError as e:
            check("forcing cannot bypass a missing capability",
                  "必需能力" in str(e), str(e))


def test_no_vision_is_a_soft_conflict() -> None:
    from cua import model_probe

    section("endpoint without vision")
    caps = FakeCapabilities(vision=False)
    with FakeEndpoint(caps) as ep:
        base_url = ep.base_url
        report = model_probe.run_probes(base_url, "key", "text-model")

    vis = report.get("vision")
    check("vision fails", vis is not None and not vis.ok)
    check("vision failure is optional, so not blocking", not report.blocked)

    conflicts = model_probe.reconcile(report, {"VISION_MODE": "multimodal",
                                               "LLM_CAPABILITY": "auto"})
    vision_conflicts = [c for c in conflicts if c["key"] == "VISION_MODE"]
    check("choosing multimodal without vision is flagged", len(vision_conflicts) == 1,
          json.dumps(conflicts, ensure_ascii=False))
    conflict = vision_conflicts[0]
    check("conflict is fixable", conflict["fixable"])
    check("conflict suggests text_vlm", conflict["suggestion"] == "text_vlm")
    check("conflict is not blocking", conflict["severity"] != "blocking")

    # Auto mode must not raise a conflict for the same endpoint — the wizard
    # would otherwise nag about a setting the operator never made.
    auto_conflicts = model_probe.reconcile(report, {"VISION_MODE": "auto",
                                                   "LLM_CAPABILITY": "auto"})
    check("auto mode is silent about missing vision",
          not [c for c in auto_conflicts if c["key"] == "VISION_MODE"],
          json.dumps(auto_conflicts, ensure_ascii=False))

    # Forcing the operator's choice restores multimodal.
    # Vision is an optional capability, so this report is not blocked and the
    # override applies: the operator asked for multimodal, the probe says it
    # will fail, and "keep my setting anyway" means exactly that.
    forced = model_probe.apply_intent("key", base_url, "text-model", report,
                                      {"VISION_MODE": True})
    check("forcing keeps multimodal", forced["VISION_MODE"] == "multimodal", str(forced))

    default = model_probe.apply_intent("key", base_url, "text-model", report, {})
    check("not forcing falls back to text_vlm",
          default["VISION_MODE"] == "text_vlm", str(default))

    # suggested_settings is the wizard's own proposal, and reaches the same
    # conclusion through a different code path.
    suggestion = model_probe.suggested_settings("key", base_url, "text-model", report)
    check("suggestion picks text_vlm",
          suggestion["VISION_MODE"] == "text_vlm", str(suggestion))


def test_no_thinking_is_a_soft_conflict() -> None:
    from cua import model_probe

    section("endpoint without a reasoning trace")
    caps = FakeCapabilities(thinking=False)
    with FakeEndpoint(caps) as ep:
        base_url = ep.base_url
        report = model_probe.run_probes(base_url, "key", "plain-chat")

    th = report.get("thinking")
    check("thinking fails", th is not None and not th.ok, th.detail if th else "missing")
    check("thinking failure does not block setup", not report.blocked)

    conflicts = model_probe.reconcile(report, {"VISION_MODE": "auto",
                                               "LLM_CAPABILITY": "thinking"})
    cap = [c for c in conflicts if c["key"] == "LLM_CAPABILITY"]
    check("asking for thinking on a plain model is flagged", len(cap) == 1,
          json.dumps(conflicts, ensure_ascii=False))
    check("conflict suggests plain", cap and cap[0]["suggestion"] == "plain")
    check("conflict is fixable", cap and cap[0]["fixable"])

    # Only the optional thinking capability is missing, so the report is not
    # blocked and apply_intent must still honour the override — that is the
    # path the wizard's "keep my setting anyway" button takes.
    forced = model_probe.apply_intent("key", base_url, "plain-chat", report,
                                      {"LLM_CAPABILITY": True})
    check("forcing keeps thinking on an unblocked report",
          forced["LLM_CAPABILITY"] == "thinking", str(forced))

    default = model_probe.apply_intent("key", base_url, "plain-chat", report, {})
    check("not forcing falls back to plain",
          default["LLM_CAPABILITY"] == "plain", str(default))


def test_unreachable_endpoint() -> None:
    from cua import model_probe

    section("unreachable endpoint")
    caps = FakeCapabilities(reachable=False)
    with FakeEndpoint(caps) as ep:
        report = model_probe.run_probes(ep.base_url, "key", "any-model")

    conn = report.get("connectivity")
    check("connectivity fails", conn is not None and not conn.ok)
    check("report blocked", report.blocked)
    check("everything else skipped",
          all("未测试" in (r.detail or "") for r in report.results if r.key != "connectivity"),
          str([(r.key, r.detail) for r in report.results]))

    # A dead endpoint must not spin up the other four probes: that would turn a
    # 3-second failure into a 3-minute wait.
    check("only one request was attempted", len(caps.seen) == 1, str(len(caps.seen)))


def test_streaming_failure() -> None:
    from cua import model_probe

    section("endpoint that cannot stream")
    caps = FakeCapabilities(streaming=False)
    with FakeEndpoint(caps) as ep:
        report = model_probe.run_probes(ep.base_url, "key", "half-broken")

    shape = report.get("response_shape")
    check("response_shape fails", shape is not None and not shape.ok, shape.detail if shape else "")
    check("streaming failure blocks setup", report.blocked)
    # The agent streams every chat turn, so this must be a hard stop.
    check("response_shape is a required capability", shape.severity == "required")


def test_tool_result_failure() -> None:
    from cua import model_probe

    section("endpoint that rejects tool messages")
    caps = FakeCapabilities(tool_results=False)
    with FakeEndpoint(caps) as ep:
        report = model_probe.run_probes(ep.base_url, "key", "old-style")

    tr = report.get("tool_results")
    check("tool_results fails", tr is not None and not tr.ok, tr.detail if tr else "missing")
    check("tool_results is required", tr.severity == "required")
    check("report blocked", report.blocked)


def test_missing_vlm_blocks_text_only_setup() -> None:
    from cua import model_probe
    from cua import config

    section("text_vlm with no VLM anywhere")
    caps = FakeCapabilities(vision=False)
    original = (config.VLM_API_KEY, config.VLM_AUTH_KEY, config.VLM_API_URL)
    config.VLM_API_KEY = ""
    config.VLM_AUTH_KEY = ""
    config.VLM_API_URL = ""
    try:
        with FakeEndpoint(caps) as ep:
            report = model_probe.run_probes(ep.base_url, "key", "text-only")
        conflicts = model_probe.reconcile(report, {"VISION_MODE": "text_vlm",
                                                   "LLM_CAPABILITY": "auto"})
        blocking = [c for c in conflicts if c["severity"] == "blocking"]
        check("no vision path at all is blocking", len(blocking) == 1,
              json.dumps(conflicts, ensure_ascii=False))
        check("blocking explains the dead end",
              blocking and "只能依赖 OCR" in blocking[0]["explain"],
              blocking[0]["explain"] if blocking else "")
    finally:
        config.VLM_API_KEY, config.VLM_AUTH_KEY, config.VLM_API_URL = original


def test_empty_inputs() -> None:
    from cua import model_probe

    section("empty input handling")
    report = model_probe.run_probes("", "key", "m")
    check("empty base url fails fast", report.blocked)
    check("only connectivity reported", len(report.results) == 1)

    report = model_probe.run_probes("https://x.co", "key", "  ")
    check("blank model fails fast", report.blocked)

    # A whitespace-only model would otherwise produce a confusing 404 later.
    check("blank model detail is clear",
          "模型 ID" in (report.get("connectivity").detail or ""),
          report.get("connectivity").detail)


def main() -> int:
    print("=" * 62)
    print("  Model capability probe tests")
    print("=" * 62)

    test_url_normalisation()
    test_full_capability()
    test_no_tool_calls_is_blocking()
    test_no_vision_is_a_soft_conflict()
    test_no_thinking_is_a_soft_conflict()
    test_unreachable_endpoint()
    test_streaming_failure()
    test_tool_result_failure()
    test_missing_vlm_blocks_text_only_setup()
    test_empty_inputs()
    test_wrong_shapes_are_explained()
    test_keepalive_hostile_gateway()
    test_blocked_always_yields_a_conflict()
    test_blocked_without_conflicts_is_impossible()
    test_probed_capabilities_are_persisted()
    test_tool_choice_is_never_pinned()
    test_pinned_tool_choice_error_is_not_called_unsupported()
    test_budgets_survive_reasoning_models()
    test_ocr_availability_has_one_source_of_truth()
    test_status_specific_hints()
    test_network_error_hints()

    print()
    print("=" * 62)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    if FAIL:
        for f in FAIL:
            print(f"    FAIL: {f}")
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())