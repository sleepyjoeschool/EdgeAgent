"""VLM 工具必须按**视觉模式**选择后端，而不是永远找独立 VLM。

真实故障：Vision Mode 是 `multimodal`（主模型自己看得见），
`VLM_Action_AnalyzeScreen` 却去要 `VLM_API_KEY`，于是报

    Error: VLM is not configured. Set an API key in Settings → 视觉 → VLM API Key,
    or switch Vision Mode to 'multimodal' and use a vision-capable main model.

同一轮里 `ScreenCaptureAction_CaptureScreenInline` **成功**了——模型确实看得见。
两个工具互相矛盾，模型据此在总结里写下「VLM 功能不可用」，
而这与它自己刚刚成功看到屏幕的事实相反。

根因：执行器无条件走独立 VLM。修法：按模式分流——
  * `multimodal` → 图片挂到主模型自己的对话（inline_vision）
  * `text_vlm`  → 独立 VLM 分析后返回文字
  * `no_vlm`    → 明确说能力已关闭，而不是报配置错误

Run:  python tests/test_vlm_mode_routing.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cua import config, inline_vision  # noqa: E402
from cua.executors import vlm  # noqa: E402

PASS, FAIL = [], []

# 1x1 PNG，给 AnalyzeImage 用
TINY_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8"
    "/58BAwAI/AL+hc2rNAAAAABJRU5ErkJggg=="
)


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok' if ok else FAIL}] {name}" + (f"  {detail}" if detail else ""))


class Ctx:
    """Minimal stand-in for ToolContext: only the parts the executor touches."""

    def __init__(self) -> None:
        self.messages: list[dict] = []

    def check_stop(self) -> None:
        pass


def set_mode(mode: str) -> None:
    config.VISION_MODE = mode


def image_parts(messages: list[dict]) -> list[dict]:
    out = []
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, list):
            out.extend(p for p in content if isinstance(p, dict) and p.get("type") == "image_url")
    return out


def main() -> int:
    original = config.VISION_MODE
    try:
        print("=== 1. multimodal：两个工具都必须把图挂到主模型对话 ===")
        set_mode("multimodal")
        check("模式判定为 inline", inline_vision.is_inline_mode())

        ctx = Ctx()
        out = vlm.execute("VLM_Action_AnalyzeScreen",
                          {"PromptString": "屏幕上有什么？"}, ctx)
        check("AnalyzeScreen 不再报未配置",
              "not configured" not in out and "Error" not in out, out[:80])
        check("AnalyzeScreen 挂上了图片", len(image_parts(ctx.messages)) == 1)
        check("AnalyzeScreen 返回可读确认", "see" in out.lower(), out[:70])

        ctx2 = Ctx()
        out2 = vlm.execute("VLM_Action_AnalyzeImage",
                           {"ImgBase64": TINY_PNG_B64, "PromptString": "这是什么？"}, ctx2)
        check("AnalyzeImage 不再报未配置",
              "not configured" not in out2 and "Error" not in out2, out2[:80])
        check("AnalyzeImage 挂上了图片", len(image_parts(ctx2.messages)) == 1)
        # The declared mime must describe the bytes actually sent. It is not
        # "the input format preserved": normalize_b64 re-encodes through
        # Pillow, which always emits JPEG. A PNG announced as JPEG would be
        # rejected outright by some providers, so test agreement, not format.
        parts2 = image_parts(ctx2.messages)
        url = parts2[0]["image_url"]["url"] if parts2 else ""
        payload = url.split("base64,", 1)[1] if "base64," in url else ""
        check("声明的 mime 与真实字节一致", url.startswith("data:image/jpeg;base64,")
              and payload.startswith("/9j/"), url[:34])

        print("\n=== 2. 空 prompt / 空图片仍要拦住 ===")
        check("AnalyzeScreen 空 prompt 报错",
              vlm.execute("VLM_Action_AnalyzeScreen", {"PromptString": "  "}, Ctx())
              .startswith("Error:"))
        check("AnalyzeImage 空图片报错",
              vlm.execute("VLM_Action_AnalyzeImage",
                          {"ImgBase64": "", "PromptString": "x"}, Ctx())
              .startswith("Error:"))

        print("\n=== 3. 没有对话可挂时必须说清楚，而不是崩掉 ===")
        # Only the messages-less case is real: the engine always passes a ctx,
        # but a ToolContext whose messages were never wired up is a genuine
        # way for this to be reached (a headless run).
        class NoMsgs:
            messages = None
            def check_stop(self):
                pass

        check("messages=None 不抛异常",
              vlm.execute("VLM_Action_AnalyzeScreen", {"PromptString": "x"}, NoMsgs())
              .startswith("Error:"))
        # The message is only useful if it names something that works without
        # a conversation. OCR/YOLO return text and need none.
        no_msg = vlm.execute("VLM_Action_AnalyzeScreen", {"PromptString": "x"}, NoMsgs())
        check("提示指向不需要对话的替代方案",
              "CaptureScreen (OCR)" in no_msg or "DetectObjects" in no_msg, no_msg[:90])

        print("\n=== 4. text_vlm：仍应走独立 VLM，未配置时如实报错 ===")
        set_mode("text_vlm")
        check("模式判定为非 inline", not inline_vision.is_inline_mode())
        ctx3 = Ctx()
        out3 = vlm.execute("VLM_Action_AnalyzeScreen",
                           {"PromptString": "屏幕上有什么？"}, ctx3)
        has_key = bool(((config.VLM_API_KEY or config.VLM_AUTH_KEY) or "").strip())
        if has_key:
            print("  （已配置 VLM Key，跳过未配置断言）")
        else:
            check("未配置 VLM Key 时报未配置", "not configured" in out3, out3[:70])
        check("text_vlm 下不挂图到主模型对话", len(image_parts(ctx3.messages)) == 0)

        print("\n=== 5. 模式取值只有 multimodal / text_vlm 两种 ===")
        # resolve_vision_mode() has no third value, so the executor must not
        # branch on one. Guards against reintroducing a dead 'no_vlm' arm.
        seen = set()
        for raw in ["auto", "multimodal", "text_vlm", "vlm", "inline", "", "garbage"]:
            config.VISION_MODE = raw
            seen.add(config.resolve_vision_mode())
        check("只可能解析出两种模式", seen == {"multimodal", "text_vlm"}, str(sorted(seen)))

        print("\n=== 6. 未知工具名要拒绝 ===")
        check("未知函数报错",
              vlm.execute("VLM_Action_Nope", {}, Ctx()).startswith("Error: unknown"))

        print("\n=== 7. 工具描述必须讲清按模式分流 ===")
        import json
        spec = json.loads(
            (Path(__file__).resolve().parents[1]
             / "prompt-content-json" / "VLM_Action.json").read_text(encoding="utf-8")
        )
        blob = json.dumps(spec, ensure_ascii=False)
        check("描述提到 multimodal 与 text_vlm", "multimodal" in blob and "text_vlm" in blob)
        check("描述说明本人可见（而非独立端点）",
              "your own conversation" in blob or "YOU look at it" in blob)
    finally:
        config.VISION_MODE = original

    print("\n" + "=" * 60)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print("   FAILED:", f)
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
