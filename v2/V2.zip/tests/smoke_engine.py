"""End-to-end smoke test of the agent core against a scripted LLM.

Exercises the parts that are easy to break and hard to eyeball:

* tool-call deltas assembling into complete calls
* meta-tool handling (LoadSkillCategory expands the active schema)
* UUID tagging + filter-on-send deletion satisfying the OpenAI pairing rule
* context stripping between steps
* TASK_COMPLETE termination and stuck detection
* approval bridging (operator says no -> SAFETY BLOCK reaches the model)
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cua import config, llm_client, modes, security_check, tool_loader
from cua.context import ToolContext
from cua.engine import AgentEngine, _filter_deleted, _strip_to_summaries
from cua.runtime import CallbackRuntime

config.LLM_API_KEY = "test-key"
config.MAX_STEPS = 12


class OfflineAudit:
    """Stands in for the real audit call so no network traffic occurs.

    The audit endpoint is unreachable here, which is precisely the case the
    safety policy has to handle deliberately rather than by accident.
    """

    reason = "RuntimeError: no route to api.deepseek.com"

    @staticmethod
    def run_audit(code, explanation):
        return security_check.AuditVerdict(
            dangerous=False, unavailable=True, audit_error=OfflineAudit.reason,
        )


security_check.run_audit = OfflineAudit.run_audit
llm_client.build_llm_client = lambda: (_ for _ in ()).throw(AssertionError("network must be stubbed"))


# ── Mock SDK surface ────────────────────────────────────────────────────

class Delta:
    def __init__(self, content=None, reasoning=None, tool_calls=None):
        self.content = content
        self.reasoning_content = reasoning
        self.tool_calls = tool_calls


class Choice:
    def __init__(self, delta):
        self.delta = delta


class Chunk:
    def __init__(self, delta):
        self.choices = [Choice(delta)]


class EmptyChunk:
    """A chunk that carries no choice at all.

    Real endpoints emit these constantly — the usage-only tail chunk, keep-alive
    frames, gateway "done" events — so the engine has to tolerate them rather
    than assume every chunk has choices[0].
    """

    def __init__(self):
        self.choices = []


class FnDelta:
    def __init__(self, index, call_id=None, name=None, arguments=None):
        self.index = index
        self.id = call_id
        self.function = FnBody(name, arguments)


class FnBody:
    def __init__(self, name=None, arguments=None):
        self.name = name
        self.arguments = arguments


def tool_delta(index, call_id, name, arguments):
    """Tool calls arrive fragmented across chunks in real streams."""
    return Chunk(Delta(tool_calls=[FnDelta(index, call_id, name, arguments)]))


class MockCompletions:
    def __init__(self, script):
        self.script = script
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        index = len(self.calls) - 1
        if index >= len(self.script):
            return iter([Chunk(Delta(content="TASK_COMPLETE script exhausted"))])
        return iter(self.script[index])


class MockClient:
    def __init__(self, script):
        self.chat = self
        self.completions = MockCompletions(script)


# ── Scenarios ───────────────────────────────────────────────────────────

def scenario_multi_step():
    """Two-step mission: load a category, act, summarize, then finish."""
    script = [
        # Step 1, round 1: thinking + LoadSkillCategory (meta tool) alongside content
        [
            Chunk(Delta(reasoning="I should open Notepad first.")),
            tool_delta(0, "call-1", "LoadSkillCategory", '{"cate'),
            tool_delta(0, None, None, 'gory":"shell"}'),
        ],
        # Step 1, round 2: real domain tool + step summary
        [
            tool_delta(0, "call-2", "ShellAction_RunShellAsync",
                       '{"ShellCode":"start \\"\\" notepad","Explanation":"Launch Notepad"}'),
            Chunk(Delta(content="I launched Notepad.")),
        ],
        # Step 2: conclude
        [
            Chunk(Delta(content="TASK_COMPLETE Notepad is open and blank.")),
        ],
    ]
    return MockClient(script)


def scenario_declined_shell():
    """A dangerous command the operator refuses."""
    script = [
        [
            tool_delta(0, "call-1", "ShellAction_RunShell",
                       '{"ShellCode":"rm -rf /","Explanation":"clean up"}'),
            Chunk(Delta(content="SAFETY BLOCK: blocked by static rules.")),
        ],
        [
            Chunk(Delta(content="TASK_COMPLETE Nothing was executed.")),
        ],
    ]
    return MockClient(script)


def scenario_stuck():
    """Three identical summaries must trip the stuck detector."""
    return MockClient([
        [Chunk(Delta(content="I clicked the button."))],
        [Chunk(Delta(content="I clicked the button."))],
        [Chunk(Delta(content="I clicked the button."))],
        [Chunk(Delta(content="I clicked the button."))],
    ])


def scenario_empty_choices():
    """Usage-only chunks interleaved with a normal reply must be skipped."""
    return MockClient([
        [
            Chunk(Delta(content="Opening the app.")),
            EmptyChunk(),
            tool_delta(0, "call-1", "BasicFunction_ReadFromClipboard", "{}"),
            EmptyChunk(),
        ],
        [
            EmptyChunk(),
            Chunk(Delta(content="TASK_COMPLETE clipboard read.")),
            EmptyChunk(),
        ],
    ])


def scenario_unbounded():
    """Four plain steps that finish — used to prove the ceiling is what stops
    a run, not the script running out."""
    return MockClient([
        [Chunk(Delta(content="step one done"))],
        [Chunk(Delta(content="step two done"))],
        [Chunk(Delta(content="step three done"))],
        [Chunk(Delta(content="TASK_COMPLETE all done"))],
    ])


def scenario_no_choices_at_all():
    """A stream that never carries a choice must fail with a readable reason."""
    return MockClient([[EmptyChunk(), EmptyChunk()]])


def scenario_context_management():
    """ListSkillResults, DeleteSkillResult, then verify the pair is filtered."""
    script = [
        [
            tool_delta(0, "c1", "BasicFunction_ReadFromClipboard", "{}"),
        ],
        [
            tool_delta(0, "c2", "ListSkillResults", "{}"),
        ],
        [
            tool_delta(0, "c3", "DeleteSkillResult", '{"uuids":["PLACEHOLDER"]}'),
            Chunk(Delta(content="Dropped the clipboard result.")),
        ],
        [
            Chunk(Delta(content="TASK_COMPLETE Context trimmed.")),
        ],
    ]
    return MockClient(script)


def scenario_cil_desktop_refused():
    """CIL mode: a desktop category load and a bare desktop tool call.

    The second call is the interesting one. It never went through
    LoadSkillCategory, which is exactly the bypass the load-time check alone
    would miss — the schema is a convention, the dispatcher is the guarantee.
    """
    script = [
        [
            tool_delta(0, "c1", "LoadSkillCategory", '{"category":"mouse"}'),
            tool_delta(1, "c2", "ShellAction_RunShell",
                       '{"ShellCode":"dir","Explanation":"List files"}'),
            Chunk(Delta(content="Mouse is unavailable in CIL mode.")),
        ],
        [
            # No load happened for mouse; the model just names the tool anyway.
            tool_delta(0, "c3", "MouseAction_LeftClick",
                       '{"X":100,"Y":100}'),
        ],
        [
            tool_delta(0, "c4", "BasicFunction_ReadFromClipboard", "{}"),
            Chunk(Delta(content="Clipboard is unavailable in CIL mode.")),
        ],
        [
            Chunk(Delta(content="TASK_COMPLETE Stayed on the command line.")),
        ],
    ]
    return MockClient(script)


def scenario_cil_browser_allowed():
    """CIL mode must still load the browser connector.

    Only the *load* is exercised. Actually calling a FullChrome_ tool would
    spawn the real MCP server, which a smoke test must not do — the call-time
    half of "browsing is allowed in CIL" is asserted against the policy
    directly in main() instead.
    """
    script = [
        [
            tool_delta(0, "c1", "LoadSkillCategory", '{"category":"fullchrome"}'),
            Chunk(Delta(content="Browser connector is available in CIL mode.")),
        ],
        [
            Chunk(Delta(content="TASK_COMPLETE Browser tools loaded.")),
        ],
    ]
    return MockClient(script)


# ── Harness ─────────────────────────────────────────────────────────────

class Recorder:
    def __init__(self):
        self.events: list[dict] = []

    def __call__(self, event: dict) -> None:
        self.events.append(event)

    def of(self, kind: str) -> list[dict]:
        return [e for e in self.events if e["type"] == kind]


def run(name, client, use_approvals=False, expected=None, max_steps=8,
        agent_mode="gui"):
    recorder = Recorder()
    runtime = CallbackRuntime() if use_approvals else None
    if use_approvals:
        runtime.approve = lambda req: False  # operator always refuses

    engine = AgentEngine(emit=recorder, runtime=runtime, client=client,
                         agent_mode=agent_mode)
    outcome = engine.run("Do the thing", max_steps=max_steps)

    print(f"\n=== {name} ===")
    print(f"  outcome: finished={outcome.finished} reason={outcome.reason} steps={outcome.steps}")
    print(f"  tool calls   : {[e['name'] for e in recorder.of('tool_call')]}")
    print(f"  tool results : {[(e['name'], e['ok']) for e in recorder.of('tool_result')]}")
    print(f"  summaries    : {recorder.of('step_summary') and [e['text'] for e in recorder.of('step_summary')]}")
    if expected:
        expected(outcome, recorder)
    return outcome, recorder


def main() -> int:
    failures: list[str] = []

    # 1. Multi-step with meta-tool loading --------------------------------
    def check_multi(outcome, recorder):
        if not outcome.finished:
            failures.append("multi: mission did not finish")
        if outcome.steps != 2:
            failures.append(f"multi: expected 2 steps, got {outcome.steps}")
        tools = recorder.of("tool_result")
        if not any(r["name"] == "LoadSkillCategory" for r in tools):
            failures.append("multi: LoadSkillCategory was never executed")
        launched = [r for r in tools if r["name"] == "ShellAction_RunShellAsync"]
        if launched and launched[0]["ok"]:
            failures.append("multi: notepad launch should be blocked without an approval path")

    run("multi-step + meta tool", scenario_multi_step(), expected=check_multi)

    # 2. Declined danger ---------------------------------------------------
    def check_decline(outcome, recorder):
        results = recorder.of("tool_result")
        shell = [r for r in results if r["name"] == "ShellAction_RunShell"]
        if not shell:
            failures.append("decline: shell tool never ran")
            return
        if shell[0]["ok"]:
            failures.append("decline: static rules failed to block 'rm -rf /'")
        if "SAFETY BLOCK" not in shell[0]["result"]:
            failures.append("decline: refusal was not surfaced as SAFETY BLOCK")

    run("static shell block", scenario_declined_shell(), expected=check_decline)

    # 3. Stuck detection ---------------------------------------------------
    def check_stuck(outcome, recorder):
        if outcome.reason != "stuck":
            failures.append(f"stuck: expected reason 'stuck', got '{outcome.reason}'")
        if outcome.steps != 3:
            failures.append(f"stuck: expected to stop at step 3, got {outcome.steps}")

    run("stuck detection", scenario_stuck(), expected=check_stuck)

    # 3b. Chunks without choices ------------------------------------------
    def check_empty_chunks(outcome, recorder):
        if "index out of range" in outcome.reason:
            failures.append(f"empty chunk: stream still indexes choices[0]: {outcome.reason}")
        if not outcome.finished:
            failures.append(f"empty chunk: mission did not finish ({outcome.reason})")
        if outcome.steps != 2:
            failures.append(f"empty chunk: expected 2 steps, got {outcome.steps}")

    run("empty-choices chunks skipped", scenario_empty_choices(), expected=check_empty_chunks)

    def check_no_choices(outcome, recorder):
        if "index out of range" in outcome.reason:
            failures.append(f"no choice: raw IndexError leaked: {outcome.reason}")
        if "no choice chunks" not in outcome.reason:
            failures.append(f"no choice: unhelpful reason '{outcome.reason}'")

    run("stream with no choices", scenario_no_choices_at_all(), expected=check_no_choices)

    # 3c. Step ceiling -----------------------------------------------------
    # The interesting case is not "a limit stops the run" — it is that without
    # one the run keeps going past where the limit would have been.
    def check_ceiling(outcome, recorder):
        if outcome.steps != 2:
            failures.append(f"ceiling: expected to stop at 2 steps, got {outcome.steps}")
        if outcome.reason != "max steps reached":
            failures.append(f"ceiling: unexpected reason '{outcome.reason}'")

    def check_unbounded(outcome, recorder):
        if not outcome.finished:
            failures.append(f"unbounded: did not finish ({outcome.reason})")
        if outcome.steps != 4:
            failures.append(f"unbounded: ran {outcome.steps} steps, expected 4")

    previous_ceiling = config.MAX_STEPS

    run("step ceiling honoured", scenario_unbounded(), max_steps=2,
        expected=check_ceiling)

    # A per-mission override must win over a lower global ceiling.
    config.MAX_STEPS = 2
    run("ceiling disabled per mission", scenario_unbounded(), max_steps=0,
        expected=check_unbounded)

    # ...and switching the ceiling off globally must do the same without any
    # per-mission argument at all.
    config.MAX_STEPS_ENABLED = False
    run("ceiling disabled globally", scenario_unbounded(), max_steps=None,
        expected=check_unbounded)
    config.MAX_STEPS_ENABLED = True
    config.MAX_STEPS = previous_ceiling

    # 4. Context management ------------------------------------------------
    messages = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "orig"},
        {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {"id": "t1", "type": "function", "function": {"name": "A", "arguments": "{}"}},
                {"id": "t2", "type": "function", "function": {"name": "B", "arguments": "{}"}},
            ],
        },
        {"role": "tool", "tool_call_id": "t1", "content": "[UUID:aaa]\nresult A"},
        {"role": "tool", "tool_call_id": "t2", "content": "[UUID:bbb]\nresult B"},
        {"role": "assistant", "content": "summarised once"},
    ]
    filtered = _filter_deleted(messages, {"t1"})
    ids = [m.get("tool_call_id") for m in filtered if m["role"] == "tool"]
    if "t1" in ids:
        failures.append("filter: deleted tool message survived")
    assistant_calls = [
        c["id"]
        for m in filtered if m["role"] == "assistant" and m.get("tool_calls")
        for c in m["tool_calls"]
    ]
    if "t1" in assistant_calls:
        failures.append("filter: assistant still references the deleted tool_call")
    print("\n=== context helpers ===")
    print(f"  surviving tool ids after deleting t1: {ids}")
    print(f"  surviving assistant tool_calls      : {assistant_calls}")

    stripped = _strip_to_summaries(messages, "orig")
    roles = [m["role"] for m in stripped]
    if roles != ["system", "user", "assistant"]:
        failures.append(f"strip: unexpected message set {roles}")
    print(f"  stripped context roles: {roles}")

    # 5. Image-carrying messages survive stripping -------------------------
    image_messages = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "orig"},
        {"role": "assistant", "content": "step one done"},
        {"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,XYZ"}},
        ]},
    ]
    kept = _strip_to_summaries(image_messages, "orig")
    if len(kept) != 4:
        failures.append("strip: inline screenshot was dropped between steps")
    print(f"  image messages preserved: {len(kept)} of 4")

    # 6. Operating-mode policy -------------------------------------------
    # GUI may do everything; CIL may not touch the desktop. Three separate
    # mechanisms have to agree, so each is checked where it actually lives.
    def check_cil_refusals(outcome, recorder):
        if not outcome.finished:
            failures.append(f"cil: mission did not finish ({outcome.reason})")

        results = {r["name"]: r for r in recorder.of("tool_result")}

        load = results.get("LoadSkillCategory")
        if load is None:
            failures.append("cil: LoadSkillCategory never ran")
        elif load["ok"] or "SAFETY BLOCK" not in load["result"]:
            failures.append(
                "cil: loading the 'mouse' category was not refused as a SAFETY BLOCK"
            )

        # The bypass path: never loaded, named directly.
        click = results.get("MouseAction_LeftClick")
        if click is None:
            failures.append("cil: the direct mouse call never reached dispatch")
        elif click["ok"] or "SAFETY BLOCK" not in click["result"]:
            failures.append(
                "cil: a desktop tool called without loading was not refused"
            )

        clip = results.get("BasicFunction_ReadFromClipboard")
        if clip is None:
            failures.append("cil: clipboard call never reached dispatch")
        elif clip["ok"] or "SAFETY BLOCK" not in clip["result"]:
            failures.append("cil: clipboard was not refused in CIL mode")

        # Shell is the point of CIL mode — it must not be caught by the block.
        shell = results.get("ShellAction_RunShell")
        if shell is None:
            failures.append("cil: shell never ran")
        elif "SAFETY BLOCK: category" in shell["result"] or (
            "SAFETY BLOCK: 'ShellAction" in shell["result"]
        ):
            failures.append("cil: shell was refused, which defeats the mode")

        # Every refusal must say what to use instead, or the model has no way
        # to recover inside the step it was blocked in.
        for name in ("MouseAction_LeftClick", "BasicFunction_ReadFromClipboard"):
            entry = results.get(name)
            if entry and "shell" not in entry["result"]:
                failures.append(f"cil: refusal for {name} offered no alternative")

    run("CIL refuses desktop tools", scenario_cil_desktop_refused(),
        agent_mode="cil", max_steps=8, expected=check_cil_refusals)

    def check_cil_browser(outcome, recorder):
        load = [r for r in recorder.of("tool_result")
                if r["name"] == "LoadSkillCategory"]
        if not load:
            failures.append("cil-browser: LoadSkillCategory never ran")
        elif not load[0]["ok"]:
            failures.append(
                f"cil-browser: the browser connector was refused — "
                f"{load[0]['result'][:160]}"
            )

    run("CIL keeps the browser connector", scenario_cil_browser_allowed(),
        agent_mode="cil", max_steps=4, expected=check_cil_browser)

    # Policy surface, checked directly so the rules are pinned independently
    # of how the engine happens to wire them today.
    print("\n=== mode policy ===")
    for category in ("keyboard", "mouse", "screen_capture", "vlm"):
        if modes.category_allowed(category, "cil"):
            failures.append(f"policy: '{category}' should be barred in CIL")
        if not modes.category_allowed(category, "gui"):
            failures.append(f"policy: '{category}' should be allowed in GUI")
    for category in ("shell", "basic", "codemodify", "fullchrome"):
        if not modes.category_allowed(category, "cil"):
            failures.append(f"policy: '{category}' should be allowed in CIL")
    for tool_name in ("BasicFunction_WriteToClipboard",
                      "BasicFunction_ReadFromClipboard"):
        if modes.tool_allowed(tool_name, "cil"):
            failures.append(f"policy: '{tool_name}' should be barred in CIL")
        if not modes.tool_allowed(tool_name, "gui"):
            failures.append(f"policy: '{tool_name}' should be allowed in GUI")
    for tool_name in ("BasicFunction_Wait", "ShellAction_RunShell"):
        if not modes.tool_allowed(tool_name, "cil"):
            failures.append(f"policy: '{tool_name}' should survive CIL")

    # An unknown mode must fall open to GUI: a typo in a request body should
    # not silently strip a mission of the tools it needs. Case and stray
    # whitespace are transport accidents and are forgiven.
    for bad in ("", None, "terminal", 7, "gu i", "cl"):
        if modes.normalize(bad) != "gui":
            failures.append(f"policy: normalize({bad!r}) should be 'gui'")
    for good in (" CIL ", "Cil", "cil\n"):
        if modes.normalize(good) != "cil":
            failures.append(f"policy: normalize({good!r}) should be 'cil'")

    # The executor table must cover every prefix the dispatcher routes on, or
    # a tool slips past the CIL block simply by not being listed.
    from cua import executors
    for prefix, module_name in executors._PREFIX_ROUTES:
        if modes.CATEGORY_EXECUTOR_PREFIXES.get(prefix) != module_name:
            failures.append(
                f"policy: prefix '{prefix}' maps to "
                f"{modes.CATEGORY_EXECUTOR_PREFIXES.get(prefix)!r} in modes but "
                f"routes to {module_name!r} in the dispatcher"
            )
    # Every desktop category's executor must be refused at dispatch time, and
    # every allowed category's executor must not be.
    for category, executor in modes.CATEGORY_EXECUTOR.items():
        expected_allowed = category not in modes.DESKTOP_ONLY_CATEGORIES
        probe = next(
            (p for p, e in modes.CATEGORY_EXECUTOR_PREFIXES.items()
             if e == executor),
            None,
        )
        if probe and modes.tool_allowed(probe + "Anything", "cil") != expected_allowed:
            failures.append(
                f"policy: dispatch of '{probe}*' should be "
                f"{'allowed' if expected_allowed else 'barred'} in CIL "
                f"(category {category})"
            )

    # The system prompt has to carry the rule, and only in CIL.
    if "CIL" not in modes.prompt_addendum("cil"):
        failures.append("policy: CIL prompt addendum does not mention the mode")
    if modes.prompt_addendum("gui"):
        failures.append("policy: GUI should carry no mode addendum")

    print(f"  CIL categories : {tool_loader.categories_for_mode('cil')}")
    print(f"  GUI categories : {tool_loader.categories_for_mode('gui')}")
    cil_names = [t["function"]["name"] for t in tool_loader.tools_for_mode("cil")]
    for banned in ("BasicFunction_WriteToClipboard", "BasicFunction_ReadFromClipboard"):
        if banned in cil_names:
            failures.append(f"policy: '{banned}' still advertised in CIL")

    # ── Verdict ──────────────────────────────────────────────────────────
    print()
    if failures:
        print("FAILURES:")
        for item in failures:
            print("  ✗", item)
        return 1
    print("All scenarios passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
