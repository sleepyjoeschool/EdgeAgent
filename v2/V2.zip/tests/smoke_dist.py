"""Verification for the packaged bundle in dist/.

Three levels of checking, because each catches something the others miss:

1. Structure   — are prompts, static assets, OCR weights, YOLO weights and a
                 *matching* Paddle stack actually inside the bundle?
2. Runtime     — does the frozen executable serve HTTP/SSE and hand out the
                 tool inventory?
3. Offline OCR — can the bundled Paddle really read the screen? Done by putting
                 the bundle's own directories on sys.path, which is how the
                 frozen loader ends up resolving them.

Usage:
    python tests/smoke_dist.py
    python tests/smoke_dist.py --skip-ocr      # skip the slow OCR load
    python tests/smoke_dist.py --bundle D:/path/to/ComputerUseAgentWeb
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_BUNDLE = ROOT / "dist" / "ComputerUseAgentWeb"
PORT = 5177


def structure(bundle: Path, failures: list[str]) -> None:
    print("\n── structure ────────────────────────────────────────────")
    internal = bundle / "_internal"
    base = internal if internal.is_dir() else bundle
    exe = bundle / "ComputerUseAgentWeb.exe"

    items = [
        ("executable", exe),
        ("tool definitions", base / "prompt-content-json" / "Entry_Point.json"),
        ("web assets", base / "webui" / "static" / "index.html"),
        ("OCR det weights", base / "models" / "ocr" / "det"),
        ("OCR rec weights", base / "models" / "ocr" / "rec"),
    ]
    for label, path in items:
        ok = path.exists()
        print(f"  {'ok ' if ok else 'MISS'} {label:20} {path.name}")
        if not ok:
            failures.append(f"bundle is missing {label} ({path})")

    models = sorted((base / "models").glob("*.pt")) if (base / "models").is_dir() else []
    if models:
        size_mb = models[0].stat().st_size / 1024 ** 2
        print(f"  ok  {'YOLO weights':20} {models[0].name} ({size_mb:.0f} MB)")
    else:
        print("  --  YOLO weights not bundled (expected unless --include-model)")

    # The Paddle pair must match paddlex, or OCR dies inside PIR at runtime on
    # the target machine while still reporting itself as "ready".
    for location in (base / "paddle", base / "paddle_env" / "paddle"):
        version_file = location / "version" / "__init__.py"
        if not version_file.is_file():
            continue
        text = version_file.read_text(encoding="utf-8", errors="replace")
        import re

        versions = re.findall(r"['\"](\d+\.\d+\.\d+)['\"]", text)
        latest = versions[0] if versions else "?"
        print(f"  ok  paddle in {location.parent.name:12} {latest}")
        if latest.startswith("3.0."):
            failures.append(
                f"paddle {latest} bundled at {location} - incompatible with "
                f"paddlex 3.7.x (PIR 'strides' error)"
            )
        break
    else:
        failures.append("no paddle found inside the bundle")


def runtime(bundle: Path, failures: list[str]) -> None:
    print("\n── runtime ──────────────────────────────────────────────")
    exe = bundle / "ComputerUseAgentWeb.exe"
    if not exe.is_file():
        failures.append("executable not found")
        return

    proc = subprocess.Popen(
        [str(exe), "--host", "127.0.0.1", "--port", str(PORT)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        cwd=str(bundle),
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    base_url = f"http://127.0.0.1:{PORT}"
    try:
        deadline = time.time() + 90
        ready = False
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(base_url + "/api/hello", timeout=3) as r:
                    hello = _json(r)
                    ready = True
                    break
            except (urllib.error.URLError, OSError):
                if proc.poll() is not None:
                    break
                time.sleep(1.0)

        if not ready:
            tail = ""
            try:
                out, _ = proc.communicate(timeout=10)
                tail = (out or "")[-1500:]
            except Exception:
                pass
            failures.append(f"packaged server did not come up.\n{tail}")
            print("  MISS server did not answer")
            return

        print(f"  ok  /api/hello        model={hello.get('model')} "
              f"vision={hello.get('vision_mode')}")

        for path, key in (("/api/status", "state"), ("/api/tools", "meta"),
                          ("/api/settings", "groups")):
            try:
                with urllib.request.urlopen(base_url + path, timeout=10) as r:
                    body = _json(r)
                value = body.get(key, "?")
                summary = value if isinstance(value, str) else f"{len(value)} entries"
                print(f"  ok  {path:24} {summary}")
            except Exception as e:
                failures.append(f"{path} failed: {e}")
                print(f"  MISS {path:24} {e}")

        try:
            with urllib.request.urlopen(base_url + "/", timeout=10) as r:
                size = len(r.read())
            print(f"  ok  /                 index.html ({size} B)")
        except Exception as e:
            failures.append(f"static index failed: {e}")

        # config overrides must land next to the exe, not inside _internal.
        override = Path.cwd() / "config_override.json"
        print(f"  --  override path would be: {bundle / 'config_override.json'}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()


def offline_ocr(bundle: Path, failures: list[str]) -> None:
    """Run the bundle's own OCR stack through a plain interpreter.

    Pointing sys.path at the bundle's directories reproduces how the frozen
    loader resolves them, so a failure here means the shipped OCR is broken.
    """
    print("\n── offline OCR (may take ~90s on first model load) ───────")
    internal = bundle / "_internal"
    base = internal if internal.is_dir() else bundle
    paddle_env = base / "paddle_env"

    script = (
        "import json, sys, time\n"
        f"sys.path.insert(0, r'{base}')\n"
        f"sys.path.insert(0, r'{paddle_env}')\n"
        "from cua.context import ToolContext\n"
        "from cua.executors import dispatch\n"
        "from cua import ocr_engine\n"
        "t0 = time.time()\n"
        "out = dispatch('ScreenCaptureAction_CaptureScreen', {}, ToolContext())\n"
        "print('ELAPSED', round(time.time()-t0, 1))\n"
        "try:\n"
        "    data = json.loads(out)\n"
        "    print('BOXES', len(data))\n"
        "    for item in data[:5]:\n"
        "        print('SAMPLE', repr(item['text'][:30]))\n"
        "except Exception:\n"
        "    print('RAW', out[:400])\n"
    )
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        cwd=str(ROOT), timeout=420,
    )
    output = (result.stdout or "") + (result.stderr or "")
    lines = [l for l in output.splitlines() if l.startswith(("ELAPSED", "BOXES", "SAMPLE", "RAW"))]
    for line in lines:
        print("  ", line)
    if not any(l.startswith("BOXES") for l in lines):
        failures.append("bundled OCR did not return any text boxes")
        print("  tail:", output[-800:])


def _json(response):
    import json

    return json.loads(response.read().decode("utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the packaged Computer Use Agent bundle.")
    parser.add_argument("--bundle", default=str(DEFAULT_BUNDLE))
    parser.add_argument("--skip-ocr", action="store_true")
    args = parser.parse_args()

    bundle = Path(args.bundle)
    if not bundle.is_dir():
        print(f"bundle not found: {bundle}")
        return 1

    size = sum(f.stat().st_size for f in bundle.rglob("*") if f.is_file())
    print(f"bundle: {bundle}  ({size / 1024 ** 3:.2f} GB)")

    failures: list[str] = []
    structure(bundle, failures)
    runtime(bundle, failures)
    if not args.skip_ocr:
        offline_ocr(bundle, failures)

    print()
    if failures:
        print("FAILURES:")
        for item in failures:
            print("  x", item)
        return 1
    print("Packaged bundle verified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
