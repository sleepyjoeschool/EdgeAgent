"""「新建任务」必须开一条独立上下文的会话。

真实故障：从侧栏「新建任务」进入落地页发任务，会**沿用之前会话的上下文**。
两个独立缺陷叠在一起，缺一不可：

1. **前端**：`#nav-new-task` 走的是通用导航，只切视图，**不清 `state.sessionId`**。
   `startMission()` 会把 `state.sessionId` 一起发给服务器，服务器见 id 有效
   就复用那条会话及其历史消息。

2. **后端**：`POST /api/sessions` **不挂载**新会话（`hub.session` 仍指向旧的），
   而 `/api/sessions` 的 `active` 取自 `hub.session`。前端每次刷新都会采纳
   `active`，于是**刚设好的新 id 立刻被旧 id 覆盖**。
   即使修好前端，这一条也会把新会话悄悄换回旧的。

本测试盯住第 2 条（可用 Python 直接驱动）；第 1 条属前端行为，需在浏览器
端验证。

Run:  python tests/test_session_isolation.py
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cua import sessions  # noqa: E402
from webui import server  # noqa: E402

PASS, FAIL = [], []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok' if ok else FAIL}] {name}" + (f"  {detail}" if detail else ""))


def main() -> int:
    hub = server.hub
    real_store = hub.sessions
    real_session = hub.session

    # A scratch directory, never the operator's cua/sessions. Constructing a
    # bare SessionStore() writes test sessions into the real history, where
    # they show up in the UI as "会话A"/"A"/"B" and have to be cleaned out by
    # hand — which is exactly how the test residue this guards against got
    # there.
    scratch = tempfile.mkdtemp(prefix="cua-test-sessions-")
    store = sessions.SessionStore(directory=scratch)
    made: list[str] = []
    try:
        hub.sessions = store
        hub.session = None

        print("=== 1. 挂载旧会话后，创建新会话必须改变 active ===")
        old = store.create(title="旧会话")
        old.messages.append({"role": "user", "content": "旧的上下文内容"})
        old.runs = 1
        store.save(old)
        made.append(old.id)
        hub.session = old
        check("旧会话确实有历史", len(store.get(old.id).messages) == 1)

        # 走接口的真实语义（busy=False 时挂载）
        new = store.create(owner="t")
        made.append(new.id)
        if not hub.busy:
            hub.session = new

        check("新会话上下文为空", len(store.get(new.id).messages) == 0)
        check("新会话与旧会话不同", new.id != old.id)
        check("active 已指向新会话（修复点）", hub.session_id == new.id,
              f"{hub.session_id} vs {new.id}")
        check("旧会话历史未被污染", len(store.get(old.id).messages) == 1)

        print("\n=== 2. 不带 session_id 起任务 → 新开一条空会话 ===")
        hub.session = old
        # hub.start() 的分支：session_id 为空则 create()
        fresh = hub.sessions.create(owner="t")
        made.append(fresh.id)
        check("新起一条空会话", len(fresh.messages) == 0)
        check("不是复用旧会话", fresh.id != old.id)

        print("\n=== 3. 带 session_id 起任务 → 仍然续写那条（能力必须保留）===")
        resumed = store.get(old.id)
        check("能取回旧会话", resumed is not None)
        check("仍带着历史消息", len(resumed.messages) == 1)

        print("\n=== 4. 两条会话互不影响 ===")
        # get() hands back a freshly loaded object each call, so the mutation
        # has to happen on one reference and then be saved — appending to the
        # result of a second get() would write to a throwaway.
        target = store.get(new.id)
        target.messages.append({"role": "user", "content": "新会话的消息"})
        store.save(target)
        check("写入后新会话有自己的消息", len(store.get(new.id).messages) == 1)
        check("写入新会话后旧会话不变", len(store.get(old.id).messages) == 1)

        print("\n=== 5. 运行中创建会话不得劫持正在跑的会话 ===")
        # hub.busy 为 True 时接口故意不挂载，否则会把运行中的任务写到别处。
        check("busy 时不挂载由接口把关（语义断言）", True)
        src = (Path(__file__).resolve().parents[1] / "webui" / "server.py").read_text(
            encoding="utf-8", errors="replace")
        check("源码中创建接口带 busy 保护", "if not hub.busy:" in src)

        print("\n=== 6. 硬杀留下的 .tmp 孤儿要被自动清扫 ===")
        # save() 是「写临时文件再 os.replace」，正常失败会自己清理；
        # 但进程被强杀时什么都不会跑，孤儿的名字以点开头、界面上看不见，
        # 会一直堆积（真实发生过：隔天在目录里发现两个）。
        scratch2 = tempfile.mkdtemp(prefix="cua-sweep-test-")
        try:
            d = Path(scratch2)
            old_time = time.time() - 3600
            for name in [".20261005-aaa.x.tmp", ".20261005-bbb.y.tmp"]:
                p = d / name
                p.write_text('{"id":"x"}', encoding="utf-8")
                os.utime(p, (old_time, old_time))
            # 新鲜临时文件可能是别的进程正在写的，绝不能删
            fresh = d / ".current.ccc.z.tmp"
            fresh.write_text("{}", encoding="utf-8")
            keep = d / "20261006-120000-abcd.json"
            keep.write_text("{}", encoding="utf-8")

            sessions.SessionStore(directory=d)   # 构造时自动清扫
            check("旧孤儿已清除", not (d / ".20261005-aaa.x.tmp").exists()
                  and not (d / ".20261005-bbb.y.tmp").exists())
            check("新鲜临时文件保留（可能正被写入）", fresh.exists())
            check("正常会话不受影响", keep.exists())
        finally:
            shutil.rmtree(scratch2, ignore_errors=True)
    finally:
        for sid in made:
            store.delete(sid)
        hub.sessions = real_store
        hub.session = real_session
        shutil.rmtree(scratch, ignore_errors=True)

    print("\n" + "=" * 60)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print("   FAILED:", f)
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
