"""暂停 / 继续 / 中断 的语义。

真实故障：**暂停中按「中断」停不下来**。

步骤循环里 `check_stop()` 在 `gate()` 之前。用户先暂停 → `gate()` 阻塞住；
此时按中断，`abort()` 既置 `_abort` **又清 `_pause`**，
于是 `gate()` 的循环条件 `while self._pause.is_set()` 先变假、循环直接退出，
里面那句 `raise` 永远走不到 —— `gate()` 正常返回，而这一轮的 `check_stop()`
早已通过，引擎于是又跑了整整一步。「按了中断却不停」就是这个。

修法：`gate()` 在循环之外**无条件**再查一次 `_abort`。这同时覆盖了
「运行中 abort 恰好落在调用方检查与 gate 之间」的窗口。

Run:  python tests/test_runtime_pause.py
"""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cua.runtime import Aborted, Runtime  # noqa: E402

PASS, FAIL = [], []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok' if ok else FAIL}] {name}" + (f"  {detail}" if detail else ""))


def call_gate(rt: Runtime) -> list[str]:
    """Run gate() on a thread and report how it left: 'ok' or 'Aborted'."""
    out: list[str] = []

    def run() -> None:
        try:
            rt.gate()
            out.append("ok")
        except Aborted:
            out.append("Aborted")

    t = threading.Thread(target=run, daemon=True)
    t.start()
    return out, t  # type: ignore[return-value]


def fresh() -> Runtime:
    rt = Runtime()
    rt.resume_from_abort()
    rt._pause.clear()
    rt.step_mode = False
    return rt


def main() -> int:
    print("=== 1. 暂停中「中断」必须抛出，而不是放行 ===")
    rt = fresh()
    rt.pause()
    out, th = call_gate(rt)
    time.sleep(0.3)
    check("暂停后 gate() 确实阻塞住", th.is_alive())
    rt.abort()
    th.join(timeout=3)
    check("中断后抛 Aborted（修复点）", out == ["Aborted"], str(out))

    print("\n=== 2. 暂停 → 继续 必须正常放行，不能误判成中断 ===")
    rt = fresh()
    rt.pause()
    out, th = call_gate(rt)
    time.sleep(0.3)
    rt.resume()
    th.join(timeout=3)
    check("继续后正常返回", out == ["ok"], str(out))

    print("\n=== 3. 未暂停时 gate() 也要拦住已中断的任务 ===")
    # 调用方的 check_stop() 在此之前运行，两者之间可能有窗口。
    rt = fresh()
    rt.abort()
    out, th = call_gate(rt)
    th.join(timeout=3)
    check("已中断 → Aborted", out == ["Aborted"], str(out))

    print("\n=== 4. 一切正常时 gate() 不得拦截 ===")
    rt = fresh()
    out, th = call_gate(rt)
    th.join(timeout=3)
    check("空闲 → 正常返回", out == ["ok"], str(out))

    print("\n=== 5. should_stop 与 gate 的判断保持一致 ===")
    rt = fresh()
    check("空闲时 should_stop=False", rt.should_stop() is False)
    rt.abort()
    check("中断后 should_stop=True", rt.should_stop() is True)

    print("\n=== 6. 步进模式：逐次放行，一次一格 ===")
    rt = fresh()
    rt.step_mode = True
    rt._step_gate.clear()
    hits: list[int] = []

    def two_steps() -> None:
        rt.gate_step(1)
        hits.append(1)
        rt.gate_step(2)
        hits.append(2)

    th = threading.Thread(target=two_steps, daemon=True)
    th.start()
    time.sleep(0.3)
    check("未放行时卡在第 1 步", hits == [], str(hits))
    rt.release_step()
    time.sleep(0.3)
    check("放行一次后走到第 2 步", hits == [1], str(hits))
    rt.release_step()
    th.join(timeout=3)
    check("再放行后走完", hits == [1, 2], str(hits))

    print("\n=== 7. 步进模式下的中断也要能打断等待 ===")
    rt = fresh()
    rt.step_mode = True
    rt._step_gate.clear()
    res: list[str] = []

    def wait_step() -> None:
        try:
            rt.gate_step(1)
            res.append("ok")
        except Aborted:
            res.append("Aborted")

    th = threading.Thread(target=wait_step, daemon=True)
    th.start()
    time.sleep(0.3)
    rt.abort()
    th.join(timeout=3)
    check("步进等待中被中断 → Aborted", res == ["Aborted"], str(res))

    print("\n=== 8. abort 会同时解除暂停与步进（否则线程会永远卡住）===")
    rt = fresh()
    rt.pause()
    rt.step_mode = True
    rt._step_gate.clear()
    rt.abort()
    check("暂停已清除", rt.paused is False)
    check("步进闸门已放行", rt._step_gate.is_set() is True)

    print("\n" + "=" * 60)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print("   FAILED:", f)
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
