"""Echo server + assertions for the OpenCode session-header plumbing.

Why a local echo instead of the real endpoint: the Go endpoint is behind
authentication we do not hold, and an auth rejection happens *before* the
session-header check — so a live probe cannot tell us whether our header was
sent, or whether it was stable. A local listener sees exactly what we put on
the wire, which is the actual question.

Two files carry the rule and both are covered here, because getting either
wrong breaks every request the operator makes:

* ``cua/llm_client.py`` decides *whether* an endpoint is OpenCode. Its answer
  comes from the hostname **or** the API path (``/zen/go/v1``), so a relay on
  an unfamiliar domain and a self-hosted gateway are recognised too. Hostname
  alone quietly excluded both, and the symptom was the same 400 for every
  model — read as "the endpoint is broken" rather than "we sent no header".
* ``cua/config.py`` decides what to *call* that endpoint in the picker, which
  must agree with what the wizard calls it.

Discipline this file learned the hard way: assert through the **production**
constructors (``llm_client.build_llm_client``, ``model_probe._client``,
``model_probe.run_probes``), never a hand-built client. A hand-built client
passed while the real probe path was still broken, because the failing request
there bypasses the SDK entirely.

Run:  python tests/test_opencode_headers.py
"""
from __future__ import annotations

import json
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cua import config, llm_client, model_probe  # noqa: E402

SEEN: list[dict] = []


class Echo(BaseHTTPRequestHandler):
    def _respond(self):
        length = int(self.headers.get("Content-Length") or 0)
        self.rfile.read(length)
        SEEN.append({
            "path": self.path,
            "session": self.headers.get("x-opencode-session"),
            "ua": self.headers.get("User-Agent"),
        })
        payload = json.dumps({
            "id": "x", "object": "chat.completion", "created": 0, "model": "m",
            "choices": [{"index": 0, "finish_reason": "stop",
                         "message": {"role": "assistant", "content": "pong"}}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    do_POST = _respond

    def do_GET(self):  # a GET /models is not expected, but record it if it comes
        self._respond()

    def log_message(self, *a):
        pass


PASS, FAIL = [], []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))


def main() -> int:
    srv = HTTPServer(("127.0.0.1", 0), Echo)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    local = f"http://127.0.0.1:{port}/v1"

    # The echo host stands in for opencode.ai so that the production header
    # logic engages while the traffic stays local. Patching the host list — a
    # module constant that is the single source of truth for the decision — is
    # what makes this an end-to-end test rather than a unit test of a helper.
    real_hosts = llm_client._OPENCODE_HOSTS
    llm_client._OPENCODE_HOSTS = ("opencode.ai", "127.0.0.1")

    old_base = config.LLM_BASE_URL
    old_key = config.LLM_API_KEY
    old_model = config.LLM_MODEL
    try:
        print("=== 1. 端点判定（主机名 ^ 路径，都不是子串）===")
        llm_client._OPENCODE_HOSTS = real_hosts
        for url, want, why in [
            ("https://opencode.ai/zen/go/v1", True, "官方域名"),
            ("https://opencode.ai/zen/v1", True, "Zen"),
            ("https://api.opencode.ai/v1", True, "子域名"),
            # 这几条是本次回归的核心：中转站域名不可能穷举，自建网关更是任意
            # 域名，主机名判定必然漏；漏掉的症状是每个模型都 400，很容易被
            # 读成「端点坏了」而不是「我们没发头」。
            ("https://relay.example.net/zen/go/v1", True, "中转站"),
            ("https://relay.example.net/zen/go/v1/", True, "中转站+尾斜杠"),
            ("https://relay.example.net/zen/go/v1/chat/completions",
             True, "中转站+完整端点"),
            ("https://my-gateway.corp.example/zen/go/v1", True, "自建网关"),
            ("https://my-gateway.corp.example/zen/v1", True, "自建网关 Zen"),
            # 负例与正例同等重要：路径标记必须落在段边界上，子串不算，
            # 否则任何路径里出现 zen 的端点都会白拿一个头。
            ("https://opencode.ai.evil.example.com/v1", False, "仿冒域名、无标记路径"),
            ("https://example.com/opencode.ai/v1", False, "路径里含品牌名"),
            ("https://example.com/v1/zen/go", False, "标记顺序颠倒"),
            ("https://example.com/zen/go/v1beta", False, "标记后无边界"),
            ("https://openrouter.ai/api/v1", False, "无关厂商"),
            (local, False, "本地回显（未加入主机名时）"),
            ("", False, "空串"),
        ]:
            check(f"is_opencode_endpoint({url or '<空>'!r}) == {want}（{why}）",
                  llm_client.is_opencode_endpoint(url) is want)
        # 查询串不该被当成路径：带参数的端点仍然要认出来。
        check("查询串不影响路径判定",
              llm_client.is_opencode_endpoint(
                  "https://gateway.example/zen/go/v1?key=abc") is True)
        llm_client._OPENCODE_HOSTS = ("opencode.ai", "127.0.0.1")

        print("\n=== 2. 头的形状 ===")
        llm_client._OPENCODE_HOSTS = real_hosts
        h = llm_client.request_headers("https://opencode.ai/zen/go/v1")
        check("带 x-opencode-session", bool(h.get("x-opencode-session")))
        check("会话 id 是 32 位十六进制",
              len(h.get("x-opencode-session", "")) == 32
              and all(c in "0123456789abcdef" for c in h["x-opencode-session"]))
        check("User-Agent 标识自己而不是 SDK", h.get("User-Agent") == "cua-webui",
              f"got {h.get('User-Agent')!r}")
        for url in ["https://api.deepseek.com", "https://openrouter.ai/api/v1", local]:
            check(f"{url} 不带头", llm_client.request_headers(url) == {})
        sid = uuid.uuid4().hex
        check("显式会话 id 优先",
              llm_client.request_headers("https://opencode.ai/zen/go/v1", session_id=sid)
              .get("x-opencode-session") == sid)
        check("无会话时两次不同",
              llm_client.request_headers("https://opencode.ai/zen/go/v1")["x-opencode-session"]
              != llm_client.request_headers("https://opencode.ai/zen/go/v1")["x-opencode-session"])
        # 中转站与自建网关：主机名不在表里，靠路径也要拿到同一组头。
        relay = "https://relay.example.net/zen/go/v1"
        rh = llm_client.request_headers(relay)
        check("中转站也带 x-opencode-session", bool(rh.get("x-opencode-session")),
              repr(rh))
        check("中转站也用 cua-webui 标识", rh.get("User-Agent") == "cua-webui",
              repr(rh.get("User-Agent")))
        check("显式会话 id 在中转站同样优先",
              llm_client.request_headers(relay, session_id=sid)
              .get("x-opencode-session") == sid)
        llm_client._OPENCODE_HOSTS = ("opencode.ai", "127.0.0.1")

        print("\n=== 3. 中转站经真实构造函数也要带头 ===")
        # 之前这一路从没被走过：主机名判定下中转站拿不到头，而本文件其余
        # 断言都打在官方域名或本地回显上，所以 400 一直复现却全绿。
        llm_client._OPENCODE_HOSTS = ("127.0.0.1",)  # 回显主机从表里摘掉
        config.LLM_BASE_URL = "http://127.0.0.1:%d/zen/go/v1" % port
        config.LLM_API_KEY = "k"
        config.LLM_MODEL = "m"
        SEEN.clear()
        try:
            rc = llm_client.build_llm_client(session_id="relay-sess")
            rc.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}],
                                       max_tokens=4, stream=False)
            rg = SEEN[0] if SEEN else {}
            check("中转站路径经 build_llm_client 拿到会话头",
                  rg.get("session") == "relay-sess", repr(rg.get("session")))
            check("中转站路径也不漏 UA", rg.get("ua") == "cua-webui", repr(rg.get("ua")))
        finally:
            llm_client._OPENCODE_HOSTS = ("opencode.ai", "127.0.0.1")

        print("\n=== 3b. build_llm_client()：真实构造函数，线上必须带头 ===")
        config.LLM_BASE_URL = local
        config.LLM_API_KEY = "k"
        config.LLM_MODEL = "m"
        SEEN.clear()
        c = llm_client.build_llm_client(session_id="sess-abc")
        c.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}],
                                  max_tokens=4, stream=False)
        g = SEEN[0] if SEEN else {}
        check("线上带了会话头", g.get("session") == "sess-abc", repr(g.get("session")))
        check("线上 UA 是 cua-webui", g.get("ua") == "cua-webui", repr(g.get("ua")))

        print("\n=== 4. llm_client.probe()：设置页的『测试』===")
        SEEN.clear()
        ok, _msg = llm_client.probe(timeout=10)
        check("probe 通过", ok)
        check("线上带了会话头", bool((SEEN[0] if SEEN else {}).get("session")))

        print("\n=== 5. model_probe._client()：带自定义 http_client 也不能丢头 ===")
        SEEN.clear()
        pc = model_probe._client("k", local, 20.0)
        pc.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}],
                                   max_tokens=4, stream=False)
        check("线上带了会话头", bool((SEEN[0] if SEEN else {}).get("session")))
        check("线上 UA 是 cua-webui", (SEEN[0] if SEEN else {}).get("ua") == "cua-webui")

        print("\n=== 6. run_probes()：连通性探测用裸 httpx，同样必须带头 ===")
        # 这一条是本文件存在的理由：连通性是其余所有探测的闸门，
        # 它走 raw httpx、拿不到 SDK 的 default_headers，漏一个头就会把
        # 健康端点报成不可达。
        SEEN.clear()
        report = model_probe.run_probes(local, "k", "m", include_optional=True, timeout=20)
        sessions = [s["session"] for s in SEEN]
        check(f"发出了 {len(SEEN)} 个请求", len(SEEN) >= 5, str(len(SEEN)))
        check("每一个都带会话头", all(bool(s) for s in sessions),
              str([s or None for s in sessions]))
        check("整轮共用同一个会话 id（提示缓存的前提）", len(set(sessions)) == 1,
              f"{len(set(sessions))} 个不同值")
        check("裸 httpx 的连通性请求也带上了 UA", all(s["ua"] == "cua-webui" for s in SEEN),
              str({s["ua"] for s in SEEN}))
        check("连通性确实通过（不再是 400）", report.get("connectivity").ok,
              report.get("connectivity").detail)

        print("\n=== 7. 非 OpenCode 端点：一个头都不加 ===")
        llm_client._OPENCODE_HOSTS = real_hosts
        SEEN.clear()
        nc = model_probe._client("k", local, 20.0)
        nc.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}],
                                   max_tokens=4, stream=False)
        g = SEEN[0] if SEEN else {}
        check("不带 x-opencode-session", not g.get("session"), repr(g.get("session")))
        check("不冒充 cua-webui", g.get("ua") != "cua-webui", repr(g.get("ua")))

        print("\n=== 8. 引擎把 session_id 透传到客户端 ===")
        llm_client._OPENCODE_HOSTS = ("opencode.ai", "127.0.0.1")
        from cua.engine import AgentEngine
        check("引擎保存了 session_id",
              AgentEngine(session_id="20261005-abc123")._session_id == "20261005-abc123")
        check("未传入时为 None", AgentEngine()._session_id is None)

        print("\n=== 9. 选择器与向导对同一端点用同一个名字 ===")
        # 同一个端点，后端与向导必须叫同一个名字——两处不一致本身就是 bug。
        from cua import config as cfg
        for url in ["https://opencode.ai/zen/go/v1",
                    "https://api.opencode.ai/zen/go/v1"]:
            check(f"provider_name({url}) == OpenCode-Go",
                  cfg.provider_name(url) == "OpenCode-Go", cfg.provider_name(url))
        for url, want in [("https://api.deepseek.com", "DeepSeek"),
                          ("http://127.0.0.1:11434/v1", "本地"),
                          ("https://opencode.ai.evil.example.com/v1", "自定义")]:
            check(f"provider_name({url}) == {want}",
                  cfg.provider_name(url) == want, cfg.provider_name(url))
        check("模型标签形如 模型@Provider",
              cfg.model_label("longcat-2.5-preview-free",
                              "https://opencode.ai/zen/go/v1")
              == "longcat-2.5-preview-free@OpenCode-Go")
    finally:
        llm_client._OPENCODE_HOSTS = real_hosts
        config.LLM_BASE_URL, config.LLM_API_KEY, config.LLM_MODEL = old_base, old_key, old_model
        srv.shutdown()

    print("\n" + "=" * 60)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print("   FAILED:", f)
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
