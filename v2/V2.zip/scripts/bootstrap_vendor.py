"""Fetch the heavy, non-pip-friendly dependencies into ``vendor/``.

Nothing under ``vendor/`` that is large or machine-specific is committed to
the repository. This script rebuilds it from public sources, so a fresh
clone gains the optional perception stack without dragging 800MB through git:

* ``vendor/paddle_env``   — the PaddlePaddle stack matching the installed
  paddlex (600MB+ of wheels). Installed with ``pip install --target`` at the
  pinned versions that are known to work together.
* ``vendor/tokencalc/tokenizers`` — the four tokenizer snapshots used by the
  exact token counter (~31 MB of JSON), downloaded from Hugging Face
  (``hf-mirror.com`` is tried automatically on networks where HF is blocked).
* ``vendor/ocr_models``   — PP-OCR det/rec weights, for offline OCR. These are
  distributed separately; point ``--ocr-models`` at a directory that holds
  them, or let PaddleOCR download into ``~/.paddlex`` on first use.

Usage
-----
    python scripts/bootstrap_vendor.py                  # paddle stack + tokenizers
    python scripts/bootstrap_vendor.py --check          # report only, fetch nothing
    python scripts/bootstrap_vendor.py --paddle-only
    python scripts/bootstrap_vendor.py --tokencalc-only
    python scripts/bootstrap_vendor.py --paddle-env D:/somewhere/paddle_env
    python scripts/bootstrap_vendor.py --ocr-models D:/somewhere/official_models

``--paddle-env`` copies an existing self-consistent tree instead of running
pip — the offline escape hatch. ``--ocr-models`` accepts either the flat
``det/`` + ``rec/`` layout or a PaddleOCR cache with ``*_det`` / ``*_rec``
directories.

Everything is optional: a component that is missing or fails to download is
reported, and the panel keeps working with that capability marked unavailable.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENDOR = ROOT / "vendor"
PADDLE_TARGET = VENDOR / "paddle_env"
MODELS_TARGET = VENDOR / "ocr_models"
TOKENCALC_DIR = VENDOR / "tokencalc"
TOKENIZERS_TARGET = TOKENCALC_DIR / "tokenizers"

#: The paddle/paddlex pair that is known to work together (3.0.x + paddlex
#: 3.7.x dies in PIR with "Type of attribute: strides is not right").
PADDLE_PINS = ("paddlepaddle==3.2.2", "paddleocr==3.7.0", "paddlex==3.7.2")

#: The CPU wheel index hosts paddlepaddle; used as an extra index so the
#: other two packages still resolve from PyPI.
PADDLE_CPU_INDEX = "https://www.paddlepaddle.org.cn/packages/stable/cpu/"

#: Tokenizer snapshots, fetched from the model repos' ``main`` branch.
HF_ENDPOINTS = (
    "https://huggingface.co/{repo}/resolve/main/{file}",
    "https://hf-mirror.com/{repo}/resolve/main/{file}",
)
TOKENIZER_FILES = ("tokenizer.json", "tokenizer_config.json", "config.json")
TOKENIZER_OPTIONAL_FILES = ("chat_template.jinja", "generation_config.json")


# ── Status report ───────────────────────────────────────────────────────

def _dir_size(path: Path) -> str:
    try:
        total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    except OSError:
        return "?"
    for unit, div in (("GB", 1024 ** 3), ("MB", 1024 ** 2), ("KB", 1024)):
        if total >= div:
            return f"{total / div:.0f} {unit}"
    return f"{total} B"


def report() -> int:
    print("组件现状：")
    ok = True

    paddle_ok = (PADDLE_TARGET / "paddle").is_dir()
    ok &= paddle_ok
    print(f"  [{'ok ' if paddle_ok else '-- '}] paddle_env        "
          f"{_dir_size(PADDLE_TARGET) if PADDLE_TARGET.is_dir() else '缺失'}"
          f"{'' if paddle_ok else '   (python scripts/bootstrap_vendor.py --paddle-only)'}")

    models_ok = (MODELS_TARGET / "det").is_dir() and (MODELS_TARGET / "rec").is_dir()
    print(f"  [{'ok ' if models_ok else '-- '}] ocr_models        "
          f"{_dir_size(MODELS_TARGET) if MODELS_TARGET.is_dir() else '缺失（PaddleOCR 首次运行会自动下载）'}")

    ready: list[str] = []
    if TOKENIZERS_TARGET.is_dir():
        for d in sorted(TOKENIZERS_TARGET.iterdir()):
            if d.is_dir() and (d / "tokenizer.json").is_file():
                ready.append(d.name)
    tok_ok = len(ready) == 4
    print(f"  [{'ok ' if tok_ok else '-- '}] tokenizers       "
          f"{_dir_size(TOKENIZERS_TARGET) if TOKENIZERS_TARGET.is_dir() else '缺失'}，"
          f"就绪 {len(ready)}/4 {ready}"
          f"{'' if tok_ok else '   (python scripts/bootstrap_vendor.py --tokencalc-only)'}")

    print("\n提示：paddle_env 与 tokenizers 都是可选组件；缺失时面板仍可启动，"
          "对应能力会明确标注为『未安装』。")
    return 0 if ok else 1


# ── Paddle stack ────────────────────────────────────────────────────────

def install_paddle() -> bool:
    """pip-install the pinned Paddle stack into ``vendor/paddle_env``."""
    if (PADDLE_TARGET / "paddle").is_dir():
        print(f"[paddle] 已存在：{PADDLE_TARGET}（需要重装请先删除该目录）")
        return True

    base_cmd = [
        sys.executable, "-m", "pip", "install",
        "--target", str(PADDLE_TARGET),
        "--upgrade",
        *PADDLE_PINS,
    ]
    attempts = [
        (base_cmd, "PyPI"),
        (base_cmd + ["--extra-index-url", PADDLE_CPU_INDEX], "PyPI + paddle CPU 索引"),
    ]
    for cmd, label in attempts:
        print(f"[paddle] pip 安装（{label}），需要几分钟…")
        result = subprocess.run(cmd)
        if result.returncode == 0:
            print(f"[paddle] 安装完成 -> {PADDLE_TARGET}")
            return True
        print(f"[paddle] 该来源失败（exit {result.returncode}），换个来源重试…")

    print("[paddle] 安装失败。可改用离线方式：")
    print("         python scripts/bootstrap_vendor.py --paddle-env <已装好的 paddle 目录>")
    return False


def copy_paddle_tree(source: str) -> bool:
    src = Path(source)
    if not (src / "paddle").is_dir():
        print(f"[paddle] 不是有效的 Paddle 目录（缺少 paddle/）：{src}")
        return False
    if PADDLE_TARGET.exists():
        shutil.rmtree(PADDLE_TARGET, ignore_errors=True)
    print(f"[paddle] 复制 {src} -> {PADDLE_TARGET}")
    shutil.copytree(src, PADDLE_TARGET, dirs_exist_ok=True)
    return True


# ── PP-OCR weights ──────────────────────────────────────────────────────

def copy_ocr_models(source: str) -> bool:
    src = Path(source)
    if not src.is_dir():
        print(f"[ocr] 目录不存在：{src}")
        return False

    flat = all((src / kind).is_dir() for kind in ("det", "rec"))
    ok = True
    for kind in ("det", "rec"):
        if flat:
            chosen = src / kind
        else:
            matches = sorted(d for d in src.iterdir() if d.is_dir() and d.name.endswith(f"_{kind}"))
            chosen = matches[-1] if matches else None
        if chosen is None:
            print(f"[ocr] 找不到 {kind} 权重：{src}")
            ok = False
            continue
        target = MODELS_TARGET / kind
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)
        print(f"[ocr] 复制 {chosen.name} -> {target}")
        shutil.copytree(chosen, target, dirs_exist_ok=True)
    return ok


# ── Tokenizers ──────────────────────────────────────────────────────────

def _load_specs():
    """Read the model table from the vendored tokencalc package."""
    sys.path.insert(0, str(TOKENCALC_DIR))
    try:
        from tokencalc.registry import all_specs  # type: ignore

        return list(all_specs())
    except Exception as exc:  # noqa: BLE001
        print(f"[tokencalc] 无法读取 vendored 包（{TOKENCALC_DIR}）：{exc}")
        return []


def _http_get(url: str, dest: Path, timeout: int = 120) -> bool:
    req = urllib.request.Request(url, headers={"User-Agent": "cua-bootstrap/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return False
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(resp.read())
        return True
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError):
        return False


def fetch_tokenizers() -> bool:
    specs = _load_specs()
    if not specs:
        return False

    ok = True
    for spec in specs:
        out_dir = TOKENIZERS_TARGET / spec.dir_name
        print(f"[tokencalc] {spec.key}  <- {spec.repo}")
        for name in TOKENIZER_FILES + TOKENIZER_OPTIONAL_FILES:
            dest = out_dir / name
            if dest.is_file() and dest.stat().st_size > 0:
                print(f"  = 已存在 {name}")
                continue
            fetched = False
            for template in HF_ENDPOINTS:
                url = template.format(repo=spec.repo, file=name)
                if _http_get(url, dest):
                    print(f"  + {name}  ({url.split('/')[2]})")
                    fetched = True
                    break
            if not fetched and name in TOKENIZER_FILES:
                print(f"  ! {name} 下载失败（HF 与镜像都不通？）")
                ok = False
    return ok


# ── main ────────────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(
        description="下载/重建 vendor/ 下的重依赖（不进仓库）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--check", action="store_true", help="只报告现状，不下载")
    parser.add_argument("--paddle-only", action="store_true")
    parser.add_argument("--tokencalc-only", action="store_true")
    parser.add_argument("--paddle-env", default="", help="从本地已有的 paddle 目录复制（离线）")
    parser.add_argument("--ocr-models", default="", help="从本地目录复制 PP-OCR det/rec 权重")
    args = parser.parse_args()

    if args.check:
        return report()

    VENDOR.mkdir(parents=True, exist_ok=True)
    do_paddle = not args.tokencalc_only
    do_tokencalc = not args.paddle_only

    ok = True
    if do_paddle:
        if args.paddle_env:
            ok &= copy_paddle_tree(args.paddle_env)
        else:
            ok &= install_paddle()
    if args.ocr_models:
        ok &= copy_ocr_models(args.ocr_models)
    if do_tokencalc:
        ok &= fetch_tokenizers()

    print()
    report()
    print()
    if ok:
        print("完成。")
    else:
        print("部分组件未能就绪 —— 见上面的提示；面板仍可启动，相关能力会标注为不可用。")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
