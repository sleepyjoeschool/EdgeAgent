"""Copy the token calculator into this repository.

The vendored copy under ``vendor/tokencalc/`` is a *build input*, checked in
alongside the source so the panel works offline and a packaged build has
everything it needs. This script reproduces it from an upstream checkout,
which is what you run after the tokenizer files change.

    python scripts/embed_tokencalc.py --source <tokencalc-upstream-dir>
    python scripts/embed_tokencalc.py --check

``--check`` verifies the vendored copy is present and usable without touching
anything, which is what CI and the packaging step want.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENDOR = ROOT / "vendor" / "tokencalc"

#: Only what the counting path needs. The upstream package also ships a
#: gateway, a SQLite ledger and a web dashboard — none of which belong here:
#: CUA talks to its own upstream and keeps its own usage records, and pulling
#: those in would drag along httpx routing, sqlite schemas and a second
#: storage format to keep in sync.
PACKAGE_FILES = ("__init__.py", "registry.py", "loader.py", "prompts.py", "counter.py")
PACKAGE_DIRS = ("vendor",)

#: The tokenizer directories, by the name the registry expects. Both the
#: tokenizer.json files and the configs they need are required — the configs
#: carry the context length and the special-token strings.
TOKENIZER_DIRS = ("hy3", "hy4", "deepseek-v4.1-flash", "deepseek-v4-pro")


def check(source: Path) -> list[str]:
    """Problems with the upstream source, or an empty list."""
    problems = []
    pkg = source / "tokencalc"
    for name in PACKAGE_FILES:
        if not (pkg / name).is_file():
            problems.append(f"缺少 {pkg / name}")
    for name in PACKAGE_DIRS:
        if not (pkg / name).is_dir():
            problems.append(f"缺少 {pkg / name}")
    for name in TOKENIZER_DIRS:
        tok = source / "tokenizers" / name / "tokenizer.json"
        if not tok.is_file():
            problems.append(f"缺少 {tok}（先运行 download_tokenizers.py）")
    return problems


def verify_vendored() -> bool:
    """Whether the vendored copy can actually count, loading it for real."""
    sys.path.insert(0, str(ROOT))
    try:
        from cua import tokencalc_bridge
    except Exception as exc:  # noqa: BLE001
        print(f"  [FAIL] 无法导入 bridge: {exc}")
        return False
    if not tokencalc_bridge.available():
        print(f"  [FAIL] 不可用: {tokencalc_bridge.unavailable_reason()}")
        return False
    print(f"  [ok]   内置计算器可用")
    for info in tokencalc_bridge.model_info():
        status = "ok" if info["ready"] else "FAIL"
        print(f"  [{status:4}] {info['key']:22} ctx={info['context_length']}")
        if not info["ready"]:
            return False
    counted = tokencalc_bridge.count_messages(
        [{"role": "user", "content": "你好，世界"}], "hy3"
    )
    if not counted:
        print("  [FAIL] 计数返回空")
        return False
    print(f"  [ok]   计数冒烟：'你好，世界' -> {counted} tokens (hy3)")
    return True


def embed(source: Path) -> int:
    problems = check(source)
    if problems:
        print("上游目录不可用：")
        for p in problems:
            print(f"  - {p}")
        return 1

    if VENDOR.exists():
        shutil.rmtree(VENDOR)
    (VENDOR / "tokencalc").mkdir(parents=True)

    for name in PACKAGE_FILES:
        shutil.copy2(source / "tokencalc" / name, VENDOR / "tokencalc" / name)
    for name in PACKAGE_DIRS:
        shutil.copytree(source / "tokencalc" / name, VENDOR / "tokencalc" / name,
                        ignore=shutil.ignore_patterns("__pycache__"))

    for name in TOKENIZER_DIRS:
        shutil.copytree(source / "tokenizers" / name, VENDOR / "tokenizers" / name,
                        ignore=shutil.ignore_patterns("__pycache__"))

    size = sum(f.stat().st_size for f in VENDOR.rglob("*") if f.is_file()) / 1e6
    print(f"已嵌入 {VENDOR}（{size:.0f} MB）")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", default=os.environ.get("TOKENCALC_SOURCE", ""),
                    help="tokencalc 上游目录（含 tokencalc/ 与 tokenizers/）；"
                         "也可用环境变量 TOKENCALC_SOURCE 指定")
    ap.add_argument("--check", action="store_true",
                    help="只验证已嵌入的副本可用，不做拷贝")
    args = ap.parse_args()

    if args.check:
        print(f"检查 {VENDOR}")
        if not VENDOR.is_dir():
            print("  [FAIL] 目录不存在，先运行本脚本（不带 --check）")
            return 1
        return 0 if verify_vendored() else 1

    if not args.source:
        print("请用 --source <目录>（或环境变量 TOKENCALC_SOURCE）指定 tokencalc 上游。")
        return 2
    rc = embed(Path(args.source))
    if rc:
        return rc
    print("\n验证嵌入结果：")
    return 0 if verify_vendored() else 1


if __name__ == "__main__":
    raise SystemExit(main())
