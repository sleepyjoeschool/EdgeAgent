"""Local password recovery for the control panel.

Run this when the panel password has been forgotten and the login screen is
unreachable::

    python scripts/reset_password.py                  # interactive
    python scripts/reset_password.py --list
    python scripts/reset_password.py --user admin --password "New-Pass-9271"
    python scripts/reset_password.py --user admin --generate

This is deliberately a **local, offline** tool rather than a web endpoint. A
reset route reachable over HTTP would be a way to take over the panel without
the old password — that is the same mistake as a "forgot password" link with no
email channel behind it. Anyone who can run this has filesystem access to the
account file, and at that point the accounts are already theirs to change.

*The server must be stopped.* A running panel keeps sessions and a cached copy
of the account store in memory; writing the file underneath it would be undone
on the next save. The script refuses to run if the port is still answering, and
says so rather than failing mysteriously later.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import socket
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from cua import auth  # noqa: E402
from cua import config  # noqa: E402


def port_is_live(host: str, port: int) -> bool:
    """Whether something is listening on the panel's port right now."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.settimeout(0.6)
    try:
        return probe.connect_ex((host, int(port))) == 0
    except OSError:
        return False
    finally:
        probe.close()


def load_accounts(path: Path) -> dict:
    """Read the account file, or explain precisely what is wrong with it."""
    if not path.exists():
        raise SystemExit(
            f"未找到账号文件：{path}\n"
            f"面板尚未初始化？直接打开 WebUI 走首次创建流程即可。"
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise SystemExit(f"账号文件不是合法 JSON：{path}\n  {e}")
    except OSError as e:
        raise SystemExit(f"无法读取 {path}：{e}")

    users = data.get("users") if isinstance(data, dict) else None
    if not isinstance(users, list):
        raise SystemExit(f"账号文件格式异常（缺少 users 列表）：{path}")
    return data


def print_accounts(path: Path) -> None:
    data = load_accounts(path)
    users = data["users"]
    if not users:
        print("账号文件里没有任何账号。")
        return
    print(f"账号文件：{path}")
    print(f"{'用户名':<20}{'角色':<10}{'状态':<10}{'最近登录'}")
    print("-" * 68)
    for u in users:
        status = []
        if u.get("disabled"):
            status.append("已禁用")
        if u.get("must_change"):
            status.append("待改密")
        print(f"{u.get('name',''):<20}{u.get('role',''):<10}"
              f"{'/'.join(status) or '正常':<10}"
              f"{time.strftime('%Y-%m-%d %H:%M', time.localtime(u['created'])) if u.get('created') else '—'}")
    print(f"\n共 {len(users)} 个账号。")


def read_new_password(generated: str | None) -> str:
    """Obtain the new password, generating one when asked."""
    if generated:
        password = auth.generate_password()
        print(f"\n已生成密码：\n\n    {password}\n")
        print("请立即复制保存——它不会再次显示。")
        return password

    first = getpass.getpass("新密码（至少 8 位，输入不回显）：")
    if not first:
        raise SystemExit("已取消。")
    second = getpass.getpass("再输一次：")
    if first != second:
        raise SystemExit("两次输入不一致，已取消。")
    return first


def main() -> int:
    parser = argparse.ArgumentParser(
        description="重置 WebUI 控制面板的登录密码（本地工具，需先停止面板）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--user", help="要重置的用户名；省略则列出全部账号")
    parser.add_argument("--password", help="直接指定新密码；省略则交互输入")
    parser.add_argument("--generate", action="store_true",
                        help="生成一个强随机密码而不是手工输入")
    parser.add_argument("--list", action="store_true", help="只列出账号，不修改")
    parser.add_argument("--host", default=None, help="面板监听地址（默认 127.0.0.1）")
    parser.add_argument("--port", type=int, default=None, help="面板端口（默认 5000）")
    args = parser.parse_args()

    store_path = config.user_store_path()

    if args.list:
        print_accounts(store_path)
        return 0

    host = args.host or config.WEB_HOST or "127.0.0.1"
    port = int(args.port or config.WEB_PORT or 5000)

    print("=" * 60)
    print("  Computer Use Agent — 密码重置")
    print("=" * 60)
    print(f"  账号文件：{store_path}")

    # Refuse while the panel is up: it holds the account store in memory and
    # would overwrite whatever we write here.
    if port_is_live(host, port):
        print()
        print(f"  !! 检测到 {host}:{port} 上还有面板在运行。")
        print("     面板在内存里缓存了账号数据，现在改文件会在下次保存时被覆盖。")
        print()
        print("     请先停止面板（关闭它的终端窗口，或按 Ctrl+C），再运行本工具。")
        return 2

    data = load_accounts(store_path)
    users = data["users"]

    if args.user:
        target = next((u for u in users
                       if str(u.get("name", "")).lower() == args.user.lower()), None)
        if target is None:
            names = ", ".join(u.get("name", "?") for u in users)
            raise SystemExit(f"找不到用户 '{args.user}'。现有账号：{names}")
    else:
        # Exactly one account is the common case and needs no question.
        if len(users) == 1:
            target = users[0]
            print(f"  唯一账号：{target.get('name')}")
        else:
            print_accounts(store_path)
            print()
            target_name = input("  要重置哪个账号？").strip()
            target = next((u for u in users
                           if str(u.get("name", "")).lower() == target_name.lower()), None)
            if target is None:
                raise SystemExit("账号名不匹配，已取消。")

    name = target.get("name", "")
    print(f"\n  即将重置 '{name}' 的密码。")

    new_password = args.password or read_new_password(args.generate)

    problem = auth.password_problem(new_password)
    if problem:
        raise SystemExit(f"  密码不可用：{problem}")
    if new_password == args.password:
        print(f"  强度评分：{auth.password_strength(new_password)}/100")

    # Reuse the store so the write path, hashing cost and file layout are
    # identical to a normal password change — no second code path to drift.
    user_store = auth.UserStore(store_path=store_path,
                                audit_path=config.audit_log_path(),
                                session_ttl=config.SESSION_TTL)
    if user_store.get(name) is None:
        raise SystemExit(f"读取账号列表时找不到 '{name}'，已取消。")

    user_store.set_password(name, new_password, must_change=False)
    # Any live session for that user is now worthless; the store is in memory
    # only when the panel is running, which we already refused.
    user_store.record(name, "password.reset", "ok",
                      detail="local recovery tool", ip="localhost")

    print()
    print(f"  已更新 '{name}' 的密码。")
    print(f"  账号文件：{store_path}")
    print()
    print("  下一步：")
    print("    1. 重新启动面板  python run_web.py")
    print("    2. 用新密码登录")
    if not args.generate:
        print("    （如果之前勾选了「登录后修改初始密码」，该标记已清除）")
    print()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n已取消。")
        raise SystemExit(1)
    except OSError as e:
        raise SystemExit(f"文件操作失败：{e}")