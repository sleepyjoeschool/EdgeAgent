"""Generate independent Tool Call Schemes for the two connectors.

Spawns each connector's MCP (stdio) server, calls ``tools/list`` and writes a
``prompt-content-json/<Name>_Scheme.json`` file in the exact same shape as the
existing ``Basic_Function.json`` (category / description / tools / examples).

Every tool name is prefixed (``CodeModify_`` / ``FullChrome_``) so the agent's
prefix-based dispatcher routes calls back to ``cua.executors.connector``.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from cua.executors.connector import CONNECTORS, MCPClient  # noqa: E402

OUT_DIR = ROOT / "prompt-content-json"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Short, human description per connector category.
DESCRIPTIONS = {
    "codemodify": (
        "CodeModify connector (agent-fs): a controlled file & code framework exposed "
        "as an MCP server — directory exploration, file search, line/column-precise "
        "read-write, search-replace & patches, multi-file transactions, single-file "
        "permission approval, isolated Python execution, snapshot rollback, file locks, "
        "turtle drawing and a safe math engine. PREFER this connector over generic shell "
        "file commands whenever a task touches files or code on disk."
    ),
    "fullchrome": (
        "FullChrome connector (agent-browser): a real, visible Chrome window driven as an "
        "MCP server — navigate, snapshot interactive elements, click/type/press, scroll, "
        "read page content, screenshot, window control (incl. background 'parked' mode) and "
        "cookies/fingerprint. PREFER this connector over the built-in screen-capture/keyboard/"
        "mouse flow for any web browsing task — it is far more reliable and leaves an audible "
        "automation trail off the page."
    ),
}

# A handful of representative usage examples per connector (name already prefixed).
EXAMPLES = {
    "codemodify": [
        {"user": "List the top two levels of D:/Projects/myproj.",
         "assistant": {"name": "CodeModify_fs_list",
                       "arguments": {"path": "D:/Projects/myproj", "depth": 2}}},
        {"user": "Read lines 10-25 of src/app.py.",
         "assistant": {"name": "CodeModify_fs_read_lines",
                       "arguments": {"path": "src/app.py", "start": 10, "end": 25}}},
        {"user": "Replace 'foo' with 'bar' in config.json (preview first).",
         "assistant": {"name": "CodeModify_edit_replace",
                       "arguments": {"path": "config.json", "old": "foo", "new": "bar"}}},
        {"user": "I need to create a new export file — ask the operator for permission.",
         "assistant": {"name": "CodeModify_perm_request",
                       "arguments": {"kind": "create", "path": "D:/Projects/myproj/export.csv",
                                     "reason": "Need to write an export artifact"}}},
        {"user": "Evaluate sqrt(3)^2 + 2^10 safely.",
         "assistant": {"name": "CodeModify_math_eval",
                       "arguments": {"expr": "sqrt(3)^2 + 2^10"}}},
    ],
    "fullchrome": [
        {"user": "Open https://www.example.com in the browser.",
         "assistant": {"name": "FullChrome_browser_navigate",
                       "arguments": {"url": "https://www.example.com"}}},
        {"user": "Get the clickable elements on the current page.",
         "assistant": {"name": "FullChrome_browser_snapshot", "arguments": {}}},
        {"user": "Click the element indexed 3.",
         "assistant": {"name": "FullChrome_browser_click", "arguments": {"index": 3}}},
        {"user": "Give me the page as markdown.",
         "assistant": {"name": "FullChrome_browser_content",
                       "arguments": {"format": "markdown"}}},
        {"user": "Move the window to the background but keep it rendering.",
         "assistant": {"name": "FullChrome_browser_window", "arguments": {"mode": "parked"}}},
    ],
}


def build_scheme(key: str) -> dict:
    info = CONNECTORS[key]
    client = MCPClient(key, info["command"], list(info["args"]), info["cwd"])
    try:
        raw_tools = client.list_tools()
    finally:
        client.close()
    prefix = info["prefix"]
    tools = []
    for t in raw_tools:
        schema = dict(t.get("inputSchema") or {"type": "object", "properties": {}})
        tools.append({
            "type": "function",
            "function": {
                "name": prefix + t["name"],
                "description": t.get("description", ""),
                "parameters": schema,
            },
        })
    return {
        "category": key,
        "description": DESCRIPTIONS[key],
        "tools": tools,
        "examples": EXAMPLES[key],
    }


def main() -> int:
    file_map = {
        "codemodify": "CodeModify_Scheme.json",
        "fullchrome": "FullChrome_Scheme.json",
    }
    for key, fname in file_map.items():
        scheme = build_scheme(key)
        out = OUT_DIR / fname
        out.write_text(json.dumps(scheme, ensure_ascii=False, indent=2),
                       encoding="utf-8")
        print(f"[ok] {fname}: {len(scheme['tools'])} tools")
    return 0


if __name__ == "__main__":
    sys.exit(main())
