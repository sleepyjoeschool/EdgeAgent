@echo off
rem ============================================================
rem  启动 CUA WebUI（后台运行，关掉本窗口也不停）
rem
rem  双击本文件即可。优先使用项目内的虚拟环境，其次使用
rem  PATH 上的 python。
rem
rem  停止服务：任务管理器结束对应 python 进程。
rem ============================================================
setlocal
cd /d "%~dp0"

set "PY="
if exist ".venv\Scripts\python.exe"  set "PY=.venv\Scripts\python.exe"
if not defined PY if exist "venv\Scripts\python.exe"  set "PY=venv\Scripts\python.exe"
if not defined PY (
  where py >nul 2>nul && set "PY=py"
)
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)

if not defined PY (
  echo 找不到 Python。请先安装 Python 3.10+，或在本目录创建 .venv 虚拟环境：
  echo     python -m venv .venv
  echo     .venv\Scripts\pip install -r requirements.txt
  pause
  exit /b 1
)

echo.
echo 正在启动 CUA WebUI ...
echo   解释器：%PY%
echo   地址： 默认 http://127.0.0.1:5000（端口可用 CUA_WEB_PORT 修改）
echo.

rem start /b 让子进程不继承本控制台，脚本退出后服务继续运行。
start "CUA WebUI" /b %PY% "%~dp0run_web.py"

echo 已启动。首次打开浏览器会引导你设置管理员密码。
echo 若浏览器打不开，先等 5 秒再刷新。
timeout /t 8 >nul
endlocal
