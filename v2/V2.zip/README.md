# Computer Use Agent

用 Python 实现的桌面自动化代理（CUA），通过 **WebUI** 操控。

自然语言任务 → LLM 决定调用哪个本地技能 → 真实敲击键盘、移动鼠标、执行 Shell → 回看屏幕 → 循环，直到任务完成。
所有工具调用都是**真实副作用**——它不是聊天机器人。

```
pip install -r requirements.txt
python run_web.py --open          # 浏览器打开 http://127.0.0.1:5000
```

> ⚠️ 运行期间代理会真实占用鼠标与键盘。请保持双手离开外设。

**首次打开时没有账号，也没有任何默认密码**：面板会带你进入「设置管理员密码」页面
（`webui/static/setup.html`），创建用户名和密码后自动登录，继续配置模型 API 即可。

---

## 快速开始

要求 Python 3.10+；离线 OCR 用的 Paddle 栈按 Python 3.11 构建，建议直接用 3.11。

```bash
# 1. 安装基础依赖
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt        # Windows
# source .venv/bin/activate && pip install -r requirements.txt   # macOS / Linux

# 2. 启动面板
python run_web.py --open
#   或双击 start_webui.cmd（Windows，后台常驻）
```

首次打开 `http://127.0.0.1:5000` 会依次经历：

1. **设置管理员账号**（独立页面，密码首次打开时由你设置，服务端无任何默认值）；
2. **配置模型 API**（任意 OpenAI 兼容端点：Base URL / 模型 ID / API Key，先测试后保存）；
3. **能力确认**（自动探测模型是否支持思维链与视觉，给出建议配置）；
4. 进入控制台。

## 目录结构

```
cua/                        核心包（合法包名，可直接 import）
├── config.py               三级配置：环境变量 > config_override.json > 默认值
├── llm_client.py           OpenAI 兼容客户端 + 按模型能力解析请求参数
├── tool_loader.py          从 JSON 载入工具定义（按需加载）
├── engine.py               ★ 唯一的 Agent 主循环（双层：step / round）
├── runtime.py              运行控制：暂停 / 中断 / 逐步执行 / 人工审批
├── context.py              ToolContext：给执行器的上下文（替代全局状态）
├── events.py               事件词汇表 —— 内核与前端之间的唯一契约
├── security_check.py       Shell 第二阶段：LLM 审计 + 人工确认桥
├── auth.py                 账号：PBKDF2 哈希、服务端会话、锁定与审计
├── sessions.py             会话存储：一个会话一个 JSON 文件（上下文 + 轨迹）
├── ocr_engine.py           OCR 后端（内置 PaddleOCR / 外部 Umi-OCR）
├── multimodal.py           VLM 传输层（OpenAI / Anthropic / Gemini / legacy）
├── inline_vision.py        截图以 image_url 直接附加到主模型
├── desktop.py              对被控端依赖的惰性封装
├── token_cache.py          前缀缓存命中口径（与上游 KV cache 对齐）
├── token_usage.py          用量统计（仅四个可精确计数的模型）
├── tokencalc_bridge.py     内置 token 计数器适配层（vendor/tokencalc）
└── executors/              技能执行器，统一 execute(fn, args, ctx) -> str
    ├── keyboard.py  mouse.py  shell.py
    ├── screen_capture.py  vlm.py  basic.py
    └── connector.py        外部连接器（MCP stdio：文件/浏览器/SSH）

webui/
├── server.py               Flask + SSE 控制台
└── static/                 单页前端（无构建工具，改完刷新即可）
    ├── setup.html          首次运行：设置管理员密码（独立首启页）
    ├── index.html          控制台 + 登录/改密门禁
    ├── app.js  style.css
    ├── api-wizard.html     模型 API 配置向导（独立页面）
    └── 404.html  5xx.html  非 API 请求的错误页

prompt-content-json/        工具定义（system prompt + function schema）
scripts/                    依赖下载、密码重置、schema 生成
tests/                      冒烟测试（LLM 传输层已打桩，无需密钥）
models/                     YOLO 权重放置目录（不随仓库分发）
vendor/                     可选重依赖（脚本下载，见 vendor/README.md）
```

---

## 架构：分步式（Step-by-Step）

这是整份代码最关键的设计：

```
for step in 1..MAX_STEPS:                  外层：每个 step 完成「一个逻辑操作」
    ├─ 重置工具集（上一步加载的分类全部作废）
    ├─ while round < MAX_INTERNAL_ROUNDS:  内层：一次 LLM 调用 = 一轮 tool call
    │   ├─ 流式请求（tools = 当前活跃工具）
    │   ├─ 有 tool_calls → 派发 → 结果追加为 tool 消息
    │   ├─ 同时返回 content 且已调用领域工具 → 视为本步总结，收尾
    │   └─ 只有 content 无 tool_calls → 本步收尾
    ├─ 判断是否以 TASK_COMPLETE 开头
    ├─ 三步相似度卡死检测
    └─ 裁剪上下文 → 注入 continue prompt → 下一步
```

**每步结束后 `messages` 被压缩成：**

```
system_prompt + 原始请求 + 历次步骤总结
```

思考链、工具调用、工具结果**全部丢弃**。模型只能靠自己写的总结来记忆状态，
总结写差了后续就会跑偏。附带 inline 截图的 user 消息会被特意保留，否则多模态
代理在第一步之后就瞎了。

---

## 相对参考实现改了什么

| 参考实现 | 本实现 |
|---|---|
| 主循环在 `main.py` / `gui.py` / `web_panel.py` 里实现了三份，行为逐渐漂移 | `cua/engine.py` 只有一份；前端只渲染事件 |
| 包目录名带连字符，只能用 `importlib.util.spec_from_file_location` 绕开包导入 | 合法包名 `cua`，直接 `from cua import ...` |
| 无条件发送 `reasoning_effort` 与 `extra_body={"thinking":...}`，换非思维链模型直接报错 | `LLM_CAPABILITY` 按模型推断，可显式覆盖 |
| 屏幕截图的目标对话列表存在模块级全局变量里 | 通过 `ToolContext` 传入，两次任务互不污染 |
| 人工确认写死为 Win32 MessageBox / tkinter 弹窗 | 抽象为 `Runtime`，WebUI 里是浏览器确认卡片 |
| **安全审计失败时静默放行** | 审计不可用是独立状态，默认改为询问操作者 |
| YOLO 默认走云端，而云端 URL/KEY 默认为空，开箱必报错 | 默认 `bundled`（本地权重），找不到权重时返回可操作的错误 |
| 缺失依赖时 import 阶段就崩 | 依赖惰性加载，缺失时降级为工具级错误，服务照常启动 |

保留未动的合理设计：meta-tool 按需加载、UUID 结果注册表、删除采用「发送前过滤」
（满足 OpenAI 协议「有 tool_call 就必须有对应 tool 消息」的约束）、看门狗、
空响应重试、静态 + LLM 两阶段 Shell 拦截。

---

## 感知三层

| 层次 | 手段 | 回答什么 | 成本 |
|---|---|---|---|
| 1 | OCR（`CaptureScreen`） | 屏幕上**写着什么** | 低，离线 |
| 2 | YOLO（`DetectObjects`） | 东西**在哪** | 中，本地权重 |
| 3 | VLM / inline 截图 | 画面**意味着什么** | 高，走 API |

提示词明确要求模型用「能回答该问题的最便宜那一层」。

**视觉模式**

- `multimodal` — 主模型本身支持图片，截图以 `image_url` 直接并入对话，无需独立 VLM。
- `text_vlm` — 文本主模型 + 独立多模态端点（`VLM_Action_*` 调用）。
- `auto` — 主模型看起来支持视觉且没配 VLM 时选 `multimodal`，否则 `text_vlm`。

---

## 工具集

初始只暴露三个元工具加 `basic`，其余通过 `LoadSkillCategory` 按需装载：

| category | 工具数 | 内容 |
|---|---|---|
| `keyboard` | 3 | 瞬时输入、逐字输入、组合键 |
| `mouse` | 7 | 取位、移动（瞬时/带时长）、左键、右键、双击、滚轮 |
| `shell` | 2 | 同步执行（120s 超时）、异步启动（GUI 程序） |
| `screen_capture` | 3 | OCR、YOLO、inline 截图 |
| `vlm` | 2 | 分析屏幕、分析 Base64 图片 |
| `basic` | 7 | 计数、数字序列、剪贴板读写、等待、人工操作、人工输入 |
| `codemodify` / `fullchrome` / `ssh` | 外部连接器 | 可选，见下 |

### 可选连接器

三个外部 MCP 连接器按需接入（`cua/executors/connector.py`）。连接器套件不在本仓库，
通过环境变量指向即可；未配置时相关工具调用会返回明确的配置提示，不影响其他功能：

```bash
CUA_CONNECTOR_KIT_DIR=/path/to/connector-kit   # CodeModify(agent-fs) + FullChrome(agent-browser)
CUA_SSH_CLIENT_DIR=/path/to/ssh-client         # 远程 SSH（自带 venv）
```

---

## WebUI

**首启页** — 首次打开（尚无管理员）时 `/` 直接显示 `setup.html`：欢迎 → 设置用户名
与密码（含服务端强密码生成器）→ 完成并自动登录。

**任务页** — 下发任务、实时事件流（可折叠的思考过程 / 工具调用卡片含参数与返回值 /
步骤总结）、暂停·继续·下一步·中断、以及危险命令的确认弹窗。

**桌面页** — 每 1.5 秒刷新的实时预览；点击图像可读出该点在真实屏幕上的坐标。

**感知页** — 三层的就绪状态与工具清单。

**设置页** — 主模型 / 视觉 / VLM / OCR / YOLO / 安全策略，含连通性自测。
密钥写入本地 `config_override.json`，掩码显示，留空表示「不改动」。

**错误页** — 非 API 路径的 404 / 5xx 返回 `webui/static/404.html` 与 `5xx.html`；
`/api/*` 始终返回 JSON（程序解析 JSON，人看页面）。

### 安全

- Shell 命令先过静态规则（管道远程执行、`Invoke-Expression`、`eval`、注册表写入、格式化等）
- 存活者再交给安全模型进行 JSON 审计；判定危险则在 WebUI 弹出确认卡片，默认拒绝
- 审计不可达时按 `SHELL_AUDIT_FAILURE_POLICY` 处理（默认 `ask`，即转人工）
- 账号密码以 PBKDF2-HMAC-SHA256 哈希 + 每用户盐存储在 `users.json`，从不写明文；
  登录失败锁定、服务端会话、CSRF 校验
- 默认只监听 `127.0.0.1`。若需局域网访问：`python run_web.py --lan`

---

## 配置优先级

```
环境变量  >  config_override.json  >  config.py 默认值
```

`config_override.json` 由设置页写入，**不进版本库**（`users.json`、`audit.log`、
`cua/sessions/` 同理，见 `.gitignore`）。

常用环境变量：`CUA_LLM_API_KEY` `CUA_LLM_BASE_URL` `CUA_LLM_MODEL`
`CUA_VISION_MODE` `CUA_OCR_ENGINE` `CUA_YOLO_INFERENCE_MODE` `CUA_MAX_STEPS`
`CUA_WEB_HOST` `CUA_WEB_PORT` `CUA_RUN_ROOT` `CUA_SESSION_DIR`

### 可选重依赖（感知与统计）

仓库只含代码；以下组件用脚本获取（缺失时面板照常启动，对应能力标注为不可用）：

```bash
python scripts/bootstrap_vendor.py            # Paddle 栈 + 分词器
python scripts/bootstrap_vendor.py --check    # 查看现状
python scripts/bootstrap_vendor.py --paddle-env <已装好的目录>   # 离线复制
python scripts/bootstrap_vendor.py --ocr-models <权重目录>       # PP-OCR 权重
```

- **本地 OCR**：`vendor/paddle_env`（由脚本安装）；权重可用
  `--ocr-models` 摆放，或让 PaddleOCR 首次运行时自动下载到 `~/.paddlex`。
- **本地 YOLO**：权重放 `models/best.pt`，或设 `YOLO_MODEL_PATH` 指向现成文件
  （权重另行托管，见 `models/README.md`）。
- **精确 token 统计**：`vendor/tokencalc`（代码已提交，分词器由脚本下载）。

---

## 测试

```
python tests/smoke_engine.py     # 主循环：工具调用分片 / 卡死检测 / 上下文裁剪
python tests/smoke_webui.py      # 全栈：任务 → SSE → 审批往返 → 真实执行
python tests/test_auth.py        # 账号、密码、会话、锁定、CSRF
python tests/test_probe.py       # 能力探测
python tests/smoke_dist.py       # 打包产物检查（需先 build_exe.py）
python tests/test_package.py     # 产物完整端到端（需先 build_exe.py）
```

`smoke_engine.py` 与 `smoke_webui.py` 直接给引擎喂假的 OpenAI 客户端，
不联网、不需要密钥；`smoke_webui.py` 里那条 Shell 命令是故意选的无害 `echo`。

---

## 打包（可选）

```bash
python build_exe.py --include-model models/best.pt   # 全量（含 OCR / 本地 YOLO）
python build_exe.py --slim                           # 去掉 torch/ultralytics
python build_exe.py --no-paddle                      # 连 OCR 也不要
```

产物：`dist/ComputerUseAgentWeb/ComputerUseAgentWeb.exe`，双击运行，
目标机无需安装 Python。Paddle 栈与 OCR 权重来自项目内的 `vendor/`（脚本获取），
不读任何项目外部路径。

---

## 排障

| 现象 | 原因 / 处理 |
|---|---|
| 启动后 OpenAI 报 401 | 未配置密钥。设置页填写 `LLM_API_KEY`，或设 `CUA_LLM_API_KEY` |
| 换模型后报「不支持 reasoning_effort」 | 由 `LLM_CAPABILITY=auto` 推断；仍不对则手动设为 `plain` |
| 第一次 OCR 要等 | PaddleOCR 首次载入模型，之后同一进程内秒级返回 |
| `YOLO weights not found` | `models/` 下放 `.pt`，或设 `YOLO_MODEL_PATH`；不需要时 `CUA_YOLO_INFERENCE_MODE=off` |
| 执行器报 `'pyautogui' is not available` | 缺包，`pip install pyautogui`；服务本身仍可启动 |
| 任务看起来卡住不动 | 桌面页看实时画面；多数情况是某步在等待人工——检查是否有未处理的确认卡片 |
| 代理反复做同一件事 | 三步总结相似度超阈值会主动中止；可勾选「逐步确认」人工把方向掰回来 |
| 打不开面板 / 页面报错 | 打开 `http://127.0.0.1:5000` 看是否为错误页；`run_web.py` 的启动失败会写 `web_crash.log` |
| 忘记密码 | 停止面板后运行 `python scripts/reset_password.py`（本地工具，不提供 HTTP 重置端点） |
