"""Flask control panel for the Computer Use Agent.

Design notes
------------

*A single mission at a time.* Executors drive the real mouse and keyboard;
two concurrent missions would fight over the pointer. Requests to start a
second mission while one is running are rejected with HTTP 409.

*SSE for streaming, POST for commands.* One long-lived ``/api/events`` stream
carries every engine event; all client actions are plain JSON posts. This
keeps reconnects trivial — a dropped stream can be re-subscribed without
losing mission state, because the transcript lives server-side.

*Approvals block the engine thread, not the server.* A dangerous shell command
parks the mission on a threading.Event until the browser answers. Flask runs
threaded, so the SSE stream and the approval endpoint stay responsive.

*Authentication is account-based, not a shared password.* See ``cua/auth.py``
for the hashing and session design. Three layers guard the endpoints:

1. ``/api/hello`` and ``/api/setup/account`` are reachable without a session —
   the first must be, so the browser can learn it needs to authenticate, and the
   second only works while no administrator exists.
2. Every other API call resolves the session cookie to a live server-side
   record. A missing or stale token is 401.
3. State-changing calls must additionally present the session's CSRF token in
   a header. Cookies are ``SameSite=Lax``, which already blocks cross-site
   form posts, but an explicit header means a cross-origin ``fetch`` from
   anywhere fails too.

*Roles gate capability, not just visibility.* ``viewer`` can watch the mission
transcript but cannot start one, answer an approval, or touch settings. The
check is enforced server-side in the decorator rather than only by hiding
buttons, because hiding buttons is not a security property.

*Setup is two phases.* ``/api/setup/account`` creates the administrator, then
``/api/setup/probe`` interrogates the model endpoint *without saving anything*
and ``/api/setup/llm`` persists what the operator confirmed. Splitting them means
an endpoint that turns out to be unusable can be retried without recreating the
account, and — more importantly — a probe can never damage a configuration
that already works.
"""

from __future__ import annotations

import base64
import binascii
import io
import json
import mimetypes
import os
import platform
import queue
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from functools import wraps
from pathlib import Path
from typing import Any

from flask import (
    Flask, Response, jsonify, redirect, request, send_from_directory,
)
from werkzeug.exceptions import HTTPException

from cua import __version__
from cua import config, desktop, llm_client, model_probe, modes, tool_loader
from cua import auth
from cua import backend
from cua import token_usage, tokencalc_bridge
from cua.auth import ROLE_LABELS, UserStore, create_store
from cua.engine import AgentEngine
from cua.executors import describe_perception
from cua.runtime import CallbackRuntime
from cua.sessions import SessionStore, title_from_task

# Formats the panel bundles that the platform mime table may not know about.
# Python resolves these from the system registry on Windows and /etc/mime.types
# elsewhere, so .webp in particular is recognised on some machines and not
# others — a bug that only ever reproduces on the machine you did not test on.
EXTRA_MIMETYPES = {
    ".webp": "image/webp",
    ".avif": "image/avif",
    ".woff2": "font/woff2",
    ".wasm": "application/wasm",
}
for _ext, _type in EXTRA_MIMETYPES.items():
    mimetypes.add_type(_type, _ext)


STATIC_DIR = Path(__file__).resolve().parent / "static"

SESSION_COOKIE = "cua_session"


# ── Application ─────────────────────────────────────────────────────────

def create_app() -> Flask:
    """Build the Flask object.

    Routes are attached below by their own decorators rather than by a
    registration function, because they need the module-level ``app`` to
    exist first — including from ``run_web.py``, which installs an extra
    ``before_request`` hook on this same object.
    """
    app = Flask(__name__, static_folder=None)
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    # The panel no longer keeps any state in Flask's signed cookie: the session
    # token is an opaque random string resolved against a server-side record.
    # A per-process random secret is still set so that Flask's session
    # machinery stays available (and silent) for anything that reaches for it.
    app.secret_key = os.urandom(32)
    return app


app = create_app()


# ── Mission state ──────────────────────────────────────────────────────

class MissionHub:
    """Server-side transcript, subscriber fan-out and approval plumbing.

    Missions run against a *session*, which owns both the model context and
    the persisted log. ``self.session`` is the one currently mounted — the
    engine mutates its message list in place, so by the time a mission ends
    the session already carries the updated context and only has to be
    written.

    Only one mission may run at a time, and therefore only one session. The
    agent drives the real mouse and keyboard; two concurrent runs would fight
    over the pointer.
    """

    def __init__(self, sessions: SessionStore | None = None) -> None:
        self.lock = threading.RLock()
        self.subscribers: list[queue.Queue] = []
        self.transcript: list[dict] = []
        self.runtime = CallbackRuntime(
            approval_hook=self._await_approval,
            text_hook=self._await_text,
        )
        self.thread: threading.Thread | None = None
        self.state = "idle"           # idle | running | paused
        self.task = ""
        self.started_at = 0.0
        self.outcome: dict | None = None
        self.actor = ""               # who started the current mission

        self.pending: dict | None = None
        self.pending_event = threading.Event()
        self.pending_result: Any = False

        self.sessions = sessions if sessions is not None else SessionStore()
        self.session = None           # Session | None
        self._last_flush = 0.0

    # ── Sessions ───────────────────────────────────────────────────────
    @property
    def session_id(self) -> str | None:
        return self.session.id if self.session else None

    def flush(self, force: bool = False) -> None:
        """Write the mounted session to disk.

        Throttled rather than per-event: a mission emits hundreds of events,
        and rewriting the whole file after each one would be IO-bound busywork
        for a log nobody is reading yet. Terminal events force a write so a
        finished session is never left half-saved.
        """
        session = self.session
        if session is None:
            return
        now = time.time()
        if not force and now - self._last_flush < config.SESSION_FLUSH_INTERVAL:
            return
        self._last_flush = now
        self.sessions.save(session)

    # ── Subscriptions ──────────────────────────────────────────────────
    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=500)
        with self.lock:
            self.subscribers.append(q)
        # Tell a fresh subscriber where things stand right now, instead of
        # leaving it guessing until the next state change. This is what makes
        # a reconnect (or a page opened mid-mission) render correctly.
        try:
            q.put_nowait({
                "type": "status",
                "ts": time.time(),
                "state": self.state,
                "pending": self.pending is not None,
                "session": self.session_id,
            })
        except queue.Full:
            pass
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self.lock:
            if q in self.subscribers:
                self.subscribers.remove(q)

    def emit(self, event: dict) -> None:
        """Sink used by the engine."""
        dirty = False
        with self.lock:
            if self.session is not None:
                event["session"] = self.session.id
                # Status events describe the transport, not the work. Keeping
                # them out of the file stops a replayed session from flipping
                # the sidebar to "running" and back for no reason.
                if event.get("type") != "status":
                    self.session.transcript.append(event)
                    dirty = True
            self.transcript.append(event)
            if len(self.transcript) > 4000:
                self.transcript = self.transcript[-2000:]
            for q in list(self.subscribers):
                try:
                    q.put_nowait(event)
                except queue.Full:
                    # A stalled reader must not stall the agent.
                    try:
                        self.subscribers.remove(q)
                    except ValueError:
                        pass
        # Outside the lock: a write is the one thing here that can block.
        if dirty:
            self.flush()

    # ── Lifecycle ──────────────────────────────────────────────────────
    @property
    def busy(self) -> bool:
        """Whether a mission is still making decisions.

        Deliberately *not* "the worker thread is alive": once the outcome is
        posted the thread is only flushing the session to disk. Counting that
        tail as busy rejects a mission the operator is entitled to start, and
        the window is real — the panel re-enables 执行 on ``run_done``, which
        the engine emits before this hub's bookkeeping runs.
        """
        if self.outcome is not None:
            return False
        return bool(self.thread and self.thread.is_alive())

    def start(self, task: str, max_steps: int | None, step_mode: bool,
              actor: str = "", session_id: str | None = None,
              full_access: bool = False, agent_mode: str = "gui",
              workspace: str = "", model: str = "") -> "object":
        """Run *task*, mounted on a session.

        An unknown ``session_id`` is not created implicitly: the caller gets
        the session back and reports it, rather than the panel silently
        inventing a new one when an operator clicks a stale entry.

        ``full_access`` / ``agent_mode`` / ``workspace`` / ``model`` come from
        the composer / landing page and are threaded into the agent so the UI
        controls map to real behaviour.
        """
        # A finished worker can still be on its way out — it writes the
        # session file after posting the outcome. Let it land before a new one
        # is mounted, or its ``finally`` would set hub.state back to "idle"
        # (and flush) while the next mission is already running.
        previous = self.thread
        if previous is not None and previous.is_alive():
            previous.join(timeout=5.0)

        session = self.sessions.get(session_id) if session_id else None
        if session_id and session is None:
            return None
        if session is None:
            session = self.sessions.create(owner=actor)
        self.session = session
        session.runs += 1
        if not session.title:
            session.title = title_from_task(task)

        # No folder chosen → give the run its own timestamped directory under
        # the configured parent. Recorded on the session so the list can group
        # it as a 任务 (a run that was not tied to a folder) rather than a 空间.
        if workspace:
            session.workspace_kind = "folder"
        else:
            created = config.make_run_dir()
            if created:
                workspace = created
                session.workspace_kind = "auto"
            elif not session.workspace:
                session.workspace_kind = "none"
        session.workspace = workspace

        # Seed the live replay buffer from the session's history, so a browser
        # that reloads mid-run sees the earlier steps too — not just whatever
        # happens next.
        self.transcript.clear()
        self.transcript.extend(session.transcript[-300:])
        self.outcome = None
        self.task = task
        self.actor = actor
        self.started_at = time.time()
        self.state = "running"
        self.runtime.resume_from_abort()
        self.runtime.step_mode = bool(step_mode)
        # Full-access mode auto-approves shell commands for this mission;
        # the workspace is exposed on the runtime so executors can sandbox it.
        self.runtime.full_access = bool(full_access)
        self.runtime.workspace = workspace or ""

        hub = self

        def sink(event: dict) -> None:
            hub.emit(event)

        agent = AgentEngine(emit=sink, runtime=self.runtime,
                            model=model or None, agent_mode=agent_mode,
                            workspace=workspace or "",
                            session_id=session.id)

        def worker() -> None:
            try:
                # The session's message list is handed over by reference; the
                # engine compresses and appends to it in place, so it leaves
                # this call already holding the continuing context.
                outcome = agent.run(task, max_steps=max_steps,
                                    messages=session.messages)
                hub.outcome = {
                    "finished": outcome.finished,
                    "reason": outcome.reason,
                    "steps": outcome.steps,
                    "elapsed": round(outcome.elapsed, 2),
                    "final_summary": outcome.final_summary,
                }
                session.steps += outcome.steps
                session.last_reason = outcome.reason
            except Exception:  # noqa: BLE001 - surfaced through the event log
                session.last_reason = "error"
                hub.emit({
                    "type": "error",
                    "ts": time.time(),
                    "message": traceback.format_exc(limit=6),
                    "fatal": True,
                })
            finally:
                hub.state = "idle"
                # Forced: a finished session must never be left half-written.
                hub.flush(force=True)

        self.thread = threading.Thread(target=worker, daemon=True, name="cua-mission")
        self.thread.start()
        return session

    # ── Approval bridge ────────────────────────────────────────────────
    def _await_approval(self, request_payload: dict) -> bool:
        return bool(self._park(request_payload))

    def _await_text(self, request_payload: dict) -> str | None:
        result = self._park(request_payload)
        return result if isinstance(result, str) else None

    def _park(self, payload: dict):
        self.pending = payload
        self.pending_result = False
        self.pending_event.clear()
        self.emit({"type": "status", "ts": time.time(), "state": "awaiting_approval"})

        timeout = float(payload.get("timeout") or config.APPROVAL_TIMEOUT)
        answered = self.pending_event.wait(timeout=timeout)

        self.pending = None
        if not answered:
            # Timeout: apply the configured headless policy rather than
            # hanging the mission forever.
            policy = (config.HEADLESS_DANGER_POLICY or "deny").strip().lower()
            return payload.get("kind") != "shell" or policy == "allow"
        return self.pending_result

    def answer(self, approved: bool, text: str = "") -> bool:
        if self.pending is None:
            return False
        self.pending_result = text if text else bool(approved)
        self.pending_event.set()
        return True


hub = MissionHub()

# Bring back the previous run's token ledger, so the statistics page does not
# start empty after a restart. Best-effort by design: a corrupt or missing
# file must not stop the panel from starting (see token_usage.load).
token_usage.load()


# ── Authentication ──────────────────────────────────────────────────────

store: UserStore = create_store()


def current_session():
    """Resolve the request's session cookie to a live session, or None."""
    return store.validate_session(request.cookies.get(SESSION_COOKIE))


def current_user():
    session = current_session()
    if session is None:
        return None
    return store.get(session.user)


def client_ip() -> str:
    return request.remote_addr or "127.0.0.1"


# Lifetime granted when the operator does not tick "keep me signed in". Long
# enough to finish a session, short enough that an unattended machine does not
# stay unlocked indefinitely.
SHORT_SESSION_TTL = 3600


def set_session_cookie(response, token: str, remember: bool = True) -> None:
    """Attach the session cookie.

    ``remember=False`` issues a one-hour cookie instead of the configured long
    one. The cookie lifetime is only half the control — the server-side session
    record carries its own expiry, so this is capped by that regardless.
    """
    ttl = int(config.SESSION_TTL) if remember else SHORT_SESSION_TTL
    response.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=ttl,
        httponly=True,
        samesite="Lax",
        # Secure is deliberately not forced: the panel is normally reached over
        # plain HTTP on localhost or a trusted LAN, where a Secure cookie would
        # simply never be sent back and nobody could stay logged in.
        secure=request.is_secure,
        path="/",
    )


def unauthenticated_response(message: str = "authentication required"):
    return jsonify({
        "error": message,
        "needs_setup": store.needs_setup,
        "authenticated": False,
    }), 401


def login_required(fn=None, *, capability: str = "view"):
    """Require a live session, and optionally a capability.

    Usable bare (``@login_required``) or parameterised
    (``@login_required(capability="control")``). ``functools.wraps`` keeps the
    wrapped function's name, which is what Flask uses as the endpoint — without
    it every route would register under the same name and collide.
    """

    def decorate(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if store.needs_setup:
                return jsonify({
                    "error": "panel setup has not been completed",
                    "needs_setup": True,
                }), 503
            session = current_session()
            if session is None:
                return unauthenticated_response()
            if capability:
                user = store.get(session.user)
                if not store.can(user, capability):
                    return jsonify({
                        "error": (
                            f"需要 '{capability}' 权限"
                            f"（当前角色：{ROLE_LABELS.get(session.role, session.role)}）"
                        ),
                        "forbidden": True,
                    }), 403
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                # CSRF: the header cannot be set by a cross-origin form post,
                # and requires the token that only this session was handed.
                token = request.headers.get("X-CSRF-Token")
                if not store.validate_csrf(session, token):
                    return jsonify({"error": "CSRF 校验失败，请刷新页面"}), 403
            return func(*args, **kwargs)
        return wrapper

    return decorate if fn is None else decorate(fn)


def admin_required(fn):
    """Shorthand for the many endpoints only an administrator may reach."""
    return login_required(fn, capability="admin")


# ── Error handling ──────────────────────────────────────────────────────
#
# Non-API requests get the bundled HTML error pages; API clients keep the
# JSON they parse. The split is by path (/api/... vs everything else),
# because the two audiences need different things — a person who mistyped a
# URL should see a page, a program should get a machine-readable error.

def _error_page(filename: str, status: int):
    """Serve one of the bundled error pages, with a plain-text fallback.

    The fallback matters: this also runs when the static tree itself is the
    thing that went wrong, and an error handler must never raise.
    """
    try:
        return send_from_directory(STATIC_DIR, filename), status
    except Exception:  # noqa: BLE001 - reporting an error must not become one
        return str(status), status


def _not_found_response():
    """404 in the dialect the caller speaks: JSON for API, a page otherwise."""
    if request.path.startswith("/api/"):
        return jsonify({"error": "not found"}), 404
    return _error_page("404.html", 404)


@app.errorhandler(404)
def handle_not_found(err):
    return _not_found_response()


@app.errorhandler(HTTPException)
def handle_http_error(err: HTTPException):
    """Every HTTP error gets the panel's own page, except under /api/.

    All 5xx map onto the same template: an operator cannot act differently
    on a 500 and a 502.
    """
    code = err.code or 500
    if request.path.startswith("/api/"):
        return jsonify({"error": err.description or err.name}), code
    if code == 404:
        return _error_page("404.html", 404)
    if code >= 500:
        return _error_page("5xx.html", code)
    return err.get_response()


@app.errorhandler(Exception)
def handle_unexpected_error(err: Exception):
    """Unhandled exceptions surface as the 5xx page, never a bare traceback."""
    traceback.print_exc()
    if request.path.startswith("/api/"):
        return jsonify({"error": f"{type(err).__name__}: {err}"}), 500
    return _error_page("5xx.html", 500)


# ── Routes: pages ───────────────────────────────────────────────────────

@app.get("/")
def index():
    """First run shows the standalone setup page; afterwards the console.

    The SPA keeps its own setup card as a fallback, but the primary
    first-run path is the dedicated page: it works before any script has
    run, so a stale cached bundle can never skip account creation.
    """
    if store.needs_setup:
        return send_from_directory(STATIC_DIR, "setup.html")
    return send_from_directory(STATIC_DIR, "index.html")


@app.get("/setup")
def setup_page():
    """The standalone first-run account page, at its own address too."""
    if not store.needs_setup:
        return redirect("/")
    return send_from_directory(STATIC_DIR, "setup.html")


@app.get("/<path:filename>")
def static_files(filename: str):
    """Serve a bundled asset.

    The explicit mimetype matters: Flask infers types from a fixed table, and
    the formats this panel ships — .webp among them — are absent from it. The
    result was a 200 response typed ``application/octet-stream``, which a
    browser refuses to render as an image. The wallpaper simply never appeared.
    """
    target = (STATIC_DIR / filename).resolve()
    if not str(target).startswith(str(STATIC_DIR.resolve())):
        return _not_found_response()
    if not target.is_file():
        return _not_found_response()

    mimetype, _ = mimetypes.guess_type(filename)
    return send_from_directory(STATIC_DIR, filename, mimetype=mimetype)


# ── Routes: session bootstrap ───────────────────────────────────────────

@app.get("/api/hello")
def api_hello():
    """Bootstrap payload for the SPA.

    Reachable without a session by design: the browser has to be able to ask
    "do I need to create an account, configure an API, or log in?" before it
    holds any credential.
    """
    session = current_session()
    user = store.get(session.user) if session else None
    return jsonify({
        "authenticated": session is not None,
        "needs_setup": store.needs_setup,
        # The console's device page is addressed to one machine; naming it with
        # the real hostname beats a hardcoded "This PC" when more than one
        # panel is open at once.
        "device": device_info(),
        # The wizard runs after the account exists but before any model is
        # reachable, so the SPA needs to know that is a pending step rather
        # than a broken install.
        "needs_llm": not llm_configured(),
        "version": __version__,
        "model": config.LLM_MODEL,
        "base_url": config.LLM_BASE_URL,
        # The model picker lives on the console page, which must render for
        # every role — so the entries ride along here rather than behind the
        # admin-only /api/settings, which a viewer cannot read at all.
        "provider": config.provider_name_for_setting(
            getattr(config, "LLM_PROVIDER", "")
        ),
        "models": config.model_entries(),
        "vision_mode": config.resolve_vision_mode(),
        "vision_resolved": (
            "multimodal — main model sees screenshots"
            if config.is_multimodal_main_model()
            else "text_vlm — text model + separate VLM"
        ),
        "capabilities": {
            "thinking": config.supports_thinking(),
            "vision": config.supports_vision_input(),
        },
        "credentials_ok": config.validate_llm_credentials() is None,
        # Whether exact token counting is available, and for the model the
        # panel is currently pointed at. The composer shows its running total
        # only when ``supported`` is true — an unsupported model must render
        # no counter at all rather than a zero that reads as a measurement.
        "tokens": {
            "available": tokencalc_bridge.available(),
            "supported": tokencalc_bridge.resolve(config.LLM_MODEL) is not None,
            "model_key": tokencalc_bridge.resolve(config.LLM_MODEL),
            "label": tokencalc_bridge.label(config.LLM_MODEL),
            "models": list(tokencalc_bridge.SUPPORTED_MODELS),
        },
        "max_steps": config.MAX_STEPS,
        # The composer has to know whether the ceiling is in force at all, or
        # it would prefill a number that the engine is going to ignore.
        "max_steps_enabled": config.MAX_STEPS_ENABLED,
        # Read on the console page, which every role loads — so it rides along
        # here rather than behind the admin-only /api/settings.
        "send_on_enter": getattr(config, "SEND_ON_ENTER", "enter"),
        # The reply header is painted for every role, on the login gate too, so
        # the identity ships with the rest of the bootstrap payload. An empty
        # name means "built into the front end"; an empty avatar means "draw
        # the built-in mark".
        "agent": {
            "name": config.agent_display_name(),
            # The resolved image the panel should render — the stored URL when
            # there is one, otherwise the uploaded file.
            "avatar": config.agent_avatar_url(),
            "default_name": config.AGENT_DEFAULT_NAME,
            # The upload's own URL, independent of which source won. The
            # settings preview has to be able to show "what the upload looks
            # like" even while a typed URL is in force, and it cannot tell the
            # two apart from ``avatar`` alone.
            "uploaded_url": config.agent_uploaded_avatar_url(),
            # Whether an uploaded file exists *behind* the resolved URL. The
            # settings page offers "移除上传的图片" only when there is one, and
            # a configured URL can be in force at the same time, so this cannot
            # be inferred from the URL itself.
            "uploaded": bool(config.agent_uploaded_avatar_url()),
        },
        "dependencies": desktop.dependency_report(),
        "user": {
            **(user.public() if user else {}),
            "csrf": session.csrf if session else None,
            "capabilities": sorted(
                cap for cap in ("view", "control", "admin")
                if user and store.can(user, cap)
            ),
        } if session else None,
    })


def llm_configured() -> bool:
    """Whether enough API configuration exists to talk to a model."""
    return config.validate_llm_credentials() is None and bool(config.LLM_MODEL)


def device_info() -> dict:
    """Identity of the machine the agent drives.

    Purely cosmetic, so a platform call that misbehaves on some build must not
    be able to fail the handshake the whole SPA depends on.
    """
    try:
        name = platform.node()
        system = platform.system()
        release = platform.release()
    except Exception:  # noqa: BLE001 - a hostname is not worth a 500
        name = system = release = ""
    return {"name": name or "This PC", "system": system, "release": release}


def acknowledging_keys(acknowledged: Any) -> list[str]:
    """Normalise the wizard's "keep my setting anyway" map or list."""
    if isinstance(acknowledged, dict):
        return [k for k, v in acknowledged.items() if v]
    if isinstance(acknowledged, list):
        return [str(k) for k in acknowledged]
    return []


def with_model_catalog(settings: dict[str, Any]) -> dict[str, Any]:
    """Fold every configured model into ``LLM_MODELS`` before it is persisted.

    Called *before* ``persist_settings``, and that ordering is the whole point:
    model_entries() derives the list from ``LLM_MODELS`` plus the current
    ``LLM_MODEL``, so reading it afterwards sees the incoming model only and the
    outgoing one is already gone. Doing it first captures both, which is what
    makes a model switch reversible instead of a one-way trip.
    """
    if "LLM_MODEL" not in settings:
        return settings
    merged = [entry["id"] for entry in config.model_entries()]
    incoming = str(settings.get("LLM_MODEL") or "").strip()
    if incoming and incoming not in merged:
        merged.append(incoming)
    return {**settings, "LLM_MODELS": merged}


def persist_settings(settings: dict[str, Any]) -> list[str] | None:
    """Write settings into ``config_override.json`` and apply them at runtime.

    Shared by the wizard and the settings page so both go through one path — a
    value that behaves correctly when set during setup must behave the same way
    when edited later.
    """
    override_path = config.override_file_path()
    stored: dict[str, Any] = {}
    if override_path.exists():
        try:
            stored = json.loads(override_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            stored = {}

    specs = {spec["key"]: spec for spec in config.SETTING_SPECS}
    applied: list[str] = []

    for key, value in settings.items():
        spec = specs.get(key)
        if spec is None:
            continue
        if spec["type"] == "secret" and str(value).strip() == _MASK_TOKEN:
            # A blank or masked secret means "leave what is stored alone", so a
            # page rendering masked values cannot wipe a key on save.
            continue
        if spec["type"] == "int":
            try:
                value = int(value)
            except (TypeError, ValueError):
                continue
        elif spec["type"] == "float":
            # Not folded into the int branch: a float setting stored through an
            # int() would silently truncate to 0 and change the behaviour —
            # DESKTOP_PREVIEW_MIN_INTERVAL being the obvious victim.
            try:
                value = float(value)
            except (TypeError, ValueError):
                continue
        elif spec["type"] == "bool":
            value = str(value).strip().lower() in ("1", "true", "yes", "on")
        elif spec["type"] == "list":
            # A list setting arrives as a JSON array from a picker, but a text
            # box would send newline-separated lines. Both are accepted, and
            # the result is de-duplicated and stripped here so the stored file
            # cannot accumulate blanks that the UI would then render as empty
            # rows.
            if isinstance(value, str):
                text = value.strip()
                if text.startswith("["):
                    try:
                        value = json.loads(text)
                    except (json.JSONDecodeError, TypeError):
                        value = [ln for ln in text.splitlines()]
                else:
                    value = [ln for ln in text.splitlines()]
            if not isinstance(value, list):
                continue
            cleaned: list[str] = []
            for item in value:
                name = str(item or "").strip()
                if name and name not in cleaned:
                    cleaned.append(name)
            value = cleaned
        else:
            value = str(value).strip()

        # Two fields need more than "strip it": the avatar is dropped into an
        # <img src> (so the scheme matters), and the name is printed above
        # every reply (so its length is a layout constraint, not a preference).
        if key == "AGENT_AVATAR":
            normalized = config.normalize_agent_avatar(value)
            if normalized is None:
                # Refusing beats storing it: an unusable URL would silently
                # shadow the uploaded file and leave the avatar blank.
                continue
            value = normalized
        elif key == "AGENT_NAME":
            value = value[: config.AGENT_NAME_MAX]

        config.set_setting(key, value)
        if not (spec["type"] == "secret" and not value):
            stored[key] = value
        else:
            stored.pop(key, None)
        applied.append(key)
    try:
        override_path.parent.mkdir(parents=True, exist_ok=True)
        override_path.write_text(
            json.dumps(stored, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except OSError:
        return None
    return applied


@app.post("/api/setup/account")
def api_setup_account():
    """Step 1 — create the initial administrator.

    Only available while no enabled admin exists, so this cannot be used to add
    a rogue admin to a panel that already has one.
    """
    if not store.needs_setup:
        return jsonify({"error": "面板已完成初始化"}), 409

    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))

    try:
        user = store.create_user(username, password, "admin")
    except ValueError as e:
        store.record(username or "anonymous", "auth.setup", "denied", detail=str(e),
                     ip=client_ip())
        return jsonify({ "error": str(e)}), 400

    # Log the new admin straight in — making them type the password twice on
    # the very first run is pure friction.
    session = store.authenticate(username, password, client_ip(),
                                 request.headers.get("User-Agent", ""))
    store.record(username, "auth.setup", "ok", ip=client_ip())
    response = jsonify({
        "ok": True,
        "user": user.public(),
        "csrf": session.csrf,
        "next": "llm" if not llm_configured() else "done",
    })
    set_session_cookie(response, session.token)
    return response


@app.post("/api/setup/probe")
@login_required
def api_setup_probe():
    """Step 2a — probe a candidate endpoint without saving anything.

    Deliberately side-effect free: the wizard shows exactly what the model can do
    and the operator decides what to keep, before anything reaches disk. A probe
    must never be able to damage a configuration that already works.
    """
    payload = request.get_json(silent=True) or {}
    base_url = str(payload.get("base_url", ""))
    api_key = str(payload.get("api_key", ""))
    model = str(payload.get("model", ""))

    include_optional = payload.get("include_optional", True)
    if not isinstance(include_optional, bool):
        include_optional = True

    try:
        timeout = float(payload.get("timeout") or model_probe.PROBE_TIMEOUT)
    except (TypeError, ValueError):
        timeout = model_probe.PROBE_TIMEOUT
    timeout = max(10.0, min(120.0, timeout))

    try:
        report = model_probe.run_probes(
            base_url, api_key, model,
            include_optional=include_optional,
            timeout=timeout,
        )
    except Exception as e:  # noqa: BLE001 - the wizard must survive anything
        return jsonify({"error": f"探测失败：{type(e).__name__}: {e}"}), 500

    intended = {
        "VISION_MODE": str(payload.get("vision_mode") or "auto").strip().lower(),
        "LLM_CAPABILITY": str(payload.get("capability") or "auto").strip().lower(),
    }
    conflicts = model_probe.reconcile(report, intended)
    suggestion = model_probe.suggested_settings(api_key, base_url, model, report)

    return jsonify({
        "report": report.as_dict(),
        "conflicts": conflicts,
        "suggested": suggestion,
        # A hard block means no setting can make this endpoint work.
        "can_proceed": not report.blocked,
    })


@app.post("/api/setup/llm")
@login_required(capability="admin")
def api_setup_llm():
    """Step 2b — persist the API configuration the operator confirmed.

    Re-probes rather than trusting the client's report: between the probe and
    this call the operator may have edited the fields, and a stale report would
    let an unsupported combination through.
    """
    payload = request.get_json(silent=True) or {}
    base_url = str(payload.get("base_url", "")).strip()
    api_key = str(payload.get("api_key", ""))
    model = str(payload.get("model", "")).strip()

    if not base_url or not model:
        return jsonify({"error": "Base URL 和模型 ID 不能为空"}), 400

    report = model_probe.run_probes(base_url, api_key, model)
    intended = {
        "VISION_MODE": str(payload.get("vision_mode") or "auto").strip().lower(),
        "LLM_CAPABILITY": str(payload.get("capability") or "auto").strip().lower(),
    }
    conflicts = model_probe.reconcile(report, intended)
    blocking = [c for c in conflicts if c.get("severity") == "blocking"]

    acknowledged = set(acknowledging_keys(payload.get("acknowledged")))
    if blocking and not acknowledged >= {c["key"] for c in blocking}:
        return jsonify({
            "error": "存在无法通过设置绕过的问题，请先更换模型或端点",
            "conflicts": conflicts,
            "blocked": True,
        }), 400

    overrides = {
        c["key"]: True for c in conflicts
        if c.get("fixable") and c["key"] in acknowledged
    }

    try:
        settings = model_probe.apply_intent(
            api_key, model_probe.normalise_base_url(base_url), model, report, overrides
        )
    except ValueError as e:
        # apply_intent refuses to build a "forced" configuration for a hard
        # block. A client that acknowledged anyway gets a clear 400 rather than
        # an unhandled 500.
        return jsonify({
            "error": str(e),
            "conflicts": conflicts,
            "blocked": True,
        }), 400

    applied = persist_settings(with_model_catalog(settings))
    if applied is None:
        return jsonify({"error": f"无法写入 {config.override_file_path()}"}), 500

    session = current_session()
    store.record(session.user if session else "unknown", "setup.llm", "ok",
                 detail=f"{model} @ {base_url} caps="
                        f"{sorted(k for k, v in report.capabilities.items() if v)}",
                 ip=client_ip())

    return jsonify({
        "ok": True,
        "applied": applied,
        "report": report.as_dict(),
        "conflicts": conflicts,
        "capabilities": report.capabilities,
        "path": str(config.override_file_path()),
    })


@app.get("/api/auth/password/generate")
def api_generate_password():
    """Mint a strong password to adopt.

    Generation is server-side on purpose. The browser's Math.random is not a
    CSPRNG, and only the server knows the active password policy — so a
    generated value cannot drift out of compliance when that policy changes.

    *Deliberately reachable without a session.* The first-run wizard asks the
    operator to choose a password **before** any account exists, so requiring a
    session here would deadlock the setup flow: you cannot log in until you set
    a password, and you cannot set one until you can call this. There is also
    nothing to protect — the response is a random string that grants no access
    on its own. What actually needs protecting is reading back a *stored*
    credential, and that stays behind the session (see /api/settings masking).

    Only audited once a session exists, so the log cannot be inflated by
    anonymous callers.
    """
    try:
        length = int(request.args.get("length", auth.DEFAULT_GENERATED_LENGTH))
    except (TypeError, ValueError):
        length = auth.DEFAULT_GENERATED_LENGTH

    password = auth.generate_password(length)

    session = current_session()
    if session is not None:
        store.record(session.user, "password.generate", "ok",
                     detail=f"length={len(password)}", ip=client_ip())

    return jsonify({
        "password": password,
        "length": len(password),
        "strength": auth.password_strength(password),
    })


@app.post("/api/auth/login")
def api_login():
    """Exchange username + password for a session cookie."""
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))

    remember = bool(payload.get("remember", True))

    try:
        session = store.authenticate(
            username, password, client_ip(), request.headers.get("User-Agent", "")
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 401

    # Shorten the server-side record too, not just the cookie. A cookie that
    # outlives its session buys nothing: validate_session() rejects it either
    # way, so shortening only the cookie would be theatre.
    if not remember and session.expires - session.created > SHORT_SESSION_TTL:
        session.expires = session.created + SHORT_SESSION_TTL

    user = store.get(session.user)
    response = jsonify({
        "ok": True,
        "user": user.public() if user else {},
        "csrf": session.csrf,
        "expires_in": int(max(0, session.expires - time.time())),
    })
    set_session_cookie(response, session.token, remember=remember)
    return response


@app.post("/api/auth/logout")
@login_required
def api_logout():
    store.logout(request.cookies.get(SESSION_COOKIE))
    response = jsonify({"ok": True})
    response.delete_cookie(SESSION_COOKIE, path="/")
    return response


@app.get("/api/auth/me")
@login_required
def api_me():
    session = current_session()
    user = store.get(session.user) if session else None
    return jsonify({
        "user": user.public() if user else {},
        "csrf": session.csrf if session else None,
        "capabilities": sorted(
            cap for cap in ("view", "control", "admin")
            if user and store.can(user, cap)
        ),
        "sessions": store.active_sessions(request.cookies.get(SESSION_COOKIE))
        if user and store.can(user, "admin") else [],
    })


@app.get("/api/auth/lockout")
def api_lockout():
    """Whether this client is currently locked out, for the login screen."""
    username = str(request.args.get("username", "")).strip()
    return jsonify(store.lockout_state(username, client_ip()))


@app.post("/api/auth/password")
@login_required
def api_change_password():
    """Change your own password. Requires the current one."""
    payload = request.get_json(silent=True) or {}
    current = str(payload.get("current_password", ""))
    new = str(payload.get("new_password", ""))

    user = current_user()
    if user is None:
        return unauthenticated_response()

    from cua.auth import verify_password

    if not verify_password(current, user.password):
        store.record(user.name, "auth.password", "denied",
                     detail="current password mismatch", ip=client_ip())
        return jsonify({"error": "当前密码不正确"}), 403

    try:
        store.set_password(user.name, new)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    # set_password drops this user's sessions, including the current one, so
    # hand back a fresh login rather than leaving the browser half-authed.
    store.record(user.name, "auth.password", "ok", ip=client_ip())
    response = jsonify({"ok": True, "reauth": True})
    response.delete_cookie(SESSION_COOKIE, path="/")
    return response


# ── Routes: user administration ─────────────────────────────────────────

@app.get("/api/users")
@admin_required
def api_list_users():
    return jsonify({
        "users": [u.public() for u in store.users],
        "roles": [{"value": r, "label": ROLE_LABELS[r]} for r in ("admin", "operator", "viewer")],
    })


@app.post("/api/users")
@admin_required
def api_create_user():
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))
    role = str(payload.get("role", "viewer")).strip().lower()
    # Admin-created accounts default to requiring a password change, so a
    # temporary password never becomes a permanent one.
    must_change = bool(payload.get("must_change", True))

    try:
        user = store.create_user(username, password, role, must_change=must_change)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True, "user": user.public()})


@app.post("/api/users/<name>/role")
@admin_required
def api_set_role(name: str):
    payload = request.get_json(silent=True) or {}
    role = str(payload.get("role", "")).strip().lower()
    try:
        store.set_role(name, role)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True})


@app.post("/api/users/<name>/password")
@admin_required
def api_admin_set_password(name: str):
    payload = request.get_json(silent=True) or {}
    password = str(payload.get("password", ""))
    must_change = bool(payload.get("must_change", True))
    try:
        store.set_password(name, password, must_change=must_change)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True})


@app.post("/api/users/<name>/disable")
@admin_required
def api_disable_user(name: str):
    payload = request.get_json(silent=True) or {}
    try:
        store.set_disabled(name, bool(payload.get("disabled", True)))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True})


@app.delete("/api/users/<name>")
@admin_required
def api_delete_user(name: str):
    try:
        store.delete_user(name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True})


@app.get("/api/audit")
@admin_required
def api_audit():
    limit = request.args.get("limit", "200")
    try:
        limit = max(1, min(1000, int(limit)))
    except (TypeError, ValueError):
        limit = 200
    return jsonify({
        "entries": store.read_audit(limit),
        "path": str(store.audit_path),
    })


@app.post("/api/sessions/revoke")
@admin_required
def api_revoke_sessions():
    payload = request.get_json(silent=True) or {}
    target = payload.get("user") or None
    count = store.drop_all_sessions(target)
    return jsonify({"ok": True, "revoked": count})


# ── Routes: status ──────────────────────────────────────────────────────

@app.get("/api/status")
@login_required
def api_status():
    session = current_session()
    return jsonify({
        "state": hub.state,
        "busy": hub.busy,
        "task": hub.task,
        "actor": hub.actor,
        "elapsed": round(time.time() - hub.started_at, 2) if hub.started_at else 0,
        "outcome": hub.outcome,
        "pending": hub.pending,
        "session": hub.session_id,
        "perception": describe_perception(),
        "desktop_view": bool(config.WEB_PANEL_DESKTOP_VIEW),
        "work": desktop.work_region_info(),
        "backend": backend.backend_info(),
        "you": session.user if session else "",
    })


# ── Routes: token usage ─────────────────────────────────────────────────
#
# Exact token accounting for the four models tokencalc ships tokenizers for.
# The panel hides every counter when the active model is not one of them, so
# these endpoints report support explicitly rather than returning zeros that
# would look like measurements.

@app.get("/api/tokens/meta")
@login_required
def api_tokens_meta():
    """Whether counting works, and which models it covers."""
    return jsonify({
        "available": tokencalc_bridge.available(),
        "reason": tokencalc_bridge.unavailable_reason(),
        "models": tokencalc_bridge.model_info(),
        "cache_window_seconds": tokencalc_bridge.CACHE_WINDOW_SECONDS,
        "active_model": config.LLM_MODEL,
        "active_supported": tokencalc_bridge.resolve(config.LLM_MODEL) is not None,
        "active_key": tokencalc_bridge.resolve(config.LLM_MODEL),
        "active_label": tokencalc_bridge.label(config.LLM_MODEL),
    })


@app.get("/api/tokens/session")
@login_required
def api_tokens_session():
    """Totals and recent records for the mounted conversation.

    ``session`` may override which conversation is reported, because the
    statistics page can look at history while a different session is mounted.
    """
    requested = (request.args.get("session") or "").strip()
    session = current_session()
    sid = requested or (hub.session_id if hub.session else None)
    if not sid:
        return jsonify({"session_id": "", "totals": None, "records": [],
                        "supported": tokencalc_bridge.available()})
    summary = token_usage.session_summary(sid)
    summary["supported"] = summary.get("supported", False) and tokencalc_bridge.available()
    return jsonify(summary)


@app.get("/api/tokens/stats")
@login_required
def api_tokens_stats():
    """Aggregated usage: grand totals, per session, per model."""
    payload = token_usage.snapshot()
    payload["available"] = tokencalc_bridge.available()
    payload["reason"] = tokencalc_bridge.unavailable_reason()
    payload["models"] = tokencalc_bridge.model_info()
    payload["cache_window_seconds"] = tokencalc_bridge.CACHE_WINDOW_SECONDS
    # Attach the human titles the session list knows, so the table does not
    # show raw ids for conversations the operator recognises by name.
    try:
        known = {s.id: s for s in hub.sessions.list()}
    except Exception:  # noqa: BLE001 - titles are decoration
        known = {}
    for row in payload.get("sessions", []):
        record = known.get(row.get("session_id"))
        row["title"] = getattr(record, "title", "") or ""
        row["model"] = getattr(record, "model", "") or ""
    return jsonify(payload)


@app.post("/api/tokens/clear")
@admin_required
def api_tokens_clear():
    """Reset the ledger. Admin-only: it destroys a measurement history."""
    token_usage.clear()
    session = current_session()
    store.record(session.user if session else "unknown", "tokens.clear", "ok",
                 ip=client_ip())
    return jsonify({"ok": True})


# ── Routes: sessions ────────────────────────────────────────────────────
#
# Sessions are the unit of history: each one owns a model context and the log
# of everything that happened in it. Reading is open to anyone who can view
# the panel; creating, renaming and deleting are control actions, so a viewer
# can watch a mission without being able to rewrite its history.

@app.get("/api/sessions")
@login_required
def api_list_sessions():
    return jsonify({
        "sessions": [s.summary() for s in hub.sessions.list()],
        "active": hub.session_id,
        "running": hub.busy,
        # Surfaced in the UI so an operator can find the files without
        # guessing where the panel decided to put them.
        "dir": str(hub.sessions.dir),
    })


@app.post("/api/sessions")
@login_required(capability="control")
def api_create_session():
    """Open a new session. Nothing runs until a mission is started in it."""
    payload = request.get_json(silent=True) or {}
    title = str(payload.get("title", "")).strip()
    auth_session = current_session()
    actor = auth_session.user if auth_session else "unknown"

    session = hub.sessions.create(title=title, owner=actor)
    # Mount it, so `active` in the session list means this new session.
    #
    # `hub.session` is "the session the next mission continues", which is the
    # same thing the delete handler unmounts. Leaving it pointing at the
    # previous session made /api/sessions report that old id as `active` — so
    # the console, which adopts `active` on every refresh, immediately
    # overwrote the new id it had just set and the fresh session silently
    # fell back to continuing the old context.
    #
    # Guarded on `busy`: creating a session mid-run must not redirect the run
    # that is already writing to the mounted one.
    if not hub.busy:
        hub.session = session
    store.record(actor, "session.create", "ok", detail=session.id, ip=client_ip())
    return jsonify({"ok": True, "session": session.summary()})

@app.get("/api/sessions/<session_id>")
@login_required
def api_get_session(session_id: str):
    """One session's replayable log.

    The message list is deliberately not returned: it is model context, can
    hold megabytes of history, and nothing on screen renders it.
    """
    session = hub.sessions.get(session_id)
    if session is None:
        return jsonify({"error": "会话不存在"}), 404
    return jsonify({
        "session": {**session.summary(), "transcript": session.transcript},
        "active": session.id == hub.session_id,
        "running": session.id == hub.session_id and hub.busy,
    })


@app.post("/api/sessions/<session_id>/mount")
@login_required
def api_mount_session(session_id: str):
    """Make *session_id* the session the next mission continues.

    Needed because selecting a session in the UI is a *server-side* fact, not
    just a local highlight: `/api/sessions` reports the mounted session as
    ``active``, and the console adopts that value on every refresh. Choosing a
    session only in the browser was therefore undone a moment later — the
    refresh that follows navigation put the previous session back, so a task
    started right after clicking a session went to the wrong context.
    """
    session = hub.sessions.get(session_id)
    if session is None:
        return jsonify({"error": "会话不存在"}), 404
    if hub.busy:
        # A run is writing to whichever session is mounted; repointing it
        # mid-flight would scatter one mission's transcript across two.
        return jsonify({"error": "任务正在运行，请先中断或等待完成"}), 409

    hub.session = session
    auth_session = current_session()
    store.record(auth_session.user if auth_session else "unknown",
                 "session.mount", "ok", detail=session_id, ip=client_ip())
    return jsonify({"ok": True, "session": session.summary()})


@app.patch("/api/sessions/<session_id>")
@login_required(capability="control")
def api_rename_session(session_id: str):
    payload = request.get_json(silent=True) or {}
    title = str(payload.get("title", "")).strip()
    if not title:
        return jsonify({"error": "会话名不能为空"}), 400

    renamed = hub.sessions.rename(session_id, title)
    if renamed is None:
        return jsonify({"error": "会话不存在"}), 404

    auth_session = current_session()
    store.record(auth_session.user if auth_session else "unknown",
                 "session.rename", "ok", detail=f"{session_id} -> {title}",
                 ip=client_ip())
    return jsonify({"ok": True, "session": renamed.summary()})


@app.delete("/api/sessions/<session_id>")
@login_required(capability="control")
def api_delete_session(session_id: str):
    if session_id == hub.session_id and hub.busy:
        return jsonify({"error": "该会话正在运行，请先中断任务"}), 409

    if not hub.sessions.delete(session_id):
        return jsonify({"error": "会话不存在"}), 404

    # Unmount it if it was mounted: otherwise the next mission would keep
    # writing to a session whose file is already gone.
    if session_id == hub.session_id:
        hub.session = None

    auth_session = current_session()
    store.record(auth_session.user if auth_session else "unknown",
                 "session.delete", "ok", detail=session_id, ip=client_ip())
    return jsonify({"ok": True})


# ── Routes: mission control ─────────────────────────────────────────────

@app.post("/api/mission")
@login_required(capability="control")
def api_start_mission():
    if hub.busy:
        # One machine, one agent: a second run would fight the first for the
        # pointer, and "which session is it in" would have no single answer.
        return jsonify({
            "error": "a mission is already running",
            "session": hub.session_id,
        }), 409

    payload = request.get_json(silent=True) or {}
    task = str(payload.get("task", "")).strip()
    if not task:
        return jsonify({"error": "task must not be empty"}), 400

    missing = config.validate_llm_credentials()
    if missing:
        return jsonify({"error": missing}), 400

    # Passed through raw: ``config.resolve_max_steps`` owns the policy, so
    # "0" (no ceiling) and an omitted value (fall back to the global setting)
    # stay distinguishable instead of both collapsing to None here.
    max_steps = payload.get("max_steps")

    session_id = str(payload.get("session_id") or "").strip() or None

    # Conversation-UI controls wired to real backend behaviour.
    agent_mode = modes.normalize(payload.get("agent_mode"))
    full_access = bool(payload.get("full_access"))
    workspace = str(payload.get("workspace") or "").strip()
    model = str(payload.get("model") or "").strip()

    session = current_session()
    actor = session.user if session else "unknown"
    store.record(actor, "mission.start", "ok",
                 detail=f"[{session_id or 'new'}] {task[:180]} | "
                        f"mode={agent_mode} model={model or '-'} "
                        f"ws={workspace or '-'} full_access={full_access}",
                 ip=client_ip())

    mounted = hub.start(task, max_steps=max_steps,
                        step_mode=bool(payload.get("step_mode")),
                        actor=actor, session_id=session_id,
                        full_access=full_access, agent_mode=agent_mode,
                        workspace=workspace, model=model)
    if mounted is None:
        # The named session vanished between listing and starting (deleted in
        # another tab, or the files were cleared). Say so instead of quietly
        # substituting a fresh one.
        return jsonify({"error": "会话不存在，请新建或选择另一条"}), 404

    return jsonify({
        "ok": True,
        "task": task,
        "actor": actor,
        "session": mounted.id,
    })


@app.post("/api/control")
@login_required(capability="control")
def api_control():
    """Pause / resume / abort / release-next-step."""
    payload = request.get_json(silent=True) or {}
    action = str(payload.get("action", "")).strip().lower()
    session = current_session()
    actor = session.user if session else "unknown"

    if action == "pause":
        if not hub.busy:
            return jsonify({"error": "no mission running"}), 409
        hub.runtime.pause()
        hub.emit({"type": "status", "ts": time.time(), "state": "paused"})
        hub.state = "paused"
        store.record(actor, "mission.pause", "ok", ip=client_ip())
        return jsonify({"ok": True, "state": "paused"})

    if action == "resume":
        hub.runtime.resume()
        hub.state = "running"
        hub.emit({"type": "status", "ts": time.time(), "state": "running"})
        store.record(actor, "mission.resume", "ok", ip=client_ip())
        return jsonify({"ok": True, "state": "running"})

    if action == "step":
        hub.runtime.resume()
        hub.runtime.release_step()
        hub.state = "running"
        store.record(actor, "mission.step", "ok", ip=client_ip())
        return jsonify({"ok": True, "state": "running"})

    if action == "abort":
        hub.runtime.abort()
        hub.state = "idle"
        hub.emit({"type": "status", "ts": time.time(), "state": "idle"})
        store.record(actor, "mission.abort", "ok", ip=client_ip())
        return jsonify({"ok": True, "state": "idle"})

    if action == "answer":
        approved = bool(payload.get("approved"))
        text = str(payload.get("text", "") or "")
        if not hub.answer(approved, text):
            return jsonify({"error": "nothing pending"}), 409
        store.record(actor, "mission.approval",
                     "ok" if approved else "denied",
                     detail=(text[:120] if text else "shell command"), ip=client_ip())
        hub.emit({"type": "status", "ts": time.time(), "state": "running"})
        return jsonify({"ok": True})

    return jsonify({"error": f"unknown action '{action}'"}), 400


# ── Routes: streaming ───────────────────────────────────────────────────

@app.get("/api/events")
def api_events():
    """Server-sent event stream of the live transcript."""
    if store.needs_setup:
        return jsonify({"error": "panel setup has not been completed"}), 503
    session = current_session()
    if session is None:
        return unauthenticated_response()

    q = hub.subscribe()
    since = float(request.args.get("since", "0") or 0)
    for event in list(hub.transcript)[-300:]:
        if since and event.get("ts", 0) <= since:
            continue
        try:
            q.put_nowait(event)
        except queue.Full:
            break

    def generate():
        try:
            while True:
                try:
                    event = q.get(timeout=15)
                except queue.Empty:
                    yield ": keepalive\n\n"
                    continue
                payload = json.dumps(event, ensure_ascii=False, default=str)
                yield f"data: {payload}\n\n"
        except GeneratorExit:
            hub.unsubscribe(q)

    headers = {
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
        "Connection": "keep-alive",
    }
    return Response(generate(), mimetype="text/event-stream", headers=headers)


# ── Routes: desktop preview ─────────────────────────────────────────────

_last_frame = 0.0


@app.get("/api/desktop.jpg")
@login_required
def api_desktop():
    """Single JPEG frame of the live desktop.

    ``?scope=work`` returns the agent's workspace rectangle instead of the
    whole screen, which is how the panel shows "what the agent sees" while a
    partition is active.
    """
    global _last_frame
    if not config.WEB_PANEL_DESKTOP_VIEW:
        return jsonify({"error": "desktop view disabled"}), 403

    # Guard against a browser hammering this endpoint while a mission runs.
    now = time.time()
    if now - _last_frame < config.DESKTOP_PREVIEW_MIN_INTERVAL:
        time.sleep(config.DESKTOP_PREVIEW_MIN_INTERVAL - (now - _last_frame))
    _last_frame = time.time()

    scope = (request.args.get("scope") or "full").strip().lower()
    region = desktop.work_region() if scope == "work" else None

    try:
        screenshot = desktop.screenshot(region=region)
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": f"capture failed: {e}"}), 500

    # Scale against the captured image, not the screen: in workspace mode the
    # crop is smaller than the display and must not be letterboxed by a limit
    # derived from the full screen.
    max_edge = 1280
    try:
        width, height = screenshot.size
        if max(width, height) > max_edge:
            scale = max_edge / float(max(width, height))
            screenshot = screenshot.resize(
                (max(1, int(width * scale)), max(1, int(height * scale)))
            )
        buffer = io.BytesIO()
        screenshot.convert("RGB").save(buffer, format="JPEG", quality=72, optimize=True)
        data = buffer.getvalue()
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": f"encoding failed: {e}"}), 500

    return Response(
        data,
        mimetype="image/jpeg",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.get("/api/screen")
@login_required
def api_screen_size():
    width, height = desktop.screen_size()
    x, y = desktop.mouse_position()
    vx, vy = desktop.screen_to_view(x, y)
    region = desktop.work_region()
    # The cursor can legitimately sit outside the workspace — the operator
    # moves it there every time they touch their own half of the screen. That
    # is exactly the "not in the agent's view" case, so report it as a flag
    # rather than emitting a negative coordinate that no image can match.
    inside = region is None or (region[0] <= x < region[0] + region[2]
                                and region[1] <= y < region[1] + region[3])
    return jsonify({
        "width": width,
        "height": height,
        "cursor": {"x": x, "y": y},
        "work": desktop.work_region_info(),
        # The cursor as the model sees it — the desktop page shows this one,
        # since the image it displays is the workspace, not the whole screen.
        "viewCursor": ({"x": vx, "y": vy} if inside else None),
    })


@app.get("/api/work-mode")
@login_required
def api_get_work_mode():
    """Current workspace configuration and what a switch would produce."""
    return jsonify(desktop.work_region_info())


@app.get("/api/shell-activity")
@login_required
def api_shell_activity():
    """Recent shell commands, newest first.

    The one part of a partitioned agent's work that is invisible on screen: a
    command runs on the host regardless of which rectangle the agent may click
    in. An operator who cannot see the agent's display needs to be able to see
    what it is running, from any device.
    """
    try:
        limit = int(request.args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    return jsonify({
        "backend": backend.backend_info(),
        "activity": backend.shell_activity(limit),
    })


@app.post("/api/pick-folder")
@login_required
def api_pick_folder():
    """Open the OS folder picker and return the chosen path.

    Runs the dialog in a *separate process* on purpose. tkinter's dialog is
    modal and blocking, so calling it on a worker thread would still freeze
    whichever thread it landed on, and on Windows a modal dialog owned by a
    non-main thread behaves unpredictably. A child process gives it a real main
    thread, and it dies with the dialog instead of lingering after it closes.

    The child's source is a constant. The title and the starting directory
    travel in the environment, so no part of this request is ever formatted
    into code — the obvious alternative, an f-string with ``{title!r}``, does
    escape correctly but makes the safety of the endpoint depend on repr()
    never being wrong, which is not a property worth relying on here.

    The child writes the choice to a *temp file*, not to stdout. stdout is not
    trustworthy here: this process is started by a launcher whose own stack
    writes to the inherited stdout — the observed case was a stream of
    "client connect to port 51053 ..." lines — and those lines landed in the
    captured output ahead of the path, so the field ended up holding a page of
    launcher noise. A file the child opens itself cannot be contaminated by
    anything else writing to stdout.
    """
    payload = request.get_json(silent=True) or {}
    title = str(payload.get("title") or "选择文件夹")[:120]
    initial = str(payload.get("initial") or "").strip()
    # A path that no longer exists makes the dialog open somewhere confusing
    # or refuse outright, so only offer a start point that is really there.
    if initial and not os.path.isdir(initial):
        initial = ""

    fd, out_path = tempfile.mkstemp(prefix="cua-pick-", suffix=".txt")
    os.close(fd)

    child = (
        "import os, sys\n"
        "def emit(value):\n"
        "    with open(os.environ['CUA_PICK_OUT'], 'w', encoding='utf-8') as fh:\n"
        "        fh.write(value)\n"
        "try:\n"
        "    from tkinter import Tk, filedialog\n"
        "except Exception as exc:\n"
        "    emit('!' + str(exc)); sys.exit(2)\n"
        "root = Tk()\n"
        "root.withdraw()\n"
        "try:\n"
        "    root.attributes('-topmost', True)\n"
        "except Exception:\n"
        "    pass\n"
        "chosen = filedialog.askdirectory(\n"
        "    title=os.environ.get('CUA_PICK_TITLE') or 'Select folder',\n"
        "    initialdir=os.environ.get('CUA_PICK_INITIAL') or None,\n"
        "    mustexist=False,\n"
        ")\n"
        "root.destroy()\n"
        "emit(chosen or '')\n"
    )

    env = dict(os.environ)
    env["CUA_PICK_TITLE"] = title
    env["CUA_PICK_OUT"] = out_path
    if initial:
        env["CUA_PICK_INITIAL"] = initial

    # CREATE_NO_WINDOW so no console flashes up behind the dialog. It exists
    # only on Windows; on other platforms the bare start works.
    kwargs = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    try:
        done = subprocess.run(
            [sys.executable, "-c", child],
            capture_output=True, text=True, timeout=300, errors="replace",
            env=env, **kwargs,
        )
    except subprocess.TimeoutExpired:
        _unlink_quietly(out_path)
        return jsonify({"error": "选择超时，请重试"}), 504
    except Exception as e:  # noqa: BLE001
        _unlink_quietly(out_path)
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 500

    raw = _read_text_quietly(out_path)
    _unlink_quietly(out_path)

    if raw.startswith("!"):
        return jsonify({
            "error": "无法打开系统文件夹对话框（缺少 tkinter？）" + raw.lstrip("!")
        }), 500
    if done.returncode == 2 and not raw:
        return jsonify({"error": "无法打开系统文件夹对话框（缺少 tkinter？）"}), 500

    path = _clean_picked_path(raw)
    if not path:
        # Fall back to the historical stdout channel only when the file came
        # back empty, so a child that somehow failed to write it still works.
        path = _clean_picked_path(done.stdout or "")
    # An empty string is the dialog's Cancel, which is a normal outcome and
    # must not overwrite whatever the field already holds.
    return jsonify({"path": path, "cancelled": not path})


def _clean_picked_path(text: str) -> str:
    """The chosen path, stripped of anything that is plainly not part of it.

    Kept deliberately shallow — the picker returns a real directory, and
    rewriting a path that is merely unusual would break the paths this exists
    to get right. It only rejects what cannot be a local path at all: control
    characters, and text long enough that no filesystem here would accept it.
    """
    value = (text or "").strip().strip('"').strip()
    if "\x00" in value or any(ord(ch) < 32 for ch in value):
        return ""
    return value[:4096]


def _read_text_quietly(path: str) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def _unlink_quietly(path: str) -> None:
    try:
        os.unlink(path)
    except OSError:
        pass


@app.post("/api/work-mode")
@login_required
def api_set_work_mode():
    """Switch between the full desktop and a partitioned workspace.

    Refuses while a mission is running: the region's size and offset are read
    per screenshot and per click, so changing them mid-task would hand the
    model a coordinate space that no longer matches the window it was
    addressing, and the very next click would land somewhere unintended.
    """
    payload = request.get_json(silent=True) or {}
    mode = str(payload.get("mode") or "").strip().lower()
    if mode not in ("primary", "region"):
        return jsonify({"error": "mode must be 'primary' or 'region'"}), 400

    region = None
    if mode == "region":
        region = (
            _as_int(payload.get("x"), config.WORK_REGION_X),
            _as_int(payload.get("y"), config.WORK_REGION_Y),
            _as_int(payload.get("width"), config.WORK_REGION_WIDTH),
            _as_int(payload.get("height"), config.WORK_REGION_HEIGHT),
        )
        if region[2] <= 0 or region[3] <= 0:
            return jsonify({
                "error": "workspace needs a positive width and height"
            }), 400

    session = current_session()
    user = session.user if session else "unknown"

    # Reject rather than queue: a queued switch would fire at some
    # unpredictable point during the next mission.
    if mode != config.work_mode() and _mission_running():
        return jsonify({
            "error": "工作位置只能在任务未运行时切换。请先停止当前任务。"
        }), 409

    # Persist through the same store the settings page uses, so a mode chosen
    # here survives a restart instead of silently reverting.
    #
    # The *effective* region is what gets written, not the requested one: a
    # request that ran past the screen edge is accepted and clamped at
    # runtime, and storing the raw numbers would make the settings page show
    # 99999-wide while the desktop is 2880 wide. Same numbers the operator
    # sees, same numbers the agent gets.
    config.set_work_mode(mode, region)
    effective = desktop.work_region()
    keys = {
        "WORK_MODE": mode,
        "WORK_REGION_X": effective[0] if effective else config.WORK_REGION_X,
        "WORK_REGION_Y": effective[1] if effective else config.WORK_REGION_Y,
        "WORK_REGION_WIDTH": effective[2] if effective else config.WORK_REGION_WIDTH,
        "WORK_REGION_HEIGHT": effective[3] if effective else config.WORK_REGION_HEIGHT,
    }
    written = persist_settings(keys)
    if written is None:
        return jsonify({"error": "could not save the workspace settings"}), 500

    store.record(user, "work_mode.change", "ok",
                 detail=f"mode={mode} region={effective}", ip=client_ip())
    return jsonify({"ok": True, **desktop.work_region_info()})


def _as_int(value, fallback: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return int(fallback)


def _mission_running() -> bool:
    """Whether a mission currently holds the desktop."""
    try:
        # hub is the module-level MissionHub singleton; busy is False as soon
        # as the outcome is produced, which is exactly the "not driving the
        # mouse right now" question being asked here.
        return bool(hub.busy)
    except Exception:  # noqa: BLE001 - a failure here must not block the UI
        return False


# ── Routes: settings ────────────────────────────────────────────────────

def _config_export_names() -> set[str]:
    return {spec["key"] for spec in config.SETTING_SPECS}


@app.get("/api/settings")
@admin_required
def api_get_settings():
    """Current effective settings. Secrets are returned masked."""
    groups: dict[str, list[dict]] = {}
    for spec in config.SETTING_SPECS:
        if spec["key"] == "LLM_MODELS":
            # Report what the picker actually offers, not the raw stored array.
            # An install configured by hand stores nothing here, yet its model
            # is real and selectable — an empty field would contradict the
            # picker right next to it.
            raw = [entry["id"] for entry in config.model_entries()]
        elif spec["key"] == "LLM_PROVIDER":
            # Blank is a legitimate value ("derive it"), so show the derived
            # name instead of an empty box that looks unconfigured.
            raw = config.provider_name_for_setting(config.get_setting(spec["key"]))
        else:
            raw = config.get_setting(spec["key"])
        if spec["type"] == "secret":
            value = "" if raw is None else str(raw)
            masked = _mask(value)
        else:
            value = raw
            masked = value
        groups.setdefault(spec["group"], []).append({
            **spec,
            "value": masked,
            "empty": spec["type"] == "secret" and not value,
        })
    return jsonify({
        "groups": groups,
        "diagnostics": {
            "llm": llm_client.describe_llm(),
            "perception": describe_perception(),
            "dependencies": desktop.dependency_report(),
        },
    })


@app.post("/api/settings")
@admin_required
def api_update_settings():
    """Persist changed settings into config_override.json.

    A blank or masked secret means "leave the stored value alone", so a page
    that renders masked values cannot accidentally wipe a key on save.
    """
    payload = request.get_json(silent=True) or {}
    applied = persist_settings(with_model_catalog(payload))
    # Bound here rather than referenced inline at the end of the handler: the
    # final response used to name a local that this function never defined,
    # so every successful save died with a NameError *after* the write had
    # already happened — settings appeared not to stick.
    override_path = config.override_file_path()
    if applied is None:
        return jsonify({"error": f"could not write {override_path}"}), 500

    # Security-relevant knobs take effect only after a restart, because the
    # store captured them at construction time.
    session = current_session()
    store.record(session.user if session else "unknown", "settings.save", "ok",
                 detail=f"{len(applied)} keys", ip=client_ip())
    if any(k in ("SESSION_TTL", "AUTH_MAX_ATTEMPTS", "AUTH_LOCKOUT_SECONDS",
                 "AUTH_LOCKOUT_WINDOW") for k in applied):
        store.record("system", "settings.restart_required", "ok",
                     detail="auth knobs changed", ip=client_ip())

    return jsonify({"ok": True, "applied": applied, "path": str(override_path)})


_MASK_TOKEN = "••••••••"


def _mask(value: str) -> str:
    return _MASK_TOKEN if value else ""


# ── Agent avatar ────────────────────────────────────────────────────────
#
# Two routes because the image has two possible sources. The upload endpoint
# stores one file beside config_override.json; the reader serves whichever
# source is currently in force, so the front end can point an <img> at a single
# stable address and never has to know which it is or where it lives.

@app.get("/api/agent/avatar")
def api_agent_avatar():
    """Serve the uploaded avatar image, or 404 when there is none.

    Unauthenticated on purpose: the reply header is painted on the login gate
    too, and an <img> tag cannot present a CSRF-safe request. Nothing secret is
    exposed — the file only ever contains an image the operator chose to show
    above every answer — and the path is fixed rather than taken from the
    request, so there is no directory to traverse.
    """
    path = config.agent_avatar_file()
    if not path.is_file():
        return jsonify({"error": "未上传头像"}), 404
    response = send_from_directory(path.parent, path.name, mimetype="image/png")
    # The URL carries an mtime query, but a cached response without this header
    # can still be reused for a re-upload under the same version-less URL.
    response.headers["Cache-Control"] = "no-cache"
    return response


@app.post("/api/agent/avatar")
@admin_required
def api_agent_avatar_upload():
    """Store an avatar uploaded from the settings page.

    Accepts a multipart file or a data URL, re-encodes it to a square PNG and
    replaces whatever was there. Re-encoding is the point, not a nicety: it
    normalises the format, caps the stored size, and strips EXIF — so an image
    straight off a phone camera cannot arrive with GPS coordinates attached.
    """
    upload = request.files.get("file")
    raw: bytes | None = None
    if upload is not None:
        raw = upload.read()
    else:
        payload = request.get_json(silent=True) or {}
        data_url = str(payload.get("data_url") or "")
        if data_url.startswith("data:") and "," in data_url:
            try:
                raw = base64.b64decode(data_url.split(",", 1)[1], validate=True)
            except (binascii.Error, ValueError):
                raw = None

    if not raw:
        return jsonify({"error": "没有收到图片"}), 400
    if len(raw) > config.AVATAR_UPLOAD_MAX_BYTES:
        limit = config.AVATAR_UPLOAD_MAX_BYTES // (1024 * 1024)
        return jsonify({"error": f"图片过大，请换一张小于 {limit}MB 的图片"}), 413

    try:
        from PIL import Image
    except ImportError:
        return jsonify({"error": "缺少 Pillow，无法处理图片"}), 500

    try:
        with Image.open(io.BytesIO(raw)) as image:
            image.load()
            # EXIF orientation first: a phone portrait shot is stored rotated,
            # and squaring it before the transpose would crop the wrong half.
            try:
                from PIL import ImageOps

                image = ImageOps.exif_transpose(image) or image
            except Exception:  # noqa: BLE001 - orientation is best-effort
                pass
            image = image.convert("RGBA")
            # Centre-crop to a square, then downscale. Cropping after the
            # resize would upscale the smaller dimension first and blur it.
            edge = config.AVATAR_STORED_EDGE
            side = min(image.width, image.height)
            left = (image.width - side) // 2
            top = (image.height - side) // 2
            image = image.crop((left, top, left + side, top + side))
            if side != edge:
                image = image.resize((edge, edge), Image.LANCZOS)
            buffer = io.BytesIO()
            image.save(buffer, format="PNG", optimize=True)
    except Exception as exc:  # noqa: BLE001 - any unreadable image, one answer
        return jsonify({"error": f"无法识别这张图片：{exc}"}), 400

    path = config.agent_avatar_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Written to a temp name and moved into place: a half-written PNG left
        # by a crash would be served as the avatar until the next upload.
        temp = path.with_suffix(".png.tmp")
        temp.write_bytes(buffer.getvalue())
        os.replace(temp, path)
    except OSError as exc:
        return jsonify({"error": f"保存失败：{exc}"}), 500

    # Picking a file is the more deliberate of the two ways to set the avatar,
    # so it takes effect now: a URL left in the box would outrank the picture
    # the operator just chose, and "上传了却没变化" reads as a broken button.
    # Clearing it also keeps the question "which source is in force" answerable
    # by looking at the box alone.
    persist_settings({"AGENT_AVATAR": ""})

    session = current_session()
    store.record(session.user if session else "unknown", "agent.avatar", "ok",
                 detail=f"{len(raw)} bytes in, {len(buffer.getvalue())} out",
                 ip=client_ip())
    uploaded_url = config.agent_uploaded_avatar_url()
    # Both URLs, matching the /api/hello shape: the box was just cleared, so
    # the resolved one and the upload's own are the same here — but the client
    # adopts them as two fields and they have to stay separate.
    return jsonify({"ok": True, "url": uploaded_url, "uploaded_url": uploaded_url})


@app.delete("/api/agent/avatar")
@admin_required
def api_agent_avatar_delete():
    """Remove the uploaded avatar, falling back to the built-in mark."""
    path = config.agent_avatar_file()
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        return jsonify({"error": f"删除失败：{exc}"}), 500
    session = current_session()
    store.record(session.user if session else "unknown", "agent.avatar", "removed",
                 ip=client_ip())
    return jsonify({"ok": True, "url": config.agent_avatar_url(), "uploaded_url": ""})


@app.post("/api/test")
@admin_required
def api_test():
    """Re-probe the saved endpoint from the settings page.

    Runs the same capability sweep as the wizard, so an operator who edits the
    model id months later discovers that the new endpoint cannot do tool calls
    — here, rather than on the first mission.
    """
    payload = request.get_json(silent=True) or {}
    target = str(payload.get("target", "llm")).lower()
    session = current_session()
    actor = session.user if session else "unknown"

    if target == "vlm":
        from cua.executors.vlm import test_backend

        ok, message = test_backend()
        store.record(actor, "probe.vlm", "ok" if ok else "fail",
                     detail=message[:200], ip=client_ip())
        return jsonify({"ok": ok, "message": message})

    report = model_probe.run_probes(
        config.LLM_BASE_URL, config.LLM_API_KEY, config.LLM_MODEL
    )
    required_ok = all(r.ok for r in report.results if r.severity == "required")
    failed = [r.label for r in report.results if not r.ok]
    if required_ok and not failed:
        message = f"{config.LLM_MODEL} 能力检查通过（{report.total_ms}ms）"
    else:
        message = "未通过：" + "、".join(failed)

    store.record(actor, "probe.llm", "ok" if required_ok else "fail",
                 detail=message[:200], ip=client_ip())
    return jsonify({
        "ok": required_ok and not failed,
        "message": message,
        "results": {r.key: r.as_dict() for r in report.results},
        "report": report.as_dict(),
    })


@app.get("/api/tools")
@login_required
def api_tools():
    """Tool inventory currently loaded from the JSON definitions."""
    try:
        entry = tool_loader.load_entry_point()
        raw_mode = request.args.get("mode")
        mode = modes.normalize(raw_mode) if raw_mode else None
        categories = tool_loader.available_categories()
        if mode is None:
            visible = dict(categories)
        else:
            visible = {
                name: info for name, info in categories.items()
                if modes.category_allowed(name, mode)
            }
        return jsonify({
            "mode": mode,
            "meta": [t["function"]["name"] for t in entry.get("tools", [])],
            "categories": {
                name: {
                    "tool_count": info.get("tool_count"),
                    "description": info.get("description"),
                    "tools": [
                        t["function"]["name"]
                        for t in tool_loader.load_category_tools(name)
                        if modes.tool_allowed(t["function"]["name"], mode)
                    ],
                }
                for name, info in visible.items()
            },
        })
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e)}), 500


# ── Entry point ─────────────────────────────────────────────────────────

def run_server(host: str | None = None, port: int | None = None, debug: bool = False) -> None:
    config.ensure_stdio()
    host = host or config.WEB_HOST
    port = int(port or config.WEB_PORT)

    # Pre-load the local OCR/YOLO engines in the background. Their first init
    # is where a mission used to wedge with a tool card stuck on 运行中; paying
    # the cost at startup keeps the first capture fast, and the perception
    # worker's hard deadline (see screen_capture._run_local) bounds it even
    # when the load itself hangs.
    if getattr(config, "PERCEPTION_WARMUP", False):
        try:
            from cua.executors import screen_capture as _perception

            threading.Thread(
                target=_perception.warmup, daemon=True, name="cua-perception-warmup",
            ).start()
        except Exception:
            pass  # warm-up is advisory; the tools report real errors

    print()
    print("=" * 62)
    print("  Computer Use Agent — Web Control Panel")
    print("=" * 62)
    print(f"  URL          : http://{host}:{port}")
    print(f"  Model        : {config.LLM_MODEL} @ {config.LLM_BASE_URL}")
    print(f"  Vision       : {config.resolve_vision_mode()}")
    print(f"  Max steps    : "
          f"{config.MAX_STEPS if config.MAX_STEPS_ENABLED else 'unlimited'}")
    print(f"  Accounts     : {store.store_path}")
    print(f"  Audit log    : {store.audit_path}")
    print(f"  Sessions     : {hub.sessions.dir}")
    missing = config.validate_llm_credentials()
    if missing:
        print()
        print("  !!! No API key configured — open Settings after login to set one.")
    if store.needs_setup:
        print()
        print("  *** First run: open the panel to create the admin account.")
    print()
    print("  WARNING: the agent controls the real mouse and keyboard.")
    print("           Keep your hands off them while a mission runs.")
    print("=" * 62)
    print()

    app.run(host=host, port=port, debug=debug, threaded=True, use_reloader=False)