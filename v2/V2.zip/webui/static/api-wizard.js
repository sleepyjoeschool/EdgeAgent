/* ══ 模型 API 配置向导 ═══════════════════════════════════════════════
   原参考稿的「能力测试」和「保存」是 setTimeout + alert 的模拟实现，
   这里全部换成真实后端：

     POST /api/setup/probe   探测端点能力，**不落盘**
     POST /api/setup/llm     确认后写入 config_override.json
     POST /api/settings      best-effort 补写推理强度等未被 setup/llm 覆盖的项

   探针报告本身就是中文的（label/detail 由 cua/model_probe.py 生成），
   所以这里只负责渲染，不再翻译，避免两套文案互相漂移。
   ══════════════════════════════════════════════════════════════════ */

(() => {
  "use strict";

  /* 只按 id 取元素，所以不接受 "#id" 写法。传错了会静默返回 null，
     真正的报错要等到有人 .click() 那一行才炸出来，且看不出根因——
     不如在这里当场说清楚。这份文件就踩过一次：点「测试能力」按钮抛
     "Cannot read properties of null"，而根因只是多写了一个井号。 */
  const $ = (id) => {
    if (String(id).startsWith("#")) {
      throw new Error(`$() 只接受 id，不要写 "#"：收到 ${JSON.stringify(id)}`);
    }
    return document.getElementById(id);
  };

  const CSRF_HEADER = "X-CSRF-Token";
  const state = { csrf: null, hello: null, provider: "", acknowledged: false, api: {}, probe: null, conflicts: [], forced: new Set() };

  /* ── 服务商预设 ──────────────────────────────────────────────────── */

  const PROVIDERS = {
    ollama: {
      name: "Ollama（本机）",
      docsUrl: "https://docs.ollama.com/api/openai-compatibility",
      keyUrl: "https://docs.ollama.com/api/openai-compatibility",
      baseUrl: "http://localhost:11434/v1/",
      models: ["qwen3:8b", "gpt-oss:20b", "gemma4:31b", "llama3", "mistral", "codellama", "mixtral", "deepseek-coder", "phi"],
      hint: "本地模型需要先执行 ollama pull <模型名> 拉取。部分客户端库要求填写 API Key，但 Ollama 本身会忽略它。",
      badge: { text: "本地", cls: "bd-teal" },
    },
    openai: {
      name: "ChatGPT（OpenAI）",
      docsUrl: "https://platform.openai.com/docs/api-reference/chat",
      keyUrl: "https://platform.openai.com/settings/organization/api-keys",
      baseUrl: "https://api.openai.com/v1",
      models: ["gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano", "o4-mini", "o3", "o3-mini", "o1", "o1-mini", "gpt-4o", "gpt-4o-mini"],
      hint: "完整模型列表见 platform.openai.com/docs/models。GPT-5 系列是当前生产默认选择。",
      badge: { text: "官方直连", cls: "bd-blue" },
    },
    anthropic: {
      name: "Anthropic（Claude）",
      docsUrl: "https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk",
      keyUrl: "https://platform.claude.com/settings/keys",
      baseUrl: "https://api.anthropic.com/v1/",
      models: ["claude-opus-5", "claude-sonnet-5", "claude-haiku-4-5", "claude-opus-4-8", "claude-sonnet-4-6"],
      hint: "Anthropic 提供 OpenAI SDK 兼容层。注意：严格的函数调用会被忽略；多条 system 消息会被合并到开头的一条。",
      badge: { text: "官方直连", cls: "bd-orange" },
    },
    google: {
      name: "Google（Gemini）",
      docsUrl: "https://ai.google.dev/gemini-api/docs/openai",
      keyUrl: "https://aistudio.google.com/apikey",
      baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai/",
      models: ["gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.1-pro", "gemini-3-flash", "gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite"],
      hint: "Gemini 的 OpenAI 兼容层使用 /v1beta/openai/ 作为 Base URL。",
      badge: { text: "官方直连", cls: "bd-sky" },
    },
    openrouter: {
      name: "OpenRouter",
      docsUrl: "https://openrouter.ai/docs/api_reference/responses/overview",
      keyUrl: "https://openrouter.ai/keys",
      baseUrl: "https://openrouter.ai/api/v1",
      models: ["openai/o4-mini", "openai/gpt-4o", "anthropic/claude-sonnet-5", "google/gemini-2.5-pro", "deepseek/deepseek-v3.2", "x-ai/grok-4.5"],
      hint: "聚合 400 多个模型，可用 /models 接口拉取完整目录。模型 ID 形如 “厂商/模型名”。",
      badge: { text: "400+ 模型", cls: "bd-emerald" },
    },
    "opencode-go": {
      name: "OpenCode GO",
      docsUrl: "https://opencode.ai/docs/go",
      keyUrl: "https://opencode.ai/auth",
      baseUrl: "https://opencode.ai/zen/go/v1",
      // 取自 GET https://opencode.ai/zen/go/v1/models 的真实清单。
      // 这份清单会随官方上下架变化，过期不会报错、只会 404 模型，所以宁可少列。
      models: ["glm-5.3", "glm-5.2", "kimi-k3", "kimi-k2.7-code", "minimax-m3",
               "deepseek-v4-pro", "deepseek-v4-flash", "qwen3.8-max", "grok-4.7", "hy3"],
      hint: "每月 10 美元订阅。本面板会自动按官方要求补上 x-opencode-session 会话头，无需手工配置；"
            + "若改用中转站地址（选「自定义」粘贴），后端按 /zen/go/v1 路径同样识别，不必手工加头。",
      badge: { text: "$10/月", cls: "bd-violet" },
    },
    tencent: {
      name: "腾讯云 Token Plan / 个人版",
      docsUrl: "https://cloud.tencent.cn/document/product/1823/130119",
      keyUrl: "https://console.cloud.tencent.com/tokenhub/tokenplan",
      baseUrl: "https://api.lkeap.cloud.tencent.com/plan/v3",
      models: ["Auto"],
      hint: "选 Auto 由平台自动选择可用模型。",
      badge: { text: "国内", cls: "bd-blue" },
    },
    "tencent-hub": {
      name: "腾讯云 TokenHub",
      docsUrl: "https://cloud.tencent.com.cn/document/product/1823/130078",
      keyUrl: "https://console.cloud.tencent.com/tokenhub/apikey",
      baseUrl: "https://tokenhub.tencentmaas.com/v1",
      models: ["hy3", "deepseek/deepseek-v4-pro", "deepseek/deepseek-flash"],
      hint: "TokenHub 会按模型名路由，部分模型需带厂商前缀。",
      badge: { text: "国内", cls: "bd-blue" },
    },
    glm: {
      name: "智谱 GLM 开放平台",
      docsUrl: "https://docs.bigmodel.cn",
      keyUrl: "https://bigmodel.cn/usercenter/proj-mgmt/apikeys",
      baseUrl: "https://open.bigmodel.cn/api/paas/v4",
      models: ["glm-5.3", "glm-5.3-flash", "glm-5.2", "glm-5.1"],
      hint: "智谱开放平台的 OpenAI 兼容接口。",
      badge: { text: "国内", cls: "bd-orange" },
    },
    kimi: {
      name: "Kimi（月之暗面）",
      docsUrl: "https://platform.kimi.com/docs/api/overview",
      keyUrl: "https://platform.kimi.com/console/api-keys",
      baseUrl: "https://api.moonshot.cn/v1",
      models: ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k"],
      hint: "月之暗面开放平台的 OpenAI 兼容接口，模型名决定上下文长度。",
      badge: { text: "国内", cls: "bd-violet" },
    },
    minimax: {
      name: "MiniMax",
      docsUrl: "https://platform.minimax.cn/docs/api-reference/text-openai-api",
      keyUrl: "https://platform.minimax.cn",
      baseUrl: "https://api.minimax.cn/v1",
      models: ["MiniMax-M3", "MiniMax-M2.7", "MiniMax-M2.7-highspeed", "MiniMax-M2.5"],
      hint: "MiniMax 的 OpenAI 兼容接口。",
      badge: { text: "国内", cls: "bd-sky" },
    },
    deepseek: {
      name: "DeepSeek",
      docsUrl: "https://api-docs.deepseek.com",
      keyUrl: "https://platform.deepseek.com/api_keys",
      baseUrl: "https://api.deepseek.com",
      models: ["deepseek-chat", "deepseek-reasoner", "deepseek-v4-pro"],
      hint: "deepseek-chat 为通用对话模型，deepseek-reasoner 带思维链。",
      badge: { text: "国内", cls: "bd-blue" },
    },
  };

  /* 推理强度：各服务商支持的可选值与默认值。文案与 cua/model_probe.py 的中文口径保持一致。 */
  const EFFORT = {
    openai: { options: ["none", "minimal", "low", "medium", "high", "xhigh"], def: "medium", hint: "与具体模型有关，部分 GPT 模型不支持 none。" },
    anthropic: { options: ["low", "medium", "high", "xhigh"], def: "high", hint: "对应 output_config.effort，默认 high。" },
    google: { options: ["none", "minimal", "low", "medium", "high"], def: "medium", hint: "对应 thinking_level，none 表示关闭思考。" },
    deepseek: { options: ["low", "medium", "high"], def: "high", hint: "默认 high。低强度适合轻量任务。" },
    openrouter: { options: ["none", "minimal", "low", "medium", "high", "xhigh"], def: "medium", hint: "跨 400+ 模型做了归一化，实际可用值因模型而异。" },
    ollama: { options: ["low", "medium", "high"], def: "medium", hint: "本地模型是否支持取决于模型架构。" },
    "opencode-go": { options: ["none", "low", "medium", "high"], def: "medium", hint: "对具备推理能力的模型生效。" },
    glm: { options: ["none", "low", "medium", "high"], def: "medium", hint: "对具备推理能力的 GLM 模型生效。" },
    kimi: { options: ["low", "medium", "high"], def: "medium", hint: "对具备推理能力的 Kimi 模型生效。" },
    minimax: { options: ["low", "medium", "high"], def: "medium", hint: "对具备推理能力的 MiniMax 模型生效。" },
    tencent: { options: ["none", "low", "medium", "high"], def: "medium", hint: "是否可用取决于所选模型。" },
    "tencent-hub": { options: ["none", "low", "medium", "high"], def: "medium", hint: "是否可用取决于所选模型。" },
    custom: { options: ["low", "medium", "high"], def: "", hint: "请查阅服务商文档确认可接受的取值。" },
  };

  const EFFORT_DESC = {
    none: { t: "关闭", b: "几乎不产生推理 token，首字延迟最低，适合分类、简单改写这类轻量任务。" },
    minimal: { t: "极低", b: "推理 token 极少，适合对速度敏感且不太需要分析的任务。" },
    low: { t: "低", b: "兼顾成本与速度，具备基础分析能力。" },
    medium: { t: "中", b: "多数推理模型的默认档位，速度与深度较为均衡。" },
    high: { t: "高", b: "模型会尝试多种路径并自行校验，适合多步规划类任务，延迟与 token 消耗明显上升。" },
    xhigh: { t: "极高", b: "在「高」的基础上进一步放宽思考预算，面向复杂问题。" },
    max: { t: "最高", b: "推理深度的上限，成本与耗时都最高。" },
  };

  const ACK_PHRASE = "我已知晓上述风险";

  /* ── 基础工具 ────────────────────────────────────────────────────── */

  function escapeHtml(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, (c) => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
    ));
  }

  function toast(message, isError = false) {
    const el = $("wz-toast");
    el.textContent = message;
    el.classList.toggle("is-err", !!isError);
    el.classList.add("is-show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove("is-show"), 3200);
  }

  function setAlert(message, kind) {
    const el = $("wz-alert");
    if (!message) { el.classList.add("hidden"); el.textContent = ""; return; }
    el.textContent = message;
    el.className = "wz-alert" + (kind ? ` is-${kind}` : "");
  }

  async function api(path, options = {}) {
    const headers = { "Content-Type": "application/json" };
    if (state.csrf && options.method && options.method !== "GET") headers[CSRF_HEADER] = state.csrf;
    const res = await fetch(path, { headers, credentials: "same-origin", ...options });
    let data = null;
    try { data = await res.json(); } catch (err) { /* 空响应体 */ }
    if (!res.ok) {
      const err = new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
      err.status = res.status;
      err.payload = data;
      throw err;
    }
    return data;
  }

  /* ── 门禁：未登录 / 非管理员 ─────────────────────────────────────── */

  async function checkAccess() {
    try {
      state.hello = await api("/api/hello");
    } catch (err) {
      showGate("无法连接后端：" + err.message);
      return false;
    }
    if (!state.hello.authenticated) {
      showGate("尚未登录。请先回到控制台完成登录，再从这里配置模型 API。");
      return false;
    }
    const caps = (state.hello.user && state.hello.user.capabilities) || [];
    if (caps.indexOf("admin") < 0) {
      showGate("当前账号不是管理员，无法读取或修改 API 配置。");
      return false;
    }
    state.csrf = (state.hello.user && state.hello.user.csrf) || null;
    return true;
  }

  function showGate(text) {
    $("wz-gate").classList.remove("hidden");
    $("wz-gate-text").textContent = text;
    ["step-1-welcome", "step-2", "step-3-warning", "step-4", "step-5-test", "expert-view", "wz-steps"]
      .forEach((id) => $(id).classList.add("hidden"));
    $("btn-next").classList.add("hidden");
    $("btn-back").classList.add("hidden");
    $("btn-save").classList.add("hidden");
    $("expert-btn-save").classList.add("hidden");
  }

  /* ── 步骤导航 ────────────────────────────────────────────────────── */

  let step = 1;
  let mode = "wizard";

  const PANELS = { 1: "step-1-welcome", 2: "step-2", 3: "step-3-warning", 4: "step-4", 5: "step-5-test" };
  const TITLES = { 1: "模型 API 配置向导", 2: "选择服务商", 3: "确认风险", 4: "配置模型", 5: "能力测试" };

  function isCustom() { return state.provider === "custom"; }

  function renderSteps() {
    // 自定义服务商多一步风险确认，所以两条路径的编号不同：
    // 官方服务商走 1→2→4→5，自定义走 1→2→3→4→5。
    const custom = isCustom();
    const map = custom
      ? [[1, "1", "说明"], [2, "2", "服务商"], [3, "3", "风险确认"], [4, "4", "配置"], [5, "5", "测试"]]
      : [[1, "1", "说明"], [2, "2", "服务商"], [4, "3", "配置"], [5, "4", "测试"]];

    [1, 2, 3, 4, 5].forEach((n) => $(`step-indicator-${n}`).classList.add("hidden"));
    [1, 2, 3, 4].forEach((n) => $(`step-sep-${n}`).classList.add("hidden"));

    map.forEach(([n, num, label], i) => {
      const el = $(`step-indicator-${n}`);
      el.classList.remove("hidden");
      el.querySelector(".wz-dot").textContent = num;
      el.querySelector(".wz-step-label").textContent = label;
      el.classList.toggle("is-current", n === step);
      el.classList.toggle("is-done", n < step);
      if (i < map.length - 1) $(`step-sep-${n}`).classList.remove("hidden");
    });
  }

  function render() {
    Object.values(PANELS).forEach((id) => $(id).classList.add("hidden"));
    $("expert-view").classList.add("hidden");
    $("wz-steps").classList.remove("hidden");

    if (mode === "expert") {
      $("expert-view").classList.remove("hidden");
      $("wz-steps").classList.add("hidden");
      $("wz-title").textContent = "专家配置";
      $("btn-back").classList.add("hidden");
      $("btn-next").classList.add("hidden");
      $("btn-save").classList.add("hidden");
      $("expert-btn-save").classList.remove("hidden");
      $("wz-foot-note").textContent = "";
      renderExpert();
      return;
    }

    $(PANELS[step]).classList.remove("hidden");
    $("wz-title").textContent = TITLES[step];
    $("expert-btn-save").classList.add("hidden");
    $("btn-save").classList.toggle("hidden", step !== 5);
    $("btn-back").classList.toggle("hidden", step === 1);
    $("btn-next").classList.toggle("hidden", step === 5);
    $("btn-next").textContent = step === 4 ? "测试能力" : "下一步";
    $("wz-foot-note").textContent = isCustom() ? "自定义服务商需先确认风险" : "";
    renderSteps();
    syncNext();
  }

  /** 「下一步」是否可点：只有选完服务商、抄完确认语才放行。 */
  function syncNext() {
    let ok = true;
    if (step === 2) ok = !!state.provider;
    if (step === 3) ok = state.acknowledged;
    $("btn-next").disabled = !ok;
  }

  $("btn-next").addEventListener("click", () => {
    if (step === 1) { step = 2; render(); return; }
    if (step === 2) {
      if (!state.provider) return;
      if (isCustom()) { step = 3; render(); }
      else { fillConfigure(); step = 4; render(); }
      return;
    }
    if (step === 3) { fillConfigure(); step = 4; render(); return; }
    // $ 就是 getElementById，不要传 "#id" —— 它会按字面去找一个 id 叫
    // "#btn-run-tests" 的元素，永远是 null，点「测试能力」直接抛
    // "Cannot read properties of null"。第 4 步的按钮也就成了摆设。
    if (step === 4) { runBtn.click(); }
  });

  $("btn-back").addEventListener("click", () => {
    if (step === 5) { step = 4; render(); return; }
    if (step === 4) { step = isCustom() ? 3 : 2; render(); return; }
    if (step === 3) { step = 2; render(); return; }
    if (step === 2) { step = 1; render(); }
  });

  $("mode-wizard").addEventListener("click", () => setMode("wizard"));
  $("mode-expert").addEventListener("click", () => setMode("expert"));
  $("jump-to-expert").addEventListener("click", () => setMode("expert"));

  function setMode(next) {
    mode = next;
    $("mode-wizard").classList.toggle("is-active", next === "wizard");
    $("mode-expert").classList.toggle("is-active", next === "expert");
    setAlert("");
    render();
  }

  /* ── 服务商选择 ──────────────────────────────────────────────────── */

  const providerSelect = $("provider-select");
  const expertProviderSelect = $("expert-provider-select");

  providerSelect.addEventListener("change", (e) => {
    state.provider = e.target.value;
    const p = PROVIDERS[state.provider];
    $("docs-link-step1").href = (p && p.docsUrl) || "#";
    syncNext();
  });

  /* ── 风险确认 ────────────────────────────────────────────────────── */

  const ackInput = $("ack-input");
  const ackFeedback = $("ack-feedback");

  ackInput.addEventListener("input", () => {
    const value = ackInput.value.trim();
    state.acknowledged = value === ACK_PHRASE;
    if (state.acknowledged) {
      ackFeedback.textContent = "已确认，可以继续。";
      ackFeedback.style.color = "var(--ok)";
    } else if (value) {
      ackFeedback.textContent = "文字不一致，请检查是否有多余空格或标点。";
      ackFeedback.style.color = "var(--err)";
    } else {
      ackFeedback.textContent = "需完全匹配，区分大小写与标点。";
      ackFeedback.style.color = "";
    }
    syncNext();
  });

  /* ── 配置步骤 ────────────────────────────────────────────────────── */

  function fillConfigure() {
    const p = PROVIDERS[state.provider];
    const custom = isCustom();

    $("selected-provider-display").innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 010 20 15.3 15.3 0 010-20z"/></svg>
      <span>${escapeHtml(p ? p.name : "自定义")}</span>
      ${p && p.badge ? `<span class="wz-badge ${p.badge.cls}">${escapeHtml(p.badge.text)}</span>` : ""}`;

    $("field-endpoint").classList.toggle("hidden", !custom);
    $("field-base-url").classList.toggle("hidden", custom);
    $("field-model-dropdown").classList.toggle("hidden", custom);
    $("field-model-input").classList.toggle("hidden", !custom);

    if (custom) {
      $("model-free-input").value = $("model-free-input").value || "";
    } else {
      $("base-url-input").value = (p && p.baseUrl) || "";
      const models = (p && p.models) || [];
      $("model-options").innerHTML = models.map((m) => `<option value="${escapeHtml(m)}"></option>`).join("");
      // 无条件覆盖：这个函数只在（重新）选定服务商后进入配置步时调用。
      // 早先用「值为空才填」，于是从 DeepSeek 换成 OpenAI 后模型 ID 仍是
      // deepseek-chat，配上一个 OpenAI 的 Base URL —— 一个自相矛盾的组合。
      $("model-select-input").value = models[0] || "";
      $("model-hint").textContent = (p && p.hint) || "";
    }

    $("docs-link-step2").href = (p && p.keyUrl) || "#";

    // 推理强度：换服务商后要重建选项，否则会留着上一家的取值。
    const cfg = EFFORT[state.provider] || EFFORT.custom;
    const sel = $("reasoning-effort-select");
    sel.innerHTML = '<option value="" disabled>使用服务商默认值</option>'
      + cfg.options.map((o) => `<option value="${o}">${o}</option>`).join("");
    sel.value = cfg.def || "";
    $("reasoning-effort-hint").textContent = cfg.hint || "";
    renderEffortBadges($("reasoning-effort-badges"), cfg.options, cfg.def || "", state.provider, syncEffort);
    renderEffortReference($("reasoning-effort-reference-body"), state.provider, cfg.options, cfg.def || "");
    renderEffortDesc($("reasoning-effort-description"), state.provider, cfg.def || "");
  }

  function effortDesc(provider, level) {
    if (!level) return null;
    if (provider === "deepseek") {
      return { none: { t: "关闭", b: "关闭思考模式，响应最快，不输出思维链。" } }[level] || EFFORT_DESC[level];
    }
    return EFFORT_DESC[level] || null;
  }

  /* 推理强度的两条编辑路径（点徽标 / 改下拉）必须落到同一个副作用上，
     否则会出现「下拉显示 high、说明还写着 medium」这种自相矛盾的界面。 */
  function syncEffort(level) {
    $("reasoning-effort-select").value = level;
    $("reasoning-effort-badges").querySelectorAll(".wz-badge-btn")
      .forEach((x) => x.classList.toggle("is-active", x.dataset.value === level));
    renderEffortDesc($("reasoning-effort-description"), state.provider, level);
  }

  function syncExpertEffort(level) {
    $("expert-reasoning-effort-select").value = level;
    $("expert-reasoning-effort-badges").querySelectorAll(".wz-badge-btn")
      .forEach((x) => x.classList.toggle("is-active", x.dataset.value === level));
    renderEffortDesc($("expert-reasoning-effort-description"), expertProvider, level);
  }

  function renderEffortDesc(host, provider, level) {
    const d = effortDesc(provider, level);
    if (!d) { host.classList.add("hidden"); return; }
    const title = host.querySelector("b");
    const body = host.querySelector("span");
    if (title) title.textContent = d.t;
    if (body) body.textContent = d.b;
    host.classList.remove("hidden");
  }

  function renderEffortBadges(host, options, selected, provider, onPick) {
    host.innerHTML = options.map((o) => {
      const d = effortDesc(provider, o);
      return `<button type="button" class="wz-badge-btn${o === selected ? " is-active" : ""}"
        data-value="${escapeHtml(o)}"${d ? ` title="${escapeHtml(d.t + "：" + d.b)}"` : ""}>${escapeHtml(o)}</button>`;
    }).join("");
    host.querySelectorAll(".wz-badge-btn").forEach((b) => {
      b.addEventListener("click", () => {
        const cur = host.querySelector(".wz-badge-btn.is-active");
        const next = cur && cur.dataset.value === b.dataset.value ? "" : b.dataset.value;
        host.querySelectorAll(".wz-badge-btn").forEach((x) => x.classList.toggle("is-active", x.dataset.value === next));
        onPick(next);
      });
    });
  }

  function renderEffortReference(host, provider, options, def) {
    host.innerHTML = options.map((o) => {
      const d = effortDesc(provider, o);
      return `<div class="wz-ref-row">
        <span class="wz-ref-key">${escapeHtml(o)}${o === def ? " •默认" : ""}</span>
        <span>${escapeHtml(d ? d.b : "")}</span></div>`;
    }).join("");
  }

  // 勾掉「思维链」时收起推理强度，避免提交一个用户看不见的取值。
  $("check-reasoning").addEventListener("change", (e) => {
    $("field-reasoning-effort").classList.toggle("hidden", !e.target.checked);
  });
  $("check-reasoning").dispatchEvent(new Event("change"));

  /* 上下文窗口徽标：点一下写入，再点一下清空。 */
  function setupContextBadges(badges, input) {
    badges.addEventListener("click", (e) => {
      const b = e.target.closest(".wz-badge-btn");
      if (!b) return;
      input.value = input.value === b.dataset.value ? "" : b.dataset.value;
      badges.querySelectorAll(".wz-badge-btn").forEach((x) => x.classList.toggle("is-active", x.dataset.value === input.value));
    });
    input.addEventListener("input", () => {
      badges.querySelectorAll(".wz-badge-btn").forEach((x) => x.classList.toggle("is-active", x.dataset.value === input.value));
    });
  }
  setupContextBadges($("input-badges"), $("input-context-input"));
  setupContextBadges($("output-badges"), $("output-context-input"));
  setupContextBadges($("expert-input-badges"), $("expert-input-context"));
  setupContextBadges($("expert-output-badges"), $("expert-output-context"));

  /* 推理强度下拉：用手输/切换时，徽标高亮与说明文字都要跟着走。
     只靠徽标点击同步会让两条编辑路径表现不一致。 */
  $("reasoning-effort-select").addEventListener("change", (e) => syncEffort(e.target.value || ""));
  $("expert-reasoning-effort-select").addEventListener("change", (e) => syncExpertEffort(e.target.value || ""));

  /* 显示 / 隐藏 API Key */
  $("api-key-eye").addEventListener("click", () => {
    const el = $("api-key");
    const show = el.type === "password";
    el.type = show ? "text" : "password";
    $("api-key-eye").title = show ? "隐藏密钥" : "显示密钥";
  });

  /* ── 读取表单 → 请求体 ───────────────────────────────────────────── */

  function readConfig() {
    const custom = isCustom();
    const baseUrl = custom ? $("endpoint-input").value.trim() : $("base-url-input").value.trim();
    const model = custom ? $("model-free-input").value.trim() : $("model-select-input").value.trim();
    const withImage = $("check-image").checked;
    const withThinking = $("check-reasoning").checked;

    // 勾选项直接映射成意图，交给 /api/setup/probe 与真实探测结果对照，
    // 冲突会在第 5 步列出来——这正是「测试」这一步的价值。
    const visionMode = withImage ? "multimodal" : "text_vlm";
    const capability = withThinking ? "thinking" : (withImage ? "vision" : "plain");

    return {
      base_url: baseUrl,
      api_key: $("api-key").value,
      model,
      vision_mode: visionMode,
      capability,
      // 不勾「思维链」就不该带上推理强度：面板已收起，用户看不到也改不了这个值，
      // 把它一起提交等于把一个看不见的档位写进配置。
      reasoning_effort: withThinking ? ($("reasoning-effort-select").value || "") : "",
      context_input: $("input-context-input").value.trim(),
      context_output: $("output-context-input").value.trim(),
      tool_calling: $("check-tool").checked,
    };
  }

  /* ── 第 5 步：能力测试 ───────────────────────────────────────────── */

  const TEST_CARDS = {
    tool: { match: ["tool_calls", "tool_results"], name: "工具调用" },
    image: { match: ["vision"], name: "图片输入" },
    reasoning: { match: ["thinking"], name: "思维链" },
  };

  function setStatus(cardId, kind, text) {
    const el = document.querySelector(`#${cardId} [data-status]`);
    if (!el) return;
    el.className = "wz-status" + (kind ? ` is-${kind}` : "");
    el.textContent = text;
  }

  /**
   * Roll several probe rows up into one badge.
   *
   * 「部分可用」只在一项通过、另一项没通过时才对。若这一组里**一条都没通过**，
   * 那是不支持而不是部分可用——把「可选能力缺失」显示成部分可用，等于告诉
   * 操作者模型似乎还行，而这正是探测要澄清的事情。
   */
  function statusFor(mine) {
    if (!mine.length) return ["", "未测试"];
    if (mine.some((r) => probeClass(r) === "fail")) return ["fail", "不支持"];
    const passes = mine.filter((r) => probeClass(r) === "pass").length;
    if (passes === mine.length) return ["pass", "通过"];
    if (passes === 0) {
      // 「未验证」和「未测试」都是「没测出结果」，不是「不支持」。
      // 早先只有 skipped 走这条路，inconclusive 会掉进 fail 分支，
      // 于是限流导致的探测失败被显示成「不支持」——那正是操作者读到的结论。
      return mine.every((r) => probeClass(r) === "skip" || r.inconclusive)
        ? ["skip", "未验证"]
        : ["fail", "不支持"];
    }
    return ["running", "部分可用"];
  }

  function probeClass(r) {
    if (r.skipped) return "skip";
    if (r.ok) return "pass";
    // 未验证：探测跑了但没得出结论（限流 / 5xx），不能算失败。
    if (r.inconclusive) return "skip";
    return r.severity === "required" ? "fail" : "warn";
  }

  function probeHtml(r) {
    const cls = probeClass(r);
    const mark = cls === "pass" ? "✓" : cls === "fail" ? "✕" : cls === "warn" ? "!" : "–";
    const tag = r.severity === "required" ? "必需" : "可选";
    return `<div class="wz-probe is-${cls}">
      <span class="wz-probe-mark">${mark}</span>
      <div>
        <div class="wz-probe-name">${escapeHtml(r.label)}
          <span class="wz-probe-tag${r.severity === "required" ? " is-required" : ""}">${tag}</span>
        </div>
        <div class="wz-probe-detail">${escapeHtml(r.detail)}</div>
      </div>
      <span class="wz-probe-ms">${r.ms ? r.ms + "ms" : "—"}</span>
      ${r.evidence ? `<div class="wz-probe-evidence">${escapeHtml(r.evidence)}</div>` : ""}
    </div>`;
  }

  function conflictHtml(c) {
    const blocking = c.severity === "blocking";
    const forced = state.forced.has(c.key);
    const badge = blocking ? "必须处理" : forced ? "已强制保留" : "建议修改";
    let choices = "";
    if (c.fixable && c.suggestion) {
      // 两个选项互斥：被选中的一侧显示「已选」，另一侧留一个按钮。
      // 早先两侧都跟着 forced 走，结果一选「强制保留」两个按钮一起消失，
      // 用户再也退不回建议值——一个只能单向切换的选择器。
      choices = `
        <div class="wz-choice">
          <span>选项 A</span>
          <code>${escapeHtml(c.suggestion)}</code>
          <span class="wz-muted">按探测结果自动调整</span>
          <span class="wz-spacer"></span>
          ${forced
            ? '<button type="button" class="wz-mini" data-action="suggest">改用建议</button>'
            : '<span class="wz-picked">✓ 已选</span>'}
        </div>
        <div class="wz-choice">
          <span>选项 B</span>
          <code>${escapeHtml(String(c.chosen))}</code>
          <span class="wz-muted">忽略探测结果，强制保留</span>
          <span class="wz-spacer"></span>
          ${forced
            ? '<span class="wz-picked">✓ 已选</span>'
            : '<button type="button" class="wz-mini" data-action="force">强制保留</button>'}
        </div>`;
    } else if (!blocking) {
      choices = '<div class="wz-choice"><span class="wz-muted">该问题不影响启动，保存后可在「设置 → API」页继续处理。</span></div>';
    }
    return `<div class="wz-conflict${blocking ? " is-blocking" : forced ? " is-resolved" : ""}">
      <div class="wz-conflict-head"><span class="wz-conflict-badge">${badge}</span><b>${escapeHtml(c.label)}</b></div>
      <p class="wz-conflict-why">${escapeHtml(c.explain)}</p>
      ${choices}
    </div>`;
  }

  function renderProbe() {
    const report = state.probe || { results: [] };
    const results = report.results || [];

    $("test-model-display").textContent = report.model || readConfig().model || "—";

    Object.entries(TEST_CARDS).forEach(([key, def]) => {
      const [kind, text] = statusFor(results.filter((r) => def.match.indexOf(r.key) >= 0));
      setStatus(`test-card-${key}`, kind, text);
    });

    $("test-detail-wrap").classList.remove("hidden");
    $("test-detail").innerHTML = results.map(probeHtml).join("");

    const zone = $("test-conflicts");
    zone.innerHTML = state.conflicts.map(conflictHtml).join("");
    zone.querySelectorAll("[data-action]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const box = btn.closest(".wz-conflict");
        const idx = Array.from(zone.querySelectorAll(".wz-conflict")).indexOf(box);
        const c = state.conflicts[idx];
        if (!c) return;
        if (btn.dataset.action === "force") state.forced.add(c.key);
        else state.forced.delete(c.key);
        renderProbe();
      });
    });

    const blocked = state.conflicts.some((c) => c.severity === "blocking");
    const passed = results.filter((r) => r.ok).map((r) => r.label);
    const summary = $("test-summary");
    summary.className = "wz-summary" + (blocked ? " is-bad" : " is-ok");
    summary.innerHTML = blocked
      ? "<b>无法继续：</b>该模型缺少必需能力，任何设置都无法让代理工作。请更换模型或端点后重新测试。"
      : `必需能力<b>全部通过</b>，总耗时 ${report.total_ms || 0}ms。`
        + (passed.length ? ` 可用能力：${passed.map(escapeHtml).join("、")}。` : "")
        + " 确认后将写入 config_override.json。";

    const save = $("btn-save");
    save.disabled = blocked;
    save.textContent = blocked ? "无法保存" : "保存并进入控制台";
    save.onclick = blocked ? null : saveConfig;
  }

  const runBtn = $("btn-run-tests");

  async function runProbe(opts = {}) {
    // 专家模式与向导模式读的是两套表单，取错表单会让探测跑在一个空配置上。
    const cfg = opts.expert ? readExpert() : readConfig();
    if (!cfg.base_url) throw new Error(opts.expert && expertProvider === "custom" ? "请填写接口地址" : "请填写 Base URL");
    if (!cfg.model) throw new Error("请填写模型 ID");
    if (!cfg.tool_calling) throw new Error("必须启用「工具调用」：计算机操作代理完全依赖它");

    return api("/api/setup/probe", {
      method: "POST",
      body: JSON.stringify({
        base_url: cfg.base_url,
        api_key: cfg.api_key,
        model: cfg.model,
        vision_mode: cfg.vision_mode,
        capability: cfg.capability,
        include_optional: opts.includeOptional !== false,
      }),
    });
  }

  runBtn.addEventListener("click", async () => {
    const enteredFromConfigure = step === 4;
    if (runBtn.disabled) return;
    setAlert("");
    runBtn.disabled = true;
    const original = runBtn.innerHTML;
    runBtn.innerHTML = '<svg class="wz-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>正在测试…';

    if (enteredFromConfigure) {
      Object.keys(TEST_CARDS).forEach((k) => setStatus(`test-card-${k}`, "running", "测试中…"));
      step = 5;
      render();
    }

    try {
      const res = await runProbe();
      state.probe = res.report;
      state.conflicts = res.conflicts || [];
      state.forced = new Set();
      renderProbe();
    } catch (err) {
      Object.keys(TEST_CARDS).forEach((k) => setStatus(`test-card-${k}`, "", "未测试"));
      setAlert("探测失败：" + err.message, "err");
      // 判据是「这次是从配置步推进来的」，不是「还没有旧报告」。
      // 用后者会有一个很难查的组合：先测成功一次，改坏配置再测失败 →
      // 页面停在结果页展示上一次的报告，看起来像是新结果。
      if (enteredFromConfigure) { step = 4; render(); }
    } finally {
      runBtn.disabled = false;
      runBtn.innerHTML = original;
    }
  });

  /* ── 保存 ────────────────────────────────────────────────────────── */

  async function saveConfig() {
    const cfg = readConfig();
    const btn = $("btn-save");
    btn.disabled = true;
    const original = btn.textContent;
    btn.textContent = "保存中…";
    setAlert("");

    const acknowledged = {};
    state.conflicts.forEach((c) => { if (state.forced.has(c.key)) acknowledged[c.key] = true; });

    try {
      const res = await api("/api/setup/llm", {
        method: "POST",
        body: JSON.stringify({
          base_url: cfg.base_url,
          api_key: cfg.api_key,
          model: cfg.model,
          vision_mode: cfg.vision_mode,
          capability: cfg.capability,
          acknowledged,
        }),
      });

      // 推理强度不在 /api/setup/llm 的入参里，单独补写一次；失败不影响主流程。
      const extras = await writeExtras(cfg);
      toast(`已保存 ${res.applied.length + extras} 项配置`);
      // 主模型配置已落盘，控制台的「模型」按钮与设置页都读得到新值。
      location.href = "/";
    } catch (err) {
      btn.disabled = false;
      btn.textContent = original;
      const conflicts = err.payload && err.payload.conflicts;
      if (conflicts && conflicts.length) {
        state.conflicts = conflicts;
        state.probe = (err.payload && err.payload.report) || state.probe;
        renderProbe();
      }
      setAlert("保存失败：" + err.message, "err");
      toast(err.message, true);
    }
  }

  /** 写入探针不产出、但向导会收集的项（推理强度、实测能力标记）。 */
  async function writeExtras(cfg) {
    const body = {};
    if (cfg.reasoning_effort) body.REASONING_EFFORT = cfg.reasoning_effort;
    const caps = (state.probe && state.probe.results) || [];
    const find = (k) => caps.find((r) => r.key === k);
    const vis = find("vision");
    const think = find("thinking");
    if (vis) body.LLM_PROBED_VISION = !!vis.ok;
    if (think) body.LLM_PROBED_THINKING = !!think.ok;
    if (!Object.keys(body).length) return 0;
    try {
      const res = await api("/api/settings", { method: "POST", body: JSON.stringify(body) });
      return (res.applied || []).length;
    } catch (err) {
      return 0; // 主配置已保存，这里的补充项失败不阻断
    }
  }

  /* ── 测试连通性 ──────────────────────────────────────────────────── */

  $("btn-test-connection").addEventListener("click", (e) => doConnectionTest(e.currentTarget, $("api-key").value, false));

  async function doConnectionTest(btn, apiKey, expert) {
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = "测试中…";
    setAlert("");
    try {
      const cfg = expert ? readExpert() : readConfig();
      if (!cfg.base_url || !cfg.model) throw new Error("请先填写接口地址与模型 ID");
      const res = await api("/api/setup/probe", {
        method: "POST",
        body: JSON.stringify({
          base_url: cfg.base_url,
          api_key: apiKey,
          model: cfg.model,
          include_optional: false,
        }),
      });
      const rs = (res.report && res.report.results) || [];
      const bad = rs.filter((r) => !r.ok && r.severity === "required");
      if (bad.length) {
        setAlert(`连通性测试未通过：${bad.map((r) => r.label).join("、")} —— ${bad[0].detail}`, "err");
        toast("连通性测试未通过", true);
      } else {
        setAlert(`连通性正常：${res.report.model} @ ${res.report.base_url}（${res.report.total_ms}ms）`, "ok");
        toast("连通性正常");
      }
    } catch (err) {
      setAlert("测试失败：" + err.message, "err");
      toast(err.message, true);
    } finally {
      btn.disabled = false;
      btn.textContent = original;
    }
  }

  /* ── 专家模式 ────────────────────────────────────────────────────── */

  let expertProvider = "";

  expertProviderSelect.addEventListener("change", (e) => {
    expertProvider = e.target.value;
    $("expert-model-input").value = "";
    renderExpert();
  });

  function readExpert() {
    const custom = expertProvider === "custom";
    const withImage = $("expert-check-image").checked;
    const withThinking = $("expert-check-reasoning").checked;
    return {
      base_url: custom ? $("expert-endpoint-input").value.trim() : $("expert-base-url-input").value.trim(),
      api_key: $("expert-api-key").value,
      model: $("expert-model-input").value.trim(),
      vision_mode: withImage ? "multimodal" : "text_vlm",
      capability: withThinking ? "thinking" : (withImage ? "vision" : "plain"),
      reasoning_effort: withThinking ? ($("expert-reasoning-effort-select").value || "") : "",
      context_input: $("expert-input-context").value.trim(),
      context_output: $("expert-output-context").value.trim(),
      tool_calling: $("expert-check-tool").checked,
    };
  }

  function renderExpert() {
    if (!expertProvider) {
      expertProvider = state.provider && state.provider !== "custom" ? state.provider : "openai";
    }
    expertProviderSelect.value = expertProvider;

    const custom = expertProvider === "custom";
    const p = custom ? null : PROVIDERS[expertProvider];

    $("expert-field-endpoint").classList.toggle("hidden", !custom);
    $("expert-field-base-url").classList.toggle("hidden", custom);
    if (custom) {
      $("expert-base-url-input").value = "";
    } else {
      $("expert-base-url-input").value = (p && p.baseUrl) || "";
    }

    $("expert-docs-link").href = (p && p.keyUrl) || "#";

    const dl = $("expert-model-options");
    if (custom) {
      dl.innerHTML = "";
      $("expert-model-hint").textContent = "";
      $("expert-model-input").placeholder = "例如 deepseek-chat 或 openai/gpt-4o";
    } else {
      const models = (p && p.models) || [];
      dl.innerHTML = models.map((m) => `<option value="${escapeHtml(m)}"></option>`).join("");
      if (!$("expert-model-input").value && models.length) $("expert-model-input").value = models[0];
      $("expert-model-hint").textContent = (p && p.hint) || "";
      $("expert-model-input").placeholder = "选择或直接输入模型 ID…";
    }

    const cfg = EFFORT[expertProvider] || EFFORT.custom;
    const sel = $("expert-reasoning-effort-select");
    sel.innerHTML = '<option value="" disabled>使用服务商默认值</option>'
      + cfg.options.map((o) => `<option value="${o}">${o}</option>`).join("");
    sel.value = cfg.def || "";
    $("expert-reasoning-effort-hint").textContent = cfg.hint || "";
    renderEffortBadges($("expert-reasoning-effort-badges"), cfg.options, cfg.def || "", expertProvider,
      syncExpertEffort);
    renderEffortReference($("expert-reasoning-effort-reference-body"), expertProvider, cfg.options, cfg.def || "");
    renderEffortDesc($("expert-reasoning-effort-description"), expertProvider, cfg.def || "");
    $("expert-reasoning-effort-block").classList.toggle("hidden", !$("expert-check-reasoning").checked);
  }

  $("expert-check-reasoning").addEventListener("change", (e) => {
    $("expert-reasoning-effort-block").classList.toggle("hidden", !e.target.checked);
  });

  $("expert-btn-test-connection").addEventListener("click", (e) => {
    doConnectionTest(e.currentTarget, $("expert-api-key").value, true);
  });

  $("expert-btn-run-tests").addEventListener("click", async () => {
    const btn = $("expert-btn-run-tests");
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<svg class="wz-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>正在测试…';
    setAlert("");
    $("expert-test-results").classList.remove("hidden");
    [["tool", "工具调用"], ["image", "图片输入"], ["reasoning", "思维链"]]
      .forEach(([k]) => setStatus(`expert-test-row-${k}`, "running", "测试中…"));

    try {
      const res = await runProbe({ expert: true });
      const rs = (res.report && res.report.results) || [];
      const pick = (keys) => rs.filter((r) => keys.indexOf(r.key) >= 0);
      [["tool", ["tool_calls", "tool_results"]], ["image", ["vision"]], ["reasoning", ["thinking"]]]
        .forEach(([k, keys]) => {
          const [kind, text] = statusFor(pick(keys));
          setStatus(`expert-test-row-${k}`, kind, text);
        });

      state.probe = res.report;
      state.conflicts = res.conflicts || [];
      const conf = state.conflicts.length;
      setAlert(conf ? `探测完成，存在 ${conf} 处需注意的差异（保存时会再次校验）。` : "探测完成，未发现异常。", conf ? "" : "ok");
    } catch (err) {
      setAlert("探测失败：" + err.message, "err");
      [["tool"], ["image"], ["reasoning"]].forEach(([k]) => setStatus(`expert-test-row-${k}`, "", "未测试"));
    } finally {
      btn.disabled = false;
      btn.innerHTML = original;
    }
  });

  $("expert-btn-save").addEventListener("click", async () => {
    const btn = $("expert-btn-save");
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = "保存中…";
    setAlert("");
    const cfg = readExpert();
    try {
      if (!cfg.base_url) throw new Error(expertProvider === "custom" ? "请填写接口地址" : "请填写 Base URL");
      if (!cfg.model) throw new Error("请填写模型 ID");
      if (!cfg.tool_calling) throw new Error("必须启用「工具调用」");
      const res = await api("/api/setup/llm", {
        method: "POST",
        body: JSON.stringify({
          base_url: cfg.base_url,
          api_key: cfg.api_key,
          model: cfg.model,
          vision_mode: cfg.vision_mode,
          capability: cfg.capability,
          acknowledged: {},
        }),
      });
      const extras = await writeExtras(cfg);
      toast(`已保存 ${res.applied.length + extras} 项配置`);
      location.href = "/";
    } catch (err) {
      btn.disabled = false;
      btn.textContent = original;
      setAlert("保存失败：" + err.message, "err");
      toast(err.message, true);
    }
  });

  /* ── 启动 ────────────────────────────────────────────────────────── */

  (async () => {
    if (!(await checkAccess())) return;
    render();
  })();
})();
