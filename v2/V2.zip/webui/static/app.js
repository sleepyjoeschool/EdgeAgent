/* Computer Use Agent — console client.
 *
 * One EventSource carries everything the engine emits. The renderer keeps a
 * little state machine so streaming deltas (thinking / answer text) append
 * into one growing node instead of spawning thousands of DOM elements.
 *
 * Boot decides between four screens from /api/hello:
 *   needs_setup  -> the wizard, step 1 (create an administrator)
 *   needs_llm    -> the wizard, step 2 (configure and probe a model endpoint)
 *   not authed   -> login
 *   authed       -> the console
 *
 * Every mutating request carries the session's CSRF token in a header, and a
 * 401 anywhere drops us back to the login card rather than failing silently.
 */
"use strict";

const $ = (id) => document.getElementById(id);
const state = {
  csrf: null,
  user: null,
  caps: new Set(),
  busy: false,
  // Last status reported by the server ("running" / "paused" /
  // "awaiting_approval" / "idle"). Kept separately from `busy` because the run
  // strip has to distinguish "paused" from "parked waiting for a step" — both
  // are busy, and only one of them needs the 下一步 button.
  runState: "idle",
  paused: false,
  steps: 0,
  started: 0,
  // The task text of the run currently on screen. The title bar reads from it,
  // and the footer's retry re-runs it — the composer may hold something else by
  // then, so it cannot stand in for this.
  currentTask: "",
  pending: null,
  perception: {},
  // Whether the server will serve /api/desktop.jpg. Read from /api/status so
  // the device card can say why its preview is missing instead of just failing.
  desktopView: true,
  // Which console view is on screen; the sidebar groups read it to decide
  // which header is lit.
  currentView: "dashboard",
  // Whether 我的设备's sub-views are expanded in the sidebar.
  deviceNavOpen: false,
  // Whether the Agent 会话 group (新建任务 + 任务/空间 tree) is expanded.
  // Starts open: the history is what the sidebar is for.
  sessionsNavOpen: true,
  // Expansion flags for the sidebar tree's sections and individual spaces;
  // both default expanded, and the flags survive the 15s re-render.
  treeOpen: { tasks: true, spaces: true, unclassified: true, space: {} },
  // The mounted session: whose context a mission will continue, and whose
  // transcript is on screen.
  sessionId: null,
  sessions: [],
  sessionsOpen: false,
  // Set while a stored transcript is being replayed, so the renderer does not
  // wipe the panel on each stored run_start.
  replaying: false,
  hello: null,
  stagedPassword: null,
  // Wizard state, kept so "back" and "retry" never lose what was typed.
  api: { base_url: "", api_key: "", model: "", vision_mode: "auto", capability: "auto" },
  probe: null,
  conflicts: [],
  // Conflict keys the operator chose to keep despite the probe.
  forced: new Set(),
  // Conversation-UI controls wired to real backend behaviour.
  fullAccess: false,     // Default Permission vs Full Access
  agentMode: "gui",      // "gui" | "cil"
  workspace: "",         // selected working directory ("" = unrestricted)
  currentModel: "",      // active LLM model id
  // "enter" | "ctrl_enter", from /api/hello. Defaults to send-on-Enter, which
  // is what the setting ships as; applyRole() overwrites it from the server.
  sendOnEnter: "enter",
  // Who the reply header is signed by, from /api/hello. Kept on state rather
  // than read per render: the header is rebuilt for every message and every
  // replayed session, and the answer must not depend on which render path ran.
  // ``avatar`` is "" for the built-in mark, a URL otherwise.
  agent: { name: "", avatar: "", uploadedUrl: "", defaultName: "Agent", uploaded: false },
  // Token accounting, from /api/hello and the token_usage events. `supported`
  // is "the active model has an exact tokenizer": when false every counter is
  // hidden rather than showing a zero that would look like a measurement.
  tokens: { available: true, supported: false, modelKey: "", label: "", models: [], session: null },
};

const CAP_LABEL = { admin: "管理员", operator: "操作员", viewer: "只读" };

/* ── Utilities ─────────────────────────────────────────────────────── */

function toast(message, isError = false) {
  const el = $("toast");
  el.textContent = message;
  el.classList.remove("hidden");
  el.classList.toggle("err", isError);
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.add("hidden"), 3400);
}

function preview(obj) {
  if (obj === undefined || obj === null) return "";
  const text = typeof obj === "string" ? obj : JSON.stringify(obj, null, 2);
  return text.length > 320 ? text.slice(0, 320) + " …" : text;
}

function fmtDate(ts) {
  if (!ts) return "从未";
  return new Date(ts * 1000).toLocaleString("zh-CN", {
    hour12: false, month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
  });
}

function escapeHtml(text) {
  return String(text ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Auth failure drops us to the right screen; anything else surfaces a toast. */
class ApiError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.status = status;
    this.payload = payload || {};
  }
}

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (state.csrf && options.method && options.method !== "GET") {
    headers["X-CSRF-Token"] = state.csrf;
  }
  const res = await fetch(path, { ...options, headers, credentials: "same-origin" });
  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    if (res.status === 401 && state.user) {
      showGate("login", data.error);
      throw new ApiError(data.error || "登录已失效", 401, data);
    }
    throw new ApiError(data.error || "HTTP " + res.status, res.status, data);
  }
  return data;
}

function showError(id, message) {
  const el = $(id);
  el.textContent = message;
  el.classList.remove("hidden");
}

function clearError(id) {
  $(id).classList.add("hidden");
}

/* White-mode only: theme switching (light/dark/auto) has been removed.
   The stylesheet carries a single light palette. */

function toggleFullscreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen();
    return;
  }
  // Requesting fullscreen can be refused by policy; say so instead of failing
  // silently, since the button then looks broken.
  Promise.resolve(document.documentElement.requestFullscreen?.())
    .catch(() => toast("当前浏览器拒绝了全屏请求", true));
}

/* ── Password strength meter ───────────────────────────────────────── */

function scorePassword(v) {
  let score = 0;
  if (v.length >= 8) score += 34;
  if (v.length >= 14) score += 18;
  if (new Set(v).size >= 6) score += 18;
  if (/[a-z]/.test(v) && /[A-Z]/.test(v) && /[0-9]/.test(v)) score += 16;
  if (/[^a-zA-Z0-9]/.test(v)) score += 14;
  return Math.min(100, score);
}

function wireMeter(inputId, meterId, hintId) {
  const input = $(inputId);
  const meter = $(meterId).parentElement;
  const bar = $(meterId);
  input.addEventListener("input", () => {
    const v = input.value;
    const score = scorePassword(v);
    bar.style.width = score + "%";
    meter.classList.remove("low", "mid", "high");
    meter.classList.add(score < 45 ? "low" : score < 75 ? "mid" : "high");
    if (hintId && v) {
      $(hintId).textContent = score < 45 ? "偏弱，再长一些或加入符号"
        : score < 75 ? "一般" : "强度不错";
    }
    // Once the value stops being the one we generated, the "copy it now"
    // banner is describing something that no longer exists.
    if (!input.classList.contains("pw-generated")) {
      showPasswordNotes(inputId, false);
    } else if (v) {
      showPasswordNotes(inputId, true);
    }
  });
}

/* ── Login wallpaper ───────────────────────────────────────────────── */

/**
 * Fade the sharp wallpaper in once it has actually decoded.
 *
 * The column ships a 5 KB blurred placeholder as its background, so it is never
 * an empty rectangle; this only upgrades it. Preloading in JS rather than
 * trusting the CSS background alone is what makes the cross-fade possible —
 * a CSS background swaps the instant it is painted, with no transition.
 */
function loadWallpaper() {
  const art = document.querySelector(".gate-art");
  if (!art) return;

  const sharp = new Image();
  sharp.src = "/img/login-wallpaper-1600.webp";
  sharp.addEventListener("load", () => art.classList.add("has-image"), { once: true });
  // A missing or corrupt image just leaves the blurred placeholder in place.
  sharp.addEventListener("error", () => {}, { once: true });
}

/* ── Recovery modal ────────────────────────────────────────────────── */

/**
 * The reference design links to password help. There is no remote reset —
 * a "forgot password" endpoint reachable over HTTP would be a way to take the
 * panel over without the old password — so the link opens the local command
 * instead of pretending a mail will arrive.
 */
function wireRecoveryModal() {
  const modal = $("recovery-modal");
  if (!modal) return;

  const open = (e) => { e.preventDefault(); modal.classList.remove("hidden"); };
  const close = () => modal.classList.add("hidden");

  $("li-forgot")?.addEventListener("click", open);
  $("li-help")?.addEventListener("click", open);
  $("recovery-close")?.addEventListener("click", close);
  // Clicking the backdrop closes, matching the reference behaviour.
  modal.addEventListener("click", (e) => {
    if (e.target === modal) close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !modal.classList.contains("hidden")) close();
  });
}

/* ── Password generation ────────────────────────────────────────────── */

/**
 * Ask the server for a strong password and drop it into a field.
 *
 * Generation is a server round-trip on purpose: the browser's Math.random is
 * not a CSPRNG, and only the server knows the current password policy, so a
 * generated value cannot drift out of compliance with it.
 */
async function generateInto(inputId, opts = {}) {
  const input = $(inputId);
  const btn = document.querySelector(`[data-generate="${inputId}"]`);
  if (!input) return;

  if (btn) {
    btn.disabled = true;
    btn.textContent = "生成中…";
  }
  try {
    const res = await api(
      `/api/auth/password/generate?length=${opts.length || 20}`
    );

    input.value = res.password;
    input.classList.add("pw-generated");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    // Reveal immediately: a password nobody can read is useless, and the
    // whole point of generating is not having to recall it later.
    input.type = "text";

    // Mirror into the confirmation field so the form is submittable without
    // retyping. Both fields only ever hold the same generated value.
    const confirmId = opts.confirm;
    if (confirmId && $(confirmId)) {
      $(confirmId).value = res.password;
      $(confirmId).type = "text";
    }

    // Drive the strength meter through its normal input path so the score can
    // never disagree with what the user sees.
    input.dispatchEvent(new Event("input"));
    if (confirmId && $(confirmId)) $(confirmId).dispatchEvent(new Event("input"));

    showPasswordNotes(inputId, true);

    if (opts.onDone) opts.onDone(res.password);
  } catch (err) {
    toast(err.message, true);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "生成";
    }
  }
}

/** Toggle the "save this now" banner belonging to the given field. */
function showPasswordNotes(inputId, visible) {
  // Each form carries at most one banner; find the card that owns the field.
  const card = $(inputId).closest(".gate-card") || $(inputId).closest(".card");
  if (!card) return;
  const note = card.querySelector("[data-pw-note]");
  if (note) note.classList.toggle("hidden", !visible);
}

/** Copy text, reporting the result on the button itself. */
async function copyToClipboard(text, btn) {
  const label = btn ? btn.textContent : "";
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else {
      // Plain-HTTP LAN is the normal deployment here, where the async
      // clipboard API is unavailable — fall back to the legacy path.
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      if (!ok) throw new Error("copy rejected");
    }
    if (btn) {
      btn.textContent = "已复制";
      btn.classList.add("copied");
      setTimeout(() => {
        btn.textContent = label;
        btn.classList.remove("copied");
      }, 1600);
    }
    return true;
  } catch (err) {
    toast("复制失败，请手动选中密码复制", true);
    return false;
  }
}

document.querySelectorAll("[data-generate]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const id = btn.dataset.generate;
    // The setup and change-password cards both confirm the value.
    const confirmId = id === "su-password" ? "su-confirm"
      : id === "ch-password" ? "ch-confirm"
      : id === "pw-new" ? "pw-confirm"
      : null;
    generateInto(id, { confirm: confirmId });
  });
});

document.querySelectorAll("[data-copy]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const input = $(btn.dataset.copy);
    if (!input || !input.value) {
      toast("还没有密码可复制");
      return;
    }
    await copyToClipboard(input.value, btn);
  });
});

document.querySelectorAll("[data-reveal]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const input = $(btn.dataset.reveal);
    if (!input) return;
    // With nothing typed there is nothing to reveal.
    if (!input.value) {
      toast("还没有密码可显示");
      return;
    }
    const wasHidden = input.type === "password";
    input.type = wasHidden ? "text" : "password";
    // The password ends up visible exactly when it was hidden before the click,
    // so `revealed` tracks `wasHidden` — not its negation. Toggling with
    // !wasHidden left the icon showing the opposite state on every click.
    btn.classList.toggle("revealed", wasHidden);
    // A class, not textContent: the button holds an inline SVG, and assigning
    // textContent would replace the whole graphic with a glyph — one of the
    // very glyphs that went missing in the first place.
    btn.title = wasHidden ? "隐藏密码" : "显示密码";
    btn.setAttribute("aria-label", btn.title);
  });
});

/* ── Gate routing ──────────────────────────────────────────────────── */

const GATE_CARDS = ["setup-card", "api-card", "probe-card", "login-card", "change-card"];

function showGate(which, message) {
  $("app").classList.add("hidden");
  $("gate").classList.remove("hidden");
  GATE_CARDS.forEach((id) => $(id).classList.add("hidden"));
  $(`${which}-card`).classList.remove("hidden");

  if (message) {
    const target = { login: "li-error", setup: "su-error", api: "ap-error", change: "ch-error" }[which];
    if (target) showError(target, message);
  }
  const focus = {
    login: "li-username", setup: "su-username",
    api: "ap-base", probe: "pb-save", change: "ch-password",
  }[which];
  if (focus) setTimeout(() => $(focus).focus(), 60);
}

function hideGate() {
  $("gate").classList.add("hidden");
  $("app").classList.remove("hidden");
}

/* ── Step 1: administrator ────────────────────────────────────────── */

$("su-submit").addEventListener("click", async (e) => {
  e.preventDefault();
  clearError("su-error");
  showPasswordNotes("su-password", false);
  const username = $("su-username").value.trim();
  const password = $("su-password").value;
  if (!username) return showError("su-error", "请填写用户名");
  if (password !== $("su-confirm").value) return showError("su-error", "两次输入的密码不一致");

  const btn = $("su-submit");
  btn.disabled = true;
  try {
    const res = await api("/api/setup/account", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    });
    state.csrf = res.csrf;
    state.user = res.user;
    state.hello = null;
    state.stagedPassword = null;
    if (res.next === "llm") {
      prefillApiForm();
      showGate("api");
    } else {
      await enterConsole();
    }
  } catch (err) {
    showError("su-error", err.message);
  } finally {
    btn.disabled = false;
  }
});

$("su-confirm").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("su-submit").click();
});

function prefillApiForm() {
  const h = state.hello || {};
  if (!$("ap-base").value) $("ap-base").value = h.base_url || "";
  if (!$("ap-model").value) $("ap-model").value = h.model || "";
  $("ap-vision").value = state.api.vision_mode || "auto";
  $("ap-capability").value = state.api.capability || "auto";
}

/* ── Step 2: API configuration ────────────────────────────────────── */

function readApiForm() {
  state.api = {
    base_url: $("ap-base").value.trim(),
    api_key: $("ap-key").value,
    model: $("ap-model").value.trim(),
    vision_mode: $("ap-vision").value,
    capability: $("ap-capability").value,
  };
  return state.api;
}

$("ap-test").addEventListener("click", async (e) => {
  e.preventDefault();
  clearError("ap-error");
  const cfg = readApiForm();
  if (!cfg.base_url) return showError("ap-error", "请填写 Base URL");
  if (!cfg.model) return showError("ap-error", "请填写模型 ID");

  const btn = $("ap-test");
  btn.disabled = true;
  btn.textContent = "测试中…约需 10-30 秒";
  try {
    const res = await api("/api/setup/probe", { method: "POST", body: JSON.stringify(cfg) });
    state.probe = res.report;
    state.conflicts = res.conflicts || [];
    state.forced = new Set();
    renderProbe(res);
    showGate("probe");
  } catch (err) {
    showError("ap-error", err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "测试并查看能力";
  }
});

$("ap-back").addEventListener("click", () => showGate("setup"));
$("pb-back").addEventListener("click", () => { prefillApiForm(); showGate("api"); });
$("pb-retry").addEventListener("click", () => { prefillApiForm(); $("ap-test").click(); });

/* ── Step 3: probe results + conflict resolution ───────────────────── */

function probeItemClass(result) {
  if ((result.detail || "").indexOf("未测试") >= 0) return "skip";
  if (result.ok) return "pass";
  return result.severity === "required" ? "fail" : "warn";
}

function probeItemHtml(result) {
  const cls = probeItemClass(result);
  const mark = cls === "pass" ? "✓" : cls === "fail" ? "✕" : cls === "warn" ? "!" : "–";
  const tag = result.severity === "required" ? "必需" : "可选";
  return `
    <div class="probe-item ${cls}">
      <span class="probe-mark">${mark}</span>
      <div>
        <div class="probe-name">${escapeHtml(result.label)}
          <span class="probe-tag tag-${result.severity}">${tag}</span>
        </div>
        <div class="probe-detail">${escapeHtml(result.detail)}</div>
      </div>
      <span class="probe-ms">${result.ms ? result.ms + "ms" : "—"}</span>
      ${result.evidence ? `<div class="probe-evidence">${escapeHtml(result.evidence)}</div>` : ""}
    </div>`;
}

/** Whether any conflict is a hard stop, regardless of what was forced. */
function isBlocked() {
  return state.conflicts.some((c) => c.severity === "blocking");
}

function renderProbe(res) {
  const report = res.report || state.probe || {};
  $("pb-target").textContent = `${report.model} @ ${report.base_url}`;

  $("pb-list").innerHTML = (report.results || []).map(probeItemHtml).join("");

  const zone = $("pb-conflicts");
  if (!state.conflicts.length) {
    zone.innerHTML = "";
  } else {
    zone.innerHTML = state.conflicts.map(conflictHtml).join("");
    zone.querySelectorAll("[data-conflict-action]").forEach((btn) => {
      btn.addEventListener("click", () => resolveConflict(btn));
    });
  }

  const passed = (report.results || []).filter((r) => r.ok).map((r) => r.label);
  const blocked = isBlocked();

  const summary = $("pb-summary");
  summary.className = "probe-summary " + (blocked ? "bad" : "ok");
  summary.innerHTML = blocked
    ? "<b>无法继续：</b>该模型缺少必需能力，任何设置都无法让代理工作。请更换模型或端点后重新测试。"
    : `必需能力<b>全部通过</b>，总耗时 ${report.total_ms || 0}ms。` +
      (passed.length ? ` 可用能力：${passed.map(escapeHtml).join("、")}。` : "") +
      " 确认后将保存到 config_override.json。";

  $("pb-save").disabled = blocked;
  $("pb-save").textContent = blocked ? "无法保存" : "保存并进入控制台";
}

function conflictHtml(c) {
  const blocking = c.severity === "blocking";
  const forced = state.forced.has(c.key);
  const badge = blocking ? "必须处理" : forced ? "已强制保留" : "建议修改";

  let choices = "";
  if (c.fixable && c.suggestion) {
    choices = `
      <div class="conflict-choice">
        <span>${forced ? "选项 B" : "选项 A"}</span>
        <code>${escapeHtml(c.suggestion)}</code>
        <span class="muted">按探测结果自动调整</span>
        <span class="spacer"></span>
        ${forced ? '<span class="conflict-picked">✓ 已选</span>'
          : '<button class="mini-btn" data-conflict-action="suggest">采用建议</button>'}
      </div>
      <div class="conflict-choice">
        <span>选项 B</span>
        <code>${escapeHtml(String(c.chosen))}</code>
        <span class="muted">忽略探测结果，强制保留</span>
        <span class="spacer"></span>
        ${forced ? '<span class="conflict-picked">✓ 已选</span>'
          : '<button class="mini-btn" data-conflict-action="force">强制保留</button>'}
      </div>`;
  } else if (!blocking) {
    choices = '<div class="conflict-choice"><span class="muted">该问题不影响启动，可在「设置」页稍后处理。</span></div>';
  }

  return `
    <div class="conflict ${blocking ? "blocking" : forced ? "resolved" : ""}">
      <div class="conflict-head">
        <span class="conflict-badge">${badge}</span>
        <b>${escapeHtml(c.label)}</b>
      </div>
      <p class="conflict-why">${escapeHtml(c.explain)}</p>
      ${choices}
    </div>`;
}

function resolveConflict(btn) {
  const box = btn.closest(".conflict");
  const idx = Array.from(document.querySelectorAll("#pb-conflicts .conflict")).indexOf(box);
  const conflict = state.conflicts[idx];
  if (!conflict) return;

  if (btn.dataset.conflictAction === "force") state.forced.add(conflict.key);
  else state.forced.delete(conflict.key);

  renderProbe({ report: state.probe });
}

$("pb-save").addEventListener("click", async () => {
  const cfg = readApiForm();
  const btn = $("pb-save");
  btn.disabled = true;
  btn.textContent = "保存中…";
  try {
    const acknowledged = {};
    state.conflicts.forEach((c) => {
      if (state.forced.has(c.key)) acknowledged[c.key] = true;
    });
    const res = await api("/api/setup/llm", {
      method: "POST",
      body: JSON.stringify({ ...cfg, acknowledged }),
    });
    toast(`已保存 ${res.applied.length} 项配置`);
    state.hello = null;
    await enterConsole();
  } catch (err) {
    btn.disabled = false;
    btn.textContent = "保存并进入控制台";
    showError("ap-error", err.message);
    showGate("api");
  }
});

/* ── Login / change password ──────────────────────────────────────── */

$("li-submit").addEventListener("click", async (e) => {
  e.preventDefault();
  clearError("li-error");
  const username = $("li-username").value.trim();
  const password = $("li-password").value;
  if (!username || !password) return showError("li-error", "请填写用户名和密码");

  const btn = $("li-submit");
  const remember = $("li-remember")?.checked ?? false;
  btn.disabled = true;
  btn.querySelector("span")?.remove();
  try {
    const res = await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password, remember }),
    });
    state.csrf = res.csrf;
    state.user = res.user;
    // Drop any hello cached before this login; it describes a session that
    // no longer exists.
    state.hello = null;
    if (res.user.must_change) {
      // Held only in memory, only until the change succeeds, never persisted.
      state.stagedPassword = password;
      $("ch-who").textContent = `${res.user.name} · ${CAP_LABEL[res.user.role] || res.user.role}`;
      showGate("change");
      return;
    }
    await enterConsole();
  } catch (err) {
    showError("li-error", err.message);
    refreshLockoutHint(username);
  } finally {
    btn.disabled = false;
  }
});

$("li-password").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("li-submit").click();
});

async function refreshLockoutHint(username) {
  const note = $("li-lockout");
  if (!username) { note.textContent = ""; return; }
  try {
    const res = await api(`/api/auth/lockout?username=${encodeURIComponent(username)}`);
    note.textContent = res.locked
      ? `已锁定，请 ${res.retry_after} 秒后重试（连续 ${res.max_attempts} 次失败会锁定）`
      : `连续 ${res.max_attempts} 次失败将临时锁定`;
  } catch (err) { /* hint only — never block the login on it */ }
}

$("li-username").addEventListener("blur", () => refreshLockoutHint($("li-username").value.trim()));

$("ch-submit").addEventListener("click", async (e) => {
  e.preventDefault();
  clearError("ch-error");
  const password = $("ch-password").value;
  if (password !== $("ch-confirm").value) return showError("ch-error", "两次输入的密码不一致");
  if (!state.stagedPassword) {
    showError("ch-error", "会话已失效，请重新登录");
    showGate("login");
    return;
  }

  const btn = $("ch-submit");
  btn.disabled = true;
  try {
    // The server drops *every* session for this user on a successful change —
    // including this one — so the cookie is gone when this returns.
    await api("/api/auth/password", {
      method: "POST",
      body: JSON.stringify({
        current_password: state.stagedPassword,
        new_password: password,
      }),
    });
    state.stagedPassword = null;
    state.csrf = null;
    state.user = null;
    toast("密码已更新，请用新密码登录");
    showGate("login");
  } catch (err) {
    showError("ch-error", err.message);
  } finally {
    btn.disabled = false;
  }
});

/** Forget the local session and drop back to the login card. */
function localLogout(message) {
  state.csrf = null;
  state.user = null;
  state.caps = new Set();
  state.stagedPassword = null;
  state.hello = null;
  resetIdentity();
  showGate("login");
  if (message) toast(message);
}

$("btn-logout").addEventListener("click", async () => {
  try {
    await api("/api/auth/logout", { method: "POST" });
  } catch (err) { /* already invalid server-side; drop the UI regardless */ }
  localLogout("已退出登录");
});

/* ── Boot ─────────────────────────────────────────────────────────── */

/**
 * Adopt user identity, CSRF token and capabilities from a hello-shaped payload.
 *
 * Every screen that can be reached by an authenticated user must go through
 * here. The wizard's step 2 is reachable without ever calling enterConsole(),
 * which is exactly how it came to miss the CSRF token.
 */
function adoptSession(hello) {
  if (!hello || !hello.user) return;
  state.user = hello.user;
  state.csrf = hello.user.csrf || state.csrf;
  state.caps = new Set(hello.user.capabilities || []);
  applyRole();
}

async function enterConsole() {
  hideGate();

  // Always re-read. state.hello may hold the payload boot() saw *before* the
  // operator logged in, and that copy has user: null — adopting it left the
  // sidebar stuck on its placeholder dashes for the whole session.
  state.hello = await api("/api/hello");
  adoptSession(state.hello);
  const hello = state.hello;

  $("tb-version").textContent = `v${hello.version}`;
  $("st-vision").textContent = hello.vision_mode;
  $("st-model").textContent = hello.model || "—";
  $("st-model").title = hello.model || "";
  if (!$("opt-steps").value) $("opt-steps").value = hello.max_steps;
  // Read here, alongside the other server-driven UI state, so a page reload
  // picks up a changed binding without any extra request.
  state.sendOnEnter = hello.send_on_enter === "ctrl_enter" ? "ctrl_enter" : "enter";
  applySendHint();
  adoptAgentIdentity(hello.agent);
  adoptTokenSupport(hello.tokens);
  // The ceiling may be switched off globally; show that rather than a number
  // the engine is going to ignore.
  $("opt-unlimited").checked = hello.max_steps_enabled === false;
  syncStepLimit();
  // Seed the landing-page mirror from the authoritative fields, so the two
  // entry points start out agreeing instead of the landing control showing a
  // hardcoded 50 while the panel is configured for something else.
  $("dash-steps-input").value = $("opt-steps").value;
  $("dash-unlimited-toggle").checked = $("opt-unlimited").checked;
  syncStepControls("composer");

  $("st-nollm-row").classList.toggle("hidden", !hello.needs_llm);
  if (hello.needs_llm) {
    toast("尚未配置模型 API — 请到「设置 → API Setting」完成配置");
  }

  connectStream();
  await refreshAll();
  refreshDashboard();
  refreshStatus();
  await loadWorkInfo();
  await refreshSessions();
  // Awaited so the model labels below already know the provider; otherwise the
  // first paint would show the bare model id and flip a frame later.
  await loadCurrentModel();
  // Sync the landing-page controls to the shared state.
  setAgentMode(state.agentMode);
  updateWorkspaceUI();
  updateModelLabels();

  // Nothing has streamed yet in this process. If a session is already
  // mounted, show what it holds rather than an empty panel — the transcript
  // only refills itself from the event stream once a mission runs.
  if (state.sessionId && !$("transcript").childElementCount) {
    const stored = await api(`/api/sessions/${encodeURIComponent(state.sessionId)}`)
      .catch(() => null);
    if (stored) replayTranscript(stored.session.transcript || []);
  }

  startPolling();
}

/** Clear the sidebar identity block. Used on logout and before adoption. */
function resetIdentity() {
  $("who-name").textContent = "—";
  $("who-role").textContent = "—";
  $("who-avatar").textContent = "?";
}

/**
 * Adopt the agent's display name and avatar from the bootstrap payload.
 *
 * Also rewrites any reply header that is already on screen. The payload
 * arrives on every console entry, and a header built before a save would
 * otherwise keep the old name until the page was reloaded — which reads as
 * "the setting did not stick".
 */
function adoptAgentIdentity(agent) {
  const payload = agent || {};
  const before = [
    state.agent.name, state.agent.avatar, state.agent.uploadedUrl, state.agent.defaultName,
  ].join("|");
  state.agent = {
    name: String(payload.name || ""),
    // The URL actually rendered. The server resolves which source wins, so the
    // front end never has to re-derive the precedence rule and risk disagreeing
    // with it.
    avatar: String(payload.avatar || ""),
    // The standalone upload's own URL, when one exists. Tracked separately
    // because ``avatar`` may be a typed URL instead — and a stale copy of that
    // would be shown as "the uploaded image" the moment the box is emptied.
    uploadedUrl: String(payload.uploaded_url || ""),
    defaultName: String(payload.default_name || "Agent"),
    uploaded: !!payload.uploaded,
  };
  const after = [
    state.agent.name, state.agent.avatar, state.agent.uploadedUrl, state.agent.defaultName,
  ].join("|");
  if (before === after) return;
  document.querySelectorAll(".msg-ai .ai-header").forEach((header) => {
    const name = header.querySelector(".ai-name");
    if (name) name.textContent = agentDisplayName();
    const avatar = header.querySelector(".ai-avatar");
    // Rebuilt rather than patched: both the picture and the fallback mark may
    // have changed, and the two have to stay consistent with each other.
    if (avatar) avatar.innerHTML = agentAvatarHtml();
  });
}

function applyRole() {
  const can = (cap) => state.caps.has(cap);

  // Hide what the role cannot do. The server enforces the same rules; this is
  // only so the UI does not offer dead buttons.
  document.querySelectorAll("[data-cap]").forEach((el) => {
    const allowed = can(el.dataset.cap);
    if (el.classList.contains("nav-item")) {
      el.classList.toggle("denied", !allowed);
      el.disabled = !allowed;
    } else {
      el.disabled = !allowed;
    }
  });
  // A viewer's composer is read-only rather than hidden — watching a mission
  // without being able to start one is a legitimate job.
  $("task-input").disabled = !can("control");
  $("opt-step").disabled = !can("control");
  $("opt-steps").disabled = !can("control");

  if (state.user) {
    $("who-name").textContent = state.user.name;
    $("who-role").textContent = CAP_LABEL[state.user.role] || state.user.role;
    $("who-avatar").textContent = (state.user.name[0] || "?").toUpperCase();
  }
}

async function boot() {
  const hello = await api("/api/hello");
  state.hello = hello;

  if (hello.needs_setup) {
    showGate("setup");
    return;
  }
  if (!hello.authenticated) {
    showGate("login");
    refreshLockoutHint("");
    return;
  }
  // An account exists and we are logged in, but no model is reachable: send
  // the operator straight to step 2 rather than into a console that cannot run.
  if (hello.needs_llm) {
    // Adopt the session's CSRF token before showing step 2. Without this every
    // POST from the API form — probe included — is rejected with "CSRF 校验失败",
    // because the wizard is the one screen that can appear for an
    // already-authenticated user who has never been through enterConsole().
    adoptSession(hello);
    prefillApiForm();
    showGate("api");
    return;
  }
  await enterConsole();
}

/* ── Navigation ───────────────────────────────────────────────────── */

/* The three views that belong to this machine. 我的设备 stays lit while any
   of them is open, so the group never looks deselected when one of its
   children is what you are looking at. */
const DEVICE_VIEWS = new Set(["desktop", "upstream", "status"]);

const VIEW_LOADERS = {
  dashboard: () => refreshDashboard(),
  mission: () => refreshSessions(),
  desktop: () => { refreshDesktop(); if (workInfo && workInfo.mode === "region") refreshWork(); },
  upstream: () => refreshUpstream(),
  status: () => refreshStatus(),
  tokens: () => refreshTokens(),
  settings: () => refreshSettings(),
  users: () => refreshUsers(),
  audit: () => refreshAudit(),
};

function showView(view) {
  state.currentView = view;
  document.querySelectorAll(".view").forEach((v) => {
    v.classList.toggle("active", v.id === `view-${view}`);
  });
  document.querySelectorAll(".nav-item[data-view]").forEach((item) => {
    item.classList.toggle("active", item.dataset.view === view);
  });
  syncSidebarGroups();

  const loader = VIEW_LOADERS[view];
  if (loader) Promise.resolve(loader()).catch((err) => toast(err.message, true));

  // Coming back to the desktop view re-lays-out a preview that was measured
  // while hidden, so the workspace outline has to be recomputed from the sizes
  // it has *now*. Deferred to match the loader: the image is still swapping in
  // at this point and its dimensions would change again a frame later.
  if (view === "desktop") scheduleMarkerDraw();
}

/* ── Sidebar groups ──────────────────────────────────────────────────
 *
 * Both group headers are destinations *and* disclosures, WorkBuddy-style:
 * 我的设备 opens onto 桌面, Agent 会话 opens onto the 新建任务 landing.
 * The 任务 / 空间 tree under Agent 会话 starts expanded and keeps its own
 * open flags, so navigating elsewhere never collapses it behind the
 * operator's back.
 */
function syncSidebarGroups() {
  const view = state.currentView;

  const device = $("nav-device");
  if (device) {
    device.classList.toggle("active", DEVICE_VIEWS.has(view));
    device.classList.toggle("open", state.deviceNavOpen);
    $("nav-sub").classList.toggle("open", state.deviceNavOpen);
  }

  const sessions = $("nav-sessions");
  if (sessions) {
    sessions.classList.toggle("active", view === "dashboard");
    sessions.classList.toggle("open", state.sessionsNavOpen);
    $("nav-sessions-sub").classList.toggle("open", state.sessionsNavOpen);
  }
}

$("nav-device").addEventListener("click", () => {
  const alreadyHere = DEVICE_VIEWS.has(state.currentView);
  state.deviceNavOpen = alreadyHere ? !state.deviceNavOpen : true;
  // Arriving from anywhere else opens the group *and* shows its first view;
  // collapsing while already inside just folds the children away.
  if (!alreadyHere || state.deviceNavOpen) showView("desktop");
  else syncSidebarGroups();
});

$("nav-sessions").addEventListener("click", () => {
  const alreadyHere = state.currentView === "dashboard";
  state.sessionsNavOpen = alreadyHere ? !state.sessionsNavOpen : true;
  if (!alreadyHere || state.sessionsNavOpen) showView("dashboard");
  else syncSidebarGroups();
});

document.querySelectorAll(".nav-item[data-view]").forEach((item) => {
  item.addEventListener("click", () => {
    if (item.disabled) return;
    // 新建任务 is not just "go to the landing page" — it starts a *new*
    // conversation. Plain navigation left the previously mounted session id in
    // state, and startMission sends whatever is there, so a task typed on this
    // page silently continued the old session and inherited its context. The
    // entry has to mean what it says.
    if (item.id === "nav-new-task") {
      beginNewTask();
      return;
    }
    showView(item.dataset.view);
  });
});

/**
 * Open the landing page on a fresh, empty conversation.
 *
 * Starting the session here rather than at submit time is deliberate: the
 * session bar shows this id immediately, so what the operator sees on screen
 * matches what will actually receive their task. Deferring it would leave the
 * bar naming the old session while the task went somewhere else.
 *
 * `newSession()` already reuses an empty mounted session instead of creating a
 * twin, so clicking this entry twice does not pile up blanks.
 */
async function beginNewTask() {
  showView("dashboard");
  if (state.caps.has("control")) {
    await newSession();
    return;
  }
  // A viewer cannot create sessions. Dropping the id still matters: it is what
  // startMission would otherwise send, and inheriting a previous session's
  // context is exactly the bug this entry exists to prevent.
  state.sessionId = null;
  renderSessionBar();
}

/* ── 我的设备 ─────────────────────────────────────────────────────── */

/**
 * Load the still frame behind the device card.
 *
 * Decoded through a scratch Image rather than by assigning straight to the
 * <img>, so a slow or failed capture leaves the card on its placeholder
 * instead of showing a torn image for a second.
 */
async function refreshDashboard() {
  const screen = await api("/api/screen").catch(() => null);
  $("dev-screen").textContent = screen ? `${screen.width}×${screen.height}` : "—";
}

/** The status page carries the same cards the dashboard used to show inline:
 * running state, model & vision, and the dependency list. They live here now
 * because a landing page is for starting things, not for reading them. */
async function refreshStatus() {
  const hello = state.hello || await api("/api/hello").catch(() => null);
  if (!hello) return;
  $("st-vision").textContent = hello.vision_mode || "—";
  $("st-model").textContent = hello.model || "—";
  $("st-model").title = hello.model || "";
  $("dev-model").textContent = hello.model || "—";
  $("dev-model").title = hello.model || "";
  $("dev-vision").textContent = hello.vision_mode || "—";
  $("st-nollm-row").classList.toggle("hidden", !hello.needs_llm);
  const screen = await api("/api/screen").catch(() => null);
  $("dev-screen").textContent = screen ? `${screen.width}×${screen.height}` : "—";
  // "1280×1800" alone does not say whether the agent is confined to that
  // rectangle or merely happens to see it, so the label carries the mode.
  if (screen && screen.work) {
    const w = screen.work;
    $("dev-work").textContent = w.mode === "region" && w.region
      ? `虚拟屏 ${w.region.width}×${w.region.height}`
      : "主屏幕（整块）";
    $("dev-work").title = w.label || "";
  }
  $("dep-list").innerHTML = Object.entries(hello.dependencies || {})
    .map(([name, ok]) =>
      `<li><span>${escapeHtml(name)}</span><span class="tag ${ok ? "tag-ok" : "tag-no"}">${ok ? "ok" : "missing"}</span></li>`)
    .join("");
}

/* ── Transcript rendering ────────────────────────────────────────── */

const transcript = $("transcript");
let aiMsg = null;            // current AI message container (.msg-ai)
let aiContent = null;        // content area inside aiMsg
let aiStatus = null;         // status text node inside the AI header
let aiTimer = null;          // elapsed-time interval for the header
let currentThinking = null;  // { step, details, body }
let currentMessage = null;   // current .output-text node
/* The step's last prose node, kept past `currentMessage` being nulled.
 *
 * `run_done` clears `currentMessage` before promoteConclusion runs, and the
 * fallback selector it used — `.output-text:last-of-type` — is a trap: when the
 * engine emits `thinking` *after* the streamed message (it does, because
 * reasoning is only reported once the stream settles), the step block becomes
 * [output-text, thinking-step, step-details] and the prose is no longer the
 * last div, so the selector matches nothing and the conclusion is never moved
 * out. The run then folds away with its answer inside.
 *
 * Holding the node itself is order-independent, which is the whole point.
 */
let lastMessageNode = null;
let stepBlock = null;        // { el } — the step whose output is on screen
let workflowContext = null;  // collapsible workflow steps container
let aiFooter = null;         // footer actions container
const openToolCards = new Map();

/* Marker the engine's outer loop reads to decide a mission is finished
   (cua/engine.py::TASK_COMPLETE_MARKER). It is bookkeeping, not prose, so it
   must never reach the operator — see stripInternalMarkers. */
const TASK_COMPLETE_MARKER = "TASK_COMPLETE";

/* Trailing punctuation a model tends to glue onto the marker ("TASK_COMPLETE."). */
const MARKER_TRAIL = "[\\s:：,，.。、\\-—!！]*";

/**
 * Remove framework bookkeeping from text that a human is going to read.
 *
 * The model opens its final step summary with TASK_COMPLETE; that word is a
 * control signal for the loop, and leaving it in makes the answer read like a
 * log file. It is stripped from the leading position (the normal case) and from
 * anywhere else it turns up.
 *
 * Callers pass the *accumulated* text every time rather than each delta, which
 * is what makes this survive a stream boundary: a marker split across chunks as
 * "TASK_" + "COMPLETE" only ever matches once the buffer holds both halves.
 */
function stripInternalMarkers(text) {
  const marker = TASK_COMPLETE_MARKER;
  return String(text ?? "")
    .replace(new RegExp(`^[\\s*#>-]*${marker}\\b${MARKER_TRAIL}`, "i"), "")
    .replace(new RegExp(`\\b${marker}\\b${MARKER_TRAIL}`, "gi"), "");
}

/**
 * Start a new step and take the previous one off screen.
 *
 * The rule is the one WorkBuddy uses: what is on screen is the newest step's
 * output, never a replay of every step that led there. So the previous block is
 * folded away rather than deleted — its error notes, if any, stay readable.
 */
function beginStep() {
  if (stepBlock) stepBlock.el.classList.add("past");
  stepBlock = null;
  currentThinking = null;
  currentMessage = null;
  // Dropped with the step it belongs to: the conclusion slot is filled from the
  // run's *final* step, and a stale node from an earlier one would promote the
  // wrong text.
  lastMessageNode = null;
}

/** The container every thinking / tool / prose node of this step goes into. */
function ensureStepBlock() {
  ensureAiMessage();
  if (stepBlock) return stepBlock;
  const el = document.createElement("div");
  el.className = "step-block fade-in";
  workflowContext.append(el);
  stepBlock = { el };
  return stepBlock;
}

/**
 * Settle the prose of the step that just ended.
 *
 * The streamed deltas and this summary carry the same text, but the summary is
 * what the engine actually evaluated, so it wins. Re-deriving from it is also
 * what guarantees a clean reading: a marker whose two halves arrived in
 * different chunks is stripped here even if a fragment slipped through mid
 * stream.
 */
function finalizeStepMessage(summary) {
  if (!currentMessage || summary == null) return;
  currentMessage._raw = String(summary);
  currentMessage.textContent = stripInternalMarkers(summary);
  currentMessage = null;
}

// Inline agent avatar — the fallback when the operator has not supplied one.
// No external image dependency, so a fresh install always has a visible mark.
const AVATAR_SVG =
  '<svg viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="currentColor" ' +
  'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
  '<rect x="4" y="8" width="16" height="11" rx="3"/>' +
  '<path d="M12 8V5a2 2 0 0 1 2-2h1.5"/><circle cx="9" cy="13" r="1.1" fill="currentColor" stroke="none"/>' +
  '<circle cx="15" cy="13" r="1.1" fill="currentColor" stroke="none"/><path d="M9.5 16h5"/></svg>';

/** The name the reply header is signed with. */
function agentDisplayName() {
  return state.agent.name || state.agent.defaultName || "Agent";
}

/**
 * Inner HTML for one agent avatar.
 *
 * The configured picture sits *over* the built-in mark rather than replacing
 * it. A URL can stop working at any time — a dead link, an offline host — and
 * the reply header is not the place to discover that: with the mark still
 * underneath, a failed load degrades to the previous behaviour instead of
 * leaving a hole where the avatar was.
 *
 * The URL is escaped like any other interpolated value. It arrives from a
 * settings box, and an unescaped quote would break out of the attribute and
 * into the document.
 */
function agentAvatarHtml() {
  const mark = `<span class="ai-avatar-mark">${AVATAR_SVG}</span>`;
  const url = state.agent.avatar;
  if (!url) return mark;
  return `<img class="ai-avatar-img" src="${escapeHtml(url)}" alt="" />` + mark;
}

function scrollDown(force = false) {
  const nearBottom = transcript.scrollHeight - transcript.scrollTop - transcript.clientHeight < 80;
  if (force || nearBottom) transcript.scrollTop = transcript.scrollHeight;
}

function ensureAiMessage() {
  if (aiMsg) return;
  aiMsg = document.createElement("div");
  aiMsg.className = "msg-ai fade-in";
  // Scoped with classes, never ids: a replayed session keeps several .msg-ai
  // alive at once, and an id would make every lookup land on the first one —
  // so clicking "已完成" on the newest run would fold an older one instead.
  aiMsg.innerHTML =
    '<div class="ai-header">' +
      '<div class="ai-avatar">' + agentAvatarHtml() + '</div>' +
      '<div class="ai-name">' + escapeHtml(agentDisplayName()) + '</div>' +
    '</div>' +
    '<div class="ai-status-header" role="button" tabindex="0" title="展开/折叠执行过程">' +
      '<span class="ai-status-text">思考中…</span>' +
      '<svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>' +
    '</div>' +
    '<div class="workflow-context"></div>' +
    '<div class="ai-conclusion"></div>' +
    '<div class="ai-footer hidden">' +
      '<button type="button" class="footer-btn" data-act="copy" title="复制结论">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>' +
      '</button>' +
      '<button type="button" class="footer-btn" data-act="speak" title="朗读结论">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>' +
      '</button>' +
      '<button type="button" class="footer-btn" data-act="retry" title="重试上一条任务">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>' +
      '</button>' +
    '</div>';
  aiStatus = aiMsg.querySelector(".ai-status-text");
  workflowContext = aiMsg.querySelector(".workflow-context");
  aiContent = aiMsg.querySelector(".ai-conclusion");
  aiFooter = aiMsg.querySelector(".ai-footer");
  const statusHeader = aiMsg.querySelector(".ai-status-header");
  statusHeader.addEventListener("click", () => toggleWorkflow(aiMsg));
  statusHeader.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleWorkflow(aiMsg); }
  });
  transcript.append(aiMsg);
  if (!state.replaying) startTimer();
  wireFooterActions(aiMsg);
  scrollDown(true);
}

/**
 * Refresh the header line. Progress lives here rather than in the body: a
 * "步骤 3 / 8" row in the transcript is framework bookkeeping, and the operator
 * reads it as clutter next to the actual answer.
 */
function renderAiStatus(finalText) {
  if (!aiStatus) return;
  // The header is only a control once the run can be folded; mark it otherwise
  // so a live clock does not invite a click that does nothing.
  aiStatus.parentElement.classList.toggle("idle", !finalText);
  if (finalText) { aiStatus.textContent = finalText; return; }
  // A replayed transcript has no live clock; showing one would imply the old
  // run is still going.
  if (state.replaying || !state.started) return;
  const s = Math.floor((Date.now() - state.started) / 1000);
  // Only the elapsed time. The step number was noise: it changes on its own
  // and says nothing the operator acts on, while the clock is the thing they
  // actually watch. The step count is still reported in the finished header.
  aiStatus.textContent = `已处理 ${s}s`;
}

function startTimer() {
  if (aiTimer) clearInterval(aiTimer);
  renderAiStatus();
  aiTimer = setInterval(() => renderAiStatus(), 1000);
}

function stopTimer() {
  if (aiTimer) { clearInterval(aiTimer); aiTimer = null; }
}

/**
 * Toggle one run's folding context. Takes the .msg-ai it belongs to rather than
 * reaching for a global, because a replayed session leaves several on screen and
 * a document-wide lookup would always find the oldest.
 *
 * Folding is driven by .collapsed, which the stylesheet backs with display:none
 * rather than max-height alone. Without that, a context created in the same frame
 * it is folded has no starting box to animate from and the steps stay visible —
 * clipped, but visible. So the collapse is staged across two frames: drop the
 * max-height/opacity transition first, then let display:none land once the
 * browser has measured a real starting box.
 */
function toggleWorkflow(scope) {
  const box = scope?.querySelector(".workflow-context");
  const header = scope?.querySelector(".ai-status-header");
  if (!box) return;

  if (box.classList.contains("collapsed")) {
    // Expanding: display back on, and let the class go so it transitions open.
    box.classList.remove("no-anim");
    requestAnimationFrame(() => {
      box.classList.remove("collapsed");
      header?.classList.add("expanded");
    });
  } else {
    box.classList.add("no-anim", "collapsed");
    header?.classList.remove("expanded");
    // Two frames: the first lets the pre-collapse box be measured, the second
    // lets the transition itself run. Removing display:none is deferred.
    requestAnimationFrame(() => requestAnimationFrame(() => box.classList.remove("no-anim")));
  }
}

/** Header text for a finished run — the WorkBuddy-style "已完成 · 3 步 · 12s". */
function runDoneLabel(ev) {
  const reason = String(ev.reason || "");
  const label = reason.startsWith("error") ? "出错了"
    : reason === "task complete" ? "已完成"
    : reason === "aborted" ? "已中断"
    : reason === "stuck" ? "已停止"
    : "已结束";
  // No step count. It is bookkeeping rather than something the operator acts
  // on, and it reads as noise next to the one number that matters — how long
  // the run took.
  const bits = [label];
  if (ev.elapsed != null) bits.push(`${Math.round(ev.elapsed)}s`);
  return bits.join(" · ");
}

function renderThinking(text) {
  const block = ensureStepBlock();
  let t = currentThinking;
  if (!t) {
    const step = document.createElement("div");
    step.className = "thinking-step pulse";
    step.innerHTML =
      '<span class="ts-label">思考过程</span>' +
      '<svg class="chevron-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>';
    const details = document.createElement("div");
    details.className = "step-details hidden";
    const body = document.createElement("div");
    body.className = "thought";
    details.append(body);
    step.addEventListener("click", () => {
      const hidden = details.classList.toggle("hidden");
      step.querySelector(".chevron-icon").style.transform = hidden ? "rotate(0deg)" : "rotate(180deg)";
    });
    block.el.append(step, details);
    t = currentThinking = { step, details, body };
    scrollDown();
  }
  t.body.textContent += text;
  t.step.classList.remove("pulse"); // first token arrived
}

function renderMessage(text) {
  const block = ensureStepBlock();
  currentThinking = null;
  if (!currentMessage) {
    currentMessage = document.createElement("div");
    currentMessage.className = "output-text fade-in";
    block.el.append(currentMessage);
  }
  lastMessageNode = currentMessage;
  // Re-derive the whole visible string from the accumulated deltas instead of
  // appending, so the marker filter can see it whole.
  currentMessage._raw = (currentMessage._raw || "") + text;
  currentMessage.textContent = stripInternalMarkers(currentMessage._raw);
  scrollDown();
}

/**
 * Lift the run's last prose out of the folding context and into the conclusion
 * slot, which sits below the accordion and is never hidden.
 *
 * Order matters: finalizeStepMessage has already rewritten currentMessage with
 * the step's settled text by the time run_done arrives, so this moves the final
 * wording, not a half-streamed one. Moving the node (rather than re-creating
 * it) keeps any selection the operator already made.
 */
function promoteConclusion() {
  // The node, not a selector: see lastMessageNode for why `:last-of-type`
  // silently missed whenever the engine reported reasoning after the prose.
  const finalText = currentMessage || lastMessageNode;
  if (!finalText || !aiContent) return;
  aiContent.append(finalText);          // moves the node out of the step block
  currentMessage = null;
  lastMessageNode = null;
  stepBlock = null;                      // the next step gets a fresh block
}

function renderToolCall(ev) {
  const block = ensureStepBlock();
  currentThinking = null;
  currentMessage = null;
  const step = document.createElement("div");
  step.className = "thinking-step clickable";
  step.innerHTML =
    '<svg class="ts-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"></polyline>' +
    '<line x1="12" y1="19" x2="20" y2="19"></line></svg>' +
    `<span class="ts-label">${escapeHtml(ev.name)}</span>` +
    '<span class="badge badge-run">运行中</span>' +
    '<svg class="chevron-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>';
  const details = document.createElement("div");
  details.className = "step-details hidden";
  const pre = document.createElement("pre");
  pre.innerHTML = `<code>${escapeHtml(preview(ev.arguments) || "(no arguments)")}</code>`;
  details.append(pre);
  step.addEventListener("click", () => {
    const hidden = details.classList.toggle("hidden");
    step.querySelector(".chevron-icon").style.transform = hidden ? "rotate(0deg)" : "rotate(180deg)";
  });
  block.el.append(step, details);
  openToolCards.set(ev.id, { step, details, pre });
  scrollDown(true);
}

function renderToolResult(ev) {
  const e = openToolCards.get(ev.id);
  if (!e) return;
  const seconds = ev.seconds != null ? `${ev.seconds}s` : "";
  e.step.querySelector(".badge").outerHTML =
    `<span class="badge ${ev.ok ? "badge-ok" : "badge-err"}">${ev.ok ? "完成" : "失败"}${seconds ? " · " + seconds : ""}</span>`;
  e.pre.textContent = ev.result;
  scrollDown();
}

function stepNote(cls, text) {
  const block = ensureStepBlock();
  const note = document.createElement("div");
  note.className = "step-note " + cls;
  note.textContent = text;
  block.el.append(note);
  scrollDown();
}

/* ── Event sink ──────────────────────────────────────────────────── */

function handleEvent(ev) {
  // Events are tagged with the session they belong to. A mission started from
  // another tab still has to move the state lights, but it must not append to
  // a transcript showing a different thread.
  if (ev.session && state.sessionId && ev.session !== state.sessionId) {
    if (ev.type === "run_start") {
      // ...unless it is a new run: then this tab follows the operator there,
      // which is less confusing than silently ignoring what was just started.
      state.sessionId = ev.session;
      replayTranscript([]);
      refreshSessions();
    } else if (ev.type !== "status") {
      return;
    }
  }

  switch (ev.type) {
    case "run_start":
      // The transcript is cleared only for a live run: a stored session holds
      // one run_start per run, and honouring the clear there would leave just
      // the last run on screen.
      if (!state.replaying) {
        transcript.innerHTML = "";
        openToolCards.clear();
        stopTimer();
        state.started = Date.now();
        state.steps = 0;
      }
      // Always start a fresh message container. While replaying this is what
      // keeps two runs apart — leaving the previous run's aiMsg in place made
      // the next run's task bubble and folding context land inside it, so the
      // two runs shared one accordion and one footer.
      aiMsg = aiContent = aiStatus = null;
      workflowContext = null;
      aiFooter = null;
      currentThinking = currentMessage = lastMessageNode = null;
      stepBlock = null;
      const u = document.createElement("div");
      u.className = "msg-user fade-in";
      u.textContent = ev.task;
      transcript.append(u);
      // Outside the !replaying guard: a replayed run still names itself, and the
      // title should track whatever run the transcript is showing.
      state.currentTask = ev.task || "";
      renderMissionTitle(state.currentTask);
      ensureAiMessage();
      break;

    case "step_start":
      state.steps = ev.step;
      // Fold the previous step away first: only the newest one stays on screen.
      beginStep();
      ensureStepBlock();
      renderAiStatus();
      break;

    case "thinking":
      renderThinking(ev.text);
      break;

    case "message":
      renderMessage(ev.text);
      break;

    case "tool_call":
      renderToolCall(ev);
      break;

    case "tool_result":
      renderToolResult(ev);
      break;

    case "step_summary":
      // Deliberately not rendered. The engine repeats the step's whole output
      // here — the same text that already streamed via `message` — and prefixes
      // it with a "步骤 N 总结" label, opened by the TASK_COMPLETE control
      // marker. Showing it meant every step appeared twice, the second time
      // carrying framework bookkeeping.
      //
      // It is still useful: it is the text the loop actually judged, so it
      // settles the step's visible prose and strips the marker from it.
      finalizeStepMessage(ev.text);
      break;

    case "notice":
      stepNote("notice", `${ev.level || "提示"}：${ev.text}`);
      break;

    case "error":
      stepNote("error", `错误：${ev.message}`);
      break;

    case "status":
      applyStatus(ev.state);
      break;

    case "approval":
      showApproval(ev);
      break;

    case "approval_resolved":
      hideApproval();
      break;

    case "token_usage":
      // One per model round-trip. Updates the composer counter live, and the
      // statistics page when it happens to be on screen.
      adoptTokenUsage(ev);
      if (state.currentView === "tokens") {
        refreshTokens().catch(() => {});
      }
      break;

    case "run_done":
      currentThinking = currentMessage = null;
      stopTimer();
      renderAiStatus(runDoneLabel(ev));
      // Dynamic accordion: the run's conclusion moves out of the folding context
      // first, *then* the context collapses — so the operator is left looking at
      // the answer alone, with one click away from how it was reached.
      promoteConclusion();
      if (workflowContext) {
        // Fold through the same path a click takes, so the run that ends on its
        // own animates exactly like one the operator folds by hand.
        toggleWorkflow(aiMsg);
      }
      if (aiFooter) {
        aiFooter.classList.remove("hidden");
        aiFooter.classList.add("show");
      }
      scrollDown(true);
      setBusy(false);
      refreshSessions();
      break;
  }
}

let stream = null;

function connectStream() {
  if (stream) stream.close();
  stream = new EventSource("/api/events");

  stream.onopen = () => {
    $("conn").textContent = "已连接";
    $("conn").className = "pill pill-on";
  };
  stream.onerror = () => {
    $("conn").textContent = "重连中";
    $("conn").className = "pill pill-off";
  };
  stream.onmessage = (message) => {
    try {
      handleEvent(JSON.parse(message.data));
    } catch (err) {
      console.error("bad event", message.data, err);
    }
  };
}

/* ── Sessions ────────────────────────────────────────────────────── */

function formatStamp(ts) {
  if (!ts) return "—";
  const when = new Date(ts * 1000);
  const pad = (n) => String(n).padStart(2, "0");
  return `${when.getFullYear()}-${pad(when.getMonth() + 1)}-${pad(when.getDate())} `
       + `${pad(when.getHours())}:${pad(when.getMinutes())}`;
}

function currentSessionSummary() {
  return state.sessions.find((s) => s.id === state.sessionId) || null;
}

async function refreshSessions() {
  const payload = await api("/api/sessions").catch(() => null);
  if (!payload) return;
  state.sessions = payload.sessions || [];
  // The server knows which session is mounted; a reload has to adopt it
  // rather than falling back to "nothing selected".
  if (payload.active) state.sessionId = payload.active;
  renderSessionBar();
  renderSessionList();
  renderSidebarSessions();
  // Every path that changes which conversation is mounted funnels through
  // here, which makes this the one place the composer's token counter needs
  // to follow along. Fired without awaiting: the session list should paint
  // even if the usage request is slow.
  refreshTokenMeter().catch(() => {});
}

function renderSessionBar() {
  const current = currentSessionSummary();
  $("session-title").textContent = current
    ? current.title
    : (state.sessionId ? "（该会话已不存在）" : "未选择");

  const bits = [];
  if (current) {
    // Run count only. The step total belongs to the run's own header; repeating
    // it here made the bar read like a status dump. The last reason is left
    // out too: it is a machine value ("task complete") that the run's own
    // header already reports in words, and showing it here duplicated the
    // verdict in a language the operator never asked for.
    bits.push(`${current.runs} 次任务`);
  } else if (state.sessionId) {
    bits.push("执行时会新建一个会话");
  } else {
    bits.push("新建会话后开始，或直接执行任务");
  }
  $("session-meta").textContent = bits.join(" · ");

  // Granting/revoking a session is a control capability, so re-apply the role
  // gate here: applyRole() ran earlier and renderSessionBar() would otherwise
  // re-enable the two buttons for a viewer.
  const canControl = state.caps.has("control");
  $("session-delete").disabled = !current || state.busy || !canControl;
  $("session-rename").disabled = !current || !canControl;
}

function renderSessionList() {
  const host = $("session-list");
  if (!state.sessions.length) {
    host.innerHTML = '<div class="session-empty">还没有历史会话。点「新建会话」开始。</div>';
    return;
  }
  host.innerHTML = state.sessions.map((s) => {
    const active = s.id === state.sessionId;
    const flag = active && state.busy ? "运行中" : "";
    // The stored last_reason is deliberately not rendered: it is the engine's
    // own token ("task complete"), and the run's header already puts it into
    // words where the run itself lives.
    return `<button class="session-row ${active ? "active" : ""}" data-session="${escapeHtml(s.id)}">
      <span>
        <span class="sr-title">${escapeHtml(s.title)}</span>
        <span class="sr-sub">${formatStamp(s.updated)} · ${s.runs} 次任务</span>
      </span>
      <span class="sr-flag">${flag}</span>
    </button>`;
  }).join("");
}

/**
 * The sidebar tree under Agent 会话: every session, grouped.
 *
 * Two sections, because that is how sessions come into being — the same split
 * WorkBuddy draws in its own sidebar:
 *   任务 — the run got a timestamped directory under the configured parent, so
 *          there is no folder to group by and the run itself is the unit.
 *   空间 — the run was pointed at a folder, so its sessions collect under that
 *          folder's name; one space can hold many runs.
 *
 * Both sections render expanded by default; an individual space starts folded
 * unless it holds the session currently on screen. The split is taken from the
 * session record, not re-derived from the path: a later change to the
 * parent-directory setting must not silently reclassify history.
 */
function renderSidebarSessions() {
  const host = $("nav-session-tree");
  if (!host) return;

  const sessions = state.sessions || [];
  const tasks = sessions.filter((s) => s.workspace_kind === "auto");
  const others = sessions.filter((s) => s.workspace_kind !== "auto");

  // Sessions recorded before the workspace was tracked carry no kind. They are
  // not guessed into either bucket — the guess would be wrong about half the
  // time and the operator has no way to tell which half.
  const unclassified = others.filter((s) => !s.space);
  const spaces = new Map();
  for (const s of others) {
    if (!s.space) continue;
    if (!spaces.has(s.space)) spaces.set(s.space, []);
    spaces.get(s.space).push(s);
  }

  if (!sessions.length) {
    host.innerHTML = '<div class="nav-tree-empty">还没有会话。新建任务开始第一次运行。</div>';
    return;
  }

  const row = (s) => {
    const active = s.id === state.sessionId;
    const flag = active && state.busy ? '<span class="nav-tree-run">运行中</span>' : "";
    // A row is a wrapper rather than a single button: the ⋯ trigger must not
    // be inside the click target that opens the session, or opening the menu
    // would also switch to that session. Actions are hidden until hover —
    // WorkBuddy shows them the same way, and it keeps a long list quiet.
    return `<div class="nav-tree-row ${active ? "active" : ""}" data-session="${escapeHtml(s.id)}">
      <button type="button" class="nav-tree-open" title="${escapeHtml(s.title)}">
        <span class="nav-tree-row-text">
          <span class="nav-tree-title">${escapeHtml(s.title)}</span>
          <span class="nav-tree-sub">${formatStamp(s.updated)} · ${s.runs} 次任务</span>
        </span>${flag}
      </button>
      <button type="button" class="nav-tree-more" data-more="${escapeHtml(s.id)}" title="更多操作" aria-label="更多操作">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>
      </button>
    </div>`;
  };

  const caret = '<svg class="nav-tree-caret" viewBox="0 0 24 24" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>';
  const folder = '<svg class="nav-tree-folder" viewBox="0 0 24 24" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';

  // The 15s poll re-renders this tree, so expansion flags live in state:
  // a section the operator folded must not spring back open behind their
  // back. A space the operator never touched still defaults to open when it
  // holds the session currently on screen.
  const open = {
    tasks: state.treeOpen.tasks ? " open" : "",
    spaces: state.treeOpen.spaces ? " open" : "",
    unclassified: state.treeOpen.unclassified ? " open" : "",
  };

  const sections = [];

  if (tasks.length) {
    sections.push(`<div class="nav-tree-section${open.tasks}" data-tree-section="tasks">
      <button type="button" class="nav-tree-head"><span>任务</span><span class="nav-tree-count">${tasks.length}</span>${caret}</button>
      <div class="nav-tree-body">${tasks.map(row).join("")}</div>
    </div>`);
  }

  if (spaces.size) {
    const sorted = [...spaces.entries()].sort((a, b) => {
      const ua = Math.max(...a[1].map((s) => s.updated || 0));
      const ub = Math.max(...b[1].map((s) => s.updated || 0));
      return ub - ua;
    });
    const blocks = sorted.map(([name, items]) => {
      const touched = Object.prototype.hasOwnProperty.call(state.treeOpen.space, name);
      const isOpen = touched
        ? state.treeOpen.space[name]
        : items.some((s) => s.id === state.sessionId);
      return `<div class="nav-tree-space${isOpen ? " open" : ""}" data-space="${escapeHtml(name)}">
        <button type="button" class="nav-tree-space-head" title="${escapeHtml(name)}">
          ${folder}<span class="nav-tree-title">${escapeHtml(name)}</span>
          <span class="nav-tree-count">${items.length}</span>${caret}
        </button>
        <div class="nav-tree-space-body">${items.map(row).join("")}</div>
      </div>`;
    }).join("");
    sections.push(`<div class="nav-tree-section${open.spaces}" data-tree-section="spaces">
      <button type="button" class="nav-tree-head"><span>空间</span><span class="nav-tree-count">${spaces.size}</span>${caret}</button>
      <div class="nav-tree-body">${blocks}</div>
    </div>`);
  }

  if (unclassified.length) {
    sections.push(`<div class="nav-tree-section${open.unclassified}" data-tree-section="unclassified">
      <button type="button" class="nav-tree-head"><span>未分类</span><span class="nav-tree-count">${unclassified.length}</span>${caret}</button>
      <div class="nav-tree-body">${unclassified.map(row).join("")}</div>
    </div>`);
  }

  host.innerHTML = sections.join("");

  // The row wrapper no longer receives clicks directly; its inner button does.
  // Bound here rather than inline so a re-render cannot leave stale handlers.
  host.querySelectorAll(".nav-tree-open").forEach((btn) => {
    btn.addEventListener("click", () => {
      const rowEl = btn.closest("[data-session]");
      if (rowEl) openSession(rowEl.dataset.session);
    });
  });
  host.querySelectorAll("[data-more]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      openTreeMenu(btn, btn.dataset.more);
    });
  });
  host.querySelectorAll(".nav-tree-head").forEach((head) => {
    head.addEventListener("click", () => {
      const section = head.closest(".nav-tree-section");
      section.classList.toggle("open");
      state.treeOpen[section.dataset.treeSection] = section.classList.contains("open");
    });
  });
  host.querySelectorAll(".nav-tree-space-head").forEach((head) => {
    head.addEventListener("click", () => {
      const space = head.closest(".nav-tree-space");
      space.classList.toggle("open");
      state.treeOpen.space[space.dataset.space] = space.classList.contains("open");
    });
  });
}

/**
 * Replay a stored transcript into the panel.
 *
 * Approval events are skipped on purpose: asking again about a command the
 * operator answered last week would pop a modal over an otherwise idle
 * session, and the answer is already baked into the run.
 */function replayTranscript(events) {
  const host = $("transcript");
  state.replaying = true;
  try {
    host.innerHTML = "";
    openToolCards.clear();
    aiMsg = aiContent = aiStatus = null;
    workflowContext = null;
    aiFooter = null;
    currentThinking = currentMessage = lastMessageNode = null;
    stepBlock = null;
    stopTimer();
    for (const ev of events) {
      if (ev.type === "approval" || ev.type === "approval_resolved") continue;
      handleEvent(ev);
    }
  } finally {
    state.replaying = false;
  }
  host.scrollTop = host.scrollHeight;
}

/**
 * The ⋯ menu on a sidebar session row.
 *
 * This is where rename and delete live now. They used to be buttons on the
 * mission page's session bar, which made the *task* page carry conversation
 * management; WorkBuddy keeps both on the session row itself, and the sidebar
 * is where the operator is already looking when they want them.
 *
 * The menu sits at body level and is positioned from the trigger's rect, so
 * the tree's own scrolling cannot clip it.
 */
let treeMenuFor = null;

function openTreeMenu(trigger, sessionId) {
  const menu = $("row-menu");
  if (!menu) return;

  treeMenuFor = sessionId;
  menu.classList.add("show");

  // Flip above the row when there is not enough room below — the tree can be
  // long and its last rows sit near the viewport bottom.
  const r = trigger.getBoundingClientRect();
  const h = menu.offsetHeight || 132;
  const below = r.bottom + 6;
  const top = below + h > window.innerHeight - 8 ? Math.max(8, r.top - h - 6) : below;
  menu.style.top = `${top}px`;
  menu.style.left = `${Math.max(8, Math.min(r.left - 8, window.innerWidth - 200))}px`;
}

function closeTreeMenu() {
  treeMenuFor = null;
  $("row-menu")?.classList.remove("show");
}

$("row-menu")?.querySelectorAll("[data-act]").forEach((item) => {
  item.addEventListener("click", async () => {
    const id = treeMenuFor;
    const act = item.dataset.act;
    closeTreeMenu();
    if (!id) return;
    if (act === "open") return openSession(id);
    if (act === "rename") return renameSession(id);
    if (act === "delete") return deleteSession(id);
  });
});
// Any click elsewhere, a scroll, or Escape dismisses it.
document.addEventListener("click", (e) => {
  const menu = $("row-menu");
  if (menu?.classList.contains("show") && !menu.contains(e.target)) closeTreeMenu();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeTreeMenu();
});
$("nav-session-tree")?.addEventListener("scroll", closeTreeMenu, { passive: true });

async function renameSession(id) {
  if (!state.caps.has("control")) {
    toast("当前角色没有 control 权限，无法重命名会话", true);
    return;
  }
  const current = (state.sessions || []).find((s) => s.id === id);
  const title = (window.prompt("会话名称", current ? current.title : "") || "").trim();
  if (!title || (current && title === current.title)) return;
  try {
    await api(`/api/sessions/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify({ title }),
    });
    // refreshSessions() also re-renders the sidebar tree, which is where the
    // renamed row lives now. Calling renderSessionGroups() here would throw —
    // that page was removed when the grouping moved into the sidebar.
    await refreshSessions();
    toast("会话已重命名");
  } catch (err) {
    toast(err.message, true);
  }
}

async function deleteSession(id) {
  if (!state.caps.has("control")) {
    toast("当前角色没有 control 权限，无法删除会话", true);
    return;
  }
  const current = (state.sessions || []).find((s) => s.id === id);
  if (id === state.sessionId && state.busy) {
    toast("该会话正在运行，请先中断任务", true);
    return;
  }
  const name = current ? current.title : id;
  if (!window.confirm(`删除会话「${name}」？\n轨迹与上下文都会从磁盘移除，无法恢复。`)) return;
  try {
    await api(`/api/sessions/${encodeURIComponent(id)}`, { method: "DELETE" });
    // If the mounted one went away the server drops the mount; adopt that
    // rather than leaving a dead id selected.
    if (id === state.sessionId) {
      state.sessionId = null;
      replayTranscript([]);
      showView("dashboard");
    }
    await refreshSessions();
    toast("会话已删除");
  } catch (err) {
    toast(err.message, true);
  }
}

async function openSession(id) {
  const payload = await api(`/api/sessions/${encodeURIComponent(id)}`)
    .catch((err) => { toast(err.message, true); return null; });
  if (!payload) return;

  // Tell the server which session is now selected, before any refresh can
  // disagree. `/api/sessions` reports the mounted session as `active` and this
  // page adopts that value, so a local-only selection was silently reverted by
  // the refresh that follows navigation — a task started right after clicking
  // a session then continued the *previous* one's context.
  if (!state.busy) {
    await api(`/api/sessions/${encodeURIComponent(id)}/mount`, { method: "POST" })
      .catch(() => { /* non-fatal: the local selection still applies */ });
  }

  state.sessionId = id;
  replayTranscript(payload.session.transcript || []);
  closeSessionList();
  renderSessionBar();
  renderSessionList();
  // The sidebar tree needs the tick to follow too, and it may be the surface
  // the click came from.
  renderSidebarSessions();
  // Picking a session is a request to look at it, so land on the transcript
  // rather than leaving the operator on the list they just chose from.
  showView("mission");
}

function closeSessionList() {
  state.sessionsOpen = false;
  $("session-list").classList.add("hidden");
  $("session-current").classList.remove("open");
}

async function newSession() {
  if (!state.caps.has("control")) {
    toast("当前角色没有 control 权限，无法新建会话", true);
    return null;
  }
  const mounted = currentSessionSummary();
  // Clicking the button twice should not leave two unnamed sessions behind.
  if (mounted && !mounted.runs) {
    closeSessionList();
    renderSessionBar();
    return mounted.id;
  }

  const payload = await api("/api/sessions", {
    method: "POST",
    body: JSON.stringify({}),
  }).catch((err) => { toast(err.message, true); return null; });
  if (!payload) return null;

  state.sessionId = payload.session.id;
  replayTranscript([]);
  await refreshSessions();
  closeSessionList();
  return state.sessionId;
}

$("session-current").addEventListener("click", () => {
  state.sessionsOpen = !state.sessionsOpen;
  $("session-list").classList.toggle("hidden", !state.sessionsOpen);
  $("session-current").classList.toggle("open", state.sessionsOpen);
  if (state.sessionsOpen) refreshSessions();
});

$("session-list").addEventListener("click", (e) => {
  const row = e.target.closest("[data-session]");
  if (row) openSession(row.dataset.session);
});

$("session-new").addEventListener("click", async () => {
  await newSession();
  $("task-input").focus();
});

/* The full browser used to be its own page; the sidebar tree is the browser
   now, so "浏览全部" reveals the Agent 会话 group instead of navigating. */
$("session-browse").addEventListener("click", () => {
  closeSessionList();
  state.sessionsNavOpen = true;
  syncSidebarGroups();
  refreshSessions();
});

$("session-rename").addEventListener("click", async () => {
  const current = currentSessionSummary();
  if (!current) return;
  const title = (window.prompt("会话名称", current.title) || "").trim();
  if (!title || title === current.title) return;
  try {
    await api(`/api/sessions/${encodeURIComponent(current.id)}`, {
      method: "PATCH",
      body: JSON.stringify({ title }),
    });
    await refreshSessions();
    toast("会话已重命名");
  } catch (err) {
    toast(err.message, true);
  }
});

$("session-delete").addEventListener("click", async () => {
  const current = currentSessionSummary();
  if (!current) return;
  if (state.busy) {
    toast("会话正在运行，请先中断任务", true);
    return;
  }
  if (!window.confirm(`删除会话「${current.title}」？\n轨迹与上下文都会从磁盘移除，无法恢复。`)) {
    return;
  }
  try {
    await api(`/api/sessions/${encodeURIComponent(current.id)}`, { method: "DELETE" });
    state.sessionId = null;
    replayTranscript([]);
    await refreshSessions();
    toast("会话已删除");
  } catch (err) {
    toast(err.message, true);
  }
});

/* ── Mission controls ────────────────────────────────────────────── */

/** Grey out the number field when the step ceiling is switched off. */
function syncStepLimit() {
  const off = $("opt-unlimited").checked;
  // This runs after applyRole() on every console entry, so a role without
  // control would otherwise get the field back by merely toggling the ceiling.
  $("opt-steps").disabled = off || !state.caps.has("control");
  $("opt-steps").title = off
    ? "已关闭步数上限：任务会跑到模型声明完成、卡住检测触发，或你手动中断"
    : "";
}

$("opt-unlimited").addEventListener("change", syncStepLimit);

/* ── Step ceiling on the landing page ────────────────────────────────
 *
 * A thin view over the composer's own #opt-steps / #opt-unlimited, not a
 * second setting: startMission reads those two elements, so keeping one pair
 * of inputs authoritative means the two screens can never disagree about the
 * limit that is actually sent. This mirrors them and routes its edits back.
 *
 * Elements are looked up on each use rather than captured in module-level
 * consts. Those consts would sit here, above their first use at the bottom of
 * the file, and a `const` in the temporal dead zone throws — which took the
 * whole script down from that line on, leaving the control inert. Nothing here
 * runs in a hot path, so the lookup costs nothing worth measuring.
 */
function syncStepControls(source) {
  const input = $("dash-steps-input");
  const unlimited = $("dash-unlimited-toggle");
  const composerUnlimited = $("opt-unlimited");
  const composerSteps = $("opt-steps");
  if (!input || !unlimited) return;

  if (source === "composer") {
    // The composer is authoritative — copy it into the landing mirror.
    //
    // The mirror's previous state must not be consulted here. Reading it first
    // (as an earlier version did) meant a stale mirror overrode the very change
    // that triggered this call, so unchecking "不限步数" in the composer was
    // immediately undone by the mirror still holding `true`.
    unlimited.checked = composerUnlimited.checked;
    input.value = composerSteps.value;
  } else {
    // The mirror was just edited; push it back to the authoritative fields.
    composerUnlimited.checked = unlimited.checked;
    const n = parseInt(input.value, 10);
    if (unlimited.checked || !Number.isFinite(n) || n <= 0) {
      composerSteps.value = input.value;
    } else {
      composerSteps.value = n;
    }
  }

  // One render, after the copy, so the label can never describe the other side.
  input.disabled = unlimited.checked;
  syncStepLimit();
  renderStepLabel();
}

/** The button says what will happen, so the limit is readable without opening it. */
function renderStepLabel() {
  const el = $("dash-steps-text");
  const input = $("dash-steps-input");
  const unlimited = $("dash-unlimited-toggle");
  if (!el || !input || !unlimited) return;
  if (unlimited.checked) {
    el.textContent = "不限步数";
  } else {
    const n = parseInt(input.value, 10);
    el.textContent = `最多 ${Number.isFinite(n) && n > 0 ? n : "—"} 步`;
  }
  el.title = el.textContent;
}

$("dash-steps-btn").addEventListener("click", (e) => {
  e.stopPropagation();
  $("dash-steps-popover").classList.toggle("show");
  $("dash-steps-btn").classList.toggle("active");
});
$("dash-unlimited-toggle").addEventListener("change", () => syncStepControls("dash"));
$("dash-steps-input").addEventListener("input", () => syncStepControls("dash"));
// Editing the composer's field must not leave the landing control stale.
$("opt-steps").addEventListener("input", () => syncStepControls("composer"));
$("opt-unlimited").addEventListener("change", () => syncStepControls("composer"));

function setBusy(busy) {
  state.busy = busy;
  const canControl = state.caps.has("control");
  // Both send buttons double as the stop button while a mission runs, so a
  // control-capable user must not have them disabled — the click calls abort
  // instead of submit. They are the only controls on their page while busy,
  // so leaving either one inert is what makes a run feel unstoppable.
  for (const id of ["btn-run", "landing-run"]) {
    const btn = $(id);
    if (!btn) continue;
    btn.disabled = !canControl;
    btn.classList.toggle("stop", busy);
    btn.title = busy ? "停止任务" : "执行";
  }
  $("btn-abort").disabled = !busy || !canControl;
  $("btn-pause").disabled = !busy || !canControl;
  $("btn-next").disabled = !busy || !canControl;
  $("task-input").disabled = busy || !canControl;
  // The landing input stays *editable* while busy: its button is now a stop
  // control, and disabling the field would suggest the whole page is locked.
  // Submission is what must not start a second run, and submitLanding handles
  // that by branching on state.busy.
  updateRunStrip();
}

/**
 * The run strip above the composer.
 *
 * Hidden except when the operator has something to decide. Those states are:
 *   paused          — 继续 is the only way forward
 *   step_mode       — a "next step" run is parked at gate_step() and, with the
 *                     old header buttons gone, 下一步 is the *only* thing that
 *                     releases it; without this the run would hang forever
 *   awaiting_approval — 中断 matters, and an inline prompt can be missed
 *
 * Showing them always would defeat the point of the simplified page; showing
 * them never would strand a step-mode run.
 */
function updateRunStrip() {
  const strip = $("run-strip");
  if (!strip) return;

  const canControl = state.caps.has("control");
  const stepping = $("opt-step")?.checked === true;
  const paused = state.runState === "paused";
  const waiting = state.runState === "awaiting_approval";
  const needed = state.busy && canControl && (paused || waiting || stepping);
  strip.classList.toggle("hidden", !needed);
  if (!needed) return;

  const label = $("run-strip-label");
  if (label) {
    label.textContent = paused ? "已暂停"
      : waiting ? "等待确认"
      : "逐步确认中";
  }
  // Each control is shown only where it applies, so the strip stays a
  // two-or-three word affair rather than a toolbar.
  $("btn-pause2").classList.toggle("hidden", paused || waiting);
  $("btn-resume2").classList.toggle("hidden", !paused);
  $("btn-next2").classList.toggle("hidden", !stepping && !paused);
  $("btn-abort2").classList.toggle("hidden", false);
}

function applyStatus(value) {
  const labels = {
    idle: "空闲", running: "运行中", paused: "已暂停", awaiting_approval: "等待确认",
  };
  state.runState = value;
  $("st-state").textContent = labels[value] || value;
  $("dev-state").textContent = $("st-state").textContent;
  $("st-dot").className = "state-dot " + (
    value === "running" ? "running" :
    value === "paused" ? "paused" :
    value === "awaiting_approval" ? "awaiting" : ""
  );
  setBusy(["running", "paused", "awaiting_approval"].includes(value));

  const paused = value === "paused";
  $("btn-pause").classList.toggle("hidden", paused);
  $("btn-resume").classList.toggle("hidden", !paused);
  $("btn-resume").disabled = !paused || !state.caps.has("control");
  updateRunStrip();
}

/* Start a mission from any entry point (composer or the landing input). The
   live transcript keeps streaming into the mission view, so we surface it. */
async function startMission(task) {
  task = (task || "").trim();
  if (!task) return;
  try {
    const res = await api("/api/mission", {
      method: "POST",
      body: JSON.stringify({
        task,
        step_mode: $("opt-step").checked,
        // 0 is the explicit "no ceiling" the server understands; leaving the
        // field empty falls back to whatever the panel is configured for.
        max_steps: $("opt-unlimited").checked
          ? 0
          : (parseInt($("opt-steps").value, 10) || undefined),
        // Omitted means "whatever is mounted"; the server creates one when
        // nothing is, and names it from this task.
        session_id: state.sessionId || undefined,
        // Conversation-UI controls wired to real backend behaviour.
        full_access: state.fullAccess,
        agent_mode: state.agentMode,
        workspace: state.workspace || undefined,
        model: state.currentModel || undefined,
      }),
    });
    if (res.session) {
      state.sessionId = res.session;
      renderSessionBar();
      renderSessionList();
    }
    showView("mission");
  } catch (err) {
    toast(err.message, true);
  }
}

$("composer").addEventListener("submit", async (e) => {
  e.preventDefault();
  // While a mission is running the send button becomes "stop".
  if (state.busy) {
    control("abort");
    return;
  }
  const task = $("task-input").value;
  if (!task.trim()) return;
  await startMission(task);
  $("task-input").value = "";
});

$("task-input").addEventListener("keydown", (e) => {
  if (!isSendKey(e)) return;
  e.preventDefault();
  // Submit the form rather than calling startMission directly, so the
  // composer's own handler stays the single path a send can take.
  $("composer").requestSubmit ? $("composer").requestSubmit() : $("composer").dispatchEvent(new Event("submit", { cancelable: true }));
});

$("btn-pause").addEventListener("click", () => control("pause"));
$("btn-resume").addEventListener("click", () => control("resume"));
$("btn-next").addEventListener("click", () => control("step"));
$("btn-abort").addEventListener("click", () => control("abort"));

// The visible controls. The four above still exist (hidden, off-layout) because
// the status logic drives them; these are what the operator actually presses.
$("btn-pause2")?.addEventListener("click", () => control("pause"));
$("btn-resume2")?.addEventListener("click", () => control("resume"));
$("btn-next2")?.addEventListener("click", () => control("step"));
$("btn-abort2")?.addEventListener("click", () => control("abort"));
$("session-new2")?.addEventListener("click", async () => {
  const id = await newSession();
  if (id) showView("mission");
});

async function control(action, extra = {}) {
  try {
    await api("/api/control", { method: "POST", body: JSON.stringify({ action, ...extra }) });
  } catch (err) {
    toast(err.message, true);
  }
}

/* ── Permission (Default / Full Access) ───────────────────────────── */
const permissionBtn = $("permission-btn");
const permissionPopover = $("permission-popover");
const fullAccessToggle = $("full-access-toggle");
const permissionModal = $("permission-modal");
const pmUnderstand = $("pm-understand");
const pmAllow = $("pm-allow");

function updatePermissionUI() {
  const full = state.fullAccess;
  const label = full ? "完全访问" : "默认权限";
  const desc = full
    ? "完全访问已启用。所有任务将跳过确认步骤，直接操作你的电脑。"
    : "默认权限已启用。代理不能直接运行 shell 命令。任何使用 cmd、PowerShell 或注册表的尝试都会被自动拦截，你可以审批一次性操作。";
  $("permission-btn-text").textContent = label;
  $("popover-desc").textContent = desc;
  // Mirror the same state on the landing page's Default / Full Access control.
  const dashText = $("dash-permission-text");
  const dashDesc = $("dash-popover-desc");
  if (dashText) dashText.textContent = label;
  if (dashDesc) dashDesc.textContent = desc;
}

permissionBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  permissionPopover.classList.toggle("show");
  permissionBtn.classList.toggle("active");
});

fullAccessToggle.addEventListener("change", () => {
  if (fullAccessToggle.checked && !state.fullAccess) {
    permissionPopover.classList.remove("show");
    permissionBtn.classList.remove("active");
    openPermissionModal();
  } else if (!fullAccessToggle.checked && state.fullAccess) {
    state.fullAccess = false;
    // Mirror onto the landing page's switch as well, or the two controls end
    // up disagreeing about the same flag.
    resetPermissionToggles();
    updatePermissionUI();
  }
});

/* The modal is hidden with the same `.hidden` convention as every other
   overlay. It used to be toggled with a `.show` class that no rule matched,
   so it was painted on load and could never be dismissed. */
function openPermissionModal() {
  pmUnderstand.checked = false;
  pmAllow.disabled = true;
  permissionModal.classList.remove("hidden");
}

function resetPermissionToggles() {
  fullAccessToggle.checked = state.fullAccess;
  const dashToggle = $("dash-full-access-toggle");
  if (dashToggle) dashToggle.checked = state.fullAccess;
}

function closePermissionModal() {
  permissionModal.classList.add("hidden");
  resetPermissionToggles();
  pmUnderstand.checked = false;
  pmAllow.disabled = true;
}
$("pm-close").addEventListener("click", closePermissionModal);
$("pm-cancel").addEventListener("click", closePermissionModal);
permissionModal.addEventListener("click", (e) => { if (e.target === permissionModal) closePermissionModal(); });
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !permissionModal.classList.contains("hidden")) closePermissionModal();
});
pmUnderstand.addEventListener("change", () => { pmAllow.disabled = !pmUnderstand.checked; });
pmAllow.addEventListener("click", () => {
  state.fullAccess = true;
  fullAccessToggle.checked = true;
  const dashToggle = $("dash-full-access-toggle");
  if (dashToggle) dashToggle.checked = true;
  permissionModal.classList.add("hidden");
  updatePermissionUI();
  toast("已启用完全访问：任务将跳过确认步骤");
});
updatePermissionUI();

/* ── Model selector ───────────────────────────────────────────────── *
 *
 * The list is whatever the operator actually configured — served by
 * /api/hello as `models` — not a built-in catalogue. A hardcoded preset list
 * was worse than useless here: it named models that were never saved, and the
 * tick beside a row has to mean "this is the live configuration" to be worth
 * drawing at all.
 *
 * Each row reads `model-id@Provider`, e.g. `big-pickle@OpenCode-Go`; the
 * provider half is resolved server-side from the Base URL.
 */
let MODEL_PRESETS = [];

const modelBtn = $("model-btn");
const modelPopover = $("model-popover");
const modelList = $("model-list");
const modelInput = $("model-input");

function renderModelList() {
  modelList.innerHTML = "";
  const current = state.currentModel || "";
  if (!MODEL_PRESETS.length) {
    // Says why the list is empty rather than showing a blank panel: an empty
    // picker usually means the model was never configured, not that the panel
    // is broken.
    modelList.innerHTML =
      '<div class="model-empty">还没有配置模型。在上方填写模型 ID 并应用，或先完成 API 配置向导。</div>';
    return;
  }
  for (const m of MODEL_PRESETS) {
    const item = document.createElement("div");
    const active = m.id === current;
    item.className = "model-item" + (active ? " active" : "");
    item.innerHTML =
      `<span class="model-label">${escapeHtml(m.label || m.id)}</span>` +
      // A tick only on the live one; the row is still clickable, so an
      // inactive entry needs no other marker.
      (active ? '<span class="model-tick" aria-label="当前使用">✓</span>' : "");
    item.title = active ? `${m.label || m.id}（当前使用）` : `切换到 ${m.label || m.id}`;
    item.addEventListener("click", () => applyModel(m.id));
    modelList.append(item);
  }
}

async function applyModel(id) {
  id = (id || "").trim();
  if (!id) return;
  try {
    // The server folds the new id into LLM_MODELS before writing, so the
    // previously selected model stays in the list and the switch is reversible.
    await api("/api/settings", { method: "POST", body: JSON.stringify({ LLM_MODEL: id }) });
    state.currentModel = id;
    // Re-read rather than mutating locally: the response is the only authority
    // on which entries now exist.
    state.hello = null;
    await loadCurrentModel();
    // Whether the counter exists at all depends on the model, so a switch has
    // to re-ask. Doing it here (not inside loadCurrentModel) keeps the token
    // refresh out of the path that runs on every page load.
    const hello = await api("/api/hello").catch(() => null);
    if (hello) {
      state.hello = hello;
      adoptTokenSupport(hello.tokens);
      await refreshTokenMeter();
    }
    modelPopover.classList.remove("show");
    toast(`模型已切换为 ${id}`);
  } catch (err) { toast(err.message, true); }
}

/** Keep both the composer and landing model labels in sync with the selection. */
function updateModelLabels() {
  // `模型@提供商` everywhere the selection is shown, so the provider travels
  // with the model — otherwise two providers' identically-named models are
  // indistinguishable in the UI.
  const entry = MODEL_PRESETS.find((m) => m.id === state.currentModel);
  let label = state.currentModel || "模型";
  if (entry) {
    label = entry.label || entry.id;
  } else if (state.hello && state.hello.provider && state.currentModel) {
    // The entry list may be absent (an older server, or a mock that omits it)
    // while the provider is still known. Composing from those two keeps the
    // label complete instead of dropping the provider on the floor.
    label = `${state.currentModel}@${state.hello.provider}`;
  }
  const composerText = $("model-btn-text");
  if (composerText) composerText.textContent = label;
  const landingText = $("landing-model-text");
  if (landingText) landingText.textContent = label;
}

/** The model popover is shared by the composer and the landing page; this
 *  positions the fixed popover next to whichever button opened it. */
function openModelPopover(anchor) {
  modelPopover.classList.add("show");
  // Light up whichever button opened it — the composer and the landing page
  // share this one popover, so the active state has to follow the anchor.
  modelBtn.classList.toggle("active", anchor === modelBtn);
  landingModelBtn.classList.toggle("active", anchor !== modelBtn);
  const r = anchor.getBoundingClientRect();
  const pw = modelPopover.offsetWidth || 320;
  const ph = modelPopover.offsetHeight || 240;
  let left = Math.max(8, r.right - pw);
  let top = r.bottom + 8;
  if (top + ph > window.innerHeight - 8) top = Math.max(8, r.top - ph - 8);
  modelPopover.style.left = left + "px";
  modelPopover.style.top = top + "px";
  modelPopover.style.right = "auto";
}
function closeModelPopover() {
  modelPopover.classList.remove("show");
  modelBtn.classList.remove("active");
  landingModelBtn.classList.remove("active");
}

modelBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  if (modelPopover.classList.contains("show")) closeModelPopover();
  else openModelPopover(modelBtn);
});
$("model-apply").addEventListener("click", () => applyModel(modelInput.value));
modelInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); applyModel(modelInput.value); } });

async function loadCurrentModel() {
  // Read from /api/hello, not /api/settings: the model picker is part of the
  // console chrome and every role sees it, while /api/settings is admin-only
  // and would answer a 403 to a viewer — after which the picker would render
  // empty for them.
  try {
    const hello = state.hello || await api("/api/hello");
    state.hello = hello;
    const models = Array.isArray(hello.models) ? hello.models : [];
    MODEL_PRESETS = models.map((m) => ({
      id: String(m.id || ""),
      provider: String(m.provider || ""),
      label: String(m.label || m.id || ""),
    })).filter((m) => m.id);
    // The configured model is the source of truth for what is active; the
    // entry list only supplies the provider label.
    if (hello.model) state.currentModel = hello.model;
  } catch (err) {
    // Non-fatal: the button keeps its placeholder and the picker explains.
    MODEL_PRESETS = [];
  }
  updateModelLabels();
  renderModelList();
}

/* ── Landing page (我的设备) controls ────────────────────────────── */
/* The dashboard landing mirrors the composer's real controls: GUI/CIL mode,
   a workspace, Default / Full Access permission, and the model picker. All of
   them feed the shared `state` and are sent with every mission. */

const landingInput = $("landing-input");
const landingRun = $("landing-run");
const modeGui = $("mode-gui");
const modeCil = $("mode-cil");
const wsBtn = $("ws-btn");
const wsPopover = $("ws-popover");
const wsInput = $("ws-input");
const wsApply = $("ws-apply");
const wsBrowse = $("ws-browse");
const wsSearch = $("ws-search");
const wsList = $("ws-list");
const wsCustom = $("ws-custom");
const wsNew = $("ws-new");
const dashPermissionBtn = $("dash-permission-btn");
const dashPermissionPopover = $("dash-permission-popover");
const dashFullAccessToggle = $("dash-full-access-toggle");
const landingModelBtn = $("landing-model");
const modeHint = $("mode-hint");

/* The mode boundary is enforced in the backend (see cua/modes.py), so the UI
   states it here instead of letting the model discover it through a refused
   tool call three steps into a mission. */
const MODE_HINTS = {
  gui: "GUI 模式：可操作整台电脑——鼠标、键盘、截屏、识屏、剪贴板全部可用。",
  cil: "CIL 模式：仅执行非桌面任务。命令行、文件与代码、浏览器可用；鼠标、键盘、截屏、识屏、剪贴板不可用。",
};

function setAgentMode(mode) {
  state.agentMode = mode;
  modeGui.classList.toggle("active", mode === "gui");
  modeCil.classList.toggle("active", mode === "cil");
  if (modeHint) {
    modeHint.textContent = MODE_HINTS[mode] || "";
    modeHint.classList.toggle("is-cil", mode === "cil");
  }
}
modeGui.addEventListener("click", () => setAgentMode("gui"));
modeCil.addEventListener("click", () => setAgentMode("cil"));

function submitLanding() {
  // Same dual role as the composer's button: while something is running this
  // is the stop control. The run lives on the task view, but the operator may
  // still be sitting on this page, and "I can't stop it from here" is exactly
  // the complaint this addresses.
  if (state.busy) {
    control("abort");
    return;
  }
  const task = landingInput.value;
  if (!task.trim()) return;
  startMission(task).then(() => { landingInput.value = ""; });
}
/**
 * Whether this keystroke should send, under the configured key binding.
 *
 * One helper for both input boxes, reading one setting: the landing page and
 * the composer must not disagree about what Enter does, and a second copy of
 * this rule is exactly how they would drift apart.
 *
 * Shift+Enter always inserts a newline, in both modes — it is the one escape
 * hatch that has to work no matter which binding is configured, otherwise a
 * send-on-Enter user has no way to write a multi-line task at all.
 */
function isSendKey(e) {
  if (e.key !== "Enter") return false;
  if (e.shiftKey) return false;
  const mode = state.sendOnEnter === "ctrl_enter" ? "ctrl_enter" : "enter";
  return mode === "enter" ? true : (e.ctrlKey || e.metaKey);
}

/**
 * Say which key sends, in the input's own placeholder hint.
 *
 * Without this the binding is invisible: a user who pressed Enter and got a
 * newline would have no way to learn that Ctrl+Enter sends, short of finding
 * the setting. The placeholder is the only text the input already carries.
 */
function applySendHint() {
  const hint = state.sendOnEnter === "ctrl_enter" ? "Ctrl+Enter 发送" : "Enter 发送";
  for (const id of ["task-input", "landing-input"]) {
    const el = $(id);
    if (el) el.title = `${hint}，Shift+Enter 换行`;
  }
  const note = $("send-hint");
  if (note) note.textContent = `${hint}，Shift+Enter 换行`;
}

landingInput.addEventListener("keydown", (e) => {
  if (!isSendKey(e)) return;
  e.preventDefault();
  submitLanding();
});
landingRun.addEventListener("click", submitLanding);

/**
 * The workspace label.
 *
 * Held to a single line and elided. A workspace is a path, and a path that is
 * somehow wrong — the observed case was a picker whose output carried a page of
 * launcher logging — must not be able to take over the layout. The full value
 * stays reachable through the title, so nothing is hidden, only bounded.
 */
function updateWorkspaceUI() {
  const el = $("ws-text");
  if (!el) return;
  const ws = (state.workspace || "").trim();
  el.textContent = ws ? `工作空间：${ws}` : "选择工作空间";
  el.title = ws || "";
  el.classList.toggle("ellipsis", !!ws);
}

/* ── Workspace picker ────────────────────────────────────────────────
 *
 * WorkBuddy-style: a searchable list of the folders the operator has already
 * run in — harvested from the session history, so nothing new has to be
 * stored — plus a typed path and the OS folder dialog for a first visit.
 * Clicking a row selects it immediately; the typed row exists for the two
 * things a picker and history cannot do: paste a path and clear the choice.
 */
function wsBasename(path) {
  return String(path).replace(/[\\/]+$/, "").split(/[\\/]/).pop() || String(path);
}

/** Distinct folder workspaces, most recently used first. */
function knownWorkspaces() {
  const seen = new Map();
  for (const s of state.sessions || []) {
    if (s.workspace_kind !== "folder" || !s.workspace) continue;
    const prev = seen.get(s.workspace) || 0;
    if ((s.updated || 0) >= prev) seen.set(s.workspace, s.updated || 0);
  }
  return [...seen.entries()].sort((a, b) => b[1] - a[1]).map(([p]) => p);
}

function renderWorkspaceList() {
  if (!wsList) return;
  const query = (wsSearch.value || "").trim().toLowerCase();
  const current = (state.workspace || "").trim();
  let paths = knownWorkspaces();
  // The live selection stays listed even before any session used it.
  if (current && !paths.includes(current)) paths = [current, ...paths];
  if (query) paths = paths.filter((p) => p.toLowerCase().includes(query));

  const rows = [];
  // Clearing is only meaningful when something is selected, and a search that
  // is narrowing the list should not trip over it.
  if (!query && current) {
    rows.push(`<button type="button" class="ws-row" data-ws-clear>
      <svg class="ws-row-folder" viewBox="0 0 24 24" aria-hidden="true"><line x1="5" y1="5" x2="19" y2="19"/><circle cx="12" cy="12" r="8"/></svg>
      <span class="ws-row-name">不限制工作区</span>
    </button>`);
  }
  rows.push(...paths.map((p) => `
    <button type="button" class="ws-row ${p === current ? "active" : ""}" data-ws-path="${escapeHtml(p)}" title="${escapeHtml(p)}">
      <svg class="ws-row-folder" viewBox="0 0 24 24" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
      <span class="ws-row-name">${escapeHtml(wsBasename(p))}</span>
      ${p === current ? '<span class="ws-row-tick">✓</span>' : ""}
    </button>`));
  wsList.innerHTML = rows.length ? rows.join("")
    : '<div class="ws-empty">没有匹配的工作空间</div>';

  wsList.querySelectorAll("[data-ws-path]").forEach((btn) => {
    btn.addEventListener("click", () => applyWorkspace(btn.dataset.wsPath));
  });
  const clear = wsList.querySelector("[data-ws-clear]");
  if (clear) clear.addEventListener("click", () => applyWorkspace(""));
}

function applyWorkspace(path) {
  state.workspace = (path || "").trim();
  wsInput.value = state.workspace;
  updateWorkspaceUI();
  closeWsPopover();
}

function openWsPopover() {
  wsPopover.classList.add("show");
  wsBtn.classList.add("active");
  renderWorkspaceList();
}
function closeWsPopover() {
  wsPopover.classList.remove("show");
  wsBtn.classList.remove("active");
}
wsBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  if (wsPopover.classList.contains("show")) closeWsPopover();
  else openWsPopover();
});
wsSearch.addEventListener("input", renderWorkspaceList);
wsApply.addEventListener("click", () => applyWorkspace(wsInput.value));
wsInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); applyWorkspace(wsInput.value); }
});
wsNew.addEventListener("click", (e) => {
  e.stopPropagation();
  wsCustom.classList.toggle("hidden");
  if (!wsCustom.classList.contains("hidden")) wsInput.focus();
});

/* Open the OS folder picker and take the answer straight away: WorkBuddy's
 * 「打开本地文件夹」 is a one-click path, and the picked directory is visible
 * in the list afterwards, so a mis-pick is one click to undo rather than an
 * applied state to clean up.
 *
 * `stopPropagation` because the popover closes on any document click.
 */
wsBrowse.addEventListener("click", async (e) => {
  e.stopPropagation();
  const label = wsBrowse.textContent;
  wsBrowse.disabled = true;
  wsBrowse.textContent = "选择中…";
  try {
    const res = await api("/api/pick-folder", {
      method: "POST",
      body: JSON.stringify({ title: "选择工作空间目录", initial: wsInput.value.trim() }),
    });
    if (res && res.path) {
      applyWorkspace(res.path);
    } else if (res && res.cancelled) {
      toast("已取消选择");
    }
  } catch (err) {
    toast(err.message || String(err), true);
  } finally {
    wsBrowse.disabled = false;
    wsBrowse.textContent = label;
  }
});

dashPermissionBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  dashPermissionPopover.classList.toggle("show");
  dashPermissionBtn.classList.toggle("active");
});
dashFullAccessToggle.addEventListener("change", () => {
  if (dashFullAccessToggle.checked && !state.fullAccess) {
    dashPermissionPopover.classList.remove("show");
    dashPermissionBtn.classList.remove("active");
    openPermissionModal();
  } else if (!dashFullAccessToggle.checked && state.fullAccess) {
    state.fullAccess = false;
    resetPermissionToggles();
    updatePermissionUI();
  }
});

landingModelBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  if (modelPopover.classList.contains("show")) closeModelPopover();
  else openModelPopover(landingModelBtn);
});

/* One click-away handler closes every open popover when the user clicks
   outside it and its anchor. */
document.addEventListener("click", (e) => {
  const t = e.target;
  if (permissionPopover.classList.contains("show") &&
      !permissionPopover.contains(t) && !permissionBtn.contains(t) &&
      !dashPermissionBtn.contains(t) && !dashPermissionPopover.contains(t)) {
    permissionPopover.classList.remove("show");
    permissionBtn.classList.remove("active");
  }
  if (modelPopover.classList.contains("show") &&
      !modelPopover.contains(t) && !modelBtn.contains(t) && !landingModelBtn.contains(t)) {
    closeModelPopover();
  }
  if (wsPopover.classList.contains("show") &&
      !wsPopover.contains(t) && !wsBtn.contains(t)) {
    closeWsPopover();
  }
  if (dashPermissionPopover.classList.contains("show") &&
      !dashPermissionPopover.contains(t) && !dashPermissionBtn.contains(t)) {
    dashPermissionPopover.classList.remove("show");
    dashPermissionBtn.classList.remove("active");
  }
  if ($("dash-steps-popover").classList.contains("show") &&
      !$("dash-steps-popover").contains(t) && !$("dash-steps-btn").contains(t)) {
    $("dash-steps-popover").classList.remove("show");
    $("dash-steps-btn").classList.remove("active");
  }
});

/* ── Approval modal ──────────────────────────────────────────────── */

function showApproval(ev) {
  state.pending = ev;
  const wantsText = ev.kind === "human_input";

  if (ev.kind === "shell") {
    $("approval-title").textContent = "危险命令需要确认";
    const parts = (ev.parts || []).map((p) => `· ${p.part}  —  ${p.why}`).join("\n");
    $("approval-body").textContent =
      `风险：${ev.risk || "未说明"}\n\n命令：\n${ev.command}\n\n分析：\n${parts || "(无)"}`;
  } else {
    $("approval-title").textContent = "代理需要协助";
    $("approval-body").textContent = ev.message || "";
  }

  // Only a control-capable user may answer. A viewer watching a mission sees
  // the prompt but cannot resolve it — the operator will.
  const canAnswer = state.caps.has("control");
  $("approval-input-wrap").classList.toggle("hidden", !wantsText);
  $("approval-approve").textContent = wantsText ? "提交" : "批准";
  $("approval-approve").disabled = !canAnswer;
  $("approval-deny").disabled = !canAnswer;
  $("approval").classList.remove("hidden");
  if (wantsText && canAnswer) $("approval-input").focus();
}

function hideApproval() {
  state.pending = null;
  $("approval").classList.add("hidden");
  $("approval-input").value = "";
}

/* ── Mission title ─────────────────────────────────────────────── */

/**
 * The title bar names the run in front of the operator. It is derived from the
 * task rather than typed by hand: a prompt() dialog that forgets its value on
 * cancel, and an editable field nothing persists, are both worse than a title
 * the system already knows. Renaming lives in the session bar, which has a
 * backend to save it to.
 */
function renderMissionTitle(task) {
  const title = $("mission-title");
  if (!title) return;
  const text = String(task || "").replace(/\s+/g, " ").trim();
  title.textContent = text.length > 60 ? text.slice(0, 60) + "…" : (text || "未命名任务");
}

/* ── Footer actions ────────────────────────────────────────────── */

/**
 * Wire one run's footer. Buttons are delegated by data-act rather than bound per
 * title, so trimming one does not silently orphan its handler.
 *
 * Only actions with something real behind them get a button: copy, read-aloud
 * (both pure browser APIs) and retry (re-runs the mission's own task text). The
 * reference design's thumbs-up / thumbs-down / "more" have no backend here — a
 * button that toasts "感谢反馈" without recording anything is worse than no
 * button, because it reads as feedback that was kept.
 */
function wireFooterActions(scope) {
  const footer = scope?.querySelector(".ai-footer");
  if (!footer) return;

  footer.addEventListener("click", async (e) => {
    const btn = e.target.closest(".footer-btn");
    if (!btn) return;
    const conclusion = scope.querySelector(".ai-conclusion")?.textContent.trim() || "";

    switch (btn.dataset.act) {
      case "copy": {
        if (!conclusion) return toast("没有可复制的结论", true);
        try {
          await navigator.clipboard.writeText(conclusion);
          toast("结论已复制");
        } catch {
          // Clipboard needs a secure context; plain http on a LAN host is not
          // one, and an unhandled rejection here would be invisible.
          toast("复制失败：浏览器拒绝了剪贴板访问", true);
        }
        break;
      }
      case "speak": {
        if (!conclusion) return toast("没有可朗读的结论", true);
        if (!("speechSynthesis" in window)) return toast("当前浏览器不支持朗读", true);
        speechSynthesis.cancel();          // a second click should not stack
        const u = new SpeechSynthesisUtterance(conclusion);
        u.lang = "zh-CN";
        speechSynthesis.speak(u);
        break;
      }
      case "retry": {
        // The task that produced this run, not whatever the composer holds now.
        const task = state.currentTask;
        if (!task) return toast("没有可重试的任务", true);
        await startMission(task);
        break;
      }
    }
  });
}

$("approval-approve").addEventListener("click", async () => {
  const wantsText = state.pending && state.pending.kind === "human_input";
  const text = $("approval-input").value.trim();
  if (wantsText && !text) return toast("请输入内容", true);
  await control("answer", { approved: true, text: wantsText ? text : "" });
  hideApproval();
});

$("approval-deny").addEventListener("click", async () => {
  await control("answer", { approved: false });
  hideApproval();
});

/* ── Desktop preview ─────────────────────────────────────────────── */

let desktopBusy = false;
async function refreshDesktop() {
  if (desktopBusy) return;
  desktopBusy = true;
  const img = $("desktop-img");
  const overlay = $("desk-overlay");
  overlay.classList.remove("hidden");
  try {
    await loadInto(img, `/api/desktop.jpg?t=${Date.now()}`);
    overlay.classList.add("hidden");
    scheduleMarkerDraw();
  } catch {
    overlay.classList.remove("hidden");
    overlay.innerHTML = "<span>无法获取屏幕画面</span>";
  } finally {
    desktopBusy = false;
  }
}

function loadInto(img, url) {
  return new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = url;
  });
}

/* ── Agent workspace (screen partition) ────────────────────────────
 *
 * Primary mode is the whole desktop and costs nothing. Region mode splits the
 * display: the agent's rectangle is where perception looks and where clicks
 * land, and the operator keeps the rest. The full-screen preview on the left
 * shows that rectangle outlined; the panel on the right shows exactly what
 * the model sees, which is the part that is otherwise invisible and the part
 * that matters when the agent does something surprising.
 */

let workBusy = false;
let workInfo = null;

async function refreshWork() {
  if (workBusy) return;
  workBusy = true;
  const img = $("work-img");
  const overlay = $("work-overlay");
  overlay.classList.remove("hidden");
  try {
    await loadInto(img, `/api/desktop.jpg?scope=work&t=${Date.now()}`);
    overlay.classList.add("hidden");
  } catch {
    overlay.classList.remove("hidden");
    overlay.innerHTML = "<span>无法获取虚拟屏画面</span>";
  } finally {
    workBusy = false;
  }
}

/** Repaint the workspace outline over the full-screen preview.
 *
 * Three things are easy to get wrong here, and each produces a silently
 * misplaced outline rather than an error:
 *
 *  - the *scale* is measured against the screen width the server reported,
 *    not against the image's naturalWidth. The preview endpoint downscales to
 *    fit (max edge 1280), so a 2880-wide screen arrives as a 1280-wide file;
 *    dividing by naturalWidth would then treat the whole picture as one
 *    screen and draw the outline at roughly twice the right size.
 *  - the *origin* is the image's own offset inside .desktop-wrap, not the
 *    wrap's. The wrap is `place-items: center`, so a narrow preview sits
 *    centred with empty space either side, and anchoring at the wrap's
 *    top-left slides the outline off the picture entirely. offsetLeft/Top are
 *    used rather than a rect difference because the wrap scrolls.
 *  - a hidden view has no layout (clientWidth 0), so the draw is skipped and
 *    re-run on the next frame instead of committing zero-sized geometry.
 */
function drawWorkMarker() {
  const marker = $("desk-marker");
  const img = $("desktop-img");
  const screenW = workInfo && workInfo.screen && workInfo.screen.width;
  if (!workInfo || !workInfo.region || !screenW || !img.naturalWidth || !img.clientWidth) {
    marker.classList.add("hidden");
    return;
  }
  const r = workInfo.region;
  const sx = img.clientWidth / screenW;
  const sy = img.clientHeight / (workInfo.screen.height || screenW);
  /* offsetLeft/offsetTop are the image's position inside its positioned
     ancestor, and unlike getBoundingClientRect they are unaffected by
     scrolling inside .desktop-wrap. Measuring via the rect would fold the
     wrap's scrollTop into the offset and slide the outline off the picture the
     moment the preview is scrolled. */
  const offX = img.offsetLeft;
  const offY = img.offsetTop;
  const imgW = img.offsetWidth;
  const imgH = img.offsetHeight;

  // Clamp to the picture. A region flush against an edge rounds to a pixel
  // past it, and a dashed outline hanging over the edge reads as "the agent
  // can click off-screen" — the opposite of what the mouse executor's clamp
  // guarantees. The origin is rounded *before* the extent is derived from it:
  // rounding both independently lets round(x) + round(w) exceed the bound by a
  // pixel even when x + w never did.
  const left = Math.round(Math.max(0, Math.min(offX + r.x * sx, imgW - 1)));
  const top = Math.round(Math.max(0, Math.min(offY + r.y * sy, imgH - 1)));
  const width = Math.max(1, Math.min(Math.round(r.width * sx), offX + imgW - left));
  const height = Math.max(1, Math.min(Math.round(r.height * sy), offY + imgH - top));

  marker.classList.remove("hidden");
  marker.style.left = `${left}px`;
  marker.style.top = `${top}px`;
  marker.style.width = `${width}px`;
  marker.style.height = `${height}px`;
}

/** Redraw the outline once the preview has been laid out.
 *
 * Two frames, not one: the first rAF can still run before the newly visible
 * view has been sized, and the image only gets a clientWidth after it has
 * painted at least once.
 */
function scheduleMarkerDraw() {
  requestAnimationFrame(() => requestAnimationFrame(drawWorkMarker));
}

function renderWork(info) {
  if (!info) return;
  workInfo = info;
  const regionMode = info.mode === "region" && info.region;

  $("work-primary").classList.toggle("active", !regionMode);
  $("work-region").classList.toggle("active", !!regionMode);
  // The region inputs are meaningless without a region, so they are hidden
  // rather than shown disabled — a disabled control invites the question of
  // why it cannot be edited.
  $("work-config").classList.toggle("hidden", !regionMode);
  $("work-col").classList.toggle("hidden", !regionMode);
  $("desk-full-wrap").classList.toggle("is-solo", !regionMode);
  $("work-split").classList.toggle("is-solo", !regionMode);
  // Shell activity is only interesting once the agent is fenced in: in
  // primary mode the operator can see the agent's screen directly, so the
  // panel would be noise.
  $("shell-panel").classList.toggle("hidden", !regionMode);
  if (regionMode) refreshShellActivity();

  if (regionMode) {
    const r = info.region;
    $("work-desc").textContent =
      `Agent 只在右侧 ${r.width}×${r.height} 的区域内工作，` +
      `左边 ${r.x} 像素留给你自己用。`;
    $("work-col-size").textContent = `${r.width}×${r.height}`;
    // Only overwrite an input the operator is not currently editing.
    for (const [id, value] of [["work-x", r.x], ["work-y", r.y],
                               ["work-w", r.width], ["work-h", r.height]]) {
      if (document.activeElement !== $(id)) $(id).value = value;
    }
  } else {
    $("work-desc").textContent = "Agent 在主屏幕的整块桌面工作。";
    $("work-col-size").textContent = "—";
  }
  drawWorkMarker();
}

/** Render the agent's recent host-side commands.
 *
 * The panel exists because of an uncomfortable asymmetry: the workspace stops
 * the agent from *clicking* on your half of the screen, but a shell command
 * has no coordinates at all and lands wherever it names. Being able to read
 * what ran is the honest mitigation — not a claim that nothing can happen.
 */
async function refreshShellActivity() {
  const res = await api("/api/shell-activity?limit=20").catch(() => null);
  if (!res) return;
  $("shell-cwd").textContent = res.backend ? res.backend.shell_cwd : "—";
  const list = $("shell-list");
  const rows = res.activity || [];
  list.innerHTML = rows.map((e) => {
    const rc = e.returncode === null ? "—" : e.returncode;
    // An async launch has no exit code by design, so it is not styled as a
    // failure — it simply has nothing to report yet.
    const cls = e.returncode === null ? "" : (e.ok ? "ok" : "bad");
    const when = new Date((e.ts || 0) * 1000).toLocaleTimeString("zh-CN", { hour12: false });
    return `<li class="${cls}"><span class="shell-rc">${escapeHtml(String(rc))}</span>` +
           `<span class="shell-cmd" title="${escapeHtml(e.command)}">${escapeHtml(e.command)}</span>` +
           `<span class="shell-when">${escapeHtml(when)}</span></li>`;
  }).join("");
}

async function loadWorkInfo() {
  const info = await api("/api/work-mode").catch(() => null);
  if (info) renderWork(info);
}

async function switchWork(mode) {
  const body = { mode };
  if (mode === "region") {
    body.x = Number($("work-x").value) || 0;
    body.y = Number($("work-y").value) || 0;
    body.width = Number($("work-w").value) || 0;
    body.height = Number($("work-h").value) || 0;
  }
  const res = await api("/api/work-mode", { method: "POST", body: JSON.stringify(body) })
    .catch((e) => ({ error: String(e && e.message || e) }));
  if (res && res.error) {
    toast(res.error);
    // Re-read rather than assuming: a 409 means the server kept the old mode.
    await loadWorkInfo();
    return;
  }
  renderWork(res);
  refreshDesktop();
  if (res && res.mode === "region") {
    refreshWork();
    refreshShellActivity();
  }}

$("work-primary").addEventListener("click", () => switchWork("primary"));
$("work-region").addEventListener("click", () => switchWork("region"));
$("work-apply").addEventListener("click", () => switchWork("region"));
$("work-half").addEventListener("click", async () => {
  // The common case by far: park the agent on the right, keep the left free.
  const screen = await api("/api/screen").catch(() => null);
  const w = screen ? screen.width : 0;
  const h = screen ? screen.height : 0;
  if (!w || !h) return;
  $("work-x").value = Math.floor(w / 2);
  $("work-y").value = 0;
  $("work-w").value = w - Math.floor(w / 2);
  $("work-h").value = h;
  switchWork("region");
});

$("desktop-img").addEventListener("click", async (e) => {
  const screen = await api("/api/screen").catch(() => null);
  const rect = e.target.getBoundingClientRect();
  const x = Math.round(((e.clientX - rect.left) / rect.width) * (screen ? screen.width : 0));
  const y = Math.round(((e.clientY - rect.top) / rect.height) * (screen ? screen.height : 0));
  $("desktop-coord").textContent =
    `X:${x} Y:${y} （屏幕 ${screen ? screen.width : "?"}×${screen ? screen.height : "?"}）`;
  // A partitioned workspace makes the distinction matter: a point inside the
  // agent's rectangle is a coordinate the model can actually use, one outside
  // it is not. Labelling them identically would invite the operator to hand
  // the agent a point it will never click.
  if (screen && screen.work && screen.work.region) {
    const r = screen.work.region;
    const inside = x >= r.x && x < r.x + r.width && y >= r.y && y < r.y + r.height;
    $("desktop-coord").textContent += inside
      ? `　—　在虚拟屏内，Agent 可点击（虚拟屏内坐标 ${x - r.x},${y - r.y}）`
      : `　—　在虚拟屏外，Agent 不会点击这里`;
  }
});

$("desk-refresh").addEventListener("click", () => {
  refreshDesktop();
  if (workInfo && workInfo.mode === "region") {
    refreshWork();
    refreshShellActivity();
  }
});
$("shell-refresh").addEventListener("click", refreshShellActivity);

// The outline is positioned in CSS pixels over a scaled image, so any change
// to the preview's box invalidates it — a window resize, a sidebar collapse,
// the device panel opening. Resizing fires in bursts, so recompute on the
// trailing edge instead of every event.
let markerResizeTimer = null;
window.addEventListener("resize", () => {
  if (!workInfo || !workInfo.region) return;
  clearTimeout(markerResizeTimer);
  markerResizeTimer = setTimeout(drawWorkMarker, 150);
});

/* ── Perception + tools ──────────────────────────────────────────── */

async function refreshUpstream() {
  const [status, tools] = await Promise.all([
    api("/api/status"),
    api("/api/tools").catch(() => null),
  ]);
  state.perception = status.perception || {};

  const cards = [
    ["OCR", "读取屏幕文本。廉价、离线，日常首选。", {
      "引擎": state.perception.ocr_engine, "就绪": state.perception.ocr_ready,
    }],
    ["YOLO", "定位按钮、图标、窗口等元素，给出包围盒。", {
      "模式": state.perception.yolo_mode, "权重": state.perception.yolo_weights,
    }],
    ["VLM", "深度视觉理解。慢且贵，仅在前两者不够时用。", {
      "视觉模式": state.perception.vision_mode,
    }],
  ];

  $("perception").innerHTML = cards.map(([name, desc, rows]) => `
    <div class="card">
      <h4>${name}</h4><p>${desc}</p>
      <dl>${Object.entries(rows).map(([k, v]) => `<dt>${escapeHtml(k)}</dt><dd>${escapeHtml(v ?? "—")}</dd>`).join("")}</dl>
    </div>`).join("");

  if (!tools) return;
  const cats = Object.entries(tools.categories || {}).map(([name, info]) => `
    <div class="cat">
      <h4>${escapeHtml(name)} <span class="muted">(${info.tool_count})</span></h4>
      <p class="muted">${escapeHtml(info.description || "")}</p>
      <ul>${(info.tools || []).map((t) => `<li>${escapeHtml(t)}</li>`).join("")}</ul>
    </div>`).join("");
  $("toolbox").innerHTML =
    `<div class="cat"><h4>元工具</h4><ul>${(tools.meta || []).map((m) => `<li>${escapeHtml(m)}</li>`).join("")}</ul></div>${cats}`;
}

/* ── Token usage ────────────────────────────────────────────────────
 *
 * Only the four models with an exact tokenizer get numbers. Everything here
 * reads `state.tokens.supported` before rendering anything: showing "0" for a
 * model we cannot measure would be a lie dressed as a measurement, and the
 * whole point of the feature is that the figure can be trusted.
 *
 * Two sources are reported and labelled separately, because they are not the
 * same claim:
 *   upstream  — the endpoint's own usage block (what the bill uses)
 *   tokenizer — counted here against the same prompt the model received
 *   prefix    — cache hit matched against this conversation's recent prompts
 */

/** Compact token count: 1234 -> "1.2K", 1500000 -> "1.5M". */
function fmtTokens(n) {
  const v = Number(n || 0);
  if (!isFinite(v)) return "—";
  if (v < 1000) return String(v);
  if (v < 1000000) {
    const k = v / 1000;
    // One decimal below 100K ("12.3K"), none above ("123K"): the extra digit
    // is noise once the number is large.
    return (k < 100 ? k.toFixed(1) : Math.round(k)) + "K";
  }
  const m = v / 1000000;
  return (m < 100 ? m.toFixed(2) : m.toFixed(1)) + "M";
}

/** Exact count with thousands separators, for tables. */
function fmtTokensExact(n) {
  const v = Number(n || 0);
  if (!isFinite(v)) return "—";
  return v.toLocaleString("en-US");
}

function fmtSeconds(v) {
  const s = Number(v || 0);
  if (!isFinite(s) || s <= 0) return "—";
  return s < 10 ? s.toFixed(1) + "s" : Math.round(s) + "s";
}

function fmtWhen(ts) {
  const n = Number(ts || 0);
  if (!n) return "—";
  const d = new Date(n * 1000);
  const pad = (x) => String(x).padStart(2, "0");
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const SOURCE_LABEL = {
  upstream: "上游",
  tokenizer: "本地分词器",
  prefix: "前缀匹配",
  none: "—",
};

/**
 * Adopt whether the active model can be measured.
 *
 * Called from enterConsole and from every model switch, because the counter
 * has to appear and disappear as the operator picks a different model — this
 * is a property of the model, not of the session.
 */
function adoptTokenSupport(payload) {
  const info = payload || {};
  const before = !!state.tokens.supported;
  state.tokens = {
    available: info.available !== false,
    supported: !!info.supported,
    modelKey: info.model_key || "",
    label: info.label || "",
    models: info.models || [],
  };
  syncTokenMeter();
  // The statistics page states which models it can cover, so it has to be
  // repainted when that set changes under it.
  if (before !== state.tokens.supported && state.currentView === "tokens") {
    refreshTokens().catch(() => {});
  }
}

/** Show or hide the composer's counter, and set its caption. */
function syncTokenMeter() {
  const el = $("token-meter");
  if (!el) return;
  const supported = state.tokens.supported && state.tokens.available;
  el.classList.toggle("hidden", !supported);
  if (!supported) return;
  paintTokenMeter();
}

/** Paint the current session total into the composer counter. */
function paintTokenMeter() {
  const el = $("token-meter-text");
  if (!el) return;
  const t = state.tokens.session || {};
  const total = Number(t.total_tokens || 0);
  el.textContent = fmtTokens(total);
  const meter = $("token-meter");
  if (meter) {
    // The full breakdown lives in the tooltip: the composer has room for one
    // number, and the split is what the statistics page is for.
    meter.title =
      `本会话累计 ${fmtTokensExact(total)} tokens\n` +
      `输入 ${fmtTokensExact(t.input_tokens)}（其中缓存输入 ${fmtTokensExact(t.cached_tokens)}）\n` +
      `输出 ${fmtTokensExact(t.output_tokens)}\n` +
      `${state.tokens.label || "当前模型"} · 点击查看统计`;
    meter.classList.toggle("warming", Number(t.requests || 0) === 0);
  }
}

/** Adopt a token_usage event's session total (arrives once per round-trip). */
function adoptTokenUsage(ev) {
  if (!state.tokens.supported) return;
  if (ev.session_total) {
    state.tokens.session = ev.session_total;
    paintTokenMeter();
  }
}

/** Load the mounted session's totals for the counter. */
async function refreshTokenMeter() {
  if (!state.tokens.supported || !state.tokens.available) return;
  const sid = state.sessionId;
  if (!sid) {
    state.tokens.session = null;
    paintTokenMeter();
    return;
  }
  const payload = await api(`/api/tokens/session?session=${encodeURIComponent(sid)}`)
    .catch(() => null);
  if (!payload) return;
  state.tokens.session = payload.totals || null;
  paintTokenMeter();
}

/** The statistics page. */
async function refreshTokens() {
  const payload = await api("/api/tokens/stats").catch((err) => {
    toast(err.message, true);
    return null;
  });
  if (!payload) return;

  $("tokens-unavailable").classList.toggle("hidden", payload.available !== false);
  if (payload.available === false) {
    $("tokens-unavailable-reason").textContent =
      payload.reason || "内置 token 计算器不可用。";
  }

  const models = payload.models || [];
  const labels = models.map((m) => m.label || m.key).join("、");
  $("tokens-sub").textContent = payload.available === false
    ? "内置 token 计算器不可用。"
    : `按会话与模型统计输入 / 缓存输入 / 输出 Token。支持：${labels}；`
      + `缓存按前缀匹配，${Math.round((payload.cache_window_seconds || 600) / 60)} 分钟内有效。`;

  const totals = payload.totals || {};
  const requests = Number(totals.requests || 0);
  const cacheRate = totals.input_tokens
    ? Math.round((Number(totals.cached_tokens || 0) / Number(totals.input_tokens)) * 100)
    : 0;
  $("tokens-kpi").innerHTML = [
    ["请求数", fmtTokensExact(requests), `${fmtTokensExact(totals.unsupported_requests || 0)} 次未测量`],
    ["输入", fmtTokensExact(totals.input_tokens),
     `其中缓存 ${fmtTokensExact(totals.cached_tokens)}（${cacheRate}%）`],
    ["输出", fmtTokensExact(totals.output_tokens), ""],
    ["合计", fmtTokensExact(totals.total_tokens), requests ? `${fmtTokens(requests)} 次往返` : ""],
  ].map(([label, value, sub]) => `
    <div class="kpi">
      <span class="kpi-label">${escapeHtml(label)}</span>
      <span class="kpi-value">${escapeHtml(value)}</span>
      ${sub ? `<span class="kpi-sub">${escapeHtml(sub)}</span>` : ""}
    </div>`).join("");

  $("tokens-model-body").innerHTML = (payload.by_model || []).length
    ? payload.by_model.map((row) => {
        const pct = row.input_tokens
          ? Math.round((row.cached_tokens / row.input_tokens) * 100) : 0;
        return `<tr>
          <td>${escapeHtml(row.label || row.model_key)}</td>
          <td class="num">${fmtTokensExact(row.requests)}</td>
          <td class="num">${fmtTokensExact(row.input_tokens)}</td>
          <td class="num">${cacheShareHtml(row.cached_tokens, row.input_tokens, pct)}</td>
          <td class="num">${fmtTokensExact(row.output_tokens)}</td>
          <td class="num">${fmtTokensExact(row.total_tokens)}</td>
        </tr>`;
      }).join("")
    : `<tr><td colspan="6" class="muted">还没有可统计的请求。</td></tr>`;

  const sessions = payload.sessions || [];
  $("tokens-session-body").innerHTML = sessions.length
    ? sessions.map((row) => {
        const pct = row.input_tokens
          ? Math.round((row.cached_tokens / row.input_tokens) * 100) : 0;
        const title = row.title || row.session_id || "（未命名）";
        return `<tr>
          <td title="${escapeHtml(row.session_id || "")}">${escapeHtml(title)}</td>
          <td>${escapeHtml(row.model || "—")}</td>
          <td class="num">${fmtTokensExact(row.requests)}</td>
          <td class="num">${fmtTokensExact(row.input_tokens)}</td>
          <td class="num">${cacheShareHtml(row.cached_tokens, row.input_tokens, pct)}</td>
          <td class="num">${fmtTokensExact(row.output_tokens)}</td>
          <td class="num">${fmtTokensExact(row.total_tokens)}</td>
          <td>${escapeHtml(fmtWhen(row.last_at))}</td>
        </tr>`;
      }).join("")
    : `<tr><td colspan="8" class="muted">还没有记录。运行一个任务后这里会出现统计。</td></tr>`;

  await paintTokenDetail();
}

function cacheShareHtml(cached, total, pct) {
  if (!total) return `<span class="muted">—</span>`;
  return `<span class="cache-share">
    <span>${fmtTokensExact(cached)}</span>
    <span class="cache-bar"><i style="width:${Math.max(0, Math.min(100, pct))}%"></i></span>
    <span class="cache-pct">${pct}%</span>
  </span>`;
}

/** The per-request detail for whichever session is mounted. */
async function paintTokenDetail() {
  const host = $("tokens-detail-body");
  const hint = $("tokens-detail-hint");
  if (!host) return;
  const sid = state.sessionId;
  if (!sid) {
    hint.textContent = "当前没有挂载会话。";
    host.innerHTML = `<tr><td colspan="7" class="muted">先打开或新建一个会话。</td></tr>`;
    return;
  }
  const payload = await api(`/api/tokens/session?session=${encodeURIComponent(sid)}`)
    .catch(() => null);
  if (!payload) return;
  const current = currentSessionSummary();
  hint.textContent = `会话「${current ? current.title : sid}」的每次模型往返。`;
  const records = payload.records || [];
  host.innerHTML = records.length
    ? records.map((r) => `<tr>
        <td>${escapeHtml(fmtWhen(r.ts))}</td>
        <td class="num">${escapeHtml(String(r.step || "—"))}</td>
        <td class="num">${fmtTokensExact(r.input_tokens)}</td>
        <td class="num">${r.cached_tokens ? fmtTokensExact(r.cached_tokens) : '<span class="muted">0</span>'}</td>
        <td class="num">${fmtTokensExact(r.output_tokens)}</td>
        <td class="token-cell">
          <span class="src-tag ${r.input_source === "upstream" ? "upstream" : ""}">输入·${escapeHtml(SOURCE_LABEL[r.input_source] || r.input_source || "—")}</span>
          ${r.cached_tokens ? `<span class="src-tag">缓存·${escapeHtml(SOURCE_LABEL[r.cache_source] || r.cache_source || "—")}</span>` : ""}
          <span class="src-tag">输出·${escapeHtml(SOURCE_LABEL[r.output_source] || r.output_source || "—")}</span>
        </td>
        <td class="num">${escapeHtml(fmtSeconds(r.seconds))}</td>
      </tr>`).join("")
    : `<tr><td colspan="7" class="muted">这个会话还没有记录。</td></tr>`;
}

$("tokens-reload")?.addEventListener("click", () => {
  refreshTokens().catch((err) => toast(err.message, true));
});

$("tokens-clear")?.addEventListener("click", async () => {
  if (!window.confirm("清空全部 Token 统计？此操作不可撤销。")) return;
  try {
    await api("/api/tokens/clear", { method: "POST" });
    toast("已清空 Token 统计");
    state.tokens.session = null;
    paintTokenMeter();
    await refreshTokens();
  } catch (err) {
    toast(err.message, true);
  }
});

// Clicking the counter is the obvious way for someone who just noticed it to
// ask "where does that number come from" — send them to the page that says.
$("token-meter")?.addEventListener("click", () => {
  document.querySelector('.nav-item[data-view="tokens"]')?.click();
});

/* ── Settings ─────────────────────────────────────────────────────── */

/**
 * Which pane a setting lands in, decided from its key rather than from a
 * hand-maintained list of key names. A setting added to SETTING_SPECS later
 * sorts itself into a pane instead of silently landing nowhere.
 */
function paneForField(field) {
  const key = field.key;
  if (key.startsWith("LLM_")) return "api";
  if (key === "VISION_MODE" || key.startsWith("VLM_")) return "vlm";
  if (key.startsWith("OCR_")) return "ocr";
  if (key.startsWith("YOLO_")) return "yolo";
  if (key.startsWith("SHELL_") || key.startsWith("HEADLESS_")
      || key.startsWith("APPROVAL_") || key.startsWith("SESSION_")
      || key.startsWith("AUTH_")) return "security";
  return "general";
}

/* Read-only lines under each perception pane, so the operator can see what is
   actually wired up before changing it. */
const PERCEPTION_ROWS = {
  vlm: [["视觉模式", "vision_mode"], ["链路", "vision_resolved"]],
  ocr: [["引擎", "ocr_engine"], ["就绪", "ocr_ready"]],
  yolo: [["模式", "yolo_mode"], ["权重", "yolo_weights"]],
};

async function refreshSettings() {
  // Every pane except 修改登录密码 reads /api/settings, which is admin-only.
  // For anyone else, showing those panes only earns a permission toast on
  // each visit, so they are hidden and the login pane is selected instead.
  const isAdmin = state.caps.has("admin");
  document.querySelectorAll(".settings-tab").forEach((tab) => {
    tab.classList.toggle("hidden", !isAdmin && tab.dataset.tab !== "login");
  });
  document.querySelectorAll(".settings-pane").forEach((pane) => {
    pane.classList.toggle("hidden", !isAdmin && pane.id !== "tab-login");
  });
  if (!isAdmin) {
    const loginTab = document.querySelector('.settings-tab[data-tab="login"]');
    if (loginTab && !loginTab.classList.contains("active")) loginTab.click();
    return;
  }

  // Re-read the identity before painting the controls that show it. The avatar
  // block reports whether an upload exists, and state.agent only carries that
  // from the last /api/hello — which may predate an upload made in this tab, or
  // in another one. Painting from a stale copy left the block claiming "内置
  // 图标" over a file that was really there.
  await refreshAgentIdentity();

  const payload = await api("/api/settings").catch((err) => {
    toast(err.message, true);
    return null;
  });
  if (!payload) return;

  const buckets = {};
  for (const fields of Object.values(payload.groups || {})) {
    for (const field of fields) {
      const pane = paneForField(field);
      (buckets[pane] = buckets[pane] || []).push(field);
    }
  }
  for (const [pane, fields] of Object.entries(buckets)) {
    const host = $(`body-${pane}`);
    if (!host) continue;
    host.innerHTML = fields.length
      ? fields.map(fieldHtml).join("")
      : '<span class="muted">这一页没有可配置的项目。</span>';
  }
  splitVisionModeFields(buckets.vlm || []);
  attachAvatarControls();

  const diag = payload.diagnostics || {};
  const missing = Object.entries(diag.dependencies || {})
    .filter(([, ok]) => !ok).map(([name]) => name);
  $("body-general")?.insertAdjacentHTML("beforeend", `
    <div class="field-row2">
      <span class="help">当前生效的链路</span>
      <pre class="code">${escapeHtml(diag.llm || "")}
缺失依赖：${escapeHtml(missing.join("、") || "无")}</pre>
    </div>`);

  const perception = {
    ...(diag.perception || {}),
    ...(state.hello ? { vision_resolved: state.hello.vision_resolved } : {}),
  };
  for (const [pane, rows] of Object.entries(PERCEPTION_ROWS)) {
    const host = $(`state-${pane}`);
    if (!host) continue;
    const filled = rows
      .filter(([, key]) => perception[key] !== undefined && perception[key] !== null)
      .map(([label, key]) =>
        `<dt>${escapeHtml(label)}</dt><dd>${escapeHtml(String(perception[key]))}</dd>`)
      .join("");
    host.innerHTML = filled || '<dt class="muted">暂无状态</dt>';
  }
}

/**
 * Separate the vision *mode* from the standalone-VLM fields under it.
 *
 * In multimodal mode the main model reads the screenshots itself and nothing
 * below applies, so those fields are folded into one block that collapses —
 * leaving them visible would invite configuring a backend that never runs.
 */
function splitVisionModeFields(fields) {
  const host = $("body-vlm");
  if (!host) return;

  const mode = fields.find((f) => f.key === "VISION_MODE");
  const rest = fields.filter((f) => f.key !== "VISION_MODE");
  if (!mode || !rest.length) return;

  host.innerHTML = `
    ${fieldHtml(mode)}
    <div class="sub-fields" id="vlm-sub">${rest.map(fieldHtml).join("")}</div>
    <p class="help" id="vlm-note"></p>`;
  syncVisionMode();
}

/**
 * Bold the avatar block onto the General pane.
 *
 * The URL text box is an ordinary setting and is rendered with the rest of the
 * fields; this adds what a text box cannot express — a file picker for a local
 * image, a preview of what is actually in force, and a way to take an upload
 * back. Rebuilt on every pane refresh, matching the fields around it.
 */
function attachAvatarControls() {
  const host = $("body-general");
  const urlField = $("set-AGENT_AVATAR");
  if (!host || !urlField) return;

  const row = urlField.closest(".field-row2");
  if (!row) return;

  row.insertAdjacentHTML("beforeend", `
    <div class="avatar-controls" id="avatar-controls">
      <div class="avatar-preview" id="avatar-preview"></div>
      <div class="avatar-buttons">
        <button type="button" class="btn-ghost" id="avatar-pick">上传本地图片…</button>
        <button type="button" class="btn-ghost" id="avatar-clear">移除上传的图片</button>
        <input type="file" id="avatar-file" accept="image/*" class="hidden" />
      </div>
      <span class="help" id="avatar-status"></span>
    </div>`);

  paintAvatarPreview();
}

/** Show what the reply header will actually use, given the two sources. */
function paintAvatarPreview() {
  const host = $("avatar-preview");
  if (!host) return;
  const typed = ($("set-AGENT_AVATAR")?.value || "").trim();
  // The upload's own URL, not the resolved one: while a typed URL is in force,
  // ``state.agent.avatar`` holds *that*, and reusing it here would label the
  // typed picture as "已上传的图片" the moment the box is emptied.
  const uploaded = state.agent.uploadedUrl;
  // The URL box wins when it holds something, which is exactly the precedence
  // the server applies — a preview that disagreed with the header would be
  // worse than no preview at all.
  const effective = typed || uploaded;
  const source = typed ? "图片地址" : uploaded ? "已上传的图片" : "内置图标";
  host.innerHTML =
    `<span class="avatar-frame">${avatarPreviewInner(effective)}</span>` +
    `<span class="avatar-src">预览 · ${escapeHtml(source)}</span>`;

  const clear = $("avatar-clear");
  if (clear) clear.disabled = !state.agent.uploaded;
}

function avatarPreviewInner(url) {
  const mark = `<span class="ai-avatar-mark">${AVATAR_SVG}</span>`;
  if (!url) return mark;
  return `<img class="ai-avatar-img" src="${escapeHtml(url)}" alt="" />` + mark;
}

/** Upload one file and adopt whatever the server resolves it to. */
async function uploadAvatar(file) {
  const status = $("avatar-status");
  if (!file) return;
  if (status) status.textContent = "上传中…";

  const body = new FormData();
  body.append("file", file);
  try {
    // Not routed through api(): that helper forces a JSON content type, and a
    // multipart body has to set its own boundary. The CSRF header is still
    // required, so it is attached by hand.
    const res = await fetch("/api/agent/avatar", {
      method: "POST",
      headers: state.csrf ? { "X-CSRF-Token": state.csrf } : {},
      body,
      credentials: "same-origin",
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);

    // Adopt immediately rather than waiting for the next /api/hello: the
    // preview and every reply header on screen update in this tick.
    state.agent.uploaded = true;
    adoptAgentIdentity({
      name: state.agent.name,
      avatar: data.url,
      uploaded_url: data.url,
      default_name: state.agent.defaultName,
      uploaded: true,
    });
    // The server cleared the stored URL — a leftover address would outrank the
    // picture just chosen. Mirror that here, or the box would still show an
    // address that is no longer in force.
    const urlInput = $("set-AGENT_AVATAR");
    if (urlInput) urlInput.value = "";
    if (status) status.textContent = "已上传，回复头像已更新";
    paintAvatarPreview();
  } catch (err) {
    if (status) status.textContent = "";
    toast(err.message, true);
  } finally {
    // Cleared so picking the same file twice still fires a change event.
    const input = $("avatar-file");
    if (input) input.value = "";
  }
}

async function clearAvatarUpload() {
  const status = $("avatar-status");
  try {
    const data = await api("/api/agent/avatar", { method: "DELETE" });
    state.agent.uploaded = false;
    adoptAgentIdentity({
      name: state.agent.name,
      avatar: data.url,
      uploaded_url: "",
      default_name: state.agent.defaultName,
      uploaded: false,
    });
    if (status) status.textContent = "已移除上传的图片";
    paintAvatarPreview();
  } catch (err) {
    toast(err.message, true);
  }
}

function syncVisionMode() {
  const select = $("set-VISION_MODE");
  const sub = $("vlm-sub");
  const note = $("vlm-note");
  if (!select || !sub) return;

  const multimodal = select.value === "multimodal";
  sub.classList.toggle("hidden", multimodal);
  // Disabled, not merely hidden: the pane's save button walks [data-key], and
  // a hidden field that is still posted would re-save a value the operator
  // cannot see.
  sub.querySelectorAll("input, select").forEach((el) => { el.disabled = multimodal; });

  if (note) {
    note.textContent = multimodal
      ? "主模型直接读取截图，下面的独立 VLM 不参与运行，已收起。"
      : "主模型不读图时由这里的独立 VLM 描述屏幕（auto 模式下按探测结果决定是否使用）。";
  }
}

// Delegated: the fields are re-rendered on every refresh, so the listener has
// to live on the container rather than on the select.
$("body-vlm").addEventListener("change", (e) => {
  if (e.target.id === "set-VISION_MODE") syncVisionMode();
});

function fieldHtml(field) {
  const id = `set-${field.key}`;
  const key = escapeHtml(field.key);
  const help = field.help ? `<span class="help">${escapeHtml(field.help)}</span>` : "";

  if (field.type === "bool") {
    return `<label class="bool-row" for="${id}">
      <span class="switch">
        <input type="checkbox" id="${id}" data-key="${key}" ${field.value ? "checked" : ""} />
        <span class="slider"></span>
      </span>
      <span class="bool-text"><b>${escapeHtml(field.label)}</b>${help}</span>
    </label>`;
  }
  if (field.type === "choice") {
    return `<div class="field-row2">
      <label for="${id}">${escapeHtml(field.label)}</label>
      <select id="${id}" data-key="${key}">${(field.choices || [])
        .map((c) => `<option value="${escapeHtml(c)}" ${c === String(field.value) ? "selected" : ""}>${escapeHtml(c)}</option>`).join("")}</select>
      ${help}
    </div>`;
  }
  const numeric = field.type === "int" || field.type === "float";
  if (field.type === "dir") {
    // A path the operator should not have to type: the OS folder picker is
    // both faster and the only reliable way to get a path with spaces,
    // non-ASCII characters or a network drive right. The text box stays
    // editable because the field also has to be *clearable* — an empty value
    // means "use the project root", and a picker alone cannot express that.
    return `<div class="field-row2">
    <label for="${id}">${escapeHtml(field.label)}</label>
    <div class="dir-picker">
      <input id="${id}" type="text" data-key="${key}" value="${escapeHtml(field.value ?? "")}"
             placeholder="${escapeHtml(field.placeholder || "")}" />
      <button type="button" class="btn-ghost" data-pick-dir="${key}"
              data-title="${escapeHtml(field.label)}">选择…</button>
    </div>
    ${help}
  </div>`;
  }
  const inputType = field.type === "secret" ? "password" : numeric ? "number" : "text";
  const step = field.type === "float" ? ' step="0.1"' : "";
  return `<div class="field-row2">
    <label for="${id}">${escapeHtml(field.label)}</label>
    <input id="${id}" type="${inputType}"${step} data-key="${key}" value="${escapeHtml(field.value ?? "")}" />
    ${help}
  </div>`;
}

/* Folder picker.
 *
 * Delegated on the document because the settings panes are re-rendered from
 * /api/settings on every visit, so a listener bound to a button element would
 * be lost the next time the pane is rebuilt.
 *
 * The dialog is a *blocking* native window, so the button stays disabled and
 * the label says so until the request returns — otherwise a second click
 * would open a second dialog with no way to tell which one answered.
 */
document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-pick-dir]");
  if (!btn) return;
  const key = btn.dataset.pickDir;
  const input = document.querySelector(`[data-key="${key}"]`);
  const label = btn.textContent;
  btn.disabled = true;
  btn.textContent = "选择中…";
  try {
    const res = await api("/api/pick-folder", {
      method: "POST",
      body: JSON.stringify({ title: btn.dataset.title || "选择文件夹",
                             initial: input ? input.value : "" }),
    });
    // A cancelled dialog returns an empty path; leaving the field untouched is
    // the only sane reading of "user changed their mind".
    if (res && res.path) {
      if (input) {
        input.value = res.path;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    } else if (res && res.cancelled) {
      toast("已取消选择");
    }
  } catch (err) {
    toast(err.message || String(err), true);
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
});

/* Avatar upload / removal.
 *
 * Delegated on the document for the same reason as the folder picker above:
 * the pane is rebuilt from /api/settings on every visit, so a listener bound
 * to the buttons would be gone by the next time they are clicked. */
document.addEventListener("click", (e) => {
  if (e.target.closest("#avatar-pick")) {
    $("avatar-file")?.click();
    return;
  }
  if (e.target.closest("#avatar-clear")) {
    clearAvatarUpload();
  }
});

document.addEventListener("change", (e) => {
  if (e.target.id === "avatar-file") uploadAvatar(e.target.files?.[0]);
});

// A typed URL changes what the preview should show; the server has the last
// word on whether it is usable, so the preview is only repainted, not saved.
document.addEventListener("input", (e) => {
  if (e.target.id === "set-AGENT_AVATAR") paintAvatarPreview();
});

/* Each pane saves only its own fields: editing the YOLO backend must not be
   able to rewrite the API key, including the masked placeholder for it. */document.querySelectorAll("[data-save]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const pane = btn.dataset.save;
    const body = {};
    document.querySelectorAll(`#tab-${pane} [data-key]`).forEach((el) => {
      // Fields the pane has switched off are left out entirely: posting them
      // would re-save values the operator can neither see nor edit.
      if (el.disabled || el.closest(".hidden")) return;
      body[el.dataset.key] = el.type === "checkbox" ? el.checked : el.value;
    });

    const label = btn.textContent;
    btn.disabled = true;
    btn.textContent = "保存中…";
    try {
      const res = await api("/api/settings", { method: "POST", body: JSON.stringify(body) });
      toast(`已保存 ${res.applied.length} 项到 config_override.json`);
      state.hello = null;
      // The name and avatar live in the reply header, not on this page, so
      // saving them has to reach back and repaint what is already rendered —
      // otherwise the change looks like it did not take until a reload.
      if (pane === "general" || "AGENT_NAME" in body || "AGENT_AVATAR" in body) {
        await refreshAgentIdentity();
      }
      await refreshSettings();
    } catch (err) {
      toast(err.message, true);
    } finally {
      btn.disabled = false;
      btn.textContent = label;
    }
  });
});

/** Re-read /api/hello for the agent identity and adopt it. */
async function refreshAgentIdentity() {
  const hello = await api("/api/hello").catch(() => null);
  if (hello) {
    state.hello = hello;
    adoptAgentIdentity(hello.agent);
  }
}

document.querySelectorAll(".settings-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".settings-tab").forEach((t) => t.classList.toggle("active", t === tab));
    document.querySelectorAll(".settings-pane").forEach((pane) => {
      pane.classList.toggle("active", pane.id === `tab-${tab.dataset.tab}`);
    });
  });
});

/* ── WebUI Login Setting ──────────────────────────────────────────── */

$("pw-save").addEventListener("click", async () => {
  clearError("pw-error");
  const current = $("pw-current").value;
  const next = $("pw-new").value;
  if (!current) return showError("pw-error", "请先填写当前密码");
  if (!next) return showError("pw-error", "请填写新密码");
  if (next !== $("pw-confirm").value) return showError("pw-error", "两次输入的新密码不一致");

  const btn = $("pw-save");
  btn.disabled = true;
  try {
    // The server drops every session for this user on success — including the
    // one making the call — so there is nothing left to refresh afterwards.
    await api("/api/auth/password", {
      method: "POST",
      body: JSON.stringify({ current_password: current, new_password: next }),
    });
    $("pw-current").value = "";
    $("pw-new").value = "";
    $("pw-confirm").value = "";
    showPasswordNotes("pw-new", false);
    localLogout("密码已更新，请用新密码登录");
  } catch (err) {
    showError("pw-error", err.message);
  } finally {
    btn.disabled = false;
  }
});

$("probe-llm").addEventListener("click", async () => {
  const btn = $("probe-llm");
  const out = $("probe-out-llm");
  btn.disabled = true;
  btn.textContent = "测试中…";
  out.textContent = "";
  try {
    const res = await api("/api/test", { method: "POST", body: JSON.stringify({ target: "llm" }) });
    $("caps-report").innerHTML = Object.values(res.results || {}).map(probeItemHtml).join("");
    out.textContent = res.message;
    out.className = res.ok ? "muted" : "warn-text";
  } catch (err) {
    out.textContent = err.message;
    out.className = "warn-text";
  } finally {
    btn.disabled = false;
    btn.textContent = "测试主模型能力";
  }
});

$("probe-vlm").addEventListener("click", async () => {
  const out = $("probe-out-vlm");
  out.textContent = "测试中…";
  try {
    const res = await api("/api/test", { method: "POST", body: JSON.stringify({ target: "vlm" }) });
    out.textContent = `${res.ok ? "✓" : "✗"} ${res.message}`;
    out.className = res.ok ? "muted" : "warn-text";
  } catch (err) {
    out.textContent = `✗ ${err.message}`;
    out.className = "warn-text";
  }
});

/* ── User administration ─────────────────────────────────────────── */

async function refreshUsers() {
  const [usersPayload, me] = await Promise.all([
    api("/api/users").catch((err) => { toast(err.message, true); return null; }),
    api("/api/auth/me").catch(() => null),
  ]);
  if (!usersPayload) return;

  $("users-body").innerHTML = usersPayload.users.map((u) => {
    const isMe = state.user && u.name === state.user.name;
    const status = u.disabled
      ? '<span class="status-chip off">已禁用</span>'
      : u.must_change
        ? '<span class="status-chip warn">待改密</span>'
        : '<span class="status-chip on">正常</span>';
    return `<tr class="${isMe ? "me" : ""}">
      <td><b>${escapeHtml(u.name)}</b>${isMe ? ' <span class="muted">(我)</span>' : ""}</td>
      <td><span class="role-chip ${escapeHtml(u.role)}">${escapeHtml(u.role_label)}</span></td>
      <td>${status}</td>
      <td class="mono">${escapeHtml(fmtDate(u.last_login))}</td>
      <td><div class="acts">
        <select data-role-for="${escapeHtml(u.name)}" ${u.role === "admin" ? "disabled" : ""}>
          ${usersPayload.roles.map((r) =>
            `<option value="${escapeHtml(r.value)}" ${r.value === u.role ? "selected" : ""}>${escapeHtml(r.label)}</option>`).join("")}
        </select>
        <button class="mini-btn" data-pw-for="${escapeHtml(u.name)}">改密</button>
        <button class="mini-btn" data-toggle-for="${escapeHtml(u.name)}" data-disabled="${u.disabled}">${u.disabled ? "启用" : "禁用"}</button>
        <button class="mini-btn danger" data-del-for="${escapeHtml(u.name)}" ${isMe ? "disabled title='不能删除自己'" : ""}>删除</button>
      </div></td>
    </tr>`;
  }).join("");

  const sessions = (me && me.sessions) || [];
  $("sessions-body").innerHTML = sessions.length ? sessions.map((s) => `
    <tr class="${s.current ? "me" : ""}">
      <td>${escapeHtml(s.user)}${s.current ? ' <span class="muted">(当前)</span>' : ""}</td>
      <td class="mono">${escapeHtml(s.ip || "—")}</td>
      <td class="mono ellipsis" style="max-width:220px" title="${escapeHtml(s.user_agent)}">${escapeHtml((s.user_agent || "—").slice(0, 60))}</td>
      <td class="mono">${escapeHtml(fmtDate(s.expires))}</td>
      <td><div class="acts">
        <button class="mini-btn danger" data-revoke-for="${escapeHtml(s.user)}">注销</button>
      </div></td>
    </tr>`).join("")
    : '<tr class="empty-row"><td colspan="5">暂无在线会话</td></tr>';

  wireUserActions();
}

function wireUserActions() {
  document.querySelectorAll("[data-role-for]").forEach((el) => {
    el.onchange = async () => {
      try {
        await api(`/api/users/${encodeURIComponent(el.dataset.roleFor)}/role`, {
          method: "POST", body: JSON.stringify({ role: el.value }),
        });
        toast(`已将 ${el.dataset.roleFor} 设为${CAP_LABEL[el.value] || el.value}`);
        refreshUsers();
      } catch (err) { toast(err.message, true); refreshUsers(); }
    };
  });

  document.querySelectorAll("[data-pw-for]").forEach((el) => {
    el.onclick = async () => {
      const name = el.dataset.pwFor;
      const password = prompt(`为 ${name} 设置新密码（至少 8 位）：`);
      if (!password) return;
      try {
        await api(`/api/users/${encodeURIComponent(name)}/password`, {
          method: "POST", body: JSON.stringify({ password, must_change: true }),
        });
        toast(`已重置 ${name} 的密码，其下次登录需修改`);
        refreshUsers();
      } catch (err) { toast(err.message, true); }
    };
  });

  document.querySelectorAll("[data-toggle-for]").forEach((el) => {
    el.onclick = async () => {
      const name = el.dataset.toggleFor;
      const disable = el.dataset.disabled !== "true";
      try {
        await api(`/api/users/${encodeURIComponent(name)}/disable`, {
          method: "POST", body: JSON.stringify({ disabled: disable }),
        });
        toast(`${disable ? "已禁用" : "已启用"} ${name}`);
        refreshUsers();
      } catch (err) { toast(err.message, true); }
    };
  });

  document.querySelectorAll("[data-del-for]").forEach((el) => {
    el.onclick = async () => {
      const name = el.dataset.delFor;
      if (!confirm(`确定删除用户 ${name}？此操作不可撤销。`)) return;
      try {
        await api(`/api/users/${encodeURIComponent(name)}`, { method: "DELETE" });
        toast(`已删除 ${name}`);
        refreshUsers();
      } catch (err) { toast(err.message, true); }
    };
  });

  document.querySelectorAll("[data-revoke-for]").forEach((el) => {
    el.onclick = async () => {
      try {
        const res = await api("/api/sessions/revoke", {
          method: "POST", body: JSON.stringify({ user: el.dataset.revokeFor }),
        });
        toast(`已注销 ${res.revoked} 个会话`);
        refreshUsers();
      } catch (err) { toast(err.message, true); }
    };
  });
}

$("user-create").addEventListener("submit", async (e) => {
  e.preventDefault();
  clearError("nu-error");
  try {
    await api("/api/users", {
      method: "POST",
      body: JSON.stringify({
        username: $("nu-username").value.trim(),
        password: $("nu-password").value,
        role: $("nu-role").value,
        must_change: true,
      }),
    });
    $("nu-username").value = "";
    $("nu-password").value = "";
    toast("用户已创建");
    refreshUsers();
  } catch (err) {
    showError("nu-error", err.message);
  }
});

$("users-reload").addEventListener("click", refreshUsers);

$("revoke-all").addEventListener("click", async () => {
  if (!confirm("注销全部会话？包括你自己的登录。")) return;
  try {
    const res = await api("/api/sessions/revoke", { method: "POST", body: JSON.stringify({}) });
    toast(`已注销 ${res.revoked} 个会话`);
    showGate("login");
  } catch (err) { toast(err.message, true); }
});

/* ── Audit log ───────────────────────────────────────────────────── */

async function refreshAudit() {
  const payload = await api("/api/audit?limit=300").catch((err) => {
    toast(err.message, true);
    return null;
  });
  if (!payload) return;

  $("audit-path").textContent = payload.path;
  $("audit-body").innerHTML = payload.entries.length ? payload.entries.map((e) => {
    const cls = e.outcome === "ok" ? "on" : e.outcome === "denied" ? "off" : "warn";
    return `<tr>
      <td class="mono">${escapeHtml(e.time)}</td>
      <td><b>${escapeHtml(e.actor)}</b></td>
      <td class="mono">${escapeHtml(e.action)}</td>
      <td><span class="status-chip ${cls}">${escapeHtml(e.outcome)}</span></td>
      <td class="ellipsis" style="max-width:320px" title="${escapeHtml(e.detail)}">${escapeHtml(e.detail || "—")}</td>
      <td class="mono">${escapeHtml(e.ip || "—")}</td>
    </tr>`;
  }).join("")
    : '<tr class="empty-row"><td colspan="6">暂无审计记录</td></tr>';
}

$("audit-reload").addEventListener("click", refreshAudit);

/* ── Polling ─────────────────────────────────────────────────────── */

async function refreshAll() {
  const status = await api("/api/status").catch(() => null);
  if (!status) return;
  state.desktopView = status.desktop_view !== false;
  if (status.busy !== state.busy) setBusy(status.busy);
  if (status.pending && !state.pending) showApproval(status.pending);
  state.perception = status.perception || {};
  if (status.actor) {
    $("st-actor").textContent = status.actor;
    $("st-actor-row").classList.remove("hidden");
  }
}

let pollTimers = [];

function startPolling() {
  // enterConsole() runs again after every login / password change; without
  // this the old intervals survive and each one keeps firing.
  pollTimers.forEach(clearInterval);
  pollTimers = [
    setInterval(() => {
      if (state.started) {
        $("st-elapsed").textContent = ((Date.now() - state.started) / 1000).toFixed(1) + "s";
      }
      $("st-steps").textContent = state.steps;
    }, 500),

    // The sidebar tree is always on screen, so a slow poll keeps newly
    // finished runs appearing under 任务 / 空间 without a manual reload.
    // Run boundaries also refresh it directly, so this is a safety net.
    setInterval(() => {
      if (document.hidden) return;
      refreshSessions();
    }, 15000),

    setInterval(() => {
      const auto = $("desk-auto").checked;
      const visible = $("view-desktop").classList.contains("active");
      if (!auto || !visible) return;
      refreshDesktop();
      // The workspace pane only exists in region mode; polling it otherwise
      // would spend a second capture per tick on a hidden element.
      if (workInfo && workInfo.mode === "region") {
        refreshWork();
        refreshShellActivity();
      }
    }, 1500),

    // The workspace is read on every status tick rather than only when the
    // desktop page is open: /api/status is already being polled, the mode can
    // be changed from the settings page, and a stale outline would misreport
    // where the agent is allowed to click.
    setInterval(() => {
      if (workInfo) loadWorkInfo();
    }, 5000),

    // A slow heartbeat doubles as a session-expiry check: if the session died
    // server-side, the next 401 drops us back to the login card.
    setInterval(() => { api("/api/status").catch(() => {}); }, 60000),
  ];
}

wireMeter("su-password", "su-meter", "su-hint");
wireMeter("ch-password", "ch-meter");
wireMeter("pw-new", "pw-meter");
wireRecoveryModal();
loadWallpaper();

$("btn-fullscreen").addEventListener("click", toggleFullscreen);

/* The two "附加文件或指令" buttons have no backend behind them yet. Say so
   rather than leaving them dead to a click, which reads as a broken panel. */
["landing-add", "composer-add"].forEach((id) => {
  $(id).addEventListener("click", () =>
    toast("附加文件尚未接入后端，暂时不可用"));
});

boot().catch((err) => {
  showGate("login", String(err.message || err));
});