"""Configuration for the Computer Use Agent.

Priority chain (highest first):

    environment variables  >  config_override.json  >  hardcoded defaults

Secrets never live in source: every credential is read from the environment
or the local override file, which is written only by the user (via the WebUI
settings page or by hand).
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path


def _resolve_root_dir() -> Path:
    """Locate the project root.

    Normal runs: ``<root>/cua/config.py`` -> one level up.
    Frozen runs (PyInstaller): everything is unpacked into ``sys._MEIPASS``.
    """
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent.parent


ROOT_DIR = _resolve_root_dir()
PROMPT_JSON_DIR = ROOT_DIR / "prompt-content-json"


def override_file_path() -> Path:
    """Path to ``config_override.json``.

    Frozen runs keep it next to the exe so users can find it; source runs
    keep it inside the package directory.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "config_override.json"
    return Path(__file__).resolve().with_name("config_override.json")


def ensure_stdio() -> None:
    """Make console output tolerant of non-UTF-8 Windows code pages.

    Without this, printing a character outside the active code page raises
    UnicodeEncodeError and aborts startup instead of merely degrading a glyph.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except Exception:
            pass


# ── Main reasoning model (any OpenAI-compatible endpoint) ───────────────
# The toolkit speaks the OpenAI chat-completions protocol, so ANY provider
# exposing /chat/completions works: DeepSeek, OpenAI, Moonshot, Zhipu,
# Qwen/DashScope, SiliconFlow, OpenRouter, Groq, vLLM, Ollama, LM Studio,
# one-api / new-api gateways, or a self-hosted proxy.
LLM_API_KEY = os.environ.get("CUA_LLM_API_KEY", "")
LLM_BASE_URL = os.environ.get("CUA_LLM_BASE_URL", "https://api.deepseek.com")
LLM_MODEL = os.environ.get("CUA_LLM_MODEL", "deepseek-chat")

#: Display name of the provider the endpoint belongs to ("OpenCode-Go").
#:
#: Kept as a stored setting rather than always derived so an operator can name
#: a private gateway; when left blank it is resolved from the Base URL by
#: provider_name(). Model lists are recorded per provider, so the Models shown
#: for OpenCode-Go do not follow the operator over to OpenRouter.
LLM_PROVIDER = os.environ.get("CUA_LLM_PROVIDER", "")

#: Every model the operator has configured, as a JSON list. The picker offers
#: these; the one matching LLM_MODEL is the active one.
LLM_MODELS = []

#: Parent directory for runs that were not given a workspace.#:
#: When a mission starts with no folder chosen, a timestamped child of this
#: directory becomes its run directory. Pointing every such run at the process
#: CWD instead would scatter its files through the project checkout.
#: Empty disables the behaviour: runs are then unrestricted, as before.
RUN_ROOT = os.environ.get("CUA_RUN_ROOT", "runs")

#: Which key sends a task from the composer / landing page.
#:
#:   "enter"       — Enter sends, Shift+Enter inserts a newline
#:   "ctrl_enter"  — Enter inserts a newline, Ctrl/Cmd+Enter sends
#:
#: Resolved from ``SEND_ON_ENTER`` so the two entry points cannot disagree,
#: and so the choice survives a reload instead of living in the browser only.
SEND_ON_ENTER = os.environ.get("CUA_SEND_ON_ENTER", "enter").strip().lower()

# ── Agent identity (name + avatar) ──────────────────────────────────────
#
# What the panel prints above every reply. Both are cosmetics, but they are
# stored server-side rather than in the browser: the operator configures them
# once and every browser (and every replay of an old transcript) shows the same
# assistant.
#
# ``AGENT_NAME`` empty means "use the built-in default name"; ``AGENT_AVATAR``
# holds an image URL, while an image *uploaded* from the panel lives beside
# ``config_override.json`` (see :func:`agent_avatar_file`). A valid explicit
# URL always outranks the upload, so the two can never both be in force and
# quietly disagree about which one the operator is looking at.
AGENT_NAME = os.environ.get("CUA_AGENT_NAME", "")
AGENT_AVATAR = os.environ.get("CUA_AGENT_AVATAR", "")

#: Shown when ``AGENT_NAME`` is blank. Defined here rather than only in the
#: front end so the settings page, the API and the rendered header cannot end
#: up offering three different "default" names.
AGENT_DEFAULT_NAME = "Agent"

#: Longest accepted display name. A name is a label, not a paragraph — the cap
#: keeps the reply header from stretching across the transcript.
AGENT_NAME_MAX = 40

#: Largest accepted avatar upload, in bytes. Generous for a square avatar, and
#: small enough that a mistaken full-resolution photo is refused before Pillow
#: is asked to decode it.
AVATAR_UPLOAD_MAX_BYTES = 2 * 1024 * 1024

#: Stored avatar file, always re-encoded to PNG at this size. Squared down at
#: save time rather than at render time, so a huge upload costs one small file
#: and the browser never downloads the original.
AVATAR_STORED_EDGE = 256


def agent_avatar_file() -> Path:
    """Path of the avatar uploaded from the panel.

    Kept next to ``config_override.json`` so a frozen build stores it beside
    the exe, the same way it stores the settings that point at it.
    """
    return override_file_path().with_name("agent_avatar.png")


def normalize_agent_avatar(value) -> str | None:
    """Validate an avatar URL; ``""`` = unset, ``None`` = not usable.

    Only ``http(s)`` and site-relative paths are accepted. The value ends up in
    an ``<img src>``, so anything else — a ``javascript:`` URL, a bare Windows
    path pasted from Explorer, a ``data:`` blob — is either unsafe or means
    "upload a file instead", and is rejected rather than rendered as a broken
    image.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    if text.lower().startswith(("http://", "https://")) or text.startswith("/"):
        return text
    return None


def agent_display_name() -> str:
    """The name shown above each reply (``""`` = built-in default)."""
    return str(globals().get("AGENT_NAME") or "").strip()


def agent_avatar_url() -> str:
    """The image the panel should render, or ``""`` for the built-in mark.

    A stored-but-unusable URL falls through to the upload rather than blanking
    the avatar: whatever is on disk is still the most recent thing the operator
    deliberately chose, and a typo in a text box should not be able to hide it.
    """
    configured = normalize_agent_avatar(globals().get("AGENT_AVATAR"))
    if configured:
        return configured
    return agent_uploaded_avatar_url()


def agent_uploaded_avatar_url() -> str:
    """URL of the uploaded file, mtime-versioned, or ``""`` when there is none.

    The version query is what makes a re-upload visible: the browser caches by
    URL, and without it the second picture would keep showing the first until
    someone cleared the cache.
    """
    path = agent_avatar_file()
    try:
        if path.is_file():
            return f"/api/agent/avatar?v={int(path.stat().st_mtime)}"
    except OSError:
        pass
    return ""


def run_root_path() -> Path:
    """Absolute parent directory for auto-created run folders.

    Relative values resolve against the project root rather than the process
    CWD, so the setting means the same thing no matter where the panel was
    launched from.
    """
    raw = str(globals().get("RUN_ROOT") or "").strip()
    if not raw:
        return Path()
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        candidate = ROOT_DIR / candidate
    return candidate


def make_run_dir(stamp: str | None = None) -> str:
    """Create and return a fresh run directory, or "" when disabled.

    The name is a timestamp, so a directory sorts chronologically and two runs
    in the same second still get distinct folders (a suffix is added rather
    than overwriting). Returns "" — never raises — when the parent cannot be
    created: a run must not fail to start because of a bookkeeping folder.
    """
    root = run_root_path()
    if str(root) in ("", "."):
        return ""
    name = stamp or time.strftime("%Y%m%d-%H%M%S")
    target = root / name
    suffix = 1
    try:
        root.mkdir(parents=True, exist_ok=True)
        while target.exists():
            suffix += 1
            target = root / f"{name}-{suffix}"
        target.mkdir(parents=True, exist_ok=True)
    except OSError:
        return ""
    return str(target)

# Set when the endpoint needs no Authorization header (Ollama, LM Studio, ...).
LLM_API_KEY_OPTIONAL = os.environ.get(
    "CUA_LLM_API_KEY_OPTIONAL", ""
).strip().lower() in ("1", "true", "yes", "on")

# Request timeout for main-model calls, in seconds.
LLM_TIMEOUT = int(os.environ.get("CUA_LLM_TIMEOUT", "600") or 600)

# ── Model capability profile ────────────────────────────────────────────
# Controls which extra parameters are sent with a completion request.
#
#   "auto"      — infer from the model id (recommended)
#   "thinking"  — always send reasoning_effort + thinking payload
#   "vision"    — always allow image_url parts
#   "plain"     — send nothing beyond model/messages/tools
#
# The reference implementation hardcoded `reasoning_effort` and
# `extra_body={"thinking": {"type": "enabled"}}` unconditionally, which made
# every non-thinking provider fail outright. Here the profile is resolved per
# model and can be overridden explicitly.
LLM_CAPABILITY = os.environ.get("CUA_LLM_CAPABILITY", "auto")

# Reasoning effort used for thinking models: low | medium | high | max.
REASONING_EFFORT = os.environ.get("CUA_REASONING_EFFORT", "high")

# Whether to send the ``extra_body={"thinking": ...}`` payload when supported.
LLM_ENABLE_THINKING = os.environ.get(
    "CUA_LLM_ENABLE_THINKING", ""
).strip().lower() in ("1", "true", "yes", "on")

_THINKING_MODEL_HINTS = (
    "deepseek-reasoner", "deepseek-r1", "r1", "o1", "o3", "o4",
    "qwq", "qvq", "glm-z1", "thinking", "reasoner",
)

_MULTIMODAL_MODEL_HINTS = (
    "gpt-4o", "gpt-4.1", "gpt-4.5", "gpt-5", "o1", "o3", "o4",
    "qwen-vl", "qwen2-vl", "qwen2.5-vl", "qwen3-vl", "qvq", "vl-max", "vl-plus",
    "glm-4v", "glm-4.1v", "glm-4.5v", "cogv",
    "kimi-vl", "moonshot-vl",
    "internvl", "minicpm-v", "llama-3.2-vision", "llava", "pixtral",
    "gemma-3", "phi-3.5-vision", "phi-4-multimodal",
    "deepseek-vl", "seed-vl", "claude-3", "claude-4",
)


def _matches(model: str, hints: tuple[str, ...]) -> bool:
    m = (model or "").strip().lower()
    return bool(m) and any(h in m for h in hints)


def supports_thinking() -> bool:
    """Whether the configured main model accepts thinking parameters."""
    raw = (LLM_CAPABILITY or "auto").strip().lower()
    if raw == "thinking":
        return True
    if raw == "plain":
        return False
    # "vision" likewise says nothing about reasoning support.

    probed = probed_capabilities()
    if "thinking" in probed:
        return probed["thinking"]

    if raw == "vision":
        return _matches(LLM_MODEL, _THINKING_MODEL_HINTS)

    return _matches(LLM_MODEL, _THINKING_MODEL_HINTS)


# The keyword tables below can only recognise models anyone thought to list, so
# a gateway serving an unfamiliar id was reported as vision-capable=False even
# though the wizard had just proved otherwise by sending it a real image. The
# measured result is persisted instead (see LLM_PROBED_*), because a
# measurement beats an absence of hints — and has to survive a restart.


def probed_capabilities(base_url: str = "", model: str = "") -> dict[str, bool]:
    """The measured capabilities for the active endpoint, if any were recorded.

    Read from the persisted flags rather than an in-memory map, so a restart
    does not fall back to guessing about a model the wizard already measured.
    """
    out: dict[str, bool] = {}
    if LLM_PROBED_VISION is not None:
        out["vision"] = bool(LLM_PROBED_VISION)
    if LLM_PROBED_THINKING is not None:
        out["thinking"] = bool(LLM_PROBED_THINKING)
    return out


def supports_vision_input() -> bool:
    """Whether the main model accepts image_url content parts.

    An explicit ``LLM_CAPABILITY`` still wins — the operator's stated intent
    outranks both the hint tables and a previous probe. Otherwise a recorded
    probe decides, and only if there is none do we fall back to guessing from
    the model id.
    """
    raw = (LLM_CAPABILITY or "auto").strip().lower()
    if raw == "vision":
        return True
    if raw == "plain":
        return False
    # "thinking" is deliberately NOT short-circuited to False. Reasoning and
    # vision are independent: big-pickle does both, and forcing
    # LLM_CAPABILITY=thinking (which the wizard sets when it measures a
    # reasoning trace) must not erase a measured vision capability.

    probed = probed_capabilities()
    if "vision" in probed:
        return probed["vision"]

    if raw == "thinking":
        # No measurement available: a thinking-only model is the best hint we
        # have, and vision is confirmed by the probe on the next setup run.
        return _matches(LLM_MODEL, _MULTIMODAL_MODEL_HINTS)

    return _matches(LLM_MODEL, _MULTIMODAL_MODEL_HINTS)


# ── Vision mode: how the agent "sees" the screen ────────────────────────
#   "auto"        — pick "multimodal" when the main model is vision-capable
#                   and no separate VLM is configured, else "text_vlm"
#   "text_vlm"    — text-only main model + a separate multimodal VLM endpoint
#   "multimodal"  — one multimodal model does both jobs (screenshots attached
#                   inline as image_url parts)
VISION_MODE = os.environ.get("CUA_VISION_MODE", "auto")

# Max long edge (px) for screenshots attached inline. 0 = no resize.
INLINE_IMAGE_MAX_EDGE = 1536

# JPEG quality for inline screenshots (1-95).
INLINE_IMAGE_QUALITY = 85


def _has_vlm_configured() -> bool:
    """Whether a separate multimodal backend is configured."""
    if not (VLM_API_KEY or VLM_AUTH_KEY):
        return False
    return bool((VLM_API_URL or "").strip())


def resolve_vision_mode() -> str:
    """Return the effective vision mode: ``"text_vlm"`` or ``"multimodal"``."""
    raw = (VISION_MODE or "").strip().lower()
    if raw in ("text_vlm", "vlm"):
        return "text_vlm"
    if raw in ("multimodal", "inline"):
        return "multimodal"
    if supports_vision_input() and not _has_vlm_configured():
        return "multimodal"
    return "text_vlm"


def is_multimodal_main_model() -> bool:
    """True when the main model itself looks at screenshots."""
    return resolve_vision_mode() == "multimodal"


def llm_api_key() -> str:
    """The key to send, or a placeholder when the endpoint needs none.

    The OpenAI SDK refuses to build a client without a key; local servers
    ignore the Authorization header, so a dummy value keeps the SDK happy.
    """
    key = (LLM_API_KEY or "").strip()
    if key:
        return key
    if LLM_API_KEY_OPTIONAL:
        return "local-no-key-required"
    return ""


def validate_llm_credentials() -> str | None:
    """Return a human-readable error when the LLM credentials are unusable."""
    if not LLM_API_KEY and not LLM_API_KEY_OPTIONAL:
        return (
            "No API key configured for the main model.\n"
            "  Set CUA_LLM_API_KEY, or fill in 'API Key' in the WebUI settings\n"
            "  page. Local servers (Ollama / LM Studio) can enable\n"
            "  'API key not required' instead.\n"
            f"  Current base URL: {LLM_BASE_URL}\n"
            f"  Current model:    {LLM_MODEL}"
        )
    return None


# ── Multimodal model (VLM) ──────────────────────────────────────────────
# Providers: openai_compatible | anthropic | gemini | legacy | auto
VLM_PROVIDER = os.environ.get("CUA_VLM_PROVIDER", "openai_compatible")
VLM_API_URL = os.environ.get("CUA_VLM_API_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")
VLM_API_KEY = os.environ.get("CUA_VLM_API_KEY", "")
VLM_MODEL = os.environ.get("CUA_VLM_MODEL", "qwen-vl-max-latest")
VLM_IMAGE_DETAIL = os.environ.get("CUA_VLM_IMAGE_DETAIL", "auto")
VLM_AUTH_KEY = os.environ.get("CUA_VLM_AUTH_KEY", "")

VLM_MAX_TOKENS = 2048
VLM_TEMPERATURE = 0.2
VLM_TIMEOUT = 120
VLM_MAX_IMAGE_EDGE = 1536
VLM_SYSTEM_PROMPT = ""
VLM_SSL_VERIFY = True

# ── YOLO object detection ───────────────────────────────────────────────
# Modes:
#   "bundled" — weights shipped inside the package / found in models/
#   "local"   — alias of bundled using YOLO_MODEL_PATH
#   "cloud"   — POST frames to a remote detection API
#   "off"     — disable object detection entirely (tool returns a clear error)
YOLO_INFERENCE_MODE = os.environ.get("CUA_YOLO_INFERENCE_MODE", "bundled")
YOLO_MODEL_PATH = os.environ.get("CUA_YOLO_MODEL", "")
YOLO_CLOUD_API_URL = os.environ.get("CUA_YOLO_CLOUD_URL", "")
YOLO_CLOUD_API_KEY = os.environ.get("CUA_YOLO_CLOUD_API_KEY", "")

# ── OCR ─────────────────────────────────────────────────────────────────
# Engines: "builtin" (PaddleOCR on CPU) | "http" (Umi-OCR service) | "off"
OCR_ENGINE = os.environ.get("CUA_OCR_ENGINE", "builtin")
OCR_URL = os.environ.get("CUA_OCR_URL", "http://127.0.0.1:35001/api/ocr")
OCR_TIMEOUT = int(os.environ.get("CUA_OCR_TIMEOUT", "30") or 30)

# Directory holding a self-consistent PaddleOCR stack. Needed when the
# interpreter's own site-packages carries a mismatched paddle/paddlex pair —
# see cua/ocr_engine.py::paddle_env_candidates for the full story. Leave empty
# to use the built-in search order.
OCR_PADDLE_ENV = os.environ.get("CUA_OCR_PADDLE_ENV", "")

# Hard deadline (seconds) for the *local* heavy perception engines. PaddleOCR
# init and the first YOLO load each cost tens of seconds on CPU and both can
# hang outright on a loaded machine — the engine loop runs tools inline, so a
# hang used to wedge the whole mission with the tool card stuck on 运行中.
# The deadline turns that into a slow first call followed by an error the
# model can plan around. The HTTP engine keeps using OCR_TIMEOUT.
OCR_LOCAL_TIMEOUT = int(os.environ.get("CUA_OCR_LOCAL_TIMEOUT", "180") or 180)
YOLO_LOCAL_TIMEOUT = int(os.environ.get("CUA_YOLO_LOCAL_TIMEOUT", "180") or 180)

# Pre-load the local OCR/YOLO engines on the perception worker at server
# start, so the first real mission never pays the model-load cost mid-step.
# Turn off with CUA_PERCEPTION_WARMUP=0 if startup RAM is tight.
PERCEPTION_WARMUP = os.environ.get(
    "CUA_PERCEPTION_WARMUP", "1"
).strip().lower() in ("1", "true", "yes", "on")

# ── Agent loop limits ───────────────────────────────────────────────────
# Maximum outer steps per mission. Each step completes one logical operation.
MAX_STEPS = int(os.environ.get("CUA_MAX_STEPS", "50") or 50)

# Whether the ceiling applies at all. With this off a mission runs until the
# model declares TASK_COMPLETE, the stuck detector trips, or the operator
# aborts — there is no other way out, so an agent that cannot finish its task
# will keep driving this machine's mouse and keyboard indefinitely.
MAX_STEPS_ENABLED = os.environ.get(
    "CUA_MAX_STEPS_ENABLED", "1"
).strip().lower() in ("1", "true", "yes", "on")

# Max tool-call rounds inside a single step. One logical operation should
# never need more than this.
MAX_INTERNAL_ROUNDS = int(os.environ.get("CUA_MAX_INTERNAL_ROUNDS", "50") or 50)

# Similarity threshold for the "three summaries in a row look identical"
# stuck detector.
STUCK_SIMILARITY = 0.8

# Watchdog thresholds (seconds) distinguishing "network stalled" from
# "a tool is just slow".
WATCHDOG_CHUNK_TIMEOUT = 10.0
WATCHDOG_TOOL_TIMEOUT = 30.0

# ── Safety ──────────────────────────────────────────────────────────────
# Second-stage LLM audit for shell commands. Static rules always run first.
SHELL_LLM_AUDIT = os.environ.get(
    "CUA_SHELL_LLM_AUDIT", "1"
).strip().lower() in ("1", "true", "yes", "on")

# What to do when the auditor cannot be reached — see cua/security_check.py.
#   "ask"   — put it to the operator (WebUI shows a confirmation card). Default.
#   "allow" — fall through to the static rules only (reference behaviour).
#   "deny"  — refuse execution until the endpoint is reachable again.
SHELL_AUDIT_FAILURE_POLICY = os.environ.get(
    "CUA_SHELL_AUDIT_FAILURE_POLICY", "ask"
).strip().lower()

# When the audit flags danger, ask for approval. In the WebUI the prompt is
# bridged to the browser; headless runs fall back to this policy:
#   "deny" — refuse (safest) | "allow" — proceed
HEADLESS_DANGER_POLICY = os.environ.get("CUA_HEADLESS_DANGER_POLICY", "deny").strip().lower()

# Seconds to wait for a human answer before applying HEADLESS_DANGER_POLICY.
APPROVAL_TIMEOUT = int(os.environ.get("CUA_APPROVAL_TIMEOUT", "300") or 300)

# Working directory for shell commands. Empty means the project root.
#
# This is a convenience, not a sandbox: it decides where a *relative* path
# lands, and nothing more. The command still runs as the operator with the
# operator's privileges, so an absolute path reaches anywhere it always could.
# The real defences against a confused model are the LLM audit in
# security_check.py and the human approval gate — see cua/backend.py.
SHELL_CWD = os.environ.get("CUA_SHELL_CWD", "").strip()

# ── Remote SSH (agent connector) ───────────────────────────────
# Credentials for the ``ssh-client`` connector (see cua/executors/connector.py).
#
# ssh-client refuses to write a password into its session file — deliberately:
# ``save_password`` defaults to False, so a saved host always reports
# ``has_password=false`` and a non-interactive call would otherwise fail with
# ``auth_failed`` every single time. These three values are the supported way to
# feed it without that plaintext-on-disk trade-off: the connector injects them
# into the MCP subprocess environment, and ssh-client reads them from
# ``SSH_CLIENT_PASSWORD`` / ``SSH_CLIENT_KEY`` / ``SSH_CLIENT_PASSPHRASE``.
#
# Stored as ordinary settings (the same ``secret`` handling the LLM and VLM API
# keys already use) so the operator can fill them in from the WebUI panel
# instead of editing the launch environment.
SSH_PASSWORD = os.environ.get("CUA_SSH_PASSWORD", "")
SSH_KEY_PATH = os.environ.get("CUA_SSH_KEY_PATH", "").strip()
SSH_PASSPHRASE = os.environ.get("CUA_SSH_PASSPHRASE", "")

#: Seconds one MCP request may take. Generous by design: ``ssh_probe`` and a
#: multi-host ``ssh_batch`` are legitimately slow, and the connector's own
#: per-command timeout is what actually bounds a hung remote.
SSH_CALL_TIMEOUT = float(os.environ.get("CUA_SSH_CALL_TIMEOUT", "180") or 180)


def ssh_env() -> dict[str, str]:
    """Environment overrides for the ssh-client MCP subprocess.

    Only variables that actually have a value are emitted. An empty
    ``SSH_CLIENT_PASSWORD`` in the environment is worse than an absent one:
    ssh-client resolves the secret and finds a blank string, which then fails
    authentication *with a misleading "wrong password"* instead of falling
    through to key-based auth.
    """
    out: dict[str, str] = {}
    for key, name in (
        (SSH_PASSWORD, "SSH_CLIENT_PASSWORD"),
        (SSH_KEY_PATH, "SSH_CLIENT_KEY"),
        (SSH_PASSPHRASE, "SSH_CLIENT_PASSPHRASE"),
    ):
        value = (key or "").strip()
        if value:
            out[name] = value
    return out


# ── Agent workspace (screen partition) ──────────────────────────────────
# Lets the agent run inside a rectangle of the screen instead of the whole
# desktop, so the operator can keep using the rest of the display (watching a
# video, working in another app) while a mission runs.
#
# This is deliberately NOT isolation. Nothing is sandboxed: the agent shares
# the same desktop heap, the same clipboard, the same foreground window and
# the same shell as the operator. What changes is only the *rectangle* that
# perception looks at and the mouse is allowed to travel in — so the agent's
# clicks cannot land on the half of the screen the operator is using.
#
# Coordinates are in virtual-screen pixels and must satisfy
#   x >= 0, y >= 0, x + width <= virtual_width, y + height <= virtual_height
# ``desktop.work_region()`` clamps rather than trusting these, because a stale
# value from a monitor change would otherwise put the agent off-screen.
WORK_MODE = os.environ.get("CUA_WORK_MODE", "primary").strip().lower()

WORK_REGION_X = int(os.environ.get("CUA_WORK_REGION_X", "0") or 0)
WORK_REGION_Y = int(os.environ.get("CUA_WORK_REGION_Y", "0") or 0)
WORK_REGION_WIDTH = int(os.environ.get("CUA_WORK_REGION_WIDTH", "0") or 0)
WORK_REGION_HEIGHT = int(os.environ.get("CUA_WORK_REGION_HEIGHT", "0") or 0)

# Whether the desktop page shows the partition boundary and a live view of the
# agent's rectangle. Purely a UI affordance — the workspace is active either
# way, this only decides how much of it the operator can see.
WORK_PREVIEW_ENABLED = os.environ.get(
    "CUA_WORK_PREVIEW_ENABLED", "1"
).strip().lower() in ("1", "true", "yes", "on")


def work_mode() -> str:
    """Effective workspace mode, normalised to 'primary' or 'region'."""
    return "region" if WORK_MODE.strip().lower() == "region" else "primary"


def set_work_mode(mode: str, region: tuple[int, int, int, int] | None = None) -> None:
    """Switch the workspace at runtime.

    A no-op in spirit but not in effect: the module globals are what every
    caller reads, so writing them is what makes the change take effect without
    a restart. ``region`` is ``(x, y, width, height)`` in virtual-screen
    pixels and is ignored when the mode is 'primary'.
    """
    global WORK_MODE, WORK_REGION_X, WORK_REGION_Y
    global WORK_REGION_WIDTH, WORK_REGION_HEIGHT

    WORK_MODE = "region" if str(mode).strip().lower() == "region" else "primary"
    if region is not None:
        try:
            x, y, w, h = (int(v) for v in region)
        except (TypeError, ValueError):
            return
        WORK_REGION_X = max(0, x)
        WORK_REGION_Y = max(0, y)
        WORK_REGION_WIDTH = max(0, w)
        WORK_REGION_HEIGHT = max(0, h)


def describe_work_mode() -> str:
    """One-line human summary of the active workspace."""
    if work_mode() == "primary":
        return "主屏幕（整块桌面）"
    x, y, w, h = WORK_REGION_X, WORK_REGION_Y, WORK_REGION_WIDTH, WORK_REGION_HEIGHT
    return f"虚拟屏（{w}×{h} @ {x},{y}）"


# ── Web control panel ───────────────────────────────────────────────────
WEB_HOST = os.environ.get("CUA_WEB_HOST", "127.0.0.1")
WEB_PORT = int(os.environ.get("CUA_WEB_PORT", "5000") or 5000)
WEB_PANEL_DESKTOP_VIEW = True

# ── Web panel authentication ──────────────────────────────────────────
# Access is granted per user account, never by a single shared password. On
# first run the panel shows a setup wizard and refuses every other endpoint
# until an administrator exists, closing the window in which an
# unauthenticated caller could drive the desktop.
#
# Passwords are stored as PBKDF2-HMAC-SHA256 hashes in ``users.json`` and never
# written to source. Sessions are server-side records keyed by an opaque cookie
# token, so logging out genuinely revokes access.

# Lifetime of a login session in seconds (default 12 hours).
SESSION_TTL = int(os.environ.get("CUA_SESSION_TTL", str(12 * 3600)) or 43200)

# Failed logins before the account or client IP is locked out.
AUTH_MAX_ATTEMPTS = int(os.environ.get("CUA_AUTH_MAX_ATTEMPTS", "5") or 5)

# How long a lockout lasts, in seconds.
AUTH_LOCKOUT_SECONDS = int(os.environ.get("CUA_AUTH_LOCKOUT_SECONDS", "300") or 300)

# Window in which failed attempts are counted, in seconds. Older failures are
# forgotten so an occasional typo never accumulates into a lockout.
AUTH_LOCKOUT_WINDOW = int(os.environ.get("CUA_AUTH_LOCKOUT_WINDOW", "900") or 900)


def user_store_path() -> Path:
    """Path to ``users.json``.

    Kept beside ``config_override.json`` — next to the exe in a frozen run —
    so accounts survive a rebuild and stay easy to find.
    """
    return override_file_path().with_name("users.json")


def audit_log_path() -> Path:
    """Path to ``audit.log``, the append-only record of privileged actions."""
    return override_file_path().with_name("audit.log")


def session_dir() -> Path:
    """Folder holding one JSON file per mission session.

    Deliberately a folder rather than one document: sessions are written
    independently and often, so a single combined file would mean rewriting
    every past session on every write. It also keeps handing someone a
    transcript a matter of copying one file.

    ``CUA_SESSION_DIR`` overrides it. Exists so tests can point the store at a
    scratch directory: a verification script that constructs a SessionStore to
    exercise session logic otherwise writes into the operator's real history,
    and the notices it leaves behind ("会话A", "A", "B") are indistinguishable
    from real sessions in the UI until somebody notices and cleans them up by
    hand.
    """
    override = os.environ.get("CUA_SESSION_DIR", "").strip()
    if override:
        candidate = Path(override).expanduser()
        if not candidate.is_absolute():
            candidate = ROOT_DIR / candidate
        return candidate
    return override_file_path().with_name("sessions")


# ── Session history limits ─────────────────────────────────────────────
# Both are caps on what survives on disk, not on what the live loop may hold.
# A session that runs for hours must not be able to grow a file without bound,
# and neither number is small enough to truncate a session anyone would want
# to read back.
SESSION_TRANSCRIPT_LIMIT = 600
SESSION_MESSAGE_LIMIT = 60

# How often a running session is flushed to disk, in seconds. Events are
# appended in memory immediately; writing on every one of them would mean
# hundreds of full-file rewrites per mission.
SESSION_FLUSH_INTERVAL = 2.0

# How often the browser polls for a desktop preview frame (milliseconds hint).
DESKTOP_PREVIEW_MIN_INTERVAL = 0.7


# Probe results, written by the setup wizard. ``None`` means "not measured",
# in which case capability reporting falls back to the model-name hints above.
LLM_PROBED_VISION: bool | None = None
LLM_PROBED_THINKING: bool | None = None


# ── Settings exposed to the WebUI ──────────────────────────────────────

SETTING_SPECS: list[dict] = [
    {"key": "LLM_BASE_URL", "label": "Base URL", "group": "主模型", "type": "text",
     "help": "任意 OpenAI 兼容端点的根地址，例如 https://api.deepseek.com"},
    {"key": "LLM_MODEL", "label": "模型 ID", "group": "主模型", "type": "text",
     "help": "例如 deepseek-chat / gpt-4o / qwen-plus"},
    {"key": "LLM_API_KEY", "label": "API Key", "group": "主模型", "type": "secret",
     "help": "保存在本地 config_override.json，不会写入源码"},
    {"key": "LLM_API_KEY_OPTIONAL", "label": "无需鉴权（本地服务）", "group": "主模型", "type": "bool",
     "help": "Ollama / LM Studio 等本地端点勾选此项"},
    {"key": "LLM_PROBED_VISION", "label": "实测支持图片输入", "group": "主模型", "type": "bool",
     "help": "由初始化向导的探测写入，比按模型名猜测更可信"},
    {"key": "LLM_PROBED_THINKING", "label": "实测支持思维链", "group": "主模型", "type": "bool",
     "help": "由初始化向导的探测写入"},
    {"key": "LLM_CAPABILITY", "label": "模型能力", "group": "主模型", "type": "choice",
     "choices": ["auto", "thinking", "vision", "plain"],
     "help": "auto 按模型名推断是否支持思维链与图片输入"},
    {"key": "LLM_PROVIDER", "label": "提供商", "group": "模型选择器", "type": "text",
     "help": "显示在模型列表里的提供商名称。留空则按 Base URL 自动推导"
             "（例如 opencode.ai → OpenCode-Go）；无法识别的端点显示为「自定义」"},
    {"key": "LLM_MODELS", "label": "已配置的模型", "group": "模型选择器", "type": "list",
     "help": "模型选择器里可选的全部模型。每项一行，用「模型ID@提供商」的格式"},
    {"key": "REASONING_EFFORT", "label": "推理强度", "group": "主模型", "type": "choice",
     "choices": ["low", "medium", "high", "max"],
     "help": "仅在思维链模型上生效"},
    {"key": "VISION_MODE", "label": "视觉模式", "group": "视觉", "type": "choice",
     "choices": ["auto", "multimodal", "text_vlm"],
     "help": "multimodal=主模型直接看屏；text_vlm=文本模型 + 独立 VLM"},
    {"key": "VLM_PROVIDER", "label": "VLM Provider", "group": "视觉", "type": "choice",
     "choices": ["openai_compatible", "anthropic", "gemini", "legacy", "auto"]},
    {"key": "VLM_API_URL", "label": "VLM Base URL", "group": "视觉", "type": "text"},
    {"key": "VLM_MODEL", "label": "VLM 模型", "group": "视觉", "type": "text"},
    {"key": "VLM_API_KEY", "label": "VLM API Key", "group": "视觉", "type": "secret"},
    {"key": "OCR_ENGINE", "label": "OCR 引擎", "group": "视觉", "type": "choice",
     "choices": ["builtin", "http", "off"]},
    {"key": "OCR_URL", "label": "OCR 服务地址", "group": "视觉", "type": "text"},
    {"key": "YOLO_INFERENCE_MODE", "label": "YOLO 模式", "group": "视觉", "type": "choice",
     "choices": ["bundled", "local", "cloud", "off"]},
    {"key": "SSH_PASSWORD", "label": "SSH 登录口令", "group": "远程SSH", "type": "secret",
     "help": "注入为 SSH_CLIENT_PASSWORD，供Agent 连接远程主机使用。留空则只支持密钥认证"},
    {"key": "SSH_KEY_PATH", "label": "SSH 私钥路径", "group": "远程SSH", "type": "dir",
     "placeholder": "留空则自动使用 ~/.ssh 下的默认私钥",
     "help": "指定私钥文件（如 C:\\Users\\你\\.ssh\\id_ed25519）。留空时按 ssh-client 默认顺序查找"},
    {"key": "SSH_PASSPHRASE", "label": "SSH 私钥口令短语", "group": "远程SSH", "type": "secret",
     "help": "仅当私钥本身带口令时需要填写"},
    {"key": "SSH_CALL_TIMEOUT", "label": "SSH 调用超时（秒）", "group": "远程SSH", "type": "float",
     "help": "单次 SSH 工具调用的最长等待时间。批量执行或慢主机上可能需要调大"},
    {"key": "MAX_STEPS_ENABLED", "label": "限制最大步数", "group": "运行", "type": "bool",
     "help": "关闭后任务没有步数上限，会一直跑到模型声明完成、卡住检测触发，或手动中断"},
    {"key": "MAX_STEPS", "label": "最大步数", "group": "运行", "type": "int",
     "help": "仅在开启「限制最大步数」时生效；每次任务也可在输入框旁勾选「不限步数」单独覆盖"},
    {"key": "WEB_PANEL_DESKTOP_VIEW", "label": "启用桌面预览", "group": "运行", "type": "bool",
     "help": "关闭后面板不再返回屏幕画面，设备卡片与「桌面」页都会提示已停用"},
    {"key": "DESKTOP_PREVIEW_MIN_INTERVAL", "label": "抓屏最小间隔（秒）", "group": "运行", "type": "float",
     "help": "限制连续抓屏的频率，避免预览把 CPU 占满；0 表示不限制"},
    {"key": "WORK_MODE", "label": "Agent 工作位置", "group": "工作区", "type": "choice",
     "choices": ["primary", "region"],
     "help": "primary=在主屏幕整块桌面工作；region=只在屏幕的一块矩形（虚拟屏）内工作，"
             "其余部分留给你自己用。区域模式下 Agent 的坐标从该区域的左上角算起"},
    {"key": "WORK_REGION_X", "label": "虚拟屏左边距", "group": "工作区", "type": "int",
     "help": "虚拟屏左边界在整块屏幕上的 x 像素位置"},
    {"key": "WORK_REGION_Y", "label": "虚拟屏上边距", "group": "工作区", "type": "int",
     "help": "虚拟屏上边界在整块屏幕上的 y 像素位置"},
    {"key": "WORK_REGION_WIDTH", "label": "虚拟屏宽度", "group": "工作区", "type": "int",
     "help": "留给 Agent 的区域宽度。超过屏幕剩余宽度会被自动收窄"},
    {"key": "WORK_REGION_HEIGHT", "label": "虚拟屏高度", "group": "工作区", "type": "int",
     "help": "留给 Agent 的区域高度。超过屏幕剩余高度会被自动收窄"},
    {"key": "WORK_PREVIEW_ENABLED", "label": "桌面页显示虚拟屏", "group": "工作区", "type": "bool",
     "help": "开启后桌面页画出区域边界并可单独预览虚拟屏画面；关闭则只显示整屏"},
    {"key": "SHELL_CWD", "label": "Shell 工作目录", "group": "工作区", "type": "dir",
     "help": "留空则用项目根目录。决定相对路径落在哪里——这不是沙箱，"
             "命令仍以当前用户权限执行，绝对路径照样能访问整个磁盘。点「选择…」会弹出系统文件夹对话框"},
    {"key": "RUN_ROOT", "label": "自动运行目录母目录", "group": "工作区", "type": "dir",
     "help": "任务未手动选择工作区时，在这个目录下按时间戳建一个子文件夹作为本次运行目录。"
             "留空则不自动建目录，运行不受目录限制。相对路径按项目根解析"},
    {"key": "SEND_ON_ENTER", "label": "回车直接发送", "group": "运行", "type": "choice",
     "choices": ["enter", "ctrl_enter"],
     "help": "enter=按回车发送、Shift+回车换行；ctrl_enter=回车换行、Ctrl+回车发送"},
    {"key": "AGENT_NAME", "label": "Agent 名称", "group": "运行", "type": "text",
     "placeholder": "Agent",
     "help": "显示在每条回复上方的名字。留空则用默认的「Agent」"},
    {"key": "AGENT_AVATAR", "label": "Agent 头像地址", "group": "运行", "type": "text",
     "placeholder": "https://… 或留空使用上传的图片",
     "help": "填写图片 URL（http/https）。想用本地图片请在本页下方「上传头像」选择文件；"
             "上传的图片会被自动裁剪为正方形并压缩，地址栏留空即生效"},
    {"key": "SHELL_LLM_AUDIT", "label": "Shell 二次 LLM 审计", "group": "安全", "type": "bool"},
    {"key": "SHELL_AUDIT_FAILURE_POLICY", "label": "审计不可用时的策略", "group": "安全", "type": "choice",
     "choices": ["ask", "allow", "deny"],
     "help": "ask=询问操作者；allow=仅靠静态规则放行（参考实现的行为）；deny=拒绝执行"},
    {"key": "HEADLESS_DANGER_POLICY", "label": "无界面时危险命令策略", "group": "安全", "type": "choice",
     "choices": ["deny", "allow"]},
    {"key": "APPROVAL_TIMEOUT", "label": "人工确认超时（秒）", "group": "安全", "type": "int"},
    {"key": "SESSION_TTL", "label": "会话有效期（秒）", "group": "安全", "type": "int",
     "help": "登录后会话的有效时长，默认 43200（12 小时）"},
    {"key": "AUTH_MAX_ATTEMPTS", "label": "登录失败容许次数", "group": "安全", "type": "int",
     "help": "达到次数后锁定账号与来源 IP"},
    {"key": "AUTH_LOCKOUT_SECONDS", "label": "锁定时长（秒）", "group": "安全", "type": "int"},
]

# Legacy alias expected by the settings spec writer.
VLM_BASE_URL = VLM_API_URL


def resolve_max_steps(requested=None) -> int | None:
    """Step budget for one mission, or ``None`` for no ceiling.

    ``None`` — rather than a very large number — is the honest representation
    of "unbounded": a sentinel integer would still be a value somebody could
    compare against, print as a target, or reach by accident.

    A per-mission ``requested`` value wins over the global setting, and zero or
    negative means "no limit", so the panel can offer a per-task override
    without a second setting to keep in sync.
    """
    if requested is not None:
        try:
            value = int(requested)
        except (TypeError, ValueError):
            value = None
        if value is not None:
            return value if value > 0 else None
    if not MAX_STEPS_ENABLED:
        return None
    return int(MAX_STEPS)


def get_setting(key: str):
    """Read a setting value by name (used by the WebUI settings API)."""
    return globals().get(key)


def set_setting(key: str, value) -> None:
    """Write a setting value into this module's globals (runtime override)."""
    if key.startswith("_") or key not in globals():
        raise KeyError(key)
    globals()[key] = value


def describe_llm() -> str:
    """One-line human summary of the active main-model setup."""
    mode = resolve_vision_mode()
    vision = (
        "multimodal (main model sees screenshots)"
        if mode == "multimodal"
        else f"text + VLM ({VLM_MODEL or 'VLM not configured'})"
    )
    return f"{LLM_MODEL}  @  {LLM_BASE_URL}\nVision: {vision}"


# ── Endpoint identification ─────────────────────────────────────────────
#
# The panel shows a model as "model-id@Provider", and the provider half has to
# come from somewhere. The config holds only a Base URL, so the name is derived
# from its host — the same set the setup wizard offers, so the two never
# disagree about what a provider is called.
#
# Matched on hostname, never a substring: a URL merely containing a name
# ("api.deepseek.com.example.net") must not be labelled DeepSeek.
_PROVIDER_HOSTS: tuple[tuple[str, str], ...] = (
    ("opencode.ai", "OpenCode-Go"),
    ("openrouter.ai", "OpenRouter"),
    ("api.deepseek.com", "DeepSeek"),
    ("api.openai.com", "OpenAI"),
    ("api.anthropic.com", "Anthropic"),
    ("generativelanguage.googleapis.com", "Google Gemini"),
    ("open.bigmodel.cn", "智谱 GLM"),
    ("api.moonshot.cn", "Kimi"),
    ("api.minimax.cn", "MiniMax"),
    ("api.lkeap.cloud.tencent.com", "腾讯云 Token Plan"),
    ("tokenhub.tencentmaas.com", "腾讯云 TokenHub"),
    ("dashscope.aliyuncs.com", "阿里通义"),
    ("api.siliconflow.cn", "硅基流动"),
)

#: Base-URL substrings that mean "not a hosted provider at all". A local
#: endpoint is neither custom-unset nor a named vendor, and calling it
#: "自定义" would be misleading — the operator did nothing custom.
_LOCAL_HOSTS = ("localhost", "127.0.0.1", "0.0.0.0", "::1", "host.docker.internal")


def provider_name(base_url: str | None = None) -> str:
    """A user-facing provider label for *base_url* (default: the configured one).

    Falls back to "自定义" for an endpoint we do not recognise — which is the
    honest answer for a self-hosted gateway or a vendor added after this list
    was written, and matches what the wizard calls the same case.
    """
    url = (base_url if base_url is not None else LLM_BASE_URL) or ""
    text = url.strip()
    if not text:
        return "自定义"
    try:
        from urllib.parse import urlsplit

        host = (urlsplit(text if "://" in text else f"http://{text}").hostname or "").lower()
    except ValueError:
        return "自定义"

    if not host:
        return "自定义"
    if any(host == h or host.endswith("." + h) for h in _LOCAL_HOSTS):
        return "本地"
    for suffix, name in _PROVIDER_HOSTS:
        if host == suffix or host.endswith("." + suffix):
            return name
    return "自定义"


def model_label(model: str | None = None, base_url: str | None = None) -> str:
    """The ``model@Provider`` form the panel and picker display."""
    name = (model if model is not None else LLM_MODEL) or ""
    if not name:
        return ""
    return f"{name}@{provider_name(base_url)}"


def model_entries() -> list[dict[str, str]]:
    """Models to offer in the picker, newest first, each with its provider.

    Built from what the operator actually configured rather than a hardcoded
    catalogue: an entry is real only if it was saved, which is what makes the
    tick next to it mean something. ``LLM_MODEL`` is included even when the
    list was never written (an install configured by hand or by an older
    build), so the active model is never missing from its own picker.
    """
    provider = provider_name_for_setting(globals().get("LLM_PROVIDER"))
    raw = globals().get("LLM_MODELS")
    models: list[str] = []
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            raw = []
    if isinstance(raw, list):
        for item in raw:
            name = str(item or "").strip()
            if name and name not in models:
                models.append(name)

    current = (LLM_MODEL or "").strip()
    if current and current not in models:
        models.append(current)

    return [{"id": m, "provider": provider, "label": f"{m}@{provider}"} for m in models]


def remember_model(model: str) -> None:
    """Record *model* as configured, so the picker keeps offering it.

    Always materialises the whole list rather than appending to it. The list
    starts empty on an install configured by hand, with the only known model
    being the one in ``LLM_MODEL``; returning early because "it is already
    implied" left ``LLM_MODELS`` empty, so nothing was ever written and
    switching models silently dropped the previous one from the picker.
    """
    name = str(model or "").strip()
    models = [e["id"] for e in model_entries()]
    if name and name not in models:
        models.append(name)
    globals()["LLM_MODELS"] = models


def provider_name_for_setting(value) -> str:
    """Normalise whatever is stored for the provider.

    Derived from the Base URL when the setting is blank, so a configuration
    written before this field existed still shows a sensible name instead of
    an empty one.
    """
    text = str(value or "").strip()
    return text or provider_name()


# ── Config overrides (loaded from config_override.json if present) ──────
_OVERRIDE_FILE = override_file_path()
if _OVERRIDE_FILE.exists():
    try:
        _overrides = json.loads(_OVERRIDE_FILE.read_text(encoding="utf-8"))
        for _key, _value in _overrides.items():
            if _key in globals() and not _key.startswith("_"):
                globals()[_key] = _value
    except (json.JSONDecodeError, OSError):
        pass

# Keep the legacy alias in sync after an override rewrite.
VLM_BASE_URL = VLM_API_URL
