"""Second-stage shell safety: an LLM audit plus a human approval bridge.

Stage one (static rules) lives in ``executors/shell.py`` and always runs.
This module is stage two. Its verdict is resolved by asking a human through
``ctx.runtime`` — in the WebUI that means a confirmation card in the
browser; headless runs fall back to ``config.HEADLESS_DANGER_POLICY``.

Notable design decision carried over from the reference: **if the audit
itself fails, execution is allowed through**. A flaky model should not make
the shell unusable; the static rules still act as a floor.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from . import llm_client

SECURITY_SYSTEM_PROMPT = """\
You are an expert security auditor for computer shell commands.
Your job is to analyze commands and determine if they could cause
SERIOUS, IRREVERSIBLE damage to the computer system.

"Serious, irreversible damage" means:
- Deleting or corrupting operating system files (e.g. rm -rf /, del C:\\Windows)
- Formatting drives (e.g. format C:, mkfs)
- Wiping an entire filesystem or home directory
- Bricking the machine (firmware attacks, disk encryption sabotage)
- Mass data destruction beyond a scoped project/work directory
- Modifying system boot configuration in destructive ways

NOT considered serious/irreversible:
- Commands scoped to a specific project directory (even if they delete files)
- Normal package management (pip install, npm, apt-get)
- Git operations (even force push)
- Process management (kill, taskkill)
- File moves/renames within a workspace
- Standard build/dev commands (make, cargo, docker, etc.)

Reply with a JSON object — no other text:
{
  "is_dangerous": true or false,
  "overall_risk": "one-sentence summary of the danger, or 'safe' if none",
  "parts": [
    {"part": "the specific dangerous segment", "why": "why it's dangerous"}
  ]
}
"""


@dataclass
class AuditVerdict:
    """Outcome of one shell safety audit."""

    dangerous: bool
    risk: str = ""
    parts: list[dict] | None = None
    audit_error: str = ""
    # True when the auditor could not be reached at all, so nothing is known
    # about the command — very different from a verdict of "safe".
    unavailable: bool = False

    @property
    def parts_list(self) -> list[dict]:
        return self.parts or []


# Once the audit endpoint proves unreachable there is no point retrying on
# every command: the failure is almost never transient, and each attempt adds
# a multi-second stall to an interactive mission. Latch after this many
# consecutive failures.
_FAILURE_LATCH = 2
_consecutive_failures = 0
_offline_reason = ""


def _build_query(shell_code: str, explanation: str) -> str:
    return (
        "Analyze this shell command for safety:\n\n"
        f"Command:\n```\n{shell_code}\n```\n\n"
        f"User's stated intent:\n{explanation.strip() or '(no explanation provided)'}\n\n"
        "Output ONLY the JSON object."
    )


def _extract_json(raw: str) -> dict:
    raw = (raw or "").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", raw)
        if match:
            return json.loads(match.group(0))
        raise


def reset_failure_state() -> None:
    """Forget a previous connectivity failure (used after config changes)."""
    global _consecutive_failures, _offline_reason
    _consecutive_failures = 0
    _offline_reason = ""


def run_audit(shell_code: str, explanation: str) -> AuditVerdict:
    """Ask the configured main model whether the command is dangerous.

    Uses a fresh, context-free request so the conversation cannot talk the
    auditor into approving something it would otherwise flag.

    A transport failure is reported through ``unavailable`` rather than being
    swallowed: the caller decides what to do about a blind spot, and the
    default is *not* to proceed silently.
    """
    global _consecutive_failures, _offline_reason

    if _offline_reason:
        return AuditVerdict(
            dangerous=False, unavailable=True, audit_error=_offline_reason,
        )

    client = llm_client.build_llm_client()
    try:
        response = client.chat.completions.create(
            model=_audit_model(),
            messages=[
                {"role": "system", "content": SECURITY_SYSTEM_PROMPT},
                {"role": "user", "content": _build_query(shell_code, explanation)},
            ],
            response_format={"type": "json_object"},
            temperature=0.0,
            max_tokens=1024,
            stream=False,
            # This call targets the same endpoint as the main model, so it needs
            # whatever routing headers that endpoint requires (OpenCode answers
            # 400 MissingSessionID otherwise). No session id is threaded here:
            # the audit is a self-contained question whose answer is not cached
            # against the conversation anyway.
            extra_headers=llm_client.request_headers(),
        )
        raw = response.choices[0].message.content or ""
        data = _extract_json(raw)
    except Exception as e:  #noqa: BLE001 - audit failure must not kill the shell
        _consecutive_failures += 1
        reason = f"{type(e).__name__}: {e}"
        if _consecutive_failures >= _FAILURE_LATCH:
            _offline_reason = reason
        return AuditVerdict(dangerous=False, unavailable=True, audit_error=reason)

    _consecutive_failures = 0
    return AuditVerdict(
        dangerous=bool(data.get("is_dangerous", False)),
        risk=str(data.get("overall_risk", "") or ""),
        parts=[p for p in (data.get("parts") or []) if isinstance(p, dict)],
    )


def _audit_model() -> str:
    """The model used for auditing — the main model unless overridden."""
    from . import config

    return getattr(config, "SECURITY_AUDIT_MODEL", "") or config.LLM_MODEL


def request_approval(verdict: AuditVerdict, shell_code: str, ctx) -> bool:
    """Bridge the verdict to a human and return their decision."""
    from .runtime import build_shell_request

    # Full-access mode removes the human from the loop for shell commands: the
    # command proceeds immediately and nothing is surfaced to the browser, so
    # the confirmation card never appears.
    if getattr(ctx.runtime, "full_access", False):
        return True

    request = build_shell_request(shell_code, verdict.risk, verdict.parts_list)
    ctx.emit_approval(request)
    try:
        approved = bool(ctx.runtime.approve(request))
    except Exception:
        approved = False
    ctx.emit_approval_resolved(request, approved)
    return approved


def rejection_reason(verdict: AuditVerdict) -> str:
    """Compose the string handed back to the model when an operator says no."""
    reasons = "; ".join(
        p.get("why", "") for p in verdict.parts_list if p.get("why")
    )
    return reasons or verdict.risk or "blocked by the operator"
