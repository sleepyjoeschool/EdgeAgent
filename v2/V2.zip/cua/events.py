"""Event vocabulary emitted by the agent core.

The core never prints and never touches a browser — it pushes dictionaries
through a single sink callable. Any front-end (WebUI, CLI, tests) can render
them however it likes. Keeping this vocabulary in one module is what stops
the reference project's pattern of re-implementing the loop per front-end.
"""

from __future__ import annotations

import time
from typing import Any, Callable

EventSink = Callable[[dict], None]

# ── Event types ─────────────────────────────────────────────────────────
RUN_START = "run_start"          # {task, mode, max_steps}
STEP_START = "step_start"        # {step, max_steps}
THINKING = "thinking"            # {text}  streaming delta
MESSAGE = "message"              # {text}  streaming delta
TOOL_CALL = "tool_call"          # {id, name, arguments}
TOOL_RESULT = "tool_result"      # {id, name, ok, result, uuid, seconds}
STEP_SUMMARY = "step_summary"    # {step, text}
#: One model round-trip's token usage. Emitted only for models with an exact
#: tokenizer (hy3 / hy4 / deepseek-v4.1-flash / deepseek-v4-pro) — a front end
#: that renders a counter must treat its absence as "not measured".
TOKEN_USAGE = "token_usage"      # {step, model, input_tokens, cached_tokens, output_tokens, session_total}
NOTICE = "notice"                # {text, level}
APPROVAL_REQUEST = "approval"    # {id, kind, title, detail, timeout}
APPROVAL_RESOLVED = "approval_resolved"  # {id, approved}
STATUS = "status"                # {state}  idle|running|paused|awaiting_approval
RUN_DONE = "run_done"            # {reason, steps, elapsed}
ERROR = "error"                  # {message, fatal}


def make(event_type: str, **payload: Any) -> dict:
    """Build an event envelope."""
    return {"type": event_type, "ts": time.time(), **payload}


def null_sink(_event: dict) -> None:
    """Sink that swallows everything (used in tests / headless runs)."""
    return None
