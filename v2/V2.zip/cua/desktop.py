"""Guarded wrappers around desktop-control libraries.

Every binding is imported lazily so that a missing or unusable dependency
degrades into a clear tool-level error instead of taking the whole server
down at import time. This matters because the same package is imported by
the WebUI process, by tests, and (potentially) on machines with no desktop
session attached.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Any

_IMPORT_ERRORS: dict[str, str] = {}


def _try_import(name: str):
    try:
        module = __import__(name)
    except Exception as e:  # noqa: BLE001 - reported to the caller
        _IMPORT_ERRORS[name] = f"{type(e).__name__}: {e}"
        return None
    if name == "pyautogui":
        _configure_pyautogui(module)
    return module


def _configure_pyautogui(module: Any) -> None:
    # FAILSAFE keeps the physical mouse a usable emergency brake: throwing it
    # into a screen corner aborts the pyautogui call.
    try:
        module.FAILSAFE = True
        module.PAUSE = 0.05
    except Exception:
        pass


def last_error(name: str) -> str:
    return _IMPORT_ERRORS.get(name, "")


def unavailable_message(name: str) -> str:
    detail = last_error(name)
    suffix = f" ({detail})" if detail else ""
    pkg = {
        "pyautogui": "pip install pyautogui",
        "pyperclip": "pip install pyperclip",
        "PIL": "pip install pillow",
        "numpy": "pip install numpy",
        "requests": "pip install requests",
    }.get(name, f"pip install {name}")
    return f"Error: '{name}' is not available on this machine{suffix}. Install it with: {pkg}"


@lru_cache(maxsize=8)
def pyautogui():
    return _try_import("pyautogui")


@lru_cache(maxsize=8)
def pyperclip():
    return _try_import("pyperclip")


@lru_cache(maxsize=8)
def pillow():
    return _try_import("PIL")


@lru_cache(maxsize=8)
def numpy():
    return _try_import("numpy")


@lru_cache(maxsize=8)
def requests():
    return _try_import("requests")


def dependency_report() -> dict[str, bool]:
    """Availability snapshot shown on the WebUI status card.

    Presence only, never a working import. These names end up in /api/hello,
    which the SPA calls on every boot, so a heavyweight check here is felt
    directly as a slow page load.
    """
    return {
        "pyautogui": _module_available("pyautogui"),
        "pyperclip": _module_available("pyperclip"),
        "pillow": _module_available("PIL"),
        "numpy": _module_available("numpy"),
        "requests": _module_available("requests"),
        # OCR already answers the harder question properly: its library lives
        # in vendor/ and is only importable after the path bootstrap.
        "paddleocr": ocr_backend() == "paddleocr",
        "ultralytics": _module_available("ultralytics"),
    }


@lru_cache(maxsize=1)
def _ultralytics():
    """The YOLO class, loaded on demand — never as part of a status check.

    See ``_module_available`` for why the status card must not call this.
    """
    try:
        from ultralytics import YOLO  # type: ignore
    except Exception:
        return None
    return YOLO


@lru_cache(maxsize=64)
def _module_available(name: str) -> bool:
    """Whether a module can be located *without importing it*.

    ``find_spec`` answers the only question a status card is asking — is this
    dependency present? — without executing the package. That distinction is
    worth real time here: ``import ultralytics`` pulls in torch and cost a
    measured **5 seconds**, which is exactly the window in which the panel
    looked frozen while rendering /api/hello.
    """
    import importlib.util

    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        # A package that explodes on import (missing shared library, broken
        # transitive dep) is not "available" for our purposes.
        return False


@lru_cache(maxsize=1)
def ocr_backend() -> str:
    """Which OCR implementation is importable: ``paddleocr`` or ``none``.

    Delegates to :func:`cua.ocr_engine.paddle_available` rather than importing
    directly. PaddleOCR ships in ``vendor/paddle_env`` and is only importable
    after that directory is prepended to ``sys.path`` — a bare ``import
    paddleocr`` therefore fails on a perfectly good install and the status card
    reports "missing" while the perception view simultaneously reports ready.
    One source of truth is the whole point: two checks for one fact disagreed
    with each other in front of the operator.
    """
    from .ocr_engine import paddle_available

    return "paddleocr" if paddle_available() else "none"


def screenshot(region: tuple[int, int, int, int] | None = None):
    """Capture the screen, or one rectangle of it.

    ``region`` is ``(left, top, width, height)`` in virtual-screen pixels, the
    same coordinate space pyautogui's mouse functions use. Passing it yields an
    image of exactly that rectangle, which is how the agent gets a "second
    screen" out of a single physical display: it sees a smaller picture whose
    origin is the region's top-left corner.
    """
    pag = pyautogui()
    if pag is None:
        raise RuntimeError("pyautogui unavailable — cannot capture the screen")
    if region is None:
        return pag.screenshot()
    return pag.screenshot(region=tuple(int(v) for v in region))


def screen_size() -> tuple[int, int]:
    """Full virtual-screen size, ignoring any workspace partition."""
    pag = pyautogui()
    if pag is None:
        return (0, 0)
    try:
        width, height = pag.size()
        return int(width), int(height)
    except Exception:
        return (0, 0)


def mouse_position() -> tuple[int, int]:
    pag = pyautogui()
    if pag is None:
        return (0, 0)
    try:
        x, y = pag.position()
        return int(x), int(y)
    except Exception:
        return (0, 0)


# ── Agent workspace (screen partition) ──────────────────────────────────
# The agent's *view* of the desktop. In 'primary' mode this is the whole
# screen and every mapping below is the identity, so the partition feature
# costs nothing when it is off.


def work_region() -> tuple[int, int, int, int] | None:
    """The rectangle the agent operates in, or ``None`` for the whole screen.

    The configured rectangle is clamped to the screen rather than trusted.
    A region saved against a 2880-wide monitor would otherwise leave the agent
    clicking coordinates that no longer exist after the display changes, and
    pyautogui's FAILSAFE would fire at the corner instead of reporting a sane
    error. A rectangle that shrinks to nothing falls back to the full screen —
    a zero-sized region would make every screenshot fail with something far
    less obvious.
    """
    from . import config

    if config.work_mode() != "region":
        return None

    total_w, total_h = screen_size()
    if total_w <= 0 or total_h <= 0:
        return None

    x = max(0, int(getattr(config, "WORK_REGION_X", 0) or 0))
    y = max(0, int(getattr(config, "WORK_REGION_Y", 0) or 0))
    w = int(getattr(config, "WORK_REGION_WIDTH", 0) or 0)
    h = int(getattr(config, "WORK_REGION_HEIGHT", 0) or 0)

    # An unset or nonsensical size means "the operator has not configured it
    # yet" — use everything from the given origin to the screen edge.
    if w <= 0:
        w = total_w - x
    if h <= 0:
        h = total_h - y

    w = min(w, total_w - x)
    h = min(h, total_h - y)
    if w <= 0 or h <= 0:
        return None
    return (x, y, w, h)


def work_size() -> tuple[int, int]:
    """Size of the agent's view — what the model should believe the screen is."""
    region = work_region()
    if region is None:
        return screen_size()
    return (region[2], region[3])


def map_to_screen(x: int, y: int) -> tuple[int, int]:
    """Translate a coordinate in the agent's view into a real screen point.

    The model is shown a picture of only the workspace, so every coordinate it
    produces is relative to that rectangle's top-left corner. Without this
    shift a perfectly correct click at (100, 100) would land 1600px to the
    left, in whatever the operator happens to have open.
    """
    region = work_region()
    if region is None:
        return (int(x), int(y))
    rx, ry, rw, rh = region
    return (rx + int(x), ry + int(y))


def clamp_to_region(x: int, y: int) -> tuple[int, int]:
    """Clamp a *view* coordinate to the workspace and map it to the screen.

    Clamping is the part that makes the partition safe. The model can and
    does emit coordinates slightly outside the image it saw — a stray pixel
    from a resized screenshot, a hallucinated hotspot. Mapped through the
    offset alone, those land in the operator's half of the screen.
    """
    region = work_region()
    if region is None:
        return (int(x), int(y))
    _rx, _ry, rw, rh = region
    cx = max(0, min(int(x), rw - 1))
    cy = max(0, min(int(y), rh - 1))
    return map_to_screen(cx, cy)


def screen_to_view(x: int, y: int) -> tuple[int, int]:
    """Inverse of :func:`map_to_screen` — real screen point to view point."""
    region = work_region()
    if region is None:
        return (int(x), int(y))
    rx, ry, _rw, _rh = region
    return (int(x) - rx, int(y) - ry)


def work_region_info() -> dict[str, Any]:
    """Workspace snapshot for the WebUI (region is None in primary mode)."""
    from . import config

    total_w, total_h = screen_size()
    region = work_region()
    return {
        "mode": config.work_mode(),
        "label": config.describe_work_mode(),
        "screen": {"width": total_w, "height": total_h},
        "region": (
            {"x": region[0], "y": region[1], "width": region[2], "height": region[3]}
            if region
            else None
        ),
        "view": {
            "width": region[2] if region else total_w,
            "height": region[3] if region else total_h,
        },
        "preview": bool(getattr(config, "WORK_PREVIEW_ENABLED", True)),
    }

