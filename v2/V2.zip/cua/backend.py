"""Execution backend: one place where "the machine the agent drives" is decided.

Before this module the desktop lived in :mod:`cua.desktop` and the shell lived
in ``subprocess.run`` inside an executor, so the two were configured in
different places and only one of them could ever be moved somewhere else.
Both now go through the backend selected by :func:`get_backend`.

Why this exists when only one backend is implemented
-----------------------------------------------------
The value is not the local implementation, which is what every caller already
had. It is that **the shell and the desktop are now configured together**. A
deployment that puts the agent on another machine (a VM, a remote session)
only has to provide a second :class:`Backend` and the shell follows it — the
executor no longer holds a direct ``subprocess`` call that would silently keep
running on the host.

What this is not
----------------
**This is not a sandbox.** With ``LocalBackend`` the shell runs as the operator,
with the operator's privileges, on the operator's filesystem. The working
directory is constrained (see :func:`shell_cwd`) and that genuinely prevents a
careless relative path from landing somewhere unexpected, but ``del D:\\...``
typed by the model still works. Treat the LLM audit in ``security_check`` and
the human approval gate as the actual defence; they are the only thing standing
between a confused model and the filesystem, and this module is honest about
that rather than implying a containment it cannot provide.
"""

from __future__ import annotations

import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass
class ShellResult:
    """Outcome of a shell command run through a backend.

    ``returncode`` is ``None`` for a command that was launched and detached,
    which is how the async executor tells "still going" from "finished".
    """

    returncode: int | None
    stdout: str = ""
    stderr: str = ""
    cwd: str = ""


@runtime_checkable
class Backend(Protocol):
    """The surface every execution backend provides.

    Implementations must be importable without a desktop session so the panel
    can start on a machine with none; a missing dependency becomes a tool-level
    error rather than an import crash.
    """

    name: str

    # ── Perception ──
    def screenshot(self, region: tuple[int, int, int, int] | None = None):
        """Capture the screen, or one rectangle of it."""

    def screen_size(self) -> tuple[int, int]:
        """Full virtual-screen size in pixels."""

    def mouse_position(self) -> tuple[int, int]:
        """Current pointer position in virtual-screen coordinates."""

    # ── Action ──
    def move_to(self, x: int, y: int, duration: float = 0.0) -> None: ...
    def click(self, button: str = "left", clicks: int = 1) -> None: ...
    def write(self, text: str, interval: float = 0.0) -> None: ...
    def hotkey(self, *keys: str) -> None: ...
    def scroll(self, clicks: int) -> None: ...

    # ── Shell ──
    def run_shell(self, command: str, timeout: float,
                  cwd: str | None = None) -> ShellResult:
        """Run a command to completion, in *cwd* when one is given."""

    def spawn_shell(self, command: str, cwd: str | None = None) -> int:
        """Launch a command in *cwd* and return its pid."""

    def clipboard_write(self, text: str) -> None: ...
    def clipboard_read(self) -> str: ...


def shell_cwd() -> str:
    """Working directory for shell commands.

    Defaults to the project root, which is the honest answer: a mission that
    starts in an arbitrary directory leaves its output wherever it happened to
    be launched from, and the operator then has to hunt for it. Settable via
    ``SHELL_CWD`` for anyone who wants the agent confined to a scratch folder.

    The directory is created if missing, because failing every command with
    "directory not found" is a worse outcome than making the directory.
    """
    from . import config

    configured = (getattr(config, "SHELL_CWD", "") or "").strip()
    path = Path(configured) if configured else Path(config.ROOT_DIR)
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError:
        # Read-only or otherwise unusable: fall back to the root the process
        # already runs in, which certainly exists.
        return str(Path.cwd())
    return str(path)

def resolve_cwd(cwd: str | None) -> str:
    """Directory a shell command should run in.

    A caller-supplied *cwd* wins over the global default, but only after being
    proven to exist and to be a directory: a mission whose workspace was
    deleted between the picker and the command would otherwise fail every call
    with a confusing errno, rather than falling back to the default and still
    doing something useful.
    """
    if cwd:
        try:
            path = Path(cwd)
            if path.is_dir():
                return str(path)
        except OSError:
            pass
    return shell_cwd()



class LocalBackend:
    """Drive this machine: pyautogui for input, subprocess for the shell.

    Every binding is resolved lazily so a missing dependency surfaces as a
    readable tool error instead of preventing the server from starting.
    """

    name = "local"

    # ── Perception ──
    def screenshot(self, region: tuple[int, int, int, int] | None = None):
        from . import desktop

        pag = desktop.pyautogui()
        if pag is None:
            raise RuntimeError("pyautogui unavailable — cannot capture the screen")
        if region is None:
            return pag.screenshot()
        return pag.screenshot(region=tuple(int(v) for v in region))

    def screen_size(self) -> tuple[int, int]:
        from . import desktop

        return desktop.screen_size()

    def mouse_position(self) -> tuple[int, int]:
        from . import desktop

        return desktop.mouse_position()

    # ── Action ──
    def _pyautogui(self):
        from . import desktop

        pag = desktop.pyautogui()
        if pag is None:
            raise RuntimeError(
                desktop.unavailable_message("pyautogui")
            )
        return pag

    def move_to(self, x: int, y: int, duration: float = 0.0) -> None:
        self._pyautogui().moveTo(int(x), int(y), duration=duration or 0.0)

    def click(self, button: str = "left", clicks: int = 1) -> None:
        pag = self._pyautogui()
        if clicks == 2:
            pag.doubleClick(button=button)
        else:
            pag.click(button=button)

    def write(self, text: str, interval: float = 0.0) -> None:
        self._pyautogui().write(text, interval=interval)

    def hotkey(self, *keys: str) -> None:
        self._pyautogui().hotkey(*keys)

    def scroll(self, clicks: int) -> None:
        self._pyautogui().scroll(int(clicks))

    # ── Shell ──
    def run_shell(self, command: str, timeout: float,
                  cwd: str | None = None) -> ShellResult:
        """Run *command* to completion, in *cwd* when one is given.

        No ``shell=True`` escape hatch is offered to callers: the command is a
        single string by the time it gets here, and passing it through the shell
        is what makes quoting surprises (``&``, ``|``, ``>``) invisible to
        whatever inspection happens upstream. Everything the shell executor
        accepts was always destined for a shell, so the flag stays — but it
        lives here, in one place, rather than in an executor.
        """
        target = resolve_cwd(cwd)
        completed = subprocess.run(
            command,
            shell=True,
            cwd=target,
            capture_output=True,
            text=True,
            timeout=timeout,
            errors="replace",
        )
        return ShellResult(
            returncode=completed.returncode,
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
            cwd=target,
        )

    def spawn_shell(self, command: str, cwd: str | None = None) -> int:
        process = subprocess.Popen(
            command,
            shell=True,
            cwd=resolve_cwd(cwd),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return process.pid

    # ── Clipboard ──
    def clipboard_write(self, text: str) -> None:
        from . import desktop

        clip = desktop.pyperclip()
        if clip is None:
            raise RuntimeError(desktop.unavailable_message("pyperclip"))
        clip.copy(text)

    def clipboard_read(self) -> str:
        from . import desktop

        clip = desktop.pyperclip()
        if clip is None:
            raise RuntimeError(desktop.unavailable_message("pyperclip"))
        return clip.paste() or ""


_BACKEND: Backend | None = None


def get_backend() -> Backend:
    """The active backend, defaulting to this machine."""
    global _BACKEND
    if _BACKEND is None:
        _BACKEND = LocalBackend()
    return _BACKEND


def set_backend(backend: Backend | None) -> None:
    """Install a backend, or pass ``None`` to fall back to the local one.

    The seam a deployment needs: give it something that speaks to a VM or a
    remote session and the desktop *and* the shell both move there, because
    neither has a direct handle on the host any more.
    """
    global _BACKEND
    _BACKEND = backend


# ── Shell activity log ──────────────────────────────────────────────────
# A partitioned workspace means the operator is looking at the other half of
# the screen and cannot see what the agent is doing — so the one thing they
# most need to keep an eye on is the one thing that escapes the partition
# entirely. This is that window: the recent commands, with their outcome,
# readable from another device.
#
# Bounded because a long mission runs many commands and this is a glance, not
# an audit log — `cua/audit.log` remains the durable record.
_ACTIVITY_LIMIT = 50
_activity: list[dict] = []
_activity_lock = threading.Lock()


def record_shell_activity(command: str, returncode: int | None, ok: bool) -> None:
    """Note that a command ran, for the panel's live view."""
    entry = {
        "command": command if len(command) <= 300 else command[:300] + "…",
        "returncode": returncode,
        "ok": ok,
        "ts": time.time(),
    }
    with _activity_lock:
        _activity.append(entry)
        if len(_activity) > _ACTIVITY_LIMIT:
            del _activity[: len(_activity) - _ACTIVITY_LIMIT]


def shell_activity(limit: int = 20) -> list[dict]:
    """Most recent commands, newest first."""
    with _activity_lock:
        return list(reversed(_activity[-max(1, min(limit, _ACTIVITY_LIMIT)):]))


def backend_info() -> dict[str, str]:
    """Backend description for the WebUI status panel."""
    backend = get_backend()
    return {
        "name": getattr(backend, "name", "unknown"),
        "shell_cwd": shell_cwd(),
    }
