"""Execution context handed to every tool executor."""

from __future__ import annotations

from typing import Any, Callable

from .events import EventSink, null_sink
from .modes import normalize
from .runtime import Runtime


class ToolContext:
    """Everything an executor is allowed to touch.

    Passing this explicitly replaces the reference implementation's habit of
    stashing the live message list in a module-level global, which broke as
    soon as two missions could overlap.
    """

    def __init__(
        self,
        runtime: Runtime | None = None,
        messages: list[dict] | None = None,
        emit: EventSink = null_sink,
        mission_id: str = "",
        agent_mode: str = "gui",
    ) -> None:
        self.runtime = runtime or Runtime()
        # Which operating mode this mission runs in. Executors ask the
        # context rather than reading a global, so a refusal is a
        # property of the mission and not of the process.
        self.agent_mode = normalize(agent_mode)
        self.messages: list[dict] = messages if messages is not None else []
        self.emit = emit
        self.mission_id = mission_id

    def notice(self, text: str, level: str = "info", **extra: Any) -> None:
        try:
            from .events import NOTICE, make

            self.emit(make(NOTICE, text=text, level=level, **extra))
        except Exception:
            pass

    def check_stop(self) -> None:
        """Raise ``Aborted`` when the operator has cancelled the mission."""
        self.runtime.check_stop()

    # ── Approval helpers used by human-in-the-loop executors ───────────

    def emit_approval(self, request: dict) -> None:
        try:
            from .events import APPROVAL_REQUEST, make

            self.emit(make(APPROVAL_REQUEST, **request))
        except Exception:
            pass

    def emit_approval_resolved(self, request: dict, approved: bool) -> None:
        try:
            from .events import APPROVAL_RESOLVED, make

            self.emit(make(
                APPROVAL_RESOLVED,
                id=request.get("id", ""),
                approved=bool(approved),
            ))
        except Exception:
            pass
