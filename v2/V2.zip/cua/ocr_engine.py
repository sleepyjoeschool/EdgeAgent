"""OCR backends for reading text off the screen.

Engines:

``builtin``  PaddleOCR running locally on CPU — no service, no API key.
``http``     An external Umi-OCR / PaddleOCR-Serving instance.
``off``      Disabled; the tool returns an explanatory error.

Both engines return the same normalised shape so the executor layer never
has to care which one produced it::

    [{"text": str, "confidence": float, "box": [x1, y1, x2, y2, ...]}, ...]
"""

from __future__ import annotations

import io
import re
import threading
from pathlib import Path
from typing import Any

from . import config

# ── Paddle singletons ───────────────────────────────────────────────────
# Model init costs seconds, so it happens at most once per process. The lock
# matters: the WebUI serves tools from a worker thread while the status card
# may be probing availability at the same time.
_paddle_lock = threading.Lock()
_paddle_ocr = None
_paddle_failed = False
_paddle_error = ""

# Set by paddle_env_candidates when a discovered tree was dropped over an
# ABI mismatch, so the tool error can say *why* the engine is gone instead
# of a bare "not installed".
_abi_note = ""


def compatibility_note() -> str:
    """Why a discovered paddle tree was rejected, for UI/tool messages."""
    return _abi_note

def _interpreter_abi_tag() -> str:
    """This interpreter's compiled-module tag, e.g. ``cp313-win_amd64``."""
    import sysconfig

    suffix = sysconfig.get_config_var("EXT_SUFFIX") or ""
    match = re.search(r"\.(cp\d+[^.\\/]*)\.pyd$", suffix, re.IGNORECASE)
    return match.group(1).lower() if match else ""


def _tree_abi_tag(directory: Path) -> str:
    """The ABI tag a vendored paddle tree was built for, or "" if unknown.

    The trees are ``pip install --target`` installs, so their compiled
    modules carry the interpreter tag in the filename. ``pydantic_core`` is
    a paddleocr hard dependency and sits at the tree root, which makes it a
    cheap sentinel for the whole tree's ABI.
    """
    for pyd in sorted(directory.glob("pydantic_core/_pydantic_core.*.pyd")):
        match = re.match(r"_pydantic_core\.(cp\d+[^.]*)\.pyd$", pyd.name, re.IGNORECASE)
        if match:
            return match.group(1).lower()
    return ""


def _abi_compatible(directory: Path) -> bool:
    """Whether a vendored tree matches this interpreter.

    A cp311 tree on a cp313 interpreter used to half-import — some pure
    Python modules load, then the first compiled one dies or, worse, the
    import chain stalls — which is one of the ways the OCR path "hung".
    Checking the filename tag first reduces that to a clean, instant
    "engine unavailable".
    """
    own, tree = _interpreter_abi_tag(), _tree_abi_tag(directory)
    return not own or not tree or own == tree


def paddle_env_candidates() -> list[Path]:
    """Candidate directories holding a *matching* Paddle stack.

    Why this exists at all: PaddleOCR's parts are version-coupled. When the
    interpreter's site-packages carries ``paddlepaddle 3.0.0`` alongside
    ``paddlex 3.7.2``, ``PaddleOCR.predict`` dies inside PIR with
    ``ValueError: Type of attribute: strides is not right``. The only working
    combination here is paddle 3.2.2 + paddlex 3.7.2, which lives outside
    site-packages, so it has to be put ahead of it on ``sys.path``.

    Order matters — first match wins:

    1. ``CUA_OCR_PADDLE_ENV`` — explicit override, for pointing at your own
       self-consistent install. Trusted as-is: no ABI guessing.
    2. ``vendor/paddle_env`` — the tree vendored into this project, so a fresh
       checkout needs no machine-specific setup
    3. ``_internal/paddle_env`` — the same tree inside a packaged bundle

    Trees discovered automatically are dropped when their compiled modules
    were built for a different interpreter (see ``_abi_compatible``) — the
    explicit override is the escape hatch for unusual setups.

    Note ``insert(0)`` rather than ``append``: a broken older ``paddle`` may
    already sit in site-packages, and Python takes the first one it finds.
    """
    root = Path(config.ROOT_DIR)
    package_root = Path(__file__).resolve().parent.parent
    candidates: list[Path] = []

    override = (getattr(config, "OCR_PADDLE_ENV", "") or "").strip()
    if override:
        candidates.append(Path(override))

    candidates.extend([
        root / "vendor" / "paddle_env",
        package_root / "vendor" / "paddle_env",
        root / "_internal" / "paddle_env",
    ])

    discovered_start = 1 if override else 0
    existing = [c for c in candidates[discovered_start:] if c.is_dir()]
    filtered = [c for c in existing if _abi_compatible(c)]
    dropped = [c for c in existing if not _abi_compatible(c)]
    if dropped:
        # At least one discovered tree exists but does not match this
        # interpreter; say so, or the operator sees "not installed" and goes
        # hunting for a package that is actually sitting right there.
        global _abi_note
        example = dropped[0]
        _abi_note = (
            f"检测到 Paddle 环境 {example.name} 是为 {_tree_abi_tag(example) or '其他'} "
            f"构建的，与当前解释器（{_interpreter_abi_tag() or '未知'})不匹配，已跳过。"
            "请用 Python 3.11 运行面板，或为本解释器安装匹配的 paddlepaddle/paddleocr。"
        )
    return candidates[:discovered_start] + filtered


def active_paddle_env() -> Path | None:
    """The directory actually supplying ``paddle``, or None for site-packages."""
    import sys

    try:
        spec = __import__("paddle").__file__
    except Exception:
        return None
    source = Path(spec or "").resolve().parent.parent
    for candidate in paddle_env_candidates():
        try:
            if candidate.is_dir() and candidate.resolve() == source:
                return candidate
        except OSError:
            continue
    return None


# Packages the Paddle tree is not allowed to shadow. The env directory is a
# full `pip install --target` tree, so it also carries numpy, Pillow and cv2 —
# versions that must not replace the ones torch and OpenCV were built against.
# Loading the shared libs first means Paddle reuses the already-imported ones
# instead of dragging in its own copies.
_SHARED_PRELOAD = ("numpy", "PIL.Image", "cv2")


def _bootstrap_paddle_path() -> None:
    """Put a matching Paddle stack ahead of site-packages, for good.

    The insertion has to outlive the import statement. PaddleOCR does not
    import ``paddle`` at module-import time — it does so lazily, while
    constructing the predictor and running inference. Scoping the path change
    to the ``from paddleocr import PaddleOCR`` statement therefore lets the
    real import happen after the path is gone, and it resolves against the
    mismatched copy in site-packages.

    The shared libraries are imported first, from the canonical location.
    paddle_env is a complete ``pip install --target`` tree carrying its own
    numpy, Pillow and cv2; letting those replace the versions torch and OpenCV
    were built against invites an ABI mismatch that only shows up much later.
    Loading them up front means Paddle reuses the copies already in
    ``sys.modules``.
    """
    import sys

    for name in _SHARED_PRELOAD:
        try:
            __import__(name)
        except Exception:
            pass

    for candidate in reversed(paddle_env_candidates()):
        try:
            if candidate.is_dir() and str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
        except OSError:
            continue


def paddle_available() -> bool:
    """Whether PaddleOCR is importable. Cheap — does not load models."""
    import importlib.util

    _bootstrap_paddle_path()
    try:
        return importlib.util.find_spec("paddleocr") is not None
    except Exception:
        return False


def last_error() -> str:
    """Why the local engine failed to load, for UI diagnostics."""
    return _paddle_error


def _model_search_dirs() -> list[Path]:
    root = Path(config.ROOT_DIR)
    return [
        d for d in (
            root / "models" / "ocr",
            root / "_internal" / "models" / "ocr",
            # Vendored weights travel with the checkout and with the bundle,
            # so OCR never reaches for the network or a home-directory cache.
            root / "vendor" / "ocr_models",
            Path(__file__).resolve().parent.parent / "vendor" / "ocr_models",
            Path(__file__).resolve().parent / "models" / "ocr",
        )
        if d.is_dir()
    ]


def _bundled_model_dir() -> Path | None:
    for directory in _model_search_dirs():
        if (directory / "det").is_dir() and (directory / "rec").is_dir():
            return directory
    return None


def _init_paddle(language: str | None = None) -> Any:
    """Load PaddleOCR once. Returns None when unavailable."""
    global _paddle_ocr, _paddle_failed, _paddle_error

    with _paddle_lock:
        if _paddle_ocr is not None or _paddle_failed:
            return _paddle_ocr

        _bootstrap_paddle_path()
        try:
            # Import paddle itself while the path is in place. PaddleOCR only
            # reaches for it lazily, and by then the search order matters just
            # as much.
            from paddleocr import PaddleOCR

            import paddle  # noqa: F401 - pinned here on purpose
        except Exception as exc:  # noqa: BLE001 - reported through last_error()
            _paddle_error = f"{type(exc).__name__}: {exc}"
            _paddle_failed = True
            return None

        kwargs: dict[str, Any] = {
            "lang": _paddle_lang(language),
            # Screen captures are upright UI images; the document pipeline
            # would only pull extra models we never exercise.
            "use_doc_orientation_classify": False,
            "use_doc_unwarping": False,
            "use_textline_orientation": False,
        }

        bundled = _bundled_model_dir()
        if bundled is not None:
            kwargs["det_model_dir"] = str(bundled / "det")
            kwargs["rec_model_dir"] = str(bundled / "rec")
            if (bundled / "cls").is_dir():
                kwargs["cls_model_dir"] = str(bundled / "cls")

        # Constructor flags get renamed across releases; drop anything this
        # version does not accept rather than failing outright.
        import inspect

        try:
            accepted = set(inspect.signature(PaddleOCR.__init__).parameters)
            if accepted:
                kwargs = {k: v for k, v in kwargs.items() if k in accepted}
        except (TypeError, ValueError):
            pass

        last_error: Exception | None = None
        for attempt in (kwargs, {"lang": _paddle_lang(language)}, {}):
            try:
                _paddle_ocr = PaddleOCR(**attempt)
                return _paddle_ocr
            except TypeError as exc:
                last_error = exc
                continue
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                break

        _paddle_error = str(last_error) if last_error else "unknown error"
        _paddle_failed = True
        return None


def _paddle_lang(language: str | None) -> str:
    table = {
        "chinese_simplified": "ch", "chinese": "ch", "ch": "ch",
        "english": "en", "en": "en",
        "chinese_traditional": "chinese_cht",
        "japanese": "japan", "ja": "japan",
        "korean": "korean", "ko": "korean",
        "russian": "ru", "ru": "ru",
    }
    return table.get((language or "").lower(), "ch")


def run_builtin(
    image_bytes: bytes,
    language: str | None = None,
) -> list[dict[str, Any]] | None:
    """Run local CPU PaddleOCR over PNG/JPEG bytes.

    Returns ``None`` when the engine is unavailable so the caller can report
    a clear, actionable message.
    """
    try:
        import numpy as np
        from PIL import Image
    except Exception:
        return None

    ocr = _init_paddle(language)
    if ocr is None:
        return None

    try:
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        array = np.array(image)
    except Exception:
        return None

    # PaddleOCR 3.x renamed the entry point (ocr() deprecated, `cls` gone),
    # so prefer predict() when present.
    if hasattr(ocr, "predict"):
        try:
            raw = ocr.predict(array)
        except Exception:
            return None
    else:
        try:
            raw = ocr.ocr(array, cls=True)
        except TypeError:
            try:
                raw = ocr.ocr(array)
            except Exception:
                return None
        except Exception:
            return None

    return _normalise_paddle(raw)


# ── Result normalisation ────────────────────────────────────────────────

def _as_list(value: Any) -> list:
    if value is None:
        return []
    if hasattr(value, "tolist") and not isinstance(value, (list, tuple)):
        try:
            value = value.tolist()
        except Exception:
            return []
    if isinstance(value, (list, tuple)):
        return list(value)
    try:
        return [value]
    except Exception:
        return []


def _as_mapping(obj: Any) -> dict[str, Any] | None:
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "keys") and hasattr(obj, "__getitem__"):
        try:
            return {k: obj[k] for k in obj.keys()}
        except Exception:
            pass
    if hasattr(obj, "__dict__"):
        try:
            return dict(vars(obj))
        except Exception:
            pass
    return None


def _box_to_list(box: Any) -> list[float]:
    """Flatten ``[[x,y], ...]`` or ``[x, y, x, y, ...]`` into flat numbers.

    PaddleOCR returns numpy arrays, so avoid truth-value tests on them
    (``if not box`` raises "truth value is ambiguous"); check length instead.
    """
    if box is None:
        return []

    if hasattr(box, "tolist") and not isinstance(box, (list, tuple)):
        try:
            box = box.tolist()
        except Exception:
            return []

    if isinstance(box, (list, tuple)):
        if len(box) == 0:
            return []
        first = box[0]
        if isinstance(first, (list, tuple)) or (
            hasattr(first, "tolist") and not isinstance(first, (int, float))
        ):
            flat: list[float] = []
            for point in box:
                if hasattr(point, "tolist") and not isinstance(point, (list, tuple)):
                    point = point.tolist()
                if isinstance(point, (list, tuple)):
                    flat.extend(float(v) for v in point)
                else:
                    try:
                        flat.append(float(point))
                    except Exception:
                        pass
            return flat
        try:
            return [float(v) for v in box]
        except Exception:
            return []

    try:
        return [float(box)]
    except Exception:
        return []


def _from_mapping(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Build results from a 3.x ``{rec_texts, rec_scores, rec_polys}`` dict."""
    texts = _as_list(data.get("rec_texts"))
    if not texts:
        return []
    scores = _as_list(data.get("rec_scores"))
    polys = (
        _as_list(data.get("rec_polys"))
        or _as_list(data.get("dt_polys"))
        or _as_list(data.get("rec_boxes"))
    )
    out: list[dict[str, Any]] = []
    for i, text in enumerate(texts):
        score = scores[i] if i < len(scores) else 0.0
        out.append({
            "text": str(text),
            "confidence": round(float(score), 4),
            "box": _box_to_list(polys[i]) if i < len(polys) else [],
        })
    return out


def _normalise_paddle(raw: Any) -> list[dict[str, Any]]:
    """Flatten PaddleOCR output into our normalised list.

    Handles both the 3.x ``predict()`` result objects and the legacy 2.x
    nested ``[[box, (text, score)], ...]`` lists.
    """
    results: list[dict[str, Any]] = []
    if raw is None:
        return results

    if not isinstance(raw, (list, tuple)):
        raw = [raw]
    try:
        items = list(raw)
    except TypeError:
        return results

    mappings = [m for m in (_as_mapping(i) for i in items) if m]
    if mappings and any("rec_texts" in m for m in mappings):
        for mapping in mappings:
            results.extend(_from_mapping(mapping))
        return results

    for page in items:
        if not page:
            continue
        for item in page:
            try:
                box, recognition = item[0], item[1]
                text, score = recognition[0], recognition[1]
            except Exception:
                continue
            results.append({
                "text": str(text),
                "confidence": round(float(score), 4),
                "box": _box_to_list(box),
            })
    return results


# ── HTTP engine ─────────────────────────────────────────────────────────

def run_http(image_bytes: bytes, language: str | None = None) -> list[dict[str, Any]]:
    """Send the screenshot to an external Umi-OCR / PaddleOCR-Serving API.

    Raises ``RuntimeError`` with an actionable message on failure.
    """
    import base64
    import json

    requests = None
    try:
        import requests as _requests  # type: ignore

        requests = _requests
    except Exception:
        from urllib import request as urllib_request  # noqa: F401

    payload = json.dumps(_build_payload(image_bytes, language)).encode("utf-8")
    headers = {"Content-Type": "application/json"}

    if requests is not None:
        session = requests.Session()
        # localhost must bypass any system proxy
        session.trust_env = False
        try:
            response = session.post(
                config.OCR_URL, data=payload, headers=headers,
                timeout=config.OCR_TIMEOUT,
            )
            response.raise_for_status()
            raw = response.json()
        except Exception as e:
            raise RuntimeError(f"OCR request failed — {type(e).__name__}: {e}") from e
    else:
        from urllib import request as urlrequest

        req = urlrequest.Request(config.OCR_URL, data=payload, headers=headers)
        try:
            with urlrequest.urlopen(req, timeout=config.OCR_TIMEOUT) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            raise RuntimeError(f"OCR request failed — {type(e).__name__}: {e}") from e

    data = raw.get("data", raw) if isinstance(raw, dict) else raw
    if not data:
        return []

    results: list[dict[str, Any]] = []
    for item in data:
        text = item.get("text", "")
        confidence = item.get("confidence", item.get("score", 0))
        box = item.get("box", [])
        if box and isinstance(box[0], list):
            box = [value for point in box for value in point]
        results.append({
            "text": text,
            "confidence": round(float(confidence), 4),
            "box": box,
        })
    return results


def _build_payload(image_bytes: bytes, language: str | None) -> dict[str, Any]:
    import base64

    http_languages = {
        "chinese_simplified": "models/config_chinese.txt",
        "english": "models/config_en.txt",
        "chinese_traditional": "models/config_chinese_cht.txt",
        "japanese": "models/config_japan.txt",
        "korean": "models/config_korean.txt",
        "russian": "models/config_cyrillic.txt",
    }
    options: dict[str, Any] = {
        "ocr.cls": True,
        "tbpu.parser": "multi_para",
    }
    if language in http_languages:
        options["ocr.language"] = http_languages[language]
    return {
        "base64": base64.b64encode(image_bytes).decode("ascii"),
        "options": options,
    }
