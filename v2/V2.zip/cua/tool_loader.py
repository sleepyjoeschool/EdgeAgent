"""Loads tool definitions from JSON files and manages the tool registry.

Tool definitions live in ``prompt-content-json/`` so they can be edited
without touching Python. ``LoadSkillCategory`` pulls one category into the
active tool set at runtime, keeping the initial schema small.
"""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

from . import config, modes

PROMPT_JSON_DIR = config.PROMPT_JSON_DIR

CATEGORY_MAP: dict[str, str] = {
    "keyboard": "Keyboard_Action.json",
    "mouse": "Mouse_Action.json",
    "shell": "Shell_Action.json",
    "screen_capture": "Screen_Capture.json",
    "vlm": "VLM_Action.json",
    "basic": "Basic_Function.json",
    # External connectors (MCP stdio servers).
    "codemodify": "CodeModify_Scheme.json",
    "fullchrome": "FullChrome_Scheme.json",
    "ssh": "SSH_Scheme.json",
}


class ToolLoadError(Exception):
    """Raised when a tool definition file is missing or malformed."""


@lru_cache(maxsize=32)
def _load_json(filename: str) -> dict[str, Any]:
    path = PROMPT_JSON_DIR / filename
    if not path.is_file():
        raise ToolLoadError(f"tool definition file not found: {path}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ToolLoadError(f"{path.name} is not valid JSON: {e}") from e


def clear_cache() -> None:
    """Drop cached definitions (used after editing the JSON files live)."""
    _load_json.cache_clear()


def load_entry_point() -> dict[str, Any]:
    """Load the entry point definition (system prompt + meta tools)."""
    return _load_json("Entry_Point.json")


def system_prompt(extra: str = "") -> str:
    """Return the system prompt, optionally with a runtime addendum."""
    base = load_entry_point()["system_prompt"]
    # Rule: prefer external connectors over generic built-in tools.
    priority = load_entry_point().get("connector_priority_rule")
    if priority:
        base = f"{base}\n\n{priority}"
    if extra:
        return f"{base}\n\n{extra}"
    return base


def connector_priority_rule() -> str:
    """The 'prefer connectors' governance rule, if defined."""
    return load_entry_point().get("connector_priority_rule", "")


def load_category_tools(category: str) -> list[dict[str, Any]]:
    """Load the tools array for a given skill category."""
    if category not in CATEGORY_MAP:
        raise ValueError(
            f"Unknown category '{category}'. Valid: {sorted(CATEGORY_MAP)}"
        )
    data = _load_json(CATEGORY_MAP[category])
    return [dict(tool) for tool in data.get("tools", [])]


def get_category_description(category: str) -> str:
    """Return a human-readable description of a category."""
    cats = load_entry_point().get("available_categories", {})
    info = cats.get(category)
    return info.get("description", "") if isinstance(info, dict) else ""


def available_categories() -> dict[str, dict]:
    """Return the category metadata advertised to the model."""
    return load_entry_point().get("available_categories", {})


def categories_for_mode(mode: str | None) -> list[str]:
    """Category names loadable in *mode*, in declaration order.

    The JSON defines one superset of categories; this narrows it to what
    the mode permits, so callers that build UI lists or enumerate the
    catalogue do not have to remember the policy themselves.
    """
    return [
        name for name in CATEGORY_MAP
        if modes.category_allowed(name, mode)
    ]


def tools_for_mode(mode: str | None) -> list[dict[str, Any]]:
    """Every tool callable in *mode*, flattened across categories."""
    tools: list[dict[str, Any]] = []
    for category in categories_for_mode(mode):
        try:
            for tool in load_category_tools(category):
                if modes.tool_allowed(tool["function"]["name"], mode):
                    tools.append(dict(tool))
        except (ToolLoadError, ValueError):
            continue
    return tools


def all_tool_names() -> list[str]:
    """Every tool name across all categories (used for diagnostics)."""
    names: list[str] = []
    for category in CATEGORY_MAP:
        try:
            for tool in load_category_tools(category):
                names.append(tool["function"]["name"])
        except (ToolLoadError, ValueError):
            continue
    return names
