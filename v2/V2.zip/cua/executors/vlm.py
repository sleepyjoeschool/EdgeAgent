"""VLM executor — multimodal screen / image analysis.

Two backends satisfy these tools, and which one is correct depends on the
vision mode, not on the tool name:

* ``multimodal`` — the main model reads the image itself, so the picture is
  attached to its own conversation (``inline_vision``). There is no separate
  VLM endpoint in this mode at all, and asking for one reported
  "VLM is not configured" on a perfectly working setup — which is what the
  operator saw, while the very next step (``CaptureScreenInline``) succeeded.
* ``text_vlm`` — the main model cannot see, so a dedicated VLM endpoint does
  the looking and returns prose.

``resolve_vision_mode()`` only ever yields those two (see config), so there is
no third "vision disabled" branch to handle here.
"""

from __future__ import annotations

import base64
import io

from .. import config, desktop, inline_vision, multimodal


def execute(function_name: str, arguments: dict, ctx) -> str:
    handlers = {
        "VLM_Action_AnalyzeScreen": _analyze_screen,
        "VLM_Action_AnalyzeImage": _analyze_image,
    }
    handler = handlers.get(function_name)
    if handler is None:
        return f"Error: unknown VLM function '{function_name}'"
    ctx.check_stop()
    try:
        return handler(arguments, ctx)
    except multimodal.VLMError as e:
        return str(e) if str(e).startswith("Error:") else f"Error: {e}"
    except Exception as e:
        return f"Error: VLM inference failed — {type(e).__name__}: {e}"


def _no_conversation_message() -> str:
    """For inline mode reached without a live conversation to attach to.

    Real but rare: a headless run has no chat to put the image in. Naming a
    working alternative matters more than the diagnosis — this error is only
    useful if it tells the model what to do instead.
    """
    return (
        "Error: cannot attach the image — this run has no live conversation to "
        "attach it to. Use ScreenCaptureAction_CaptureScreen (OCR) or "
        "ScreenCaptureAction_DetectObjects (YOLO), which return text and need "
        "no conversation, or configure a separate VLM and switch Vision Mode "
        "to 'text_vlm'."
    )


def _analyze_screen(args: dict, ctx) -> str:
    prompt = (args.get("PromptString") or "").strip()
    if not prompt:
        return "Error: PromptString is empty"

    # Multimodal: hand the screen to the main model, exactly as
    # CaptureScreenInline does. Reached before the VLM path so this tool works
    # in the mode where a separate VLM is not supposed to exist.
    if inline_vision.is_inline_mode():
        if ctx is None or getattr(ctx, "messages", None) is None:
            return _no_conversation_message()
        try:
            return inline_vision.inject_screenshot(ctx.messages, prompt=prompt)
        except RuntimeError as e:
            return f"Error: {e}"
        except Exception as e:  # noqa: BLE001 - reported to the model as text
            return f"Error: failed to attach screen — {type(e).__name__}: {e}"

    try:
        screenshot = desktop.screenshot(region=desktop.work_region())
    except Exception as e:
        return f"Error: failed to capture screen — {e}"

    if multimodal.has_pil():
        answer, reasoning = multimodal.analyze_pil_image(screenshot, prompt)
    else:
        buffer = io.BytesIO()
        screenshot.save(buffer, format="PNG")
        image_b64 = base64.b64encode(buffer.getvalue()).decode("ascii")
        answer, reasoning = multimodal.analyze_image(image_b64, prompt)

    return _format_result(answer, reasoning)


def _analyze_image(args: dict, ctx) -> str:
    image_b64 = args.get("ImgBase64") or ""
    prompt = (args.get("PromptString") or "").strip()
    if not image_b64:
        return "Error: ImgBase64 is empty"
    if not prompt:
        return "Error: PromptString is empty"

    # Same split as _analyze_screen: the main model can read a caller-supplied
    # image too, so this is not a VLM-only tool.
    if inline_vision.is_inline_mode():
        if ctx is None or getattr(ctx, "messages", None) is None:
            return _no_conversation_message()
        try:
            data, mime = multimodal.normalize_b64(image_b64)
            return inline_vision.attach_image(ctx.messages, data, prompt, mime)
        except multimodal.VLMError as e:
            return f"Error: {e}"
        except Exception as e:  # noqa: BLE001 - reported to the model as text
            return f"Error: failed to attach image — {type(e).__name__}: {e}"

    answer, reasoning = multimodal.analyze_image(image_b64, prompt)
    return _format_result(answer, reasoning)


def _format_result(answer: str, reasoning: str = "") -> str:
    answer = (answer or "").strip()
    reasoning = (reasoning or "").strip()
    if not answer:
        return "Error: the multimodal backend returned empty content"
    if reasoning and reasoning != answer:
        return f"[reasoning]\n{reasoning}\n\n[answer]\n{answer}"
    return f"[answer]\n{answer}"


def describe_backend() -> str:
    return multimodal.describe()


def test_backend() -> tuple[bool, str]:
    return multimodal.test_connection()
