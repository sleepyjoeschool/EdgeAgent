"""Tool dispatcher.

Every executor exposes the same signature ``execute(fn, args, ctx) -> str``
and returns plain strings. Errors start with ``Error:``; safety refusals
start with ``SAFETY BLOCK``. The core relies on those prefixes to decide
whether a tool round succeeded and to colour the result in the UI.

Executors are imported lazily so a mission that never touches YOLO never
pays for importing ultralytics.
"""

from __future__ import annotations

import importlib
from typing import Callable

from .. import modes

_PREFIX_ROUTES: list[tuple[str, str]] = [
    ("KeyboardAction_", "keyboard"),
    ("MouseAction_", "mouse"),
    ("ShellAction_", "shell"),
    ("ScreenCaptureAction_", "screen_capture"),
    ("VLM_Action_", "vlm"),
    ("BasicFunction_", "basic"),
    # External connectors (MCP stdio servers) — all three bridge to connector.py.
    ("CodeModify_", "connector"),
    ("FullChrome_", "connector"),
    ("SSH_", "connector"),
]

_CACHE: dict[str, Callable] = {}

# Meta tools are owned by the core loop, not by an executor.
META_TOOLS = frozenset({
    "LoadSkillCategory",
    "ListSkillResults",
    "DeleteSkillResult",
})


def _resolve(module_name: str) -> Callable:
    if module_name not in _CACHE:
        module = importlib.import_module(f".{module_name}", __package__)
        _CACHE[module_name] = module.execute
    return _CACHE[module_name]


def is_supported(function_name: str) -> bool:
    """Whether some executor claims this tool name."""
    return any(function_name.startswith(prefix) for prefix, _ in _PREFIX_ROUTES)


def _mode_of(ctx) -> str:
    """The operating mode of the mission owning this call.

    ``getattr`` rather than a direct attribute: ``dispatch`` is reached
    from tests and from the packaged smoke check with a bare
    ``ToolContext()``, and a missing mode must degrade to GUI instead of
    raising out of the dispatcher.
    """
    return modes.normalize(getattr(ctx, "agent_mode", None))


def dispatch(function_name: str, arguments: dict, ctx) -> str:
    """Route a function call to its executor by name prefix.

    In CIL mode a desktop tool is refused before any executor sees it.
    Loading is blocked too, but that is a convention the model can
    ignore — it can name a tool it never loaded, so the check
    that actually holds has to live here as well.
    """
    if not modes.tool_allowed(function_name, _mode_of(ctx)):
        return modes.desktop_only_tool_reason(
            function_name, modes.alternative_for(function_name),
        )
    for prefix, module_name in _PREFIX_ROUTES:
        if function_name.startswith(prefix):
            try:
                handler = _resolve(module_name)
            except Exception as e:
                return f"Error: failed to load executor '{module_name}' — {e}"
            return handler(function_name, arguments, ctx)
    return f"Error: unrecognized function '{function_name}'"


def describe_perception() -> dict[str, str]:
    """Perception-layer diagnostics surfaced on the WebUI status card."""
    from .screen_capture import describe_perception as _describe

    return _describe()
