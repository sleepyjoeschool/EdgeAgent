"""Screen capture executor: OCR text, YOLO objects, inline screenshots.

Perception is deliberately layered — each layer answers a different question
and costs a different amount:

    OCR          what does the screen *say*      (cheap, offline)
    YOLO         where are things                (medium, local model)
    inline/VLM   what does it *mean*             (expensive, remote)

The system prompt steers the model toward the cheapest layer that answers
the question.
"""

from __future__ import annotations

import base64
import concurrent.futures as _futures
import io
import json
import os
import time
from pathlib import Path
from typing import Any, Callable

from .. import config, inline_vision, ocr_engine
from ..runtime import Aborted

LANGUAGE_MAP = {
    "chinese_simplified": "models/config_chinese.txt",
    "english": "models/config_en.txt",
    "chinese_traditional": "models/config_chinese_cht.txt",
    "japanese": "models/config_japan.txt",
    "korean": "models/config_korean.txt",
    "russian": "models/config_cyrillic.txt",
}


def execute(function_name: str, arguments: dict, ctx) -> str:
    handlers = {
        "ScreenCaptureAction_CaptureScreen": _capture_screen,
        "ScreenCaptureAction_DetectObjects": _detect_objects,
        "ScreenCaptureAction_CaptureScreenInline": _capture_screen_inline,
    }
    handler = handlers.get(function_name)
    if handler is None:
        return f"Error: unknown screen capture function '{function_name}'"
    ctx.check_stop()
    try:
        return handler(arguments, ctx)
    except Aborted:
        raise
    except Exception as e:
        return f"Error: screen capture failed — {type(e).__name__}: {e}"


# ── Perception worker ───────────────────────────────────────────────────
#
# PaddleOCR init and the first YOLO load each cost tens of seconds on CPU,
# and both can hang outright on a loaded machine. The engine loop runs tools
# inline, so that hang used to wedge the whole mission: the tool card sat on
# 运行中 forever, the watchdog never fired (it only guards the LLM stream),
# and even 中断 was dead because check_stop() is only reached between tools.
#
# Local inference therefore runs on one dedicated daemon worker with a hard
# deadline. On timeout the model gets an actionable error and the mission
# keeps moving; the wait polls check_stop() so the operator stays in control.
# A single worker also pins paddle/torch to one thread — neither is
# thread-safe — and lets the warm engine serve every later call.

_LOCAL_POLL_SECONDS = 0.5

_local_pool: _futures.ThreadPoolExecutor | None = None


def _get_local_pool() -> _futures.ThreadPoolExecutor:
    global _local_pool
    if _local_pool is None:
        _local_pool = _futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="cua-perception",
        )
    return _local_pool


class _LocalTimeout(Exception):
    """Local inference blew past its deadline; message is operator-ready."""


def _run_local(
    fn: Callable[[], Any],
    timeout: float,
    label: str,
    hint: str,
    ctx=None,
) -> Any:
    """Run heavy local inference on the perception worker under a deadline.

    ``ctx`` is the mission's ToolContext when a mission is waiting — polling
    ``check_stop()`` is what lets 中断 cut short a stuck call. Without one
    (startup warm-up) the wait simply runs to the deadline.
    """
    future = _get_local_pool().submit(fn)
    deadline = time.monotonic() + max(float(timeout), 1.0)
    while True:
        try:
            return future.result(timeout=_LOCAL_POLL_SECONDS)
        except _futures.TimeoutError:
            if ctx is not None:
                ctx.check_stop()
            if time.monotonic() >= deadline:
                raise _LocalTimeout(
                    f"{label}超过 {int(timeout)} 秒未完成，已放弃本次调用。"
                    f"{hint}"
                ) from None
        except Aborted:
            # The mission is going away either way; leave without waiting on
            # a job that may never finish. The worker thread is a daemon, so
            # it cannot block process exit either.
            raise


def warmup() -> None:
    """Pre-load the local OCR/YOLO engines on the perception worker.

    Called once at server start. Every cost paid here — paddle import, model
    load, ultralytics first import — is a cost the first real mission does
    not pay mid-step, which is exactly where a slow load used to look like a
    hang. Best-effort: failures surface through the tools themselves.
    """
    def _warm() -> None:
        engine = (getattr(config, "OCR_ENGINE", "builtin") or "builtin").strip().lower()
        if engine == "builtin":
            ocr_engine._init_paddle()
        mode = (getattr(config, "YOLO_INFERENCE_MODE", "bundled") or "bundled").strip().lower()
        if mode in ("bundled", "local"):
            try:
                _get_yolo()
            except Exception:
                pass  # the tool reports the real error when it is used

    deadline = max(config.OCR_LOCAL_TIMEOUT, config.YOLO_LOCAL_TIMEOUT) * 2
    try:
        _run_local(_warm, deadline, "感知引擎预热", "", ctx=None)
    except Exception:
        pass  # warm-up is advisory; nothing here may block startup


# ── OCR ─────────────────────────────────────────────────────────────────

def _capture_screen(args: dict, ctx) -> str:
    language = args.get("language") or None
    engine = (getattr(config, "OCR_ENGINE", "builtin") or "builtin").strip().lower()

    if engine == "off":
        return (
            "Error: OCR is disabled (OCR_ENGINE=off). Enable it in Settings → "
            "视觉 → OCR 引擎."
        )

    try:
        image_bytes = _screenshot_bytes()
    except RuntimeError as e:
        return f"Error: {e}"

    if engine == "http":
        try:
            results = ocr_engine.run_http(image_bytes, language)
        except RuntimeError as e:
            return f"Error: {e}"
        return _render(results)

    try:
        results = _run_local(
            lambda: ocr_engine.run_builtin(image_bytes, language),
            config.OCR_LOCAL_TIMEOUT,
            "本地 OCR",
            "若反复出现，请检查 PaddleOCR 安装（'pip install paddlepaddle paddleocr'），"
            "或在 设置 → 视觉 中把 OCR 引擎切换为 http / off。",
            ctx=ctx,
        )
    except _LocalTimeout as e:
        return f"Error: {e}"
    if results is None:
        detail = ocr_engine.last_error()
        compat = ocr_engine.compatibility_note()
        suffix = f" ({detail})" if detail else ""
        if compat:
            return f"Error: built-in PaddleOCR is unavailable — {compat}"
        return (
            f"Error: built-in PaddleOCR is unavailable{suffix}. Install it with "
            f"'pip install paddlepaddle paddleocr', set OCR Engine to 'http' "
            f"to use an external Umi-OCR service, or turn it off."
        )
    return _render(results)


def _render(results: list[dict[str, Any]]) -> str:
    if not results:
        return "[]"
    # Sorted top-to-bottom, left-to-right so the model reads in scan order
    # rather than whatever order the detector emitted.
    ordered = sorted(results, key=_sort_key)
    return json.dumps(ordered, ensure_ascii=False)


def _sort_key(item: dict[str, Any]) -> tuple[float, float]:
    box = item.get("box") or []
    if len(box) >= 2:
        try:
            ys = [float(box[i]) for i in range(1, len(box), 2)]
            xs = [float(box[i]) for i in range(0, len(box), 2)]
            return (min(ys), min(xs))
        except (TypeError, ValueError):
            pass
    return (0.0, 0.0)


def _screenshot_bytes() -> bytes:
    from .. import desktop

    # region=None means "the agent's view": the whole screen in primary mode,
    # the workspace rectangle otherwise. Every perception path funnels through
    # here so the model never sees a screen it is not allowed to touch.
    screenshot = desktop.screenshot(region=desktop.work_region())
    buffer = io.BytesIO()
    screenshot.save(buffer, format="PNG")
    return buffer.getvalue()


# ── Inline (multimodal main model) ──────────────────────────────────────

def _capture_screen_inline(args: dict, ctx) -> str:
    """Attach the screen to the live conversation as an image message."""
    from .. import inline_vision

    if not inline_vision.is_inline_mode():
        # Names the two perception paths that *do* work here. The old text
        # pointed at "VLM_Action_AnalyzeScreen (separate VLM)" as the
        # alternative, which is wrong in this mode — that tool answers with
        # "VLM is not configured" for the same reason this one says the main
        # model cannot see.
        return (
            "Error: Vision Mode is 'text_vlm', so the main model cannot see "
            "images. Use ScreenCaptureAction_CaptureScreen (OCR, text) or "
            "ScreenCaptureAction_DetectObjects (YOLO, positions), which work "
            "without a vision-capable main model. To see the screen directly, "
            "set Vision Mode to 'multimodal' and use a vision-capable main "
            "model."
        )

    prompt = (args.get("PromptString") or "").strip() or (
        "Here is a screenshot of the current screen. Use it to decide what to do next."
    )
    try:
        return inline_vision.inject_screenshot(ctx.messages, prompt=prompt)
    except RuntimeError as e:
        return f"Error: {e}"


# ── YOLO object detection ───────────────────────────────────────────────

def _detect_objects(args: dict, ctx) -> str:
    try:
        threshold = float(args.get("confidence_threshold", 0.5))
    except (TypeError, ValueError):
        threshold = 0.5
    threshold = max(0.0, min(1.0, threshold))

    mode = (getattr(config, "YOLO_INFERENCE_MODE", "bundled") or "bundled").strip().lower()
    if mode == "off":
        return (
            "Error: object detection is disabled (YOLO_INFERENCE_MODE=off). "
            "Change it in Settings → 视觉 → YOLO 模式."
        )
    if mode == "cloud":
        return _detect_cloud(threshold)
    return _detect_local(threshold, ctx)


def _resolve_model_path() -> str:
    """Resolve local YOLO weights, preferring anything bundled in models/."""
    configured = (config.YOLO_MODEL_PATH or "").strip()
    if configured and os.path.exists(configured):
        return configured

    models_dir = Path(config.ROOT_DIR) / "models"
    if models_dir.is_dir():
        for pattern in ("*.pt", "*.onnx", "*.pth"):
            found = sorted(models_dir.glob(pattern))
            if found:
                return str(found[0])
    return configured


_yolo = None


def _get_yolo():
    global _yolo
    if _yolo is None:
        try:
            # Ultralytics phones home (update checks, hub sync) on first
            # import unless told not to; on an offline box those calls are
            # where a "slow first load" turns into a hang.
            os.environ.setdefault("YOLO_OFFLINE", "1")
            from ultralytics import YOLO
        except Exception as e:
            raise RuntimeError(
                "ultralytics is not installed — install it with "
                f"'pip install ultralytics' ({type(e).__name__}: {e})"
            ) from e
        path = _resolve_model_path()
        if not path or not os.path.exists(path):
            raise FileNotFoundError(
                f"YOLO weights not found at '{path or '(unset)'}'. "
                f"Place a .pt file in models/, or point YOLO_MODEL_PATH at one."
            )
        _yolo = YOLO(path)
    return _yolo


def _infer_yolo(image, threshold: float) -> str:
    """Load + run YOLO and return the JSON result (or an Error: string).

    Runs on the perception worker — see the worker block above for why it
    must never run on the engine loop thread.
    """
    try:
        yolo = _get_yolo()
        predictions = yolo(image, verbose=False)
    except FileNotFoundError as e:
        return f"Error: {e}"
    except RuntimeError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: YOLO inference failed — {type(e).__name__}: {e}"

    results: list[dict[str, Any]] = []
    for prediction in predictions:
        boxes = getattr(prediction, "boxes", None)
        if boxes is None:
            continue
        names = getattr(prediction, "names", {})
        for index in range(len(boxes)):
            confidence = float(boxes.conf[index])
            if confidence < threshold:
                continue
            class_id = int(boxes.cls[index])
            results.append({
                "class": names.get(class_id, str(class_id)),
                "confidence": round(confidence, 4),
                "box": [round(float(v), 1) for v in boxes.xyxy[index].tolist()],
            })
    return json.dumps(results, ensure_ascii=False)


def _detect_local(threshold: float, ctx) -> str:
    try:
        import numpy as np

        screenshot = _screenshot_image()
        image = np.array(screenshot)
    except RuntimeError as e:
        return f"Error: {e}"

    try:
        return _run_local(
            lambda: _infer_yolo(image, threshold),
            config.YOLO_LOCAL_TIMEOUT,
            "本地 YOLO",
            "若反复出现，请检查 ultralytics 与模型权重（models/ 目录），"
            "或在 设置 → 视觉 中把 YOLO 模式切换为 cloud / off。",
            ctx=ctx,
        )
    except _LocalTimeout as e:
        return f"Error: {e}"


def _screenshot_image():
    from .. import desktop

    return desktop.screenshot(region=desktop.work_region())


def _detect_cloud(threshold: float) -> str:
    if not config.YOLO_CLOUD_API_KEY:
        return (
            "Error: YOLO cloud mode needs an API key (YOLO_CLOUD_API_KEY). "
            "Configure it in Settings, or switch YOLO mode to 'bundled'."
        )
    session_module = None
    try:
        import requests as session_module  # type: ignore
    except Exception:
        return "Error: the 'requests' package is required for cloud YOLO"

    try:
        image_bytes = _screenshot_bytes()
    except RuntimeError as e:
        return f"Error: {e}"

    payload = {"image": base64.b64encode(image_bytes).decode("ascii")}
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": config.YOLO_CLOUD_API_KEY,
    }

    session = session_module.Session()
    session.trust_env = False
    try:
        response = session.post(
            config.YOLO_CLOUD_API_URL,
            json=payload,
            headers=headers,
            timeout=60,
        )
        if response.status_code == 403:
            return "Error: YOLO cloud API returned 403 — invalid API key"
        response.raise_for_status()
        raw = response.json()
    except Exception as e:
        return f"Error: YOLO cloud request failed — {type(e).__name__}: {e}"

    results: list[dict[str, Any]] = []
    for detection in raw.get("detections", []) or []:
        confidence = float(detection.get("confidence", 0))
        if confidence < threshold:
            continue
        results.append({
            "class": detection.get("class_name", str(detection.get("class_id", ""))),
            "confidence": round(confidence, 4),
            "box": [
                detection.get("x1"), detection.get("y1"),
                detection.get("x2"), detection.get("y2"),
            ],
        })
    return json.dumps(results, ensure_ascii=False)


# ── Diagnostics used by the WebUI ───────────────────────────────────────

def describe_perception() -> dict[str, str]:
    engine = (getattr(config, "OCR_ENGINE", "builtin") or "builtin").lower()
    yolo_mode = (getattr(config, "YOLO_INFERENCE_MODE", "bundled") or "bundled").lower()
    return {
        "ocr_engine": engine,
        "ocr_ready": str(engine == "http" or ocr_engine.paddle_available()),
        "yolo_mode": yolo_mode,
        "yolo_weights": _resolve_model_path() or "(none found)",
        "vision_mode": config.resolve_vision_mode(),
    }
