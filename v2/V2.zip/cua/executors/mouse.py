"""Mouse action executor (pyautogui)."""

from __future__ import annotations

from .. import desktop


def execute(function_name: str, arguments: dict, ctx) -> str:
    handlers = {
        "MouseAction_GetPosition": _get_position,
        "MouseAction_InstantMove": _instant_move,
        "MouseAction_MovementWithDelay": _movement_with_delay,
        "MouseAction_LeftClick": _left_click,
        "MouseAction_RightClick": _right_click,
        "MouseAction_LeftDoubleClick": _left_double_click,
        "MouseAction_Scroll": _scroll,
    }
    handler = handlers.get(function_name)
    if handler is None:
        return f"Error: unknown mouse function '{function_name}'"
    pag = desktop.pyautogui()
    if pag is None:
        return desktop.unavailable_message("pyautogui")
    ctx.check_stop()
    try:
        return handler(pag, arguments)
    except Exception as e:
        return f"Error: mouse action failed — {type(e).__name__}: {e}"


def _coords(args: dict) -> tuple[int, int, str | None]:
    """Read and translate a point from the model's coordinate space.

    The model reasons about the picture it was shown, which in workspace mode
    is a crop of the real screen whose origin is the region's top-left. Two
    things therefore have to happen here, and both matter:

    * the offset — otherwise a correct (100, 100) aimed at the crop lands
      wherever that offset takes it on the physical screen;
    * the clamp — models do emit coordinates a few pixels outside the image
      they were given, and without a ceiling a stray value reaches into the
      operator's half of the display.

    In primary mode both are the identity, so the default behaviour is
    byte-for-byte what it always was.
    """
    x = args.get("XCoordinate", 0)
    y = args.get("YCoordinate", 0)
    try:
        x, y = int(x), int(y)
    except (TypeError, ValueError):
        return 0, 0, "Error: coordinates must be integers"
    if x < 0 or y < 0:
        return x, y, "Error: coordinates must be >= 0"
    sx, sy = desktop.clamp_to_region(x, y)
    return sx, sy, None


def _view_point(x, y) -> tuple[int, int]:
    """A real screen point expressed in the model's coordinate space."""
    vx, vy = desktop.screen_to_view(int(x), int(y))
    return vx, vy


def _get_position(pag, _args: dict) -> str:
    # Reported back in the model's own coordinate space, not the OS one: a
    # position of "X:1860" when the model believes the screen is 1280 wide
    # reads as an impossible value and derails its next step.
    vx, vy = _view_point(*pag.position())
    return f"X:{vx}-Y:{vy}"


def _instant_move(pag, args: dict) -> str:
    x, y, err = _coords(args)
    if err:
        return err
    pag.moveTo(x, y)
    vx, vy = _view_point(x, y)
    return f"True: cursor moved to ({vx}, {vy})"


def _movement_with_delay(pag, args: dict) -> str:
    x, y, err = _coords(args)
    if err:
        return err
    try:
        duration = float(args.get("Duration", 1.0))
    except (TypeError, ValueError):
        return "Error: Duration must be a number"
    if duration <= 0:
        return "Error: Duration must be > 0"
    pag.moveTo(x, y, duration=duration)
    vx, vy = _view_point(x, y)
    return f"True: cursor moved to ({vx}, {vy}) over {duration}s"


def _left_click(pag, _args: dict) -> str:
    pag.click(button="left")
    vx, vy = _view_point(*pag.position())
    return f"True: left click at ({vx}, {vy})"


def _right_click(pag, _args: dict) -> str:
    pag.click(button="right")
    vx, vy = _view_point(*pag.position())
    return f"True: right click at ({vx}, {vy})"


def _left_double_click(pag, _args: dict) -> str:
    pag.doubleClick(button="left")
    vx, vy = _view_point(*pag.position())
    return f"True: double click at ({vx}, {vy})"


def _scroll(pag, args: dict) -> str:
    try:
        clicks = int(args.get("clicks", 0))
    except (TypeError, ValueError):
        return "Error: clicks must be an integer"
    if clicks == 0:
        return "Error: clicks must not be zero (positive = up, negative = down)"
    pag.scroll(clicks)
    direction = "up" if clicks > 0 else "down"
    return f"True: scrolled {direction} {abs(clicks)} notch(es)"
