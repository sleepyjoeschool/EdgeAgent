"""Shell action executor, with two-stage safety interception.

Stage 1 — static rules: regex and denylist patterns checked in-process.
Stage 2 — LLM audit + human approval (see ``security_check``).

Execution goes through :mod:`cua.backend` rather than calling ``subprocess``
here, so that moving the agent to another machine moves the shell with it.
See that module for what this does and does not protect against.
"""

from __future__ import annotations

import re

from .. import backend, security_check

SUSPICIOUS_PATTERNS = [
    re.compile(r"curl\s+.*\|\s*(ba)?sh", re.I),
    re.compile(r"wget\s+.*\|\s*(ba)?sh", re.I),
    re.compile(r"irm\s+.*\|\s*iex", re.I),
    re.compile(r"Invoke-Expression", re.I),
    re.compile(r"eval\s+", re.I),
    re.compile(r"base64\s+-d", re.I),
    re.compile(r"reg\s+(add|delete)", re.I),
    re.compile(r"Remove-Item\s+.*-Recurse\s+.*C:\\\\?", re.I),
]

DANGEROUS_COMMANDS = [
    "rm -rf /", "rd /s /q C:", "format C:", "del /f /s /q C:",
    "mkfs", "shutdown /s", "shutdown -h now", "diskpart",
]

# Path fragments that would reach outside the chosen workspace. Matched
# against the command *text*, which is the only thing available before it
# runs.
#
# This is a speed bump, not a sandbox. A determined command can still reach
# the disk by other means - write a script and run it, use a UNC path,
# resolve a variable set a step earlier. What it does buy is that an
# *accidental* reach is impossible and an *intended* one shows up as a
# refusal the operator sees, rather than a surprise they find afterwards.
# It only applies when the operator actually picked a workspace; with no
# workspace the old behaviour stands unchanged.
ESCAPE_PATTERNS = [
    re.compile(r"(?:\.\.[\\/]){2,}"),          # ../../  or  ..\..\
    re.compile(r"\b[A-Za-z]:[\\/]"),                # any absolute drive path
    re.compile(r"\\\\[A-Za-z0-9_.-]+\\"),        # \\server\share
    re.compile(r"~[\\/]"),                            # ~/  or  ~\
    re.compile(r"\$HOME\b|%USERPROFILE%|%HOMEPATH%", re.I),
]

SYNC_TIMEOUT = 120
MAX_OUTPUT_CHARS = 1500


def execute(function_name: str, arguments: dict, ctx) -> str:
    if function_name == "ShellAction_RunShell":
        return _run_shell(arguments, ctx)
    if function_name == "ShellAction_RunShellAsync":
        return _run_shell_async(arguments, ctx)
    return f"Error: unknown shell function '{function_name}'"


def _read(explanations: dict, key: str) -> str:
    value = explanations.get(key, "")
    return value.strip() if isinstance(value, str) else ""


def _workspace_of(ctx) -> str:
    """The directory this mission is scoped to, or "" when unrestricted."""
    runtime = getattr(ctx, "runtime", None)
    return str(getattr(runtime, "workspace", "") or "").strip()


def _workspace_block(shell_code: str, ctx) -> str | None:
    """Refuse a command that names a path outside the chosen workspace.

    Returns a reason string, or None when the command may run. Two independent
    conditions have to agree before anything is refused, because either alone
    produces false alarms that train the operator to click through the real
    ones:

    * the command must actually name an absolute or climbing path, and
    * the operator must have chosen a workspace to be bound by.

    With no workspace this returns None and the old behaviour stands, so nothing
    changes for missions that never picked one.
    """
    workspace = _workspace_of(ctx)
    if not workspace:
        return None
    for pattern in ESCAPE_PATTERNS:
        match = pattern.search(shell_code)
        if match:
            return (
                f"SAFETY BLOCK: the command reaches outside the workspace "
                f"({workspace}) - matched {match.group(0)!r}. Files may only be "
                f"read and written inside the chosen directory. Pick a wider "
                f"workspace, or clear it to lift this restriction."
            )
    return None


def _static_block(shell_code: str) -> str | None:
    """Stage 1. Returns a reason string or None when the command looks safe."""
    for pattern in SUSPICIOUS_PATTERNS:
        if pattern.search(shell_code):
            return (
                f"SAFETY BLOCK: the command matches suspicious pattern "
                f"'{pattern.pattern}'. This resembles a malware delivery "
                f"attempt. REFUSING to execute."
            )
    lowered = shell_code.lower()
    for dangerous in DANGEROUS_COMMANDS:
        if dangerous.lower() in lowered:
            return (
                f"SAFETY BLOCK: the command contains '{dangerous}', a "
                f"destructive operation. REFUSING to execute."
            )
    return None


def _authorize(shell_code: str, explanation: str, ctx) -> str | None:
    """Stage 2. Returns a refusal string, or None when cleared to run."""
    from .. import config

    if not config.SHELL_LLM_AUDIT:
        return None

    ctx.notice("Running security audit on shell command…", level="audit")
    verdict = security_check.run_audit(shell_code, explanation)

    if verdict.unavailable:
        # Blind spot: the auditor could not be reached, so nothing is known
        # about this command. The reference implementation let this fall
        # through silently, which meant a broken key quietly disabled the
        # safety net. Here the default is to ask instead.
        policy = (config.SHELL_AUDIT_FAILURE_POLICY or "ask").strip().lower()
        reason = (
            "the security audit could not run "
            f"({verdict.audit_error or 'endpoint unreachable'})"
        )
        ctx.notice(f"Security audit unavailable — {reason}. Policy: {policy}.", level="warn")
        if policy == "allow":
            return None
        if policy == "deny":
            return f"SAFETY BLOCK: {reason}, and AUDIT_FAILURE_POLICY=deny."
        approved = security_check.request_approval(
            _unavailable_verdict(reason), shell_code, ctx,
        )
        return None if approved else f"SAFETY BLOCK: Rejected, {reason}"

    if not verdict.dangerous:
        ctx.notice("Security audit passed.", level="audit")
        return None

    approved = security_check.request_approval(verdict, shell_code, ctx)
    if approved:
        ctx.notice("Dangerous command approved by operator.", level="warn")
        return None
    return f"SAFETY BLOCK: Rejected, {security_check.rejection_reason(verdict)}"


def _unavailable_verdict(reason: str):
    """Wrap an unreachable-auditor condition in the normal verdict shape."""
    from ..security_check import AuditVerdict

    return AuditVerdict(
        dangerous=True,
        risk=f"Unverified command — {reason}",
        parts=[{"part": "the whole command", "why": "no safety audit was possible"}],
    )


def _truncate(output: str) -> str:
    if len(output) <= MAX_OUTPUT_CHARS:
        return output
    head = output[:700]
    tail = output[-700:]
    return f"{head}\n... (truncated, {len(output)} chars total) ...\n{tail}"


def _run_shell(args: dict, ctx) -> str:
    shell_code = _read(args, "ShellCode")
    explanation = _read(args, "Explanation")
    if not shell_code:
        return "Error: ShellCode must not be empty"
    if not explanation:
        return "Error: Explanation must not be empty"

    ctx.check_stop()

    blocked = _static_block(shell_code)
    if blocked:
        return blocked

    blocked = _workspace_block(shell_code, ctx)
    if blocked:
        return blocked

    blocked = _authorize(shell_code, explanation, ctx)
    if blocked:
        return blocked

    ctx.check_stop()
    try:
        result = backend.get_backend().run_shell(
            shell_code, SYNC_TIMEOUT, cwd=_workspace_of(ctx) or None
        )
    except TimeoutError:
        backend.record_shell_activity(shell_code, None, False)
        return f"Error: command timed out after {SYNC_TIMEOUT} seconds"
    except Exception as e:
        backend.record_shell_activity(shell_code, None, False)
        return f"Error: {type(e).__name__}: {e}"

    # Recorded whatever the outcome: a command that failed still ran, and
    # "rm -rf ./x" erroring halfway is exactly what an operator wants to see.
    backend.record_shell_activity(shell_code, result.returncode, result.returncode == 0)

    output = (result.stdout or "").strip()
    if result.stderr:
        output = f"{output}\n[stderr]\n{result.stderr}".strip()
    if not output:
        return f"(exit code {result.returncode}, no output)"
    return _truncate(output)


def _run_shell_async(args: dict, ctx) -> str:
    shell_code = _read(args, "ShellCode")
    explanation = _read(args, "Explanation")
    if not shell_code:
        return "Error: ShellCode must not be empty"
    if not explanation:
        return "Error: Explanation must not be empty"

    ctx.check_stop()

    blocked = _static_block(shell_code)
    if blocked:
        return blocked

    blocked = _workspace_block(shell_code, ctx)
    if blocked:
        return blocked

    blocked = _authorize(shell_code, explanation, ctx)
    if blocked:
        return blocked

    ctx.check_stop()
    try:
        pid = backend.get_backend().spawn_shell(
            shell_code, cwd=_workspace_of(ctx) or None
        )
    except Exception as e:
        backend.record_shell_activity(shell_code, None, False)
        return f"Error launching process: {type(e).__name__}: {e}"
    # No exit code to report: these keep running after the tool returns, which
    # is why they are marked as launched rather than succeeded.
    backend.record_shell_activity(shell_code, None, True)
    return f"True: launched asynchronously (pid {pid}): {shell_code}"
