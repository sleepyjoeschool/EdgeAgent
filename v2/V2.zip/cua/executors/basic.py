"""Basic utility executor: counting, clipboard, waiting, human interaction.

Human-in-the-loop tools route through ``ctx.runtime`` instead of popping a
tkinter dialog, so the same executor works whether a browser, a terminal, or
nothing at all is attached to the mission.
"""

from __future__ import annotations

import time

from .. import desktop
from ..runtime import Denied, build_human_request


def execute(function_name: str, arguments: dict, ctx) -> str:
    handlers = {
        "BasicFunction_CountInGivenString": _count_in_string,
        "BasicFunction_CountNumbers": _count_numbers,
        "BasicFunction_WriteToClipboard": _write_clipboard,
        "BasicFunction_ReadFromClipboard": _read_clipboard,
        "BasicFunction_Wait": _wait,
        "BasicFunction_HumanOperation": _human_operation,
        "BasicFunction_HumanInput": _human_input,
    }
    handler = handlers.get(function_name)
    if handler is None:
        return f"Error: unknown basic function '{function_name}'"
    ctx.check_stop()
    try:
        return handler(arguments, ctx)
    except Denied as e:
        return f"SAFETY BLOCK: {e}"
    except Exception as e:
        return f"Error: basic function failed — {type(e).__name__}: {e}"


# ── Counting ───────────────────────────────────────────────────────────

def _count_in_string(args: dict, _ctx) -> str:
    full = args.get("full_string", "") or ""
    target = args.get("target", "") or ""
    if not full or not target:
        return "Error: full_string and target must not be empty"
    ignore_case = bool(args.get("ignore_case", False))
    if ignore_case:
        return str(full.lower().count(target.lower()))
    return str(full.count(target))


def _count_numbers(args: dict, _ctx) -> str:
    start = int(args.get("start", 0))
    end = int(args.get("end", 0))
    step = int(args.get("step", 1))
    separator = args.get("separator", ",")
    if step == 0:
        return "Error: step must not be zero"
    stop = end + 1 if step > 0 else end - 1
    numbers = range(start, stop, step)
    return separator.join(str(n) for n in numbers)


# ── Clipboard ──────────────────────────────────────────────────────────

def _write_clipboard(args: dict, _ctx) -> str:
    content = args.get("content", "") or ""
    if not content:
        return "Error: content must not be empty"
    clip = desktop.pyperclip()
    if clip is None:
        return desktop.unavailable_message("pyperclip")
    clip.copy(content)
    return "True"


def _read_clipboard(_args: dict, _ctx) -> str:
    clip = desktop.pyperclip()
    if clip is None:
        return desktop.unavailable_message("pyperclip")
    try:
        text = clip.paste()
    except Exception as e:
        return f"Error: clipboard read failed — {e}"
    return text if text else "(clipboard is empty)"


# ── Waiting ────────────────────────────────────────────────────────────

def _wait(args: dict, ctx) -> str:
    try:
        seconds = int(args.get("seconds", 1))
    except (TypeError, ValueError):
        return "Error: seconds must be an integer"
    seconds = max(1, min(600, seconds))
    # Sleep in slices so an abort during the wait is honoured promptly.
    deadline = time.time() + seconds
    while time.time() < deadline:
        ctx.check_stop()
        time.sleep(min(0.25, max(0.0, deadline - time.time())))
    return f"Waited {seconds} second(s)"


# ── Human interaction ──────────────────────────────────────────────────

def _human_operation(args: dict, ctx) -> str:
    """Ask the operator to perform a manual action and wait for the ack."""
    message = (args.get("message", "") or "").strip()
    if not message:
        return "Error: message must not be empty"
    request = build_human_request(message, kind="human_operation")
    try:
        ctx.emit_approval(request)
    except AttributeError:
        pass
    approved = ctx.runtime.approve(request)
    ctx.emit_approval_resolved(request, approved)
    if not approved:
        raise Denied("the operator declined the requested manual operation")
    return "User acknowledged the operation"


def _human_input(args: dict, ctx) -> str:
    """Ask the operator to type a value; returns what they entered."""
    message = (args.get("message", "") or "").strip()
    if not message:
        return "Error: message must not be empty"
    request = build_human_request(message, kind="human_input")
    try:
        ctx.emit_approval(request)
    except AttributeError:
        pass
    answer = ctx.runtime.ask_text(request)
    ctx.emit_approval_resolved(request, answer is not None)
    if answer is None:
        raise Denied("the operator did not provide the requested input")
    return answer
