"""Connector bridge executor.

Forwards tool calls whose name carries a connector prefix to that connector's
MCP (stdio) server. Two connectors ship wired in:

* ``CodeModify_`` -> **agent-fs**  (Python MCP server, ``CodeModify/agentfs.py mcp``)
* ``FullChrome_`` -> **agent-browser** (Node MCP server, ``FullChrome/src/mcp.js``)
* ``SSH_`` -> **ssh-client** (Python MCP server, ``ssh_client.mcp_server``)

The runtime command, arguments and working directory are resolved on every
call, environment first, so the connectors can live anywhere:

* ``CUA_CONNECTOR_KIT_DIR`` / ``CUA_SSH_CLIENT_DIR`` — roots of the kits
* ``CUA_CONNECTOR_CODEMODIFY_CMD`` / ``CUA_CONNECTOR_CODEMODIFY_ARGS`` /
  ``CUA_CONNECTOR_CODEMODIFY_CWD``
* ``CUA_CONNECTOR_FULLCHROME_CMD`` / ``CUA_CONNECTOR_FULLCHROME_ARGS`` /
  ``CUA_CONNECTOR_FULLCHROME_CWD``
* ``CUA_CONNECTOR_SSH_CMD`` / ``CUA_CONNECTOR_SSH_ARGS`` /
  ``CUA_CONNECTOR_SSH_CWD``

When nothing is configured, a connector is looked for under ``vendor/`` beside
this checkout. No machine-specific absolute path is baked in: a connector that
is not installed reports a precise configuration error on its first call
instead of launching somebody else's directory.

The MCP wire protocol is JSON-RPC 2.0 over newline-delimited stdio
(``initialize`` -> ``tools/list`` -> ``tools/call``), matching what both
connectors already implement — no third-party dependency is required.
"""

from __future__ import annotations

import json
import os
import subprocess
import threading
import time
from pathlib import Path

# ── Connector registry ──────────────────────────────────────────────────
# Each connector knows how to launch its MCP server. No machine-specific path
# is baked in: the env vars above win, and when none is set the kit is
# expected under ``vendor/`` beside this checkout.
_PACKAGE_ROOT = Path(__file__).resolve().parent.parent.parent


def _kit_root() -> Path:
    """Root of the connector kit (CodeModify / FullChrome)."""
    configured = os.environ.get("CUA_CONNECTOR_KIT_DIR", "").strip()
    if configured:
        return Path(configured)
    return _PACKAGE_ROOT / "vendor" / "connector-kit"


def _ssh_client_root() -> Path:
    """Root of the ssh-client checkout (ships its own virtualenv)."""
    configured = os.environ.get("CUA_SSH_CLIENT_DIR", "").strip()
    if configured:
        return Path(configured)
    return _PACKAGE_ROOT / "vendor" / "ssh-client"


def connector_launch(key: str) -> tuple[str, list[str], str]:
    """Resolve a connector's ``(command, args, cwd)`` at call time.

    Environment overrides are read on every call rather than captured at
    import time, so a kit installed (or an env var corrected) after the
    process started is picked up without a restart. The ``vendor/`` defaults
    keep a source checkout self-contained without pinning where any
    particular machine keeps its files.
    """
    if key == "codemodify":
        kit = _kit_root()
        return (
            os.environ.get("CUA_CONNECTOR_CODEMODIFY_CMD")
            or str(kit / "CodeModify" / ".venv" / "Scripts" / "python.exe"),
            os.environ.get("CUA_CONNECTOR_CODEMODIFY_ARGS", "").split()
            or [str(kit / "CodeModify" / "agentfs.py"), "mcp"],
            os.environ.get("CUA_CONNECTOR_CODEMODIFY_CWD")
            or str(kit / "CodeModify"),
        )
    if key == "fullchrome":
        kit = _kit_root()
        return (
            os.environ.get("CUA_CONNECTOR_FULLCHROME_CMD")
            or str(kit / "FullChrome" / "vendor" / "node" / "node.exe"),
            os.environ.get("CUA_CONNECTOR_FULLCHROME_ARGS", "").split()
            or [str(kit / "FullChrome" / "src" / "mcp.js")],
            os.environ.get("CUA_CONNECTOR_FULLCHROME_CWD")
            or str(kit / "FullChrome"),
        )
    if key == "ssh":
        ssh = _ssh_client_root()
        return (
            os.environ.get("CUA_CONNECTOR_SSH_CMD")
            or str(ssh / ".venv" / "Scripts" / "python.exe"),
            os.environ.get("CUA_CONNECTOR_SSH_ARGS", "").split()
            or ["-m", "ssh_client.mcp_server"],
            os.environ.get("CUA_CONNECTOR_SSH_CWD") or str(ssh),
        )
    raise KeyError(f"unknown connector '{key}'")


def _launch_problem(key: str, command: str) -> str | None:
    """Why a connector cannot start, or ``None`` when it can.

    Only path-shaped commands are checked: a bare executable name (``node``)
    is resolved through PATH by the OS, and second-guessing that would break
    a working install. A full path that does not exist is always a
    configuration error worth naming precisely.
    """
    text = (command or "").strip()
    if not text:
        return f"connector '{key}' has no launch command configured"
    if ("/" in text or "\\" in text) and not Path(text).exists():
        return (
            f"connector '{key}' launch command not found: {text} — "
            f"set CUA_CONNECTOR_{key.upper()}_CMD (or CUA_CONNECTOR_KIT_DIR), "
            f"or place the connector kit under vendor/"
        )
    return None


def _ssh_connector_env() -> dict[str, str]:
    """Credential environment for the ssh-client MCP subprocess.

    Read through the config module on every call rather than captured at import
    time: the operator fills these in from the settings panel, which happens long
    after this module was imported, and a value snapshotted at import would stay
    stale for the life of the process.

    An empty value is omitted rather than exported. ssh-client resolves a secret
    by looking the variable up, so an exported ``SSH_CLIENT_PASSWORD=""`` is
    found and used — and the resulting failure reads as "wrong password" instead
    of falling through to key-based auth.
    """
    try:
        from .. import config
    except Exception:  # noqa: BLE001 - never block a connector on an import
        return {}
    try:
        return dict(config.ssh_env())
    except Exception:  # noqa: BLE001
        return {}


def _ssh_call_timeout() -> float:
    """Per-call ceiling for SSH, from the settings panel (defaults to 180s).

    Read lazily for the same reason as the credentials: a value captured at
    import would not see a later settings change.
    """
    try:
        from .. import config

        return float(config.SSH_CALL_TIMEOUT)
    except Exception:  # noqa: BLE001
        return float(CALL_TIMEOUT)

CONNECTORS: dict[str, dict] = {
    # Launch command / args / cwd are resolved by ``connector_launch`` at
    # call time — see its docstring for the search order.
    "codemodify": {
        "prefix": "CodeModify_",
        "label": "agent-fs (CodeModify)",
        "ensure_backend": None,  # self-contained, no separate backend needed
    },
    "fullchrome": {
        "prefix": "FullChrome_",
        "label": "agent-browser (FullChrome)",
        "ensure_backend": "_ensure_fullchrome_backend",
    },
    # ssh-client: a separate checkout with its own venv. It is deliberately not
    # merged into the main interpreter — paramiko and the mcp SDK live there, and
    # pulling them in would drag a second set of native wheels into
    # the packaged app for no benefit. The bridge is a subprocess speaking
    # JSON-RPC, so nothing needs to be importable here.
    "ssh": {
        "prefix": "SSH_",
        "label": "ssh-client (remote SSH)",
        "ensure_backend": None,
        # Credentials ride in the subprocess environment rather than in the
        # tool arguments, so a password never lands in the transcript.
        "env": _ssh_connector_env,
        # A probe or a multi-host batch on a slow link is legitimately slower
        # than a browser click; the shared 120s ceiling would cut them off.
        "call_timeout": _ssh_call_timeout,
        # The model's tool names drop the redundant second "ssh_" that the MCP
        # server already carries (``SSH_exec`` rather than ``SSH_ssh_exec``), so
        # the suffix is mapped back to the real tool name on the way out.
        "tool_map": {
            "hosts": "list_hosts",
            "probe": "ssh_probe",
            "exec": "ssh_exec",
            "batch": "ssh_batch",
            "ls": "ssh_ls",
            "download": "ssh_download",
            "upload": "ssh_upload",
            "save_host": "ssh_save_host",
        },
    },
}

CONNECTOR_BY_PREFIX: dict[str, str] = {
    info["prefix"]: key for key, info in CONNECTORS.items()
}

CALL_TIMEOUT = float(os.environ.get("CUA_CONNECTOR_CALL_TIMEOUT", "120"))


# ── Minimal MCP stdio client ─────────────────────────────────────────────
class _Future:
    """Tiny threading.Event-backed slot for a single JSON-RPC response."""

    __slots__ = ("event", "value")

    def __init__(self) -> None:
        self.event = threading.Event()
        self.value = None

    def set(self, value) -> None:
        self.value = value
        self.event.set()

    def wait(self, timeout: float):
        if not self.event.wait(timeout):
            raise TimeoutError("MCP response timed out")
        return self.value


class MCPClient:
    """Spawns one MCP server and speaks line-delimited JSON-RPC 2.0 to it."""

    def __init__(
        self,
        name: str,
        command: str,
        args: list[str],
        cwd: str,
        extra_env: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> None:
        self.name = name
        env = dict(os.environ)
        # Keep subprocess output in UTF-8 regardless of the OS code page.
        env.setdefault("PYTHONIOENCODING", "utf-8")
        env.setdefault("PYTHONUTF8", "1")
        # Connector-specific credentials. Applied last so a connector can
        # override an inherited value, and blank entries are dropped rather than
        # exported (see _ssh_connector_env for why that matters).
        for key, value in (extra_env or {}).items():
            if value:
                env[key] = value
            else:
                env.pop(key, None)
        self.proc = subprocess.Popen(
            [command, *args],
            cwd=cwd,
            env=env,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            encoding="utf-8",
            errors="replace",
        )
        self._lock = threading.Lock()
        self._pending: dict[int, _Future] = {}
        self._next_id = 1
        # Per-connector budget: a remote probe or a multi-host batch is
        # legitimately slower than a browser click, and one shared ceiling
        # would either be too tight for SSH or too patient for the others.
        self.call_timeout = float(timeout) if timeout else CALL_TIMEOUT
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        # Drain stderr so a chatty server can never block on a full pipe.
        threading.Thread(target=self._drain_stderr, daemon=True).start()
        self._initialize()

    def _read_loop(self) -> None:
        try:
            for line in self.proc.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    continue
                mid = msg.get("id")
                if mid is None:
                    continue  # server->client notification; none expected
                with self._lock:
                    fut = self._pending.get(mid)
                if fut is not None:
                    fut.set(msg)
        except (ValueError, OSError):
            pass

    def _drain_stderr(self) -> None:
        try:
            for _ in self.proc.stderr:
                pass
        except (ValueError, OSError):
            pass

    def _request(self, method: str, params=None, expect_response: bool = True):
        with self._lock:
            mid = self._next_id
            self._next_id += 1
            fut = _Future()
            self._pending[mid] = fut
        try:
            self.proc.stdin.write(
                json.dumps({"jsonrpc": "2.0", "id": mid,
                            "method": method, "params": params or {}}) + "\n"
            )
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError) as e:
            with self._lock:
                self._pending.pop(mid, None)
            raise RuntimeError(f"MCP server pipe broken: {e}") from e

        if not expect_response:
            return None
        try:
            msg = fut.wait(self.call_timeout)
        finally:
            with self._lock:
                self._pending.pop(mid, None)
        if "error" in msg and "result" not in msg:
            return msg["error"]
        return msg.get("result")

    def _initialize(self) -> None:
        self._request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "cua-connector", "version": "1.0.0"},
            },
        )
        # Notify the server we are initialized (fire-and-forget).
        try:
            self.proc.stdin.write(
                json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"})
                + "\n"
            )
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError):
            pass

    def list_tools(self) -> list[dict]:
        result = self._request("tools/list", {})
        if isinstance(result, dict) and "tools" in result:
            return result["tools"]
        return []

    def call_tool(self, name: str, arguments: dict) -> dict:
        return self._request("tools/call", {"name": name, "arguments": arguments or {}})

    def close(self) -> None:
        try:
            self.proc.stdin.close()
        except OSError:
            pass
        try:
            self.proc.terminate()
        except OSError:
            pass


# ── Client lifecycle ────────────────────────────────────────────────────
_CLIENTS: dict[str, MCPClient] = {}
_CLIENT_LOCK = threading.Lock()


def _get_client(key: str) -> MCPClient:
    with _CLIENT_LOCK:
        client = _CLIENTS.get(key)
        if client is not None and client.proc.poll() is None:
            return client
        info = CONNECTORS[key]
        command, args, cwd = connector_launch(key)
        problem = _launch_problem(key, command)
        if problem:
            raise RuntimeError(problem)
        env_fn = info.get("env")
        try:
            extra_env = dict(env_fn()) if callable(env_fn) else dict(env_fn or {})
        except Exception:  # noqa: BLE001 - a bad secret must not kill the bridge
            extra_env = {}
        raw_timeout = info.get("call_timeout")
        if callable(raw_timeout):
            try:
                raw_timeout = raw_timeout()
            except Exception:  # noqa: BLE001
                raw_timeout = None
        client = MCPClient(
            key,
            command,
            list(args),
            cwd,
            extra_env,
            float(raw_timeout) if raw_timeout else None,
        )
        _CLIENTS[key] = client
        return client


def _ensure_fullchrome_backend() -> None:
    """Bring the agent-browser control service — and its browser — up.

    Two layers, and both have to be checked. The MCP server (``mcp.js``) only
    relays to the real browser service (``server.js`` at 127.0.0.1:9333), so:

    1. Service down   -> launch ``server.js`` in the background and wait.
    2. Service up, browser closed -> ask the service to reopen the window.

    Step 2 exists because the service deliberately keeps a user-closed browser
    closed (otherwise closing the window makes it spring back forever). That
    means a later mission has to reopen it explicitly, and this is the one
    place every FullChrome_ call passes through.

    Raising is not useful here — the caller turns a failure into a tool-level
    message either way — so problems are reported through the return value and
    the tool call itself surfaces the real error.
    """
    import urllib.request

    host = os.environ.get("AGENT_BROWSER_HOST", "127.0.0.1")
    port = os.environ.get("AGENT_BROWSER_PORT", "9333")
    url = f"http://{host}:{port}/api/status"
    base = f"http://{host}:{port}"

    def _post(action: str, timeout: float = 3.0):
        """Call one service action; returns the decoded body or None."""
        req = urllib.request.Request(
            f"{base}/api/{action}",
            data=b"{}",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        token = os.environ.get("AGENT_BROWSER_TOKEN", "")
        if token:
            req.add_header("x-agent-token", token)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}")

    def _service_up() -> bool:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                return r.status == 200
        except Exception:
            return False

    if not _service_up():
        node, _args, cwd = connector_launch("fullchrome")
        server_js = str(Path(cwd) / "src" / "server.js")
        log_path = str(Path(cwd) / "data" / "connector-server.log")
        Path(cwd / "data").mkdir(parents=True, exist_ok=True)
        with open(log_path, "ab") as logf:
            subprocess.Popen(
                [node, server_js],
                cwd=cwd,
                stdout=logf,
                stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
        # Give the browser service up to ~40s to come up.
        for _ in range(40):
            if _service_up():
                break
            time.sleep(1)
        else:
            # Not fatal: the tool call still reports the connection error with
            # a clear hint, and that message is more useful than anything we
            # could raise here.
            return

    # The service is up. Ask it about the browser before assuming it can serve
    # a page: a closed window answers /api/status cheerfully and then fails
    # every page action, so "service reachable" is not "browser usable".
    try:
        body = _post("browserState")
        state = ((body or {}).get("result") or {}).get("state")
    except Exception:
        # An older build predates browserState; let the tool call decide.
        return
    if state in (None, "running"):
        return
    try:
        _post("browserStart", timeout=45.0)
    except Exception:
        # Nothing to add: the next tool call reports the real failure.
        pass


# ── Result formatting ───────────────────────────────────────────────────
def _format_result(payload) -> str:
    if not isinstance(payload, dict):
        return str(payload)
    # JSON-RPC level error (e.g. unknown tool).
    if "code" in payload and "message" in payload:
        return f"Error: MCP error {payload['code']}: {payload['message']}"
    content = payload.get("content") or []
    text = "".join(
        p.get("text", "")
        for p in content
        if isinstance(p, dict) and p.get("type") == "text"
    )
    if payload.get("isError"):
        blob = text or json.dumps(payload, ensure_ascii=False)
        if "approval_required" in blob:
            # Permission gate, not a failure: surface the request id + prompt.
            return "NEEDS_APPROVAL: " + blob
        return "Error: " + blob
    return text or json.dumps(payload, ensure_ascii=False)


def execute(function_name: str, arguments: dict, ctx) -> str:
    """Route a connector-prefixed tool call to its MCP server."""
    for prefix, key in CONNECTOR_BY_PREFIX.items():
        if function_name.startswith(prefix):
            tool = function_name[len(prefix):]
            return _call_connector(key, tool, arguments, ctx)
    return f"Error: unrecognized connector function '{function_name}'"


def _resolve_tool(key: str, tool: str) -> str:
    """Map a model-facing tool suffix onto the MCP server's real tool name.

    Identity for connectors that already agree with the model (the two existing
    ones pass through untouched); the ssh connector declares a ``tool_map`` so
    the schema can read ``SSH_exec`` instead of the stuttering ``SSH_ssh_exec``.

    An unmapped suffix is passed through as-is rather than rejected here. The
    server is the authority on what it exposes, and it answers an unknown tool
    with a clear error — which beats the bridge second-guessing the mapping and
    refusing something the server would have accepted.
    """
    mapping = CONNECTORS.get(key, {}).get("tool_map") or {}
    return mapping.get(tool, tool)


def _call_connector(key: str, tool: str, arguments: dict, ctx) -> str:
    info = CONNECTORS[key]
    ensure = info.get("ensure_backend")
    if ensure:
        try:
            globals()[ensure]()
        except Exception as e:  # backend launch is best-effort
            if ctx is not None:
                try:
                    ctx.notice(
                        f"Connector '{key}' backend check: {e}", level="warn"
                    )
                except Exception:
                    pass
    try:
        client = _get_client(key)
        result = client.call_tool(_resolve_tool(key, tool), arguments)
    except Exception as e:  # noqa: BLE001 - bridge failures are data, not crashes
        return f"Error: connector '{key}' ({tool}) failed: {type(e).__name__}: {e}"
    return _format_result(result)
