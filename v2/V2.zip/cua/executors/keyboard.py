"""Keyboard action executor (pyautogui)."""

from __future__ import annotations

from .. import desktop

# Maps our stable key identifiers onto pyautogui key names. Anything absent
# is passed through lower-cased, which covers a-z / 0-9 / function keys.
KEY_MAP = {
    "TILDE": "`",
    "Esc": "escape",
    "Space": "space",
    "PrtScn": "printscreen",
    "ScrollLock": "scrolllock",
    "Pause": "pause",
    "UpArrow": "up",
    "DownArrow": "down",
    "LeftArrow": "left",
    "RightArrow": "right",
    "CapsLock": "capslock",
    "PageUp": "pageup",
    "PageDown": "pagedown",
    "NumMultiply": "nummultiply",
    "NumAdd": "numadd",
    "NumSubtract": "numsubtract",
    "NumDecimal": "numdecimal",
    "NumDivide": "numdivide",
    "NumEnter": "numenter",
    **{f"Num{i}": f"num{i}" for i in range(10)},
}


def execute(function_name: str, arguments: dict, ctx) -> str:
    handlers = {
        "KeyboardAction_InstantInput": _instant_input,
        "KeyboardAction_KeyByKeyInput": _key_by_key_input,
        "KeyboardAction_HotkeyInput": _hotkey_input,
    }
    handler = handlers.get(function_name)
    if handler is None:
        return f"Error: unknown keyboard function '{function_name}'"
    pag = desktop.pyautogui()
    if pag is None:
        return desktop.unavailable_message("pyautogui")
    ctx.check_stop()
    try:
        return handler(pag, arguments)
    except Exception as e:
        return f"Error: keyboard action failed — {type(e).__name__}: {e}"


def _instant_input(pag, args: dict) -> str:
    text = args.get("InputContent", "") or ""
    if len(text) < 2:
        return "Error: InputContent length must be greater than 1"
    pag.write(text, interval=0)
    return f"True: instant input '{_preview(text)}' completed"


def _key_by_key_input(pag, args: dict) -> str:
    text = args.get("InputContent", "") or ""
    if len(text) < 2:
        return "Error: InputContent length must be greater than 1"
    pag.write(text, interval=0.08)
    return f"True: key-by-key input '{_preview(text)}' completed"


def _hotkey_input(pag, args: dict) -> str:
    keys = args.get("keys") or []
    if not keys:
        return "Error: keys array must not be empty"
    mapped = [KEY_MAP.get(k, k.lower()) for k in keys]
    pag.hotkey(*mapped)
    return f"True: hotkey '{'+'.join(keys)}' pressed"


def _preview(text: str, limit: int = 80) -> str:
    return text if len(text) <= limit else text[:limit] + "..."
