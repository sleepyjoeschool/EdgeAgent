"""Mission sessions, one JSON file each, in one folder.

A *session* is a thread of work, not a single run. It owns two things:

* the model context — system prompt, the operator's requests, tool traffic and
  the per-step summaries the outer loop keeps;
* the event log that the panel renders as a transcript.

Starting a mission in an existing session appends to that context rather than
rebuilding it, which is what makes "open yesterday's task and carry on" work.
The agent still only drives one machine, so only one session may be *running*
at a time — a constraint enforced by the panel, not here.

Storage follows the rule this project already uses for ``users.json`` and
``audit.log``: plain files, no driver, so an operator who needs to hand
somebody a transcript copies one file and anyone can read it. One file per
session rather than one combined document, because sessions are written
independently and often.

Three things are deliberately bounded or removed on the way to disk:

* **Screenshots are stripped.** A base64 frame is a couple of hundred
  kilobytes and is only a snapshot of one moment — the next step takes a fresh
  one. Keeping them would inflate a session into megabytes of unreadable
  noise.
* **The transcript is capped.** It is a replay log, and the tail is the part
  anybody looks at.
* **The message list is capped**, keeping the system prompt and the original
  request plus the recent tail, so a long-lived session cannot grow forever.
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import config


def new_session_id() -> str:
    """Sortable, unique, and safe as a filename."""
    return f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"


def title_from_task(task: str, limit: int = 40) -> str:
    """Derive a session name from the first thing asked of it."""
    flat = " ".join((task or "").split())
    return flat[:limit] + ("…" if len(flat) > limit else "")


@dataclass
class Session:
    """One thread of work: its context and its replayable log."""

    id: str
    title: str = ""
    owner: str = ""
    created: float = field(default_factory=time.time)
    updated: float = field(default_factory=time.time)
    runs: int = 0
    steps: int = 0
    last_reason: str = ""
    #: Directory this thread runs in, and where the name came from.
    #:
    #: ``workspace_kind`` decides how the session is grouped in the list:
    #:   "auto"    — no folder was chosen, so the run got a timestamped child
    #:               of the configured parent directory → grouped under 任务
    #:   "folder"  — the operator picked a directory → grouped under 空间, by
    #:               its own name
    #:   "none"    — no restriction, or recorded before this field existed
    #: Kept as two fields rather than inferred from the path: the inference
    #: would have to re-derive the parent directory at render time, and a
    #: later change to that setting would silently reclassify old sessions.
    workspace: str = ""
    workspace_kind: str = "none"
    messages: list[dict] = field(default_factory=list)
    transcript: list[dict] = field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        """Everything the session list needs, without the payloads."""
        return {
            "id": self.id,
            "title": self.title or "(未命名会话)",
            "owner": self.owner,
            "created": self.created,
            "updated": self.updated,
            "runs": self.runs,
            "steps": self.steps,
            "last_reason": self.last_reason,
            "events": len(self.transcript),
            "workspace": self.workspace,
            "workspace_kind": self.workspace_kind,
            "space": space_name(self.workspace, self.workspace_kind),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            **self.summary(),
            "title": self.title,
            "messages": self.messages,
            "transcript": self.transcript,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Session":
        return cls(
            id=str(data.get("id") or new_session_id()),
            title=str(data.get("title") or ""),
            owner=str(data.get("owner") or ""),
            created=float(data.get("created") or time.time()),
            updated=float(data.get("updated") or time.time()),
            runs=int(data.get("runs") or 0),
            steps=int(data.get("steps") or 0),
            last_reason=str(data.get("last_reason") or ""),
            workspace=str(data.get("workspace") or ""),
            workspace_kind=str(data.get("workspace_kind") or "none"),
            messages=list(data.get("messages") or []),
            transcript=list(data.get("transcript") or []),
        )


def space_name(workspace: str, kind: str) -> str:
    """The 空间 a session belongs to, or "" for none.

    Named from the directory's own basename, which is what makes a 空间
    recognisable at a glance: the folder the operator picked is the thing they
    remember, not the session title.
    """
    if kind != "folder" or not workspace:
        return ""
    text = workspace.rstrip("\\/")
    if not text:
        return ""
    return text.replace("\\", "/").rsplit("/", 1)[-1] or ""


# ── Payload trimming ────────────────────────────────────────────────────

_OMITTED_IMAGE = "[此处的屏幕截图已省略 — 续跑时会重新抓取]"

Event = dict


def _strip_images(message: dict) -> dict:
    """Replace inline screenshot parts with a note.

    Only the content parts are touched: the role and any tool-call references
    have to survive intact or the conversation stops being replayable.
    """
    content = message.get("content")
    if not isinstance(content, list):
        return message

    stripped = [
        {"type": "text", "text": _OMITTED_IMAGE}
        if isinstance(part, dict) and part.get("type") == "image_url"
        else part
        for part in content
    ]
    return {**message, "content": stripped}


def _cap_messages(messages: list[dict], limit: int) -> list[dict]:
    """Keep the system prompt, the original request, and the recent tail.

    Dropping the middle is safe: the outer loop already compresses history into
    summaries between steps, so what is discarded is the least load-bearing
    part of the context.
    """
    if len(messages) <= limit or limit < 3:
        return messages
    return messages[:2] + messages[-(limit - 2):]


class SessionStore:
    """Reads and writes session files under one directory."""

    def __init__(self, directory: Path | str | None = None) -> None:
        self.dir = Path(directory) if directory else config.session_dir()
        self.lock = threading.RLock()
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            # A read-only install still has to boot; the panel reports the
            # failure when a save is attempted rather than dying at import.
            pass
        self.sweep_orphan_temps()

    # ── Housekeeping ────────────────────────────────────────────────────
    def sweep_orphan_temps(self) -> int:
        """Remove ``.tmp`` files left behind by an interrupted save.

        ``save()`` writes to a temp file and then ``os.replace``s it into
        place, so a normal failure cleans up after itself. A *hard kill* does
        not: the process dies mid-write, nothing runs, and the temp file stays.
        Those files are real session data under a hidden name, so they are
        invisible in the UI and accumulate silently — two were found sitting in
        the sessions folder from a day earlier.

        Called on construction, so the panel clears them on every start.
        Bounded by age: a temp file younger than a few minutes may belong to a
        concurrent save in another process, and deleting it would corrupt that
        write. Returns how many were removed.
        """
        cutoff = time.time() - 300
        removed = 0
        try:
            candidates = list(self.dir.glob(".*.tmp"))
        except OSError:
            return 0
        for path in candidates:
            try:
                if path.stat().st_mtime > cutoff:
                    continue
                path.unlink()
                removed += 1
            except OSError:
                continue
        return removed

    # ── Paths ───────────────────────────────────────────────────────────
    def path_for(self, session_id: str) -> Path:
        """Resolve one session's file, refusing anything outside the folder.

        The id arrives from an HTTP path, so it is treated as untrusted: a
        traversal must not reach a file outside the session directory.
        """
        candidate = (self.dir / f"{session_id}.json").resolve()
        root = self.dir.resolve()
        if candidate.parent != root:
            raise ValueError("invalid session id")
        return candidate

    # ── CRUD ────────────────────────────────────────────────────────────
    def create(self, title: str = "", owner: str = "") -> Session:
        session = Session(id=new_session_id(), title=title, owner=owner)
        self.save(session)
        return session

    def list(self) -> list[Session]:
        """Every session, most recently touched first."""
        sessions: list[Session] = []
        try:
            files = sorted(self.dir.glob("*.json"))
        except OSError:
            return sessions
        for path in files:
            session = self._read(path)
            if session is not None:
                sessions.append(session)
        sessions.sort(key=lambda s: s.updated, reverse=True)
        return sessions

    def get(self, session_id: str) -> Session | None:
        try:
            path = self.path_for(session_id)
        except ValueError:
            return None
        if not path.is_file():
            return None
        return self._read(path)

    def save(self, session: Session) -> bool:
        """Write one session, atomically. Returns False if it could not."""
        with self.lock:
            session.transcript = session.transcript[-config.SESSION_TRANSCRIPT_LIMIT:]
            session.messages = _cap_messages(
                session.messages, config.SESSION_MESSAGE_LIMIT
            )
            payload = {
                **session.to_dict(),
                "messages": [_strip_images(m) for m in session.messages],
            }
            try:
                path = self.path_for(session.id)
                path.parent.mkdir(parents=True, exist_ok=True)
            except (OSError, ValueError):
                return False

            # Write-then-replace: a crash mid-write must leave the previous
            # version readable rather than truncating the session.
            try:
                with tempfile.NamedTemporaryFile(
                    "w", encoding="utf-8", dir=str(path.parent),
                    prefix=f".{session.id}.", suffix=".tmp", delete=False,
                ) as handle:
                    json.dump(payload, handle, ensure_ascii=False, indent=2)
                    tmp = Path(handle.name)
                os.replace(str(tmp), str(path))
                return True
            except OSError:
                try:
                    tmp.unlink(missing_ok=True)  # type: ignore[possibly-undefined]
                except OSError:
                    pass
                return False

    def rename(self, session_id: str, title: str) -> Session | None:
        with self.lock:
            session = self.get(session_id)
            if session is None:
                return None
            session.title = title.strip()
            self.save(session)
            return session

    def delete(self, session_id: str) -> bool:
        with self.lock:
            try:
                path = self.path_for(session_id)
            except ValueError:
                return False
            try:
                path.unlink()
                return True
            except OSError:
                return False

    # ── Internals ───────────────────────────────────────────────────────
    def _read(self, path: Path) -> Session | None:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            # A single unreadable file must not hide every other session.
            return None
        if not isinstance(data, dict):
            return None
        session = Session.from_dict(data)
        session.id = path.stem
        return session
