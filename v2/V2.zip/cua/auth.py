"""User accounts, password hashing and session tokens for the WebUI.

Design notes
------------

*No shared password.* The previous panel was guarded by a single
``WEB_PANEL_PASSWORD`` compared with ``secrets.compare_digest`` on every
request. That model has two problems: the password travels to the browser in
the clear over plain HTTP on a LAN, and there is no way to tell *who* pressed
the button that started a mission. This module replaces it with real accounts.

*First run is a setup wizard.* ``UserStore.needs_setup`` is true until an
enabled administrator exists, and the panel refuses every other endpoint until
then. The window in which an unauthenticated caller can drive a desktop is
closed by construction rather than by hoping the operator set a password.

*Hashes, never passwords.* ``hashlib.pbkdf2_hmac`` with per-user salts and a
high iteration count. Verification is constant-time via ``hmac.compare_digest``.
A JSON file is the right store for a single-machine desktop tool: it survives a
rebuild, is auditable by hand, and needs no database.

*Server-side sessions.* The cookie carries an opaque random token; the session
record lives in memory, so logging out actually invalidates the credential
immediately. Flask's own signed cookie would keep working after "logout" —
exactly the property you do not want on a panel that moves a real mouse.

*Lockout is the brute-force answer.* Guessing against a local HTTP endpoint is
cheap, so failures accumulate per username *and* per client IP. The lock is
time-based and in-memory only: restarting the server legitimately resets it,
whereas a persisted lock would let anyone lock the owner out remotely.

*Every privileged action is auditable.* ``record()`` appends a JSON line to
``audit.log`` with timestamp, actor, action and outcome. Mission control moves
a real pointer, so "who did what" must be answerable after the fact.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ── Tuning ─────────────────────────────────────────────────────────────

# PBKDF2 iterations. 240k is roughly 100ms of CPU on a modern laptop, which
# makes an offline attack on a stolen account file expensive without making an
# operator's own login feel slow. The count is stored per user, so raising it
# later is transparent to existing accounts.
PBKDF2_ITERATIONS = 240_000

SALT_BYTES = 16
TOKEN_BYTES = 32

ROLES = ("admin", "operator", "viewer")

# Capability matrix. Roles are deliberately coarse: the panel has exactly three
# things worth separating — watching, driving, and administering.
ROLE_CAPABILITIES: dict[str, frozenset[str]] = {
    "admin": frozenset({"view", "control", "admin"}),
    "operator": frozenset({"view", "control"}),
    "viewer": frozenset({"view"}),
}

ROLE_LABELS = {
    "admin": "管理员",
    "operator": "操作员",
    "viewer": "只读",
}

# NIST-style floor length. The real protection is the hash cost plus lockout,
# not exotic character-class rules.
MIN_PASSWORD_LENGTH = 8

# Known-bad passwords rejected outright. Intentionally short: a blacklist
# against the defaults that actually show up in deployments, not a policy
# engine.
COMMON_PASSWORDS = frozenset({
    "password", "password1", "password123", "passw0rd", "12345678",
    "123456789", "1234567890", "qwerty123", "qwertyuiop", "abc12345",
    "letmein123", "administrator", "admin12345", "welcome123",
    "iloveyou123", "admin@123", "root12345", "test12345", "changeme",
    "cua12345678", "cuaadmin123",
})


def password_problem(password: str) -> str | None:
    """Return why the password is unacceptable, or None when it is fine."""
    if not password:
        return "密码不能为空"
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"密码至少需要 {MIN_PASSWORD_LENGTH} 个字符"
    if password != password.strip():
        return "密码首尾不能有空格"
    if password.lower() in COMMON_PASSWORDS:
        return "这个密码过于常见，请换一个"
    if len(set(password.lower())) <= 2:
        return "密码字符种类太少，请换一个"
    return None


# ── Password generation ────────────────────────────────────────────────
#
# Hand-invented passwords are reliably weak: operators reuse the same one
# everywhere, or fall back to the name of the machine. Offering a generated
# alternative removes the temptation, and the generated value is far stronger
# than anything a human types under a "pick a password" prompt.
#
# Generation lives server-side rather than in the browser for two reasons: the
# browser's Math.random is not a CSPRNG, and only the server knows the current
# password policy — so a generated password cannot drift out of compliance
# when MIN_PASSWORD_LENGTH or the character rules change.

# Deliberately excludes characters that are easy to confuse when read off a
# screen or copied by hand: 0/O, 1/l/I, and the quote/backslash family that
# trips up shells and JSON escaping.
_GENERATE_ALPHABET = (
    "abcdefghijkmnopqrstuvwxyz"      # no l
    "ABCDEFGHJKLMNPQRSTUVWXYZ"       # no I, O
    "23456789"                      # no 0, 1
    "!@#$%^&*+-=?"                  # no quotes, backslash, backtick
)

DEFAULT_GENERATED_LENGTH = 20
MIN_GENERATED_LENGTH = 12
MAX_GENERATED_LENGTH = 64


def generate_password(length: int = DEFAULT_GENERATED_LENGTH) -> str:
    """Return a random password that satisfies :func:`password_problem`.

    Guarantees at least one character from each of the four groups, then
    shuffles — a uniform draw from the whole alphabet has a small chance of
    coming out all-lowercase, which our own policy would (rightly) reject.
    """
    length = max(MIN_GENERATED_LENGTH, min(MAX_GENERATED_LENGTH, int(length)))

    for _attempt in range(64):
        chars = [secrets.choice(_GENERATE_ALPHABET) for _ in range(length)]

        if not any(c.islower() for c in chars):
            chars[0] = secrets.choice("abcdefghijkmnopqrstuvwxyz")
        if not any(c.isupper() for c in chars):
            chars[1] = secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ")
        if not any(c.isdigit() for c in chars):
            chars[2] = secrets.choice("23456789")
        if not any(c in "!@#$%^&*+-=?" for c in chars):
            chars[3] = secrets.choice("!@#$%^&*+-=?")

        # Rejection sampling rather than shuffle(): Fisher-Yates on a list with
        # duplicate characters is biased, and we would rather not bias a
        # credential.
        for i in range(len(chars) - 1, 0, -1):
            j = secrets.randbelow(i + 1)
            chars[i], chars[j] = chars[j], chars[i]

        candidate = "".join(chars)
        if password_problem(candidate) is None:
            return candidate

    # The loop cannot realistically exhaust (the policy is mild), but falling
    # back to a longer fixed-shape string beats raising.
    return candidate


def password_strength(password: str) -> int:
    """Rough 0-100 strength score, used only to nudge the operator."""
    if not password:
        return 0
    score = 0
    if len(password) >= MIN_PASSWORD_LENGTH:
        score += 34
    if len(password) >= 14:
        score += 18
    if len(set(password)) >= 6:
        score += 18
    if not password.islower() and not password.isupper() and not password.isdigit():
        score += 16
    if any(not c.isalnum() for c in password):
        score += 14
    return min(100, score)


# ── Hashing ────────────────────────────────────────────────────────────

def hash_password(password: str, iterations: int = PBKDF2_ITERATIONS) -> dict[str, Any]:
    """Hash a password into a self-describing record.

    The iteration count travels with the record so the cost can be raised
    without invalidating existing users.
    """
    salt = secrets.token_bytes(SALT_BYTES)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, iterations
    )
    return {
        "algo": "pbkdf2_hmac_sha256",
        "iterations": iterations,
        "salt": salt.hex(),
        "hash": digest.hex(),
        "created": time.time(),
    }


def verify_password(password: str, record: dict[str, Any] | None) -> bool:
    """Constant-time password check against a stored record."""
    if not record:
        return False
    try:
        salt = bytes.fromhex(record["salt"])
        expected = bytes.fromhex(record["hash"])
        iterations = int(record.get("iterations") or PBKDF2_ITERATIONS)
    except (KeyError, TypeError, ValueError):
        return False
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, iterations
    )
    return hmac.compare_digest(digest, expected)


def needs_rehash(record: dict[str, Any] | None) -> bool:
    """Whether a record was made with a weaker cost than we want now."""
    if not record:
        return True
    try:
        return int(record.get("iterations") or 0) < PBKDF2_ITERATIONS
    except (TypeError, ValueError):
        return True


# ── Records ────────────────────────────────────────────────────────────

@dataclass
class User:
    name: str
    role: str
    password: dict[str, Any]
    created: float = 0.0
    last_login: float | None = None
    disabled: bool = False
    must_change: bool = False

    def public(self) -> dict[str, Any]:
        """Everything safe to send to the browser — never the hash."""
        return {
            "name": self.name,
            "role": self.role,
            "role_label": ROLE_LABELS.get(self.role, self.role),
            "created": self.created,
            "last_login": self.last_login,
            "disabled": self.disabled,
            "must_change": self.must_change,
        }

    def as_dict(self) -> dict[str, Any]:
        """Serialised form for the account file."""
        return {
            "name": self.name,
            "role": self.role,
            "password": self.password,
            "created": self.created,
            "last_login": self.last_login,
            "disabled": self.disabled,
            "must_change": self.must_change,
        }


@dataclass
class Session:
    token: str
    user: str
    role: str
    csrf: str
    created: float
    last_seen: float
    expires: float
    ip: str = ""
    user_agent: str = ""
    session_id: str = field(default_factory=lambda: secrets.token_hex(8))


# ── Store ──────────────────────────────────────────────────────────────

class UserStore:
    """Account persistence plus in-memory sessions and lockout state."""

    def __init__(
        self,
        store_path: Path,
        audit_path: Path,
        session_ttl: float,
        lockout_seconds: float = 300.0,
        max_attempts: int = 5,
        lockout_window: float = 900.0,
    ) -> None:
        self.store_path = Path(store_path)
        self.audit_path = Path(audit_path)
        self.session_ttl = float(session_ttl)
        self.lockout_seconds = float(lockout_seconds)
        self.max_attempts = int(max_attempts)
        self.lockout_window = float(lockout_window)

        self._lock = threading.RLock()
        self._users: dict[str, User] = {}
        self._sessions: dict[str, Session] = {}
        # key -> [first_failure_ts, failure_count, locked_until_ts]
        self._failures: dict[str, list[Any]] = {}

        self.load()

    # ── Persistence ───────────────────────────────────────────────────
    def load(self) -> None:
        """Read the account file. A damaged file is renamed, never deleted."""
        with self._lock:
            self._users = {}
            if not self.store_path.exists():
                return
            try:
                raw = json.loads(self.store_path.read_text(encoding="utf-8"))
                users = raw.get("users") if isinstance(raw, dict) else None
                if not isinstance(users, list):
                    raise ValueError("missing users list")
                for item in users:
                    user = self._user_from_dict(item)
                    if user is not None:
                        self._users[user.name] = user
            except (json.JSONDecodeError, OSError, ValueError, TypeError):
                # Never silently overwrite: the operator may still be able to
                # repair a damaged file by hand.
                backup = self.store_path.with_name(
                    f"{self.store_path.name}.corrupt-{int(time.time())}"
                )
                try:
                    self.store_path.replace(backup)
                    self.record(
                        "system", "users.corrupt", "ok",
                        detail=f"renamed unreadable file to {backup.name}",
                    )
                except OSError:
                    pass

    def save(self) -> None:
        """Atomically write the account file."""
        with self._lock:
            payload = {
                "version": 1,
                "updated": time.time(),
                "users": [u.as_dict() for u in self._users.values()],
            }
            self.store_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.store_path.with_name(f"{self.store_path.name}.tmp")
            tmp.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            # Replace rather than truncate: an interrupted write must not
            # leave a half-written account file behind.
            os.replace(tmp, self.store_path)
            self._restrict_permissions()

    def _restrict_permissions(self) -> None:
        """Best-effort chmod 0600. Largely a no-op on Windows, whose ACL
        model differs, but it matters on the POSIX targets."""
        try:
            if os.name != "nt":
                os.chmod(self.store_path, 0o600)
        except OSError:
            pass

    @staticmethod
    def _user_from_dict(item: Any) -> User | None:
        if not isinstance(item, dict):
            return None
        name = str(item.get("name", "")).strip()
        role = str(item.get("role", "")).strip().lower()
        password = item.get("password")
        if not name or role not in ROLES or not isinstance(password, dict):
            return None
        try:
            return User(
                name=name,
                role=role,
                password=password,
                created=float(item.get("created") or 0.0),
                last_login=item.get("last_login"),
                disabled=bool(item.get("disabled")),
                must_change=bool(item.get("must_change")),
            )
        except (TypeError, ValueError):
            return None

    # ── Queries ───────────────────────────────────────────────────────
    @property
    def users(self) -> list[User]:
        with self._lock:
            return sorted(self._users.values(), key=lambda u: u.created)

    def get(self, name: str) -> User | None:
        with self._lock:
            return self._users.get((name or "").strip())

    @property
    def needs_setup(self) -> bool:
        """True until at least one enabled administrator exists."""
        with self._lock:
            return not any(
                u.role == "admin" and not u.disabled for u in self._users.values()
            )

    @property
    def admin_count(self) -> int:
        with self._lock:
            return sum(
                1 for u in self._users.values()
                if u.role == "admin" and not u.disabled
            )

    def can(self, user: User | None, capability: str) -> bool:
        if user is None:
            return False
        return capability in ROLE_CAPABILITIES.get(user.role, frozenset())

    # ── Mutations ─────────────────────────────────────────────────────
    def create_user(self, name: str, password: str, role: str,
                    must_change: bool = False) -> User:
        """Create an account, or raise ``ValueError`` with a usable message."""
        name = (name or "").strip()
        role = (role or "").strip().lower()
        if not name:
            raise ValueError("用户名不能为空")
        if len(name) > 64:
            raise ValueError("用户名过长（最多 64 字符）")
        if not all(c.isalnum() or c in "._-@" for c in name):
            raise ValueError("用户名只能包含字母、数字、点、下划线、连字符、@")
        if role not in ROLES:
            raise ValueError(f"未知角色 '{role}'")
        problem = password_problem(password)
        if problem:
            raise ValueError(problem)

        with self._lock:
            lowered = name.lower()
            if any(u.name.lower() == lowered for u in self._users.values()):
                raise ValueError(f"用户名 '{name}' 已被占用")
            user = User(
                name=name,
                role=role,
                password=hash_password(password),
                created=time.time(),
                must_change=must_change,
            )
            self._users[name] = user
            self.save()
        self.record(name, "user.create", "ok", detail=f"role={role}")
        return user

    def set_password(self, name: str, password: str,
                     must_change: bool = False) -> None:
        with self._lock:
            user = self._users.get((name or "").strip())
            if user is None:
                raise ValueError("用户不存在")
            problem = password_problem(password)
            if problem:
                raise ValueError(problem)
            user.password = hash_password(password)
            user.must_change = must_change
            # A password change invalidates that user's existing sessions, so a
            # stolen cookie cannot outlive the credential it came from.
            self._drop_sessions_for(name)
            self.save()
        self.record(name, "user.password", "ok")

    def set_role(self, name: str, role: str) -> None:
        role = (role or "").strip().lower()
        if role not in ROLES:
            raise ValueError(f"未知角色 '{role}'")
        with self._lock:
            user = self._users.get((name or "").strip())
            if user is None:
                raise ValueError("用户不存在")
            if user.role == "admin" and role != "admin" and self.admin_count < 2:
                raise ValueError("至少需要保留一个管理员账号")
            if user.role != role:
                self._drop_sessions_for(name)
                user.role = role
                self.save()
        self.record(name, "user.role", "ok", detail=f"role={role}")

    def delete_user(self, name: str) -> None:
        name = (name or "").strip()
        with self._lock:
            user = self._users.get(name)
            if user is None:
                raise ValueError("用户不存在")
            if user.role == "admin" and self.admin_count < 2:
                raise ValueError("不能删除最后一个管理员账号")
            self._drop_sessions_for(name)
            del self._users[name]
            self.save()
        self.record(name, "user.delete", "ok")

    def set_disabled(self, name: str, disabled: bool) -> None:
        name = (name or "").strip()
        with self._lock:
            user = self._users.get(name)
            if user is None:
                raise ValueError("用户不存在")
            if user.role == "admin" and disabled and self.admin_count < 2:
                raise ValueError("至少需要保留一个启用的管理员账号")
            user.disabled = bool(disabled)
            if user.disabled:
                self._drop_sessions_for(name)
            self.save()
        self.record(name, "user.disable" if disabled else "user.enable", "ok")

    def clear_must_change(self, name: str) -> None:
        with self._lock:
            user = self._users.get((name or "").strip())
            if user is not None and user.must_change:
                user.must_change = False
                self.save()

    # ── Login ─────────────────────────────────────────────────────────
    def authenticate(self, username: str, password: str, ip: str = "",
                     user_agent: str = "") -> Session:
        """Verify credentials and open a session.

        Raises ``ValueError`` with a message meant for the operator. Every
        failure returns the same generic text, and the PBKDF2 work runs even
        for unknown accounts, so the endpoint does not reveal which usernames
        exist.
        """
        username = (username or "").strip()
        ip = ip or ""

        with self._lock:
            remaining = self._lockout_remaining(username, ip)
            if remaining > 0:
                raise ValueError(f"登录尝试过多，请 {int(remaining)} 秒后重试")

            user = self._users.get(username)

            if user is None or user.disabled:
                # Burn equivalent CPU so response time does not leak existence.
                hash_password(password or "")
                self._note_failure(username, ip)
                self.record(username or "anonymous", "auth.login", "denied",
                            detail="unknown or disabled user", ip=ip)
                raise ValueError("用户名或密码错误")

            if not verify_password(password or "", user.password):
                self._note_failure(username, ip)
                self.record(username, "auth.login", "denied",
                            detail="bad password", ip=ip)
                raise ValueError("用户名或密码错误")

            if needs_rehash(user.password):
                # Silent upgrade: the operator just typed a real password, so
                # it can be re-hashed at the current cost without asking.
                user.password = hash_password(password)

            user.last_login = time.time()
            self._failures.pop(f"u:{username}", None)
            session = self._create_session(user, ip, user_agent)
            self.save()

        self.record(username, "auth.login", "ok", ip=ip)
        return session

    # ── Lockout bookkeeping ───────────────────────────────────────────
    def _note_failure(self, username: str, ip: str) -> None:
        """Count one failure on both dimensions."""
        self._bump(f"u:{username}")
        if ip:
            self._bump(f"ip:{ip}")

    def _bump(self, key: str) -> None:
        state = self._failures.get(key)
        now = time.time()
        if state is None or now - state[0] > self.lockout_window:
            self._failures[key] = [now, 1, 0.0]
            return
        state[1] += 1
        if state[1] >= self.max_attempts:
            state[2] = now + self.lockout_seconds

    def _lockout_remaining(self, username: str, ip: str) -> float:
        now = time.time()
        keys = [f"u:{username}"]
        if ip:
            keys.append(f"ip:{ip}")
        worst = 0.0
        for key in keys:
            state = self._failures.get(key)
            if not state:
                continue
            if now - state[0] > self.lockout_window:
                self._failures.pop(key, None)
                continue
            locked_until = state[2]
            if locked_until > now:
                worst = max(worst, locked_until - now)
        return worst

    def lockout_state(self, username: str, ip: str = "") -> dict[str, Any]:
        """Diagnostics for the login screen: are we currently locked out?"""
        remaining = self._lockout_remaining((username or "").strip(), ip or "")
        return {
            "locked": remaining > 0,
            "retry_after": int(remaining) if remaining > 0 else 0,
            "max_attempts": self.max_attempts,
        }

    # ── Sessions ──────────────────────────────────────────────────────
    def _create_session(self, user: User, ip: str, user_agent: str = "") -> Session:
        now = time.time()
        session = Session(
            token=secrets.token_urlsafe(TOKEN_BYTES),
            user=user.name,
            role=user.role,
            csrf=secrets.token_urlsafe(TOKEN_BYTES),
            created=now,
            last_seen=now,
            expires=now + self.session_ttl,
            ip=ip,
            user_agent=(user_agent or "")[:200],
        )
        with self._lock:
            self._sessions[session.token] = session
            self._prune_sessions()
        return session

    def validate_session(self, token: str | None) -> Session | None:
        """Resolve a cookie token to a live session, or None."""
        if not token:
            return None
        with self._lock:
            session = self._sessions.get(token)
            if session is None:
                return None
            now = time.time()
            if session.expires <= now:
                self._sessions.pop(token, None)
                return None
            user = self._users.get(session.user)
            # The account may have been deleted, disabled or re-roled after the
            # token was issued — the token alone is not authority to act.
            if user is None or user.disabled or user.role != session.role:
                self._sessions.pop(token, None)
                return None
            session.last_seen = now
            return session

    @staticmethod
    def validate_csrf(session: Session | None, token: str | None) -> bool:
        """Constant-time CSRF header check for a state-changing request."""
        if session is None or not token:
            return False
        return hmac.compare_digest(session.csrf, token)

    def logout(self, token: str | None) -> str | None:
        """Drop a session. Returns the username, for the audit record."""
        if not token:
            return None
        with self._lock:
            session = self._sessions.pop(token, None)
        if session is None:
            return None
        self.record(session.user, "auth.logout", "ok", ip=session.ip)
        return session.user

    def _drop_sessions_for(self, name: str) -> None:
        with self._lock:
            for token in [t for t, s in self._sessions.items() if s.user == name]:
                self._sessions.pop(token, None)

    def drop_all_sessions(self, name: str | None = None) -> int:
        """Kick sessions for one user, or everyone. Used by the admin panel."""
        with self._lock:
            if name is None:
                count = len(self._sessions)
                self._sessions.clear()
            else:
                targets = [t for t, s in self._sessions.items() if s.user == name]
                count = len(targets)
                for token in targets:
                    self._sessions.pop(token, None)
        self.record("admin", "session.revoke", "ok",
                    detail=f"user={name or '*'} count={count}")
        return count

    def _prune_sessions(self) -> None:
        now = time.time()
        for token in [t for t, s in self._sessions.items() if s.expires <= now]:
            self._sessions.pop(token, None)

    def active_sessions(self, current_token: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            self._prune_sessions()
            return [
                {
                    "id": s.session_id,
                    "user": s.user,
                    "role": s.role,
                    "created": s.created,
                    "last_seen": s.last_seen,
                    "expires": s.expires,
                    "ip": s.ip,
                    "user_agent": s.user_agent,
                    "current": s.token == current_token,
                }
                for s in self._sessions.values()
            ]

    # ── Audit ─────────────────────────────────────────────────────────
    def record(self, actor: str, action: str, outcome: str,
               detail: str = "", ip: str = "") -> None:
        """Append one JSON line to the audit log. Never raises."""
        entry = {
            "ts": round(time.time(), 3),
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "actor": actor or "anonymous",
            "action": action,
            "outcome": outcome,
            "detail": str(detail)[:500],
            "ip": ip,
        }
        try:
            self.audit_path.parent.mkdir(parents=True, exist_ok=True)
            with self.audit_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            # Auditing must never break the request it is describing.
            pass

    def read_audit(self, limit: int = 200) -> list[dict[str, Any]]:
        """Tail of the audit log, newest first, for the admin panel."""
        try:
            lines = self.audit_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        out: list[dict[str, Any]] = []
        for line in reversed(lines[-int(limit):]):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return out


def create_store() -> UserStore:
    """Build the store from the active configuration."""
    from . import config

    return UserStore(
        store_path=config.user_store_path(),
        audit_path=config.audit_log_path(),
        session_ttl=config.SESSION_TTL,
        lockout_seconds=config.AUTH_LOCKOUT_SECONDS,
        max_attempts=config.AUTH_MAX_ATTEMPTS,
        lockout_window=config.AUTH_LOCKOUT_WINDOW,
    )