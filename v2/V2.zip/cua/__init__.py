"""Package root. Version and a convenience export surface."""

__version__ = "0.2.0"

__all__ = [
    "__version__",
]

PACKAGE_ROOT = __path__[0]
