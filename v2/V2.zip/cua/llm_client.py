"""OpenAI-compatible client construction and request-parameter shaping.

Every front-end talks to the main model through the chat-completions
protocol, so the client is built in exactly one place. Request extras
(thinking payload, reasoning effort, image input) are resolved from the
configured model capability profile instead of being hardcoded.
"""

from __future__ import annotations

import uuid
from typing import Any
from urllib.parse import urlsplit

import httpx
from openai import OpenAI

from . import config

#: Hosts that belong to OpenCode (Go subscription and Zen).
#:
#: OpenCode requires a per-conversation session id in ``x-opencode-session``
#: and rejects a request without one::
#:
#:     400 {"type":"error","error":{"type":"MissingSessionID",
#:          "message":"Request is missing x-opencode-session and cannot be
#:                     routed efficiently."}}
#:
#: It is checked *before* model routing, so every model served through these
#: hosts fails identically. It is not an auth problem — a missing or bad key
#: answers 401; this answers 400 on an otherwise valid request.
#:
#: Only well-known OpenCode hosts are listed here. A relay or gateway on a
#: domain this list has never seen cannot be enumerated by name; those are
#: recognised by their API path instead (see ``_OPENCODE_PATH_MARKERS``).
_OPENCODE_HOSTS = ("opencode.ai",)

#: Path markers that only OpenCode serves.
#:
#: A hostname list cannot cover a relay on a domain we have never seen, nor a
#: self-hosted gateway in front of OpenCode. In both cases the operator holds
#: a valid OpenCode Go subscription and every request still comes back 400 —
#: the host gave us nothing to go on. The API path is the part that *is* ours
#: to know: ``/zen/go/v1`` and ``/zen/v1`` are OpenCode's alone, and no other
#: OpenAI-compatible provider serves them.
#:
#: The original hostname-only rule existed to avoid false positives — a URL
#: merely *containing* the name must not pick the header up. A path is held to
#: the same standard: it has to sit on a real segment boundary, never as a
#: substring, so ``/v1/zen/go`` or a query string naming Zen cannot trip it.
_OPENCODE_PATH_MARKERS = ("/zen/go/v1", "/zen/v1")

#: Our own product token for the client-identification requirement in the same
#: docs. Sent as the User-Agent so the official SDK default is not leaked.
_OPENCODE_CLIENT = "cua-webui"


def _matches_opencode_path(url: str) -> bool:
    """Whether *url*'s path is one only OpenCode serves.

    Split out of :func:`is_opencode_endpoint` so the rule can be reasoned
    about on its own. A marker must start a fresh segment: it is the whole
    path, or it ends the path, or the character after it is ``/``. That lets
    ``/zen/go/v1/chat/completions`` and a base URL with trailing slashes
    match while ``/foo/zen/go/v1beta`` does not.

    The query and fragment are excluded by ``urlsplit``, so a credential
    pasted with a ``?`` suffix or a cache-busting ``#`` cannot hide the path.
    """
    path = urlsplit(url).path.rstrip("/")
    if not path:
        return False
    return any(
        path == marker or path.endswith(marker) or (marker + "/") in path
        for marker in _OPENCODE_PATH_MARKERS
    )


def is_opencode_endpoint(base_url: str | None = None) -> bool:
    """Whether *base_url* (default: the configured one) is an OpenCode endpoint.

    Two independent signals, because either one alone leaves a real case
    broken:

    * **Hostname** — matched exactly or on a dot boundary, never as a
      substring, so ``https://opencode.ai.example.com`` and a path merely
      *containing* the name cannot pick the header up by accident. This is
      what keeps the rule safe.
    * **API path** — ``/zen/go/v1`` and ``/zen/v1`` are OpenCode's alone. A
      relay on an unfamiliar domain, or a self-hosted gateway in front of
      OpenCode, is indistinguishable by host but obvious by path; without
      this, every request through one answers 400. This is what makes the
      rule complete.

    The cost of being wrong is asymmetric: missing a real endpoint breaks
    every request the operator makes, while an extra routing header sent to a
    host that ignores it is invisible. Hence both signals, and hence the
    hostname being checked first — the cheap, obviously-correct case.
    """
    url = (base_url if base_url is not None else config.LLM_BASE_URL) or ""
    if not url:
        return False
    if "://" not in url:
        url = f"http://{url}"
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    host = (parts.hostname or "").lower()
    if any(host == h or host.endswith("." + h) for h in _OPENCODE_HOSTS):
        return True
    return _matches_opencode_path(url)


def request_headers(base_url: str | None = None,
                    session_id: str | None = None) -> dict[str, str]:
    """Extra HTTP headers the configured endpoint requires.

    ``session_id`` should be a value that is *stable for one conversation* —
    OpenCode pins consecutive turns of a conversation to the same backend and
    its prompt cache. A fresh id per request still passes the presence check
    but destroys cache reuse, which is the whole reason the header exists, so
    callers with a real session should pass its id. When none is available a
    per-call id is used: correct, merely less efficient.
    """
    if not is_opencode_endpoint(base_url):
        return {}
    return {
        "x-opencode-session": session_id or uuid.uuid4().hex,
        "User-Agent": _OPENCODE_CLIENT,
    }


def build_llm_client(session_id: str | None = None) -> OpenAI:
    """Create an OpenAI client for the configured main model.

    The timeout separates connect (fail fast on a wrong base URL) from read
    (agent turns on large models can legitimately take minutes).

    ``session_id`` flows through to ``x-opencode-session`` when the endpoint
    needs it; see :func:`request_headers`.
    """
    return OpenAI(
        api_key=config.llm_api_key(),
        base_url=config.LLM_BASE_URL,
        timeout=httpx.Timeout(
            connect=15.0,
            read=float(config.LLM_TIMEOUT),
            write=30.0,
            pool=15.0,
        ),
        default_headers=request_headers(session_id=session_id),
    )


def completion_kwargs(
    messages: list[dict],
    tools: list[dict] | None = None,
    stream: bool = True,
    model: str | None = None,
) -> dict[str, Any]:
    """Build the ``chat.completions.create`` keyword arguments.

    Only parameters the resolved model profile supports are attached, so a
    plain text model does not receive ``thinking`` extras it would reject.

    ``model`` overrides the configured main model for a single mission — the
    WebUI lets the operator pick a model per run without mutating the global
    config.
    """
    kwargs: dict[str, Any] = {
        "model": model or config.LLM_MODEL,
        "messages": messages,
        "stream": stream,
    }
    if tools:
        kwargs["tools"] = tools

    if config.supports_thinking():
        kwargs["reasoning_effort"] = config.REASONING_EFFORT
        if config.LLM_ENABLE_THINKING:
            kwargs["extra_body"] = {"thinking": {"type": "enabled"}}

    return kwargs


def describe_llm() -> str:
    """One-line human summary of the active main-model setup."""
    mode = config.resolve_vision_mode()
    vision = (
        "multimodal (main model sees screenshots)"
        if mode == "multimodal"
        else f"text + VLM ({config.VLM_MODEL or 'VLM not configured'})"
    )
    caps = []
    if config.supports_thinking():
        caps.append("thinking")
    if config.supports_vision_input():
        caps.append("vision")
    return (
        f"{config.LLM_MODEL}  @  {config.LLM_BASE_URL}\n"
        f"Vision: {vision}\n"
        f"Capabilities: {', '.join(caps) or 'plain text'}"
    )


def probe(timeout: float = 45.0) -> tuple[bool, str]:
    """Cheap connectivity + credentials check used by the settings page."""
    missing = config.validate_llm_credentials()
    if missing:
        return False, missing.splitlines()[0]
    try:
        client = OpenAI(
            api_key=config.llm_api_key(),
            base_url=config.LLM_BASE_URL,
            timeout=httpx.Timeout(connect=10.0, read=timeout, write=15.0, pool=10.0),
            default_headers=request_headers(),
        )
        client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[{"role": "user", "content": "ping"}],
            max_tokens=16,
            stream=False,
        )
        return True, f"{config.LLM_MODEL} responded successfully"
    except Exception as e:  # surfaced verbatim to the settings page
        return False, f"{type(e).__name__}: {e}"
