"""Token counting for the four models tokencalc supports.

Thin adapter over the vendored ``tokencalc`` package (``vendor/tokencalc``).
Three jobs, and nothing else:

1. **Path wiring.** ``sys.path`` gets the vendored location once, and the
   package's tokenizer root is pointed at the copy inside this repository
   rather than at the author's working directory.
2. **Lazy import.** ``tokenizers`` is a compiled extension. Importing it at
   module load would make every CUA start pay for a feature most runs never
   touch, and would break outright on an install built without it — so the
   import happens on first use and a failure degrades to "unavailable"
   instead of taking the panel down.
3. **The model allow-list.** Only the four models with an exact tokenizer get
   numbers. Everything else reports unsupported rather than guessing, because
   a wrong token count is worse than an absent one.

Nothing here talks to an upstream. Counting is local and offline: the
tokenizer renders the same prompt the model would receive and counts it.
"""

from __future__ import annotations

import sys
import threading
from pathlib import Path
from typing import Any

#: ``vendor/tokencalc`` — a vendored copy of the tokencalc package.
VENDOR_DIR = Path(__file__).resolve().parent.parent / "vendor" / "tokencalc"

#: The four models we can count exactly. Keys match the tokencalc registry.
SUPPORTED_MODELS: tuple[str, ...] = (
    "hy3",
    "hy4",
    "deepseek-v4.1-flash",
    "deepseek-v4-pro",
)

#: Human-facing names, for the UI and for error messages.
MODEL_LABELS: dict[str, str] = {
    "hy3": "混元 Hy3",
    "hy4": "混元 Hy4",
    "deepseek-v4.1-flash": "DeepSeek V4.1 Flash",
    "deepseek-v4-pro": "DeepSeek V4 Pro",
}

#: A prompt prefix stays "cached" for this long, matching the DeepSeek KV
#: cache behaviour the operator asked us to mirror. The upstream keeps its
#: disk cache for hours or days and works on a best-effort basis, so this is
#: deliberately the conservative, documented window rather than a guess at
#: the real eviction time.
CACHE_WINDOW_SECONDS = 600.0

_lock = threading.Lock()
_state: dict[str, Any] = {"tried": False, "calc": None, "error": None}


def _load():
    """Import the vendored calculator once, or record why we could not.

    Returns the ``TokenCalculator``, or ``None`` when the feature is
    unavailable. The reason is kept in ``_state['error']`` so the UI can say
    something specific instead of silently showing nothing.
    """
    with _lock:
        if _state["tried"]:
            return _state["calc"]
        _state["tried"] = True
        try:
            if not VENDOR_DIR.is_dir():
                raise FileNotFoundError(f"未找到内置 token 计算器: {VENDOR_DIR}")
            if str(VENDOR_DIR) not in sys.path:
                sys.path.insert(0, str(VENDOR_DIR))
            from tokencalc import counter as _counter  # type: ignore
            # The vendored package computes its tokenizer root from its own
            # file location, so if it ever ends up installed elsewhere the
            # lookups would silently point at a directory that does not exist.
            # Pin it to the copy shipped with this repo and verify.
            from tokencalc import registry as _registry  # type: ignore

            tokenizers_dir = VENDOR_DIR / "tokenizers"
            if not tokenizers_dir.is_dir():
                raise FileNotFoundError(f"未找到分词器目录: {tokenizers_dir}")
            _registry.TOKENIZER_ROOT = tokenizers_dir

            calc = _counter.TokenCalculator(list(SUPPORTED_MODELS))
            # Prove the tokenizers actually load now rather than on the first
            # real mission: a corrupt or partial copy should be discovered
            # here, where the message can explain it, not mid-run.
            missing = [s.key for s in calc.specs if not s.is_downloaded()]
            if missing:
                raise FileNotFoundError(
                    "分词器文件缺失: " + "、".join(missing)
                )
            _state["calc"] = calc
        except Exception as exc:  # noqa: BLE001 - the panel must still start
            _state["error"] = f"{type(exc).__name__}: {exc}"
        return _state["calc"]


def available() -> bool:
    """Whether exact counting is usable in this install."""
    return _load() is not None


def unavailable_reason() -> str:
    """Why counting is unavailable, or ``""`` when it works."""
    _load()
    return _state["error"] or ""


def resolve(model: str | None) -> str | None:
    """Map an arbitrary model id onto a supported key, or ``None``.

    Matching is case-insensitive and tolerant of the decorations an operator
    may have typed into the model picker — a provider prefix (``cn:hy3``) or a
    trailing variant tag. A model we cannot resolve exactly is *not* guessed
    at: see the module docstring.
    """
    if not model:
        return None
    text = str(model).strip().lower()
    if not text:
        return None
    # Strip a provider prefix ("cn:hy3" -> "hy3") and any "@provider" suffix
    # the panel uses when displaying a label.
    if ":" in text:
        text = text.rsplit(":", 1)[-1]
    text = text.split("@", 1)[0].strip()
    if text in SUPPORTED_MODELS:
        return text
    # hy4 ships from the repo as "hy4-preview" upstream; the operator may have
    # configured either name for the same endpoint.
    if text in ("hy4-preview", "hunyuan4", "hy-4"):
        return "hy4"
    if text in ("hunyuan3", "hy-3"):
        return "hy3"
    return None


def label(model: str | None) -> str:
    """Display name for a supported model (``""`` when unsupported)."""
    key = resolve(model)
    return MODEL_LABELS.get(key, "") if key else ""


def count_messages(messages: list[dict], model: str, **kwargs) -> int | None:
    """Exact input-token count for a rendered conversation.

    ``None`` when the model is unsupported or the tokenizer is missing — the
    caller shows "unsupported" rather than a fabricated number.
    """
    key = resolve(model)
    if key is None:
        return None
    calc = _load()
    if calc is None:
        return None
    try:
        result = calc.count_messages(messages, key, **kwargs)
        return int(result.tokens) if result.ok else None
    except Exception:  # noqa: BLE001 - a count must never break a mission
        return None


def count_text(text: str, model: str) -> int | None:
    """Exact token count for a bare string (used for output estimation)."""
    key = resolve(model)
    if key is None or not text:
        return 0 if key else None
    calc = _load()
    if calc is None:
        return None
    try:
        return int(calc.count_text(text, key).tokens)
    except Exception:  # noqa: BLE001
        return None


def render_prompt(messages: list[dict], model: str, **kwargs) -> str | None:
    """The exact prompt string the model would receive, or ``None``.

    Exposed because prefix matching has to compare *the prompt as the model
    sees it* — BOS tokens and role markers included. Comparing the raw
    messages instead would report a different cache boundary than the model
    actually uses.
    """
    key = resolve(model)
    if key is None:
        return None
    try:
        from tokencalc import prompts  # type: ignore

        spec = next((s for s in _load().specs if s.key == key), None)
        if spec is None:
            return None
        return prompts.build_prompt(spec, messages, **kwargs)
    except Exception:  # noqa: BLE001
        return None


def model_info() -> list[dict]:
    """Supported models with context length, for the settings/statistics UI."""
    calc = _load()
    if calc is None:
        return [
            {
                "key": key,
                "label": MODEL_LABELS[key],
                "context_length": None,
                "ready": False,
            }
            for key in SUPPORTED_MODELS
        ]
    out = []
    for spec in calc.specs:
        try:
            ctx = spec.context_length()
        except Exception:  # noqa: BLE001
            ctx = None
        out.append({
            "key": spec.key,
            "label": spec.display,
            "context_length": ctx,
            "ready": spec.is_downloaded(),
        })
    return out
