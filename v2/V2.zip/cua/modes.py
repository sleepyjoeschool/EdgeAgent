"""Operating-mode policy: what GUI mode may do, and what CIL may not.

Two modes, one rule:

* ``gui`` — full access. Everything is available, including the mouse, the
  keyboard and the screen itself.
* ``cil`` — non-desktop tasks only. The agent drives the machine through the
  command line, through the file/code connector, or through a real browser
  driven by the ``fullchrome`` connector. Anything that reaches for the
  desktop heap — the mouse, the keyboard, the screen, the clipboard — is
  refused, because that is the surface the operator is using themselves.

Why a hard refusal rather than a prompt telling the model to be careful: the
model is told "prefer the command line" and then decides a click is easier.
An instruction is a suggestion; this is the enforcement point. Two layers use
it, and both answer the same way:

* ``LoadSkillCategory`` refuses to load a desktop category (engine.py), so a
  CIL mission never pays the context cost of tools it cannot call.
* ``dispatch`` refuses the call itself (executors/__init__.py), because a
  model can name a tool it never loaded — the schema is a convention, not a
  guarantee.

Browser browsing stays available in CIL. ``fullchrome`` drives a real Chrome
window, but it drives it as a *browser* — navigate, snapshot, click elements
by selector, read content — which is a web task, not desktop automation.
Remote SSH access stays available for the same reason: ``ssh`` reaches *another*
machine's command line and never touches this one's desktop heap.
Clipboard is refused: it is a single global resource shared with the operator,
so writing to it in a mode whose premise is "stay out of the operator's way"
would be incoherent.
"""

from __future__ import annotations

GUI = "gui"
CIL = "cil"

# Categories whose every tool reaches the desktop heap. Loading or calling any
# of these in CIL mode is refused.
DESKTOP_ONLY_CATEGORIES: frozenset[str] = frozenset({
    "keyboard",        # types into whatever window has focus
    "mouse",           # moves and clicks the shared cursor
    "screen_capture",  # reads pixels off the operator's screen
    "vlm",             # reasons about those same pixels
})

# Every category resolves to exactly one executor module, and the browser,
# file and remote-SSH connectors share ``connector`` — which is why the
# dispatch-time check keys off this rather than off the category name. Naming a
# tool the model never loaded is a bypass of the load check, and the way to close
# it is to ask the same question the dispatcher answers: which executor is this?
CATEGORY_EXECUTOR: dict[str, str] = {
    "keyboard": "keyboard",
    "mouse": "mouse",
    "shell": "shell",
    "screen_capture": "screen_capture",
    "vlm": "vlm",
    "basic": "basic",
    "codemodify": "connector",
    "fullchrome": "connector",
    "ssh": "connector",
}

# Executors that are refused outright in CIL, derived from the category table
# so the two lists cannot drift apart.
DESKTOP_ONLY_EXECUTORS: frozenset[str] = frozenset(
    CATEGORY_EXECUTOR[name] for name in DESKTOP_ONLY_CATEGORIES
)

# Tools inside otherwise-allowed categories. ``basic`` is shared: counting,
# waiting and asking the operator are mode-neutral, but the clipboard is a
# single global resource shared with the operator and does not belong to a
# mode that promises not to touch their desktop.
DESKTOP_ONLY_TOOLS: frozenset[str] = frozenset({
    "BasicFunction_WriteToClipboard",
    "BasicFunction_ReadFromClipboard",
})


def normalize(mode: str | None) -> str:
    """Coerce anything into ``"gui"`` or ``"cil"``.

    Case and surrounding whitespace are forgiven, because both are transport
    accidents rather than intent. Unknown values fall back to GUI: defaulting
    *open* is deliberate, since a typo in a request body must not silently
    strip an operator of the tools a mission needs, and defaulting to CIL
    would break missions in the more confusing direction.
    """
    return CIL if str(mode or "").strip().lower() == CIL else GUI


def is_cil(mode: str | None) -> bool:
    return normalize(mode) == CIL


def desktop_only_reason(category: str) -> str:
    """Why *category* is unavailable in CIL mode, as operator-facing text."""
    return (
        f"SAFETY BLOCK: category '{category}' is a desktop automation "
        f"category and this mission runs in CIL (command-line) mode, which "
        f"only executes non-desktop tasks. The mouse, the keyboard, screen "
        f"capture and VLM screen analysis are unavailable here. Use the "
        f"'shell' category for command-line work, 'codemodify' for files and "
        f"code, or 'fullchrome' for web browsing. Use 'ssh' when the machine "
        f"you need is a REMOTE host rather than this one. Switch the mission "
        f"to GUI mode if this task genuinely requires driving the desktop."
    )


def desktop_only_tool_reason(tool_name: str, alternative: str = "") -> str:
    """Why *tool_name* is unavailable in CIL mode.

    *alternative* names the category that covers the same need, so the model
    can reroute inside the step it was blocked in instead of burning the step
    on a retry.
    """
    hint = f" Use {alternative} instead." if alternative else ""
    return (
        f"SAFETY BLOCK: '{tool_name}' is a desktop tool and this mission runs "
        f"in CIL (command-line) mode, which only executes non-desktop tasks. "
        f"There is no way to take over the screen, the mouse, the keyboard or "
        f"the clipboard in this mode.{hint} Switch the mission to GUI mode if "
        f"this task genuinely requires driving the desktop."
    )


# Appended to the system prompt so the model knows the rule before it plans,
# rather than discovering it one refused tool call at a time.
CIL_PROMPT_ADDENDUM = (
    "[Operation mode: CIL / command line only] This mission is running in CIL "
    "mode. Only non-desktop tasks may be performed.\n"
    "Available: the 'shell' category for command-line execution, 'codemodify' "
    "for reading and writing files and code, 'fullchrome' for web browsing "
    "(navigate, snapshot, click elements, read page content), the 'ssh' "
    "category for remote hosts (probe a machine, run commands there, list and "
    "transfer files), and the mode-neutral 'basic' utilities (counting, "
    "waiting, asking the operator).\n"
    "NOT available — attempting to load or call these is refused: the "
    "'keyboard' and 'mouse' categories, the 'screen_capture' and 'vlm' "
    "categories, and the clipboard tools in 'basic'. There is no way to take "
    "over the screen, the mouse, the keyboard or the clipboard in this mode; "
    "do not plan steps that require them. If the task genuinely cannot be "
    "done without the desktop, say so and stop rather than retrying — the "
    "operator can restart the mission in GUI mode.\n"
    "Prefer the command line over GUI automation for anything a command can "
    "do; use the shell rather than launching an application and clicking it."
)


def prompt_addendum(mode: str | None) -> str:
    """The system-prompt addendum for *mode*, or "" when there is nothing to add."""
    return CIL_PROMPT_ADDENDUM if is_cil(mode) else ""


def category_allowed(category: str, mode: str | None) -> bool:
    """Whether *category* may be loaded / advertised in *mode*."""
    if is_cil(mode) and category in DESKTOP_ONLY_CATEGORIES:
        return False
    return True


def tool_allowed(tool_name: str, mode: str | None) -> bool:
    """Whether *tool_name* may be dispatched in *mode*.

    Checked by executor, not by category: at dispatch time the category is
    not known — only the tool name is — and the prefix is exactly what the
    dispatcher itself routes on. An unknown prefix falls through to the
    dispatcher, which rejects it by name anyway, so an unrecognised tool is
    not treated as a desktop one here.
    """
    if not is_cil(mode):
        return True
    if tool_name in DESKTOP_ONLY_TOOLS:
        return False
    for prefix, executor in CATEGORY_EXECUTOR_PREFIXES.items():
        if tool_name.startswith(prefix):
            return executor not in DESKTOP_ONLY_EXECUTORS
    return True


# Name prefixes the dispatcher routes on, mapped to the executor each one
# reaches. Mirrors ``executors._PREFIX_ROUTES``; the duplication is deliberate
# — this module must stay importable without pulling in the dispatcher, so
# the two directions are pinned by the tests below rather than by a shared
# import that would create a cycle.
CATEGORY_EXECUTOR_PREFIXES: dict[str, str] = {
    "KeyboardAction_": "keyboard",
    "MouseAction_": "mouse",
    "ShellAction_": "shell",
    "ScreenCaptureAction_": "screen_capture",
    "VLM_Action_": "vlm",
    "BasicFunction_": "basic",
    "CodeModify_": "connector",
    "FullChrome_": "connector",
    "SSH_": "connector",
}


def alternative_for(tool_name: str) -> str:
    """The category to reach for instead of a refused *tool_name*."""
    if tool_name in ("BasicFunction_WriteToClipboard",
                     "BasicFunction_ReadFromClipboard"):
        return ("the 'shell' or 'codemodify' category — pass the value "
                "through a file or a command-line argument")
    if tool_name.startswith("FullChrome_"):
        return "the 'fullchrome' category"
    if tool_name.startswith("CodeModify_"):
        return "the 'codemodify' category"
    if tool_name.startswith("SSH_"):
        return "the 'ssh' category"
    return ("the 'shell' category for command-line work, 'codemodify' for "
            "files and code, 'fullchrome' for web browsing, or 'ssh' for "
            "remote hosts")
