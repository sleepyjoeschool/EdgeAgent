"""Model capability probing.

The setup wizard cannot ask the operator to know which of a dozen OpenAI-compatible
providers they happen to be running. Guessing is not an option either: attaching
an ``image_url`` part to a text-only model fails mid-mission, and asking for
``reasoning_effort`` from a provider that does not know the field fails every
single turn. Both look like "the agent suddenly stopped working" much later.

So the wizard asks the endpoint directly. Each probe is one small, cheap request
whose only purpose is to make the endpoint state a fact rather than a guess:

* ``connectivity``  — the model answers a trivial prompt at all
* ``response_shape``— non-streaming JSON carries a message, and streaming SSE
  delivers a well-formed delta stream (the agent depends on both)
* ``tool_calls``    — the model emits a call we dictated, with parseable JSON args
* ``tool_results``  — a ``role:"tool"`` message round-trips (the OpenAI protocol
  requires the tool message to follow its tool_call; getting this wrong breaks
  the loop in a way that is very hard to diagnose later)
* ``vision``        — an ``image_url`` part is accepted and the model can
  describe what it sees
* ``thinking``      — ``reasoning_content`` comes back when reasoning is asked for

Nothing here reads or writes ``config`` globals. A probe runs against a candidate
endpoint *before* anything is saved, so a wrong guess cannot poison the running
configuration — that separation is the whole reason this is a separate module
instead of a function on ``llm_client``.
"""

from __future__ import annotations

import base64
import io
import json
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

# Each probe gets its own budget. They run sequentially so a hung endpoint
# cannot multiply the wait; the wizard shows progress per step.
PROBE_TIMEOUT = 45.0

# Token budgets. Small on purpose — these are probes, not work — but not so
# small that a reasoning model gets cut off before it answers.
PROBE_MAX_TOKENS = 512

# The connectivity ping asks for a single word, so its budget only has to cover
# whatever the model thinks beforehand. That turns out to be unbounded in
# practice: big-pickle's reasoning length varies run to run, and even 512 gets
# truncated often enough to make a healthy endpoint look broken. It therefore
# gets a much larger allowance, plus retries in run_probes.
CONNECTIVITY_MAX_TOKENS = 2048
CONNECTIVITY_RETRIES = 2

#: Budget for the vision probe, doubled on every retry.
#:
#: The answer is one word, but a reasoning model thinks first, and the budget
#: covers thinking *and* answer. 32 tokens is nowhere near enough — the model
#: runs out mid-thought, returns empty content with finish_reason="length", and
#: the probe wrongly reports "no image input". See probe_vision.
VISION_MAX_TOKENS = 256

#: Attempts for the optional probes (vision, thinking).
#:
#: Three, not one. These endpoints are rate limited, and a single 429 used to
#: be recorded as "this model cannot see images" — permanently, because the
#: wizard persists what it measured. A transient fault must not outlive the
#: request that hit it.
VISION_ATTEMPTS = 3

#: Seconds to wait before retrying a transient failure. Scaled by attempt
#: number, so a rate limit gets progressively more room to clear.
TRACE_RETRY_DELAY = 1.5

# The probe image: 512x512, one flat colour, PNG.
#
# **This must not be shrunk.** It used to be a 1x1 pixel, which some upstreams
# refuse outright::
#
#     400 invalid_parameter: Image too small (area=1px),
#         minimum required area: >256px
#
# That rejection then read as "this model does not accept images" — the probe
# blaming the model for its own input. The endpoint accepted images perfectly
# well; we were handing it one it had declared too small to look at.
#
# 512x512 clears the requirement under either reading of "area": width*height
# is 262144, and the shorter side alone is 512. A flat colour keeps the PNG to
# ~1.1 KB, so the base64 below costs about 1.5 KB on the wire — nothing next to
# a screenshot, and too small for any endpoint to object to on size grounds.
#
# Solid red, so the expected answer ("red") is unambiguous and can be checked.
_PROBE_IMAGE_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAAFl0lEQVR42u3VMQEAAAjDMMC/"
    "5+GBl0RCn3YKgI9GAgADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAA"
    "AAwAAAMAwAAAMAAADAAAAwDAAAAwAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAAADAAAAwAAAMA"
    "wAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAA"
    "ADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDA"
    "AAAwAAAMAAADADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAA"
    "MAAADAAAAwDAAAAwAAAMAAADADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAA"
    "AAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAMA"
    "wAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAAD"
    "AMAAADAAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDA"
    "AAAwAAAMAAADAMAAADAAAAOQAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAA"
    "ADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAw"
    "AAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAAADAAAAwAAAMAwAAAMAAA"
    "DAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADADAAAAwA"
    "AAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAAAMAAADAMAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMA"
    "wAAAMAAADAAAAwDAAAAwAAAMAAADAMAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAA"
    "ADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAMAwAAAMAAADAAAAwDAAAAw"
    "AAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAMAwAAAMAAA"
    "DAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAA"
    "AAwAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADAMAAADAAAAwAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAABuFht5BP+1U8orAAAAAElFTkSuQmCC"
)

#: What the patch above should make a working vision model answer. Kept next to
#: the image so the two cannot drift: a probe that sends one colour and accepts
#: any answer proves nothing — a text-only model replying "I cannot see images"
#: would be recorded as vision-capable.
_PROBE_IMAGE_COLOUR = "red"

#: Accepted wordings for the patch's colour, English and Chinese.
#:
#: Deliberately generous. A model looking at a red square may say "red",
#: "crimson" or even "pink" (measured: a crimson patch drew "Pink" from
#: deepseek-v4.1-flash), and the Chinese words cover a model that answers in
#: the operator's language. Rejecting those would reintroduce the very
#: false-negative this probe keeps getting wrong.
_PROBE_IMAGE_COLOUR_WORDS = (
    "red", "crimson", "scarlet", "maroon", "ruby", "vermilion", "pink",
    "红", "赤", "粉", "朱",
)

#: The second patch, used only to *discriminate*. See probe_vision.
#:
#: A single image cannot separate "this model cannot see" from "this model
#: misnamed one colour": both look like a wrong answer. Sending a second image
#: of a different colour can, because a model that is actually looking must
#: answer differently. Measured on longcat-2.5-preview-free, which answered
#: "blue" for a red square, "Black" for a blue one and "Blue" for a green one
#: — three different images, no relation between input and answer. That is a
#: model reading no image, and it deserves a definite verdict rather than the
#: "unverified" a one-image probe can honestly give.
_PROBE_IMAGE_B64_ALT = (
    "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAAFmElEQVR42u3VMQEAAAjDsIF/"
    "z+CBl0RCn1YyAeCflgDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADAMAAADAAAAwAAAMAwAAAMAAADADAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADADAAAAwAAAMAAADAMAAADAAAAwAAAMA"
    "wAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwAwAAAMAAADAMAA"
    "ADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwAw"
    "AAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAA"
    "MAAADAAAAwDAAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAA"
    "AAwAAAMAwAAAMAAADAAAAwDAAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAADAMAAADAAAAwAAAMA"
    "wAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAA"
    "ADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDA"
    "AAAwAAAMAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAA"
    "MAAADAAAAwDAAAAwAAAMAMAAJAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAw"
    "AAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAA"
    "DAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwAwAAAMAAADAMAAADAAAAwA"
    "AAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAMAAAD"
    "AMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMA"
    "wAAAMAAADAAAAwDAAAAwAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAA"
    "ADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAw"
    "AAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAAADAAAAwAAAMAwAAAMAAA"
    "DAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAMAAADAAAAwA"
    "AAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAM"
    "AAADADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMAwAAAMAAADAAA"
    "AwDAAAAwAAAMAAADADAAAAwAAAMAwAAAMAAADAAAAwDAAAAwAAAMAAADAMAAADAAAAwAAAMA"
    "wAAAMAAADACAmwUZewT/CUXzogAAAABJRU5ErkJggg=="
)

#: Accepted wordings for the second patch's colour.
_PROBE_IMAGE_ALT_COLOUR_WORDS = (
    "blue", "azure", "cobalt", "navy", "sapphire", "indigo",
    "蓝", "靛", "青",
)


class ProbeError(Exception):
    """A probe could not be run at all (bad URL, missing key, network down)."""


@dataclass
class ProbeResult:
    """Outcome of one capability probe."""

    key: str
    label: str
    ok: bool
    detail: str = ""
    ms: int = 0
    #: "required" probes block setup; "optional" ones only produce a warning.
    severity: str = "optional"
    #: Evidence worth showing the operator, e.g. the model's own reply.
    evidence: str = ""
    #: True when the probe never ran because an earlier one already failed.
    #: Distinct from ``ok=False``: nothing was learned about this capability.
    skipped: bool = False
    #: True when the probe ran but the answers did not support a conclusion —
    #: a flaky gateway, a rate limit, or a budget that the retries never got
    #: past. ``ok=False`` is a *claim* ("this model cannot do it"); this is an
    #: admission ("we could not find out").
    #:
    #: The distinction is load-bearing. The wizard used to fold every failed
    #: vision probe into ``ok=False``, which then persisted
    #: ``LLM_PROBED_VISION=false`` and had the console report "does not accept
    #: images" for a model that accepts them every time — a transient 500 at
    #: probe time turned into a permanent, wrong configuration.
    inconclusive: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "label": self.label,
            "ok": self.ok,
            "detail": self.detail,
            "ms": self.ms,
            "severity": self.severity,
            "evidence": self.evidence,
            "skipped": self.skipped,
            "inconclusive": self.inconclusive,
        }


@dataclass
class ProbeReport:
    """Everything the wizard needs to render one endpoint's capabilities."""

    base_url: str = ""
    model: str = ""
    results: list[ProbeResult] = field(default_factory=list)
    #: Wall-clock cost of the whole run.
    total_ms: int = 0

    def get(self, key: str) -> ProbeResult | None:
        for r in self.results:
            if r.key == key:
                return r
        return None

    @property
    def blocked(self) -> bool:
        """True when a required capability was *rejected* — setup must not finish.

        Two kinds of "not ok" are excluded, because neither is evidence that
        the capability is missing:

        * **Skipped** — never ran, because an earlier probe failed. Counting it
          would turn "tool calling unsupported" into two failures instead of
          one, and make an unreachable endpoint look like a model problem.
        * **Inconclusive** — ran, but the endpoint failed transiently (rate
          limit, 5xx). The most common way to reach this state is a rate limit
          on the tool-call probe, and hard-blocking on it told the operator to
          go find a different model when they already had a working one. The
          wizard still surfaces it, as a conflict they can see and force past.
        """
        return any(
            r.severity == "required" and not r.ok and not r.skipped and not r.inconclusive
            for r in self.results
        )

    @property
    def capabilities(self) -> dict[str, bool | None]:
        """What each capability is believed to be.

        Three states, not two: ``True`` supported, ``False`` rejected by the
        endpoint, ``None`` not established. A probe that ran but reached no
        conclusion must not be read as a rejection — that is what produced the
        "this model cannot see images" report for a model that can.
        """
        out: dict[str, bool | None] = {}
        for r in self.results:
            out[r.key] = None if (r.skipped or r.inconclusive) else r.ok
        return out

    def capability_unknown(self, key: str) -> bool:
        """Whether *key* was never established (skipped or inconclusive)."""
        return self.capabilities.get(key) is None

    def as_dict(self) -> dict[str, Any]:
        return {
            "base_url": self.base_url,
            "model": self.model,
            "total_ms": self.total_ms,
            "blocked": self.blocked,
            "results": [r.as_dict() for r in self.results],
        }


def _client(api_key: str, base_url: str, timeout: float):
    """An OpenAI client bound to the candidate endpoint, not to global config.

    The connection-pool settings matter more than they look. Reasoning models
    on a local gateway routinely take 10-20 s per call; with the httpx default
    of 10 max connections and a 5 s keep-alive, a probe run that fires six
    requests leaves every connection occupied by a still-open response. The
    next request then finds no free connection, and some gateways answer that
    with an HTML error page — which surfaced as a baffling "<!DOCTYPE html>"
    on probes two through six while probe one passed.

    *Keep-alive is disabled on purpose.* Some OpenAI-compatible gateways mishandle
    HTTP/1.1 connection reuse and answer the second request on a reused socket
    with `404 Cannot POST /v1/chat/completions` plus an HTML body. Measured on a
    local gateway: request 1 returned 200, requests 2..N on the same persistent
    connection all returned that 404 — which surfaced as every probe from the
    second onward failing with a bare "<!DOCTYPE html>".

    Sending ``Connection: close`` makes every probe open its own socket, which
    every server handles correctly. The cost is a TCP handshake per probe,
    which is irrelevant next to a model round trip. Verified: 12 back-to-back
    requests that way all succeed, including at zero delay.

    The trade-off is deliberate: a reused connection is faster in steady state,
    but a gateway that breaks on reuse makes *every* probe after the first lie
    about the endpoint's capabilities. Probing must be trustworthy.
    """
    from openai import OpenAI

    from . import llm_client

    # Computed once per probe run and reused. Two reasons it is not left to
    # ``default_headers`` alone: the connectivity probe below speaks raw httpx
    # and so cannot inherit the SDK's headers, and giving every request of one
    # run the same value is exactly what the session header is for.
    required = llm_client.request_headers(base_url)

    client = OpenAI(
        api_key=api_key or "local-no-key-required",
        base_url=base_url,
        timeout=httpx.Timeout(
            connect=12.0, read=timeout, write=30.0, pool=30.0
        ),
        max_retries=0,
        # The probe deliberately targets a *candidate* endpoint, so it has to
        # carry whatever that endpoint requires rather than only what the
        # currently-saved config needs. Without this, probing OpenCode fails
        # with 400 MissingSessionID and the wizard would report a healthy
        # endpoint as broken before the operator ever saves it.
        default_headers=required,
        http_client=httpx.Client(
            limits=httpx.Limits(max_connections=8, max_keepalive_connections=0),
            timeout=httpx.Timeout(
                connect=12.0, read=timeout, write=30.0, pool=30.0
            ),
            headers={"Connection": "close"},
            follow_redirects=True,
        ),
    )
    # Handed to probe_connectivity, which cannot see the SDK's headers at all.
    client._cua_required_headers = required
    return client


def normalise_base_url(url: str) -> str:
    """Accept what people actually paste: with or without ``/v1``.

    Providers disagree on whether the OpenAI-compatible root includes ``/v1``,
    and pasting the console's "API host" without it is the single most common
    setup mistake. We normalise rather than reject, then let the connectivity
    probe confirm.
    """
    url = (url or "").strip().rstrip("/")
    if not url:
        return url
    if url.endswith("/chat/completions"):
        return url[: -len("/chat/completions")]
    if not url.endswith("/v1") and "/v1/" not in url:
        url = url + "/v1"
    return url


def _error_text(exc: Exception) -> str:
    """Flatten an SDK/HTTP exception into something an operator can act on."""
    text = str(exc).strip()
    # The SDK embeds a JSON body; the first meaningful line is the useful one.
    for marker in ("Error code:", "error - "):
        if marker in text:
            text = text.split(marker, 1)[1].strip()
            break
    for line in text.splitlines():
        line = line.strip()
        if line:
            return line[:300]
    return type(exc).__name__


def _is_auth_error(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(
        token in text
        for token in ("401", "403", "unauthorized", "invalid api key", "authentication")
    )


def _is_tool_choice_error(text: str) -> bool:
    """Whether the rejection is about ``tool_choice`` rather than tools.

    Worth distinguishing because the two mean opposite things: "no tools
    support" is fatal for this agent, while "no forced tool_choice" costs
    nothing — the agent never forces a choice.
    """
    lowered = (text or "").lower()
    return "tool_choice" in lowered and (
        "does not support" in lowered
        or "not support" in lowered
        or "invalid" in lowered
        or "unsupported" in lowered
    )


def _is_missing_feature(exc: Exception) -> bool:
    """Whether the endpoint rejected a *parameter* rather than failing outright.

    Deliberately narrow: it must not swallow a complaint about the probe's own
    input. "Image too small" is a 400 with ``invalid_request_error`` in it, so a
    token list containing that type would classify a fixable bug in this file
    as a missing model capability. See :func:`_is_probe_input_error`.
    """
    if _is_probe_input_error(exc):
        return False
    text = str(exc).lower()
    return any(
        token in text
        for token in (
            "unsupported", "not support", "unknown parameter",
            "unrecognized", "does not support", "not allowed", "unrecognized request argument",
        )
    )


#: Complaints about the *image we sent*, not about the model's abilities.
#:
#: Worth their own classifier because the failure looks like a capability
#: answer and is not one. A real case::
#:
#:     400 invalid_request_error: Upstream request failed: [invalid_parameter]
#:         Image too small (area=1px), minimum required area: >256px
#:
#: The model read images fine — the probe had been sending a 1x1 pixel. Folded
#: into "does not support images", it sent the operator off to reconfigure a
#: working setup. These are bugs in the probe, and saying so is the honest
#: report.
_PROBE_INPUT_MARKERS = (
    "image too small", "too small", "minimum required area", "minimum size",
    "image too large", "too large", "dimensions", "invalid image",
    "image format", "unsupported image", "invalid_parameter", "invalid parameter",
)


def _is_probe_input_error(exc: Exception) -> bool:
    """Whether the endpoint is objecting to the probe image rather than the model."""
    text = str(exc).lower()
    return any(marker in text for marker in _PROBE_INPUT_MARKERS)


def describe_bad_response(text: str, status: int, content_type: str = "") -> str:
    """Turn an unusable HTTP response into something the operator can act on.

    The failure modes here are the ones that look identical if you only read
    "no message.content": a proxy login page served with HTTP 200, an HTML error
    body, a JSON envelope the SDK does not recognise, or a gateway that answers
    200 with an empty object. Each needs a different fix, so each gets named.
    """
    snippet = (text or "").strip()

    if not snippet:
        return f"HTTP {status}：响应体为空"

    lowered = snippet[:400].lower()

    if "<html" in lowered or "<!doctype" in lowered:
        # Extremely common: a reverse proxy or auth portal answering with a
        # web page. The status line lies; the body does not.
        return (
            f"HTTP {status} 但返回的是网页而不是 JSON —— "
            "Base URL 可能指向了代理登录页或管理界面，而不是 API 端点"
        )

    if "unauthorized" in lowered or "forbidden" in lowered:
        return f"HTTP {status}：鉴权失败（返回了 HTML 而非 JSON）—— API Key 可能无效"

    # A gateway in front of the model reports *its own* upstream failure, so the
    # status describes the proxy rather than the endpoint. These are the forms
    # seen in practice: 502/503 from nginx, "unknown host" wording on Windows,
    # and the 11001/10054 codes those map to.
    upstream_markers = (
        "upstream connect failed",
        "unknown host",
        "unknown_hosts",
        "no such host",
        "name or service not known",
        "nodename nor servname",
        "11001",     # Windows: unknown host
        "10054",     # Windows: connection reset by peer
        "10060",     # Windows: connection timed out
        "econnrefused",
    )
    if any(marker in lowered for marker in upstream_markers):
        return (
            f"HTTP {status} 无法连接到模型服务 —— 这是前置网关报的错，"
            f"不是模型端点本身的响应。可能是 Base URL 指向了网关而非模型端点、"
            f"域名不存在，或该服务未启动。原始信息：{snippet[:120]}"
        )

    if status == 502:
        return f"HTTP 502 网关错误：{snippet[:180]} —— 上游服务不可达"
    if status == 503:
        return f"HTTP 503 服务不可用：{snippet[:180]} —— 服务过载或维护中"

    if status >= 400:
        return f"HTTP {status}：{snippet[:200]}"

    # 200 but unparseable. Try to surface the real envelope.
    try:
        payload = json.loads(snippet)
    except (json.JSONDecodeError, ValueError):
        return (
            f"HTTP {status} 但响应不是合法 JSON"
            f"（{content_type or '未知类型'}）：{snippet[:160]}"
        )

    if isinstance(payload, dict):
        # Unwrap the common gateway envelopes so the real message is visible.
        for path in (("data",), ("result",), ("response",), ("body",)):
            node = payload
            for key in path:
                node = node.get(key) if isinstance(node, dict) else None
                if node is None:
                    break
            if isinstance(node, dict) and node.get("choices"):
                return (
                    f"HTTP {status}：响应被包装在 {'.'.join(path)} 里，"
                    "不是标准的 chat.completion 格式 —— 该网关可能不兼容 OpenAI 协议"
                )

        err = payload.get("error")
        if isinstance(err, dict) and err.get("message"):
            return f"HTTP {status}：{str(err['message'])[:200]}"
        if isinstance(err, str):
            return f"HTTP {status}：{err[:200]}"
        if payload.get("message"):
            return f"HTTP {status}：{str(payload['message'])[:200]}"

        keys = ", ".join(list(payload)[:8]) or "(空对象)"
        return (
            f"HTTP {status} 但响应结构不是 chat.completion"
            f"（顶层字段：{keys}）—— 该端点可能不兼容 OpenAI 协议"
        )

    return f"HTTP {status}：响应是 {type(payload).__name__}，不是预期的对象"


# ── Individual probes ──────────────────────────────────────────────────

_PROBE_TOOL = {
    "type": "function",
    "function": {
        "name": "probe_echo",
        "description": "Echo back the given value. Used to test tool calling.",
        "parameters": {
            "type": "object",
            "properties": {"value": {"type": "string"}},
            "required": ["value"],
        },
    },
}


def probe_connectivity(client, model: str) -> tuple[bool, str, str]:
    """Can this endpoint answer anything at all?

    Reads the raw HTTP body before involving the SDK. That ordering is
    deliberate: when a gateway serves an HTML login page with status 200, or
    wraps the completion in its own envelope, the SDK's parse error hides the
    only information that tells the operator what to fix. The status line and
    the body are the ground truth.
    """
    url = f"{str(client.base_url).rstrip('/')}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        # Must match the SDK client: a reused socket is not reliable on every
        # gateway, and this probe shares the endpoint with the rest of the run.
        "Connection": "close",
    }
    # This request is issued with raw httpx (see the docstring), so it does not
    # inherit the SDK client's headers — anything the endpoint requires has to
    # be repeated here. OpenCode answers 400 MissingSessionID without its
    # session header, and because connectivity gates every other probe, that
    # single omission reported a perfectly healthy endpoint as unreachable.
    headers.update(getattr(client, "_cua_required_headers", None) or {})
    api_key = getattr(client, "api_key", None)
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "Reply with the single word: pong"}],
        "max_tokens": CONNECTIVITY_MAX_TOKENS,
        "stream": False,
    }

    started = time.time()
    try:
        response = httpx.post(url, headers=headers, json=payload, timeout=45.0)
    except Exception as e:  # noqa: BLE001 - network-level failure
        text = str(e)
        # Windows and POSIX report the same underlying failure very
        # differently: a DNS miss surfaces as getaddrinfo on Linux but as a
        # reset connection (WinError 10054/10060) on Windows, because the
        # resolver answers before the socket is ever used. Matching only the
        # POSIX wording left Windows users with a bare error code.
        lowered = text.lower()
        if "certificate" in lowered or "ssl" in text.lower():
            hint = (" —— TLS 证书校验失败；"
                    "若是自签名证书，可改用 http:// 或关闭证书验证")
        elif ("name or service not known" in lowered or "getaddrinfo" in lowered
              or "nodename nor servname" in lowered
              or "10054" in text or "10060" in text
              or "no address associated" in lowered):
            hint = " —— 域名解析或连接被中断，请检查 Base URL 是否正确、域名是否存在"
        elif "connection refused" in lowered or "10061" in text:
            hint = " —— 端口未开放或服务未启动"
        elif "timed out" in lowered or "10060" in text:
            hint = " —— 连接超时，请检查网络或 Base URL"
        elif "network is unreachable" in lowered or "10051" in text:
            hint = " —— 网络不可达，请检查本机网络配置"
        else:
            hint = ""
        return False, f"{_error_text(e)}{hint}", ""

    elapsed = int((time.time() - started) * 1000)
    content_type = response.headers.get("content-type", "")

    if response.status_code >= 400:
        # Verdict first. The status code is what tells the operator what to do;
        # appending it after a long response body buries the useful part.
        verdict = ""
        if response.status_code in (401, 403):
            verdict = "API Key 不正确、已过期或无权限"
        elif response.status_code == 404:
            verdict = "路径不存在 —— Base URL 是否需要 /v1 后缀？"
        elif response.status_code == 429:
            verdict = "请求过于频繁或额度已用尽"
        elif response.status_code >= 500:
            verdict = "服务端错误"

        body_text = describe_bad_response(response.text, response.status_code,
                                         content_type)
        detail = f"HTTP {response.status_code}"
        if verdict:
            detail += f"：{verdict}"
        detail += f"（{body_text[:180]}）"
        return False, detail, ""

    # Status is 2xx. The body still has to be a chat.completion.
    try:
        body = response.json()
    except (json.JSONDecodeError, ValueError):
        return False, describe_bad_response(response.text, response.status_code,
                                             content_type), ""

    if not isinstance(body, dict):
        return False, describe_bad_response(response.text, response.status_code,
                                             content_type), ""

    choices = body.get("choices")
    if not isinstance(choices, list) or not choices:
        return False, describe_bad_response(response.text, response.status_code,
                                             content_type), ""

    first = choices[0] if isinstance(choices[0], dict) else {}
    message = first.get("message")
    if not isinstance(message, dict):
        fields = ", ".join(list(first)[:6]) or "(空)"
        return False, (
            f"HTTP {response.status_code} 但 choices[0] 里没有 message 对象"
            f"（实际字段：{fields}）"
        ), ""

    text = str(message.get("content") or "").strip()
    if not text:
        # Empty content is legitimate only when the model answered with a tool
        # call, which this probe never asks for.
        if message.get("tool_calls"):
            return True, f"响应正常（{elapsed}ms）", ""
        refusal = message.get("refusal")
        if refusal:
            return False, f"模型拒绝了请求：{str(refusal)[:200]}", ""

        finish = first.get("finish_reason")
        completion = (body.get("usage") or {}).get("completion_tokens")
        if finish == "length":
            # The most misreadable failure there is: the endpoint is fine, the
            # model simply ran out of budget mid-thought. big-pickle did exactly
            # this with a 32-token budget and returned an empty content.
            spent = f"，已消耗 {completion} 个 token" if completion else ""
            return False, (
                f"输出被 max_tokens 截断（finish_reason=length{spent}）—— "
                f"这不是端点故障，而是该模型的思考过程超出了探测给的额度。"
                f"该模型本身可用，只是需要更大的 token 预算"
            ), ""
        return False, (
            f"响应中 message.content 为空"
            f"（finish_reason={finish or '未提供'}）—— "
            f"该端点可能不返回标准 OpenAI 格式，或模型对该请求没有产生输出"
        ), ""

    return True, f"响应正常（{len(text)} 字符，{elapsed}ms）", text[:200]


def probe_response_shape(client, model: str) -> tuple[bool, str, str]:
    """Non-streaming shape plus a real SSE stream.

    The agent uses streaming exclusively for chat turns and non-streaming for the
    security audit, so both paths have to work. A provider that streams a
    malformed delta sequence passes connectivity but breaks every mission.
    """
    # -- non-streaming
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Count: 1 2 3. Reply with just the number."}],
            # Reasoning models spend the whole budget thinking before emitting
            # anything; a 24-token allowance left content empty and read as a
            # broken endpoint.
            max_tokens=CONNECTIVITY_MAX_TOKENS,
            stream=False,
        )
        content = (response.choices[0].message.content or "").strip()
        if not content:
            return False, "非流式响应缺少 message.content", ""
        if not getattr(response, "usage", None):
            # Not fatal — some local servers omit usage — but worth reporting.
            nonstream_note = "非流式正常（无 usage 字段）"
        else:
            nonstream_note = "非流式正常"
    except Exception as e:  # noqa: BLE001
        return False, f"非流式失败：{_error_text(e)}", ""

    # -- streaming
    started = time.time()
    chunks = 0
    saw_role = False
    saw_content = False
    saw_reasoning = False
    finish_reason: str | None = None
    stream = None
    try:
        stream = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Say hello in three words."}],
            # Same reasoning-model hazard as the connectivity probe: a budget
            # sized for three words can be consumed entirely by thinking, and
            # the stream then ends with no content at all.
            max_tokens=CONNECTIVITY_MAX_TOKENS,
            stream=True,
        )
        for chunk in stream:
            chunks += 1
            choices = getattr(chunk, "choices", None) or []
            if not choices:
                continue
            delta = getattr(choices[0], "delta", None)
            if delta is not None:
                if getattr(delta, "role", None):
                    saw_role = True
                if getattr(delta, "content", None):
                    saw_content = True
                if getattr(delta, "reasoning_content", None):
                    saw_reasoning = True
            if getattr(choices[0], "finish_reason", None):
                finish_reason = choices[0].finish_reason
                # A finish reason is the stream's own signal that it is done;
                # nothing after it can change the verdict.
                break
            if chunks >= 4000:
                # A runaway stream is a failure, not patience. The limit is
                # high on purpose: a reasoning model emits one chunk per
                # thought token, so a few hundred is normal and bailing out
                # early hides the content entirely — which then reads as "this
                # endpoint cannot stream" when in fact it streamed fine.
                break
    except Exception as e:  # noqa: BLE001
        return False, f"流式失败：{_error_text(e)}", ""
    finally:
        # Breaking out of the loop above leaves the response body unread.
        # Closing releases the socket now rather than whenever the collector
        # gets to it, which is what previously let a run of probes pile up
        # half-read connections and block on the pool lock.
        if stream is not None:
            try:
                stream.close()
            except Exception:
                pass

    elapsed = int((time.time() - started) * 1000)

    if chunks == 0:
        return False, "流式响应没有任何 chunk", ""
    if not saw_content:
        if finish_reason == "length":
            return False, (
                "流式响应被 max_tokens 截断（finish_reason=length，"
                f"共 {chunks} 个分片）—— 该模型的思考过程超出了探测额度，"
                "端点本身正常"
            ), ""
        reasoning_note = "（本次只收到思维链，尚未输出正文）" if saw_reasoning else ""
        return False, f"流式响应没有内容增量{reasoning_note}（共 {chunks} 个分片）", ""
    if finish_reason is None:
        return False, "流式响应缺少 finish_reason", ""

    return True, f"{nonstream_note}；流式正常（{chunks} 个分片，{elapsed}ms）", ""


def probe_tool_calls(client, model: str) -> tuple[bool, str, str]:
    """Can the model emit a tool call, with parseable arguments?

    We hand it a single tool with one required string argument and ask for that
    exact value. Anything short of a well-formed call — prose instead, malformed
    JSON arguments, a wrong function name — means the agent cannot drive the UI.

    ``tool_choice`` is deliberately **not** pinned to a specific function.
    DeepSeek's thinking mode rejects that outright ("Thinking mode does not
    support this tool_choice"), which made this probe report a perfectly
    capable model as having no tool support at all. The agent never pins
    tool_choice either — it advertises tools and lets the model decide — so the
    probe should test the same thing the agent will actually do.
    """
    started = time.time()
    response = None
    for attempt in range(1, VISION_ATTEMPTS + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": "Call the probe_echo tool with value set to exactly: p42",
                }],
                tools=[_PROBE_TOOL],
                max_tokens=CONNECTIVITY_MAX_TOKENS,
                stream=False,
            )
            break
        except Exception as e:  # noqa: BLE001
            text = str(e)
            # A provider that dislikes a specific tool_choice still supports tools.
            if _is_tool_choice_error(text):
                return False, (
                    "该端点不接受固定 tool_choice，但可能仍支持工具调用 —— "
                    "请重试或查看该端点的 thinking mode 文档"
                ), ""
            if _is_missing_feature(e):
                return False, f"该端点不支持 tools 参数：{_error_text(e)}", ""
            # Retried before concluding: this capability is *required*, so a
            # transient 429 would hard-block setup and read as "the model
            # cannot call tools" — the most expensive wrong answer in the
            # whole probe run.
            if _is_transient(e) and attempt < VISION_ATTEMPTS:
                time.sleep(TRACE_RETRY_DELAY * attempt)
                continue
            if _is_transient(e):
                return _capability_unknown(
                    f"工具调用探测未能完成（{VISION_ATTEMPTS} 次都失败于端点侧临时故障）："
                    f"{_error_text(e)}——这不代表该模型不支持工具调用，建议稍后重试"
                )
            return False, f"{_error_text(e)}", ""

    elapsed = int((time.time() - started) * 1000)

    try:
        message = response.choices[0].message
    except (AttributeError, IndexError):
        return False, "响应中没有 choices[0].message", ""

    calls = getattr(message, "tool_calls", None)
    if not calls:
        content = (getattr(message, "content", None) or "").strip()
        return False, "模型没有返回 tool_call（用文字回答了）", content[:200]

    call = calls[0]
    name = getattr(getattr(call, "function", None), "name", None)
    raw_args = getattr(getattr(call, "function", None), "arguments", None)

    if name != "probe_echo":
        return False, f"返回了错误的工具名：{name}", ""

    try:
        args = json.loads(raw_args or "{}")
    except (json.JSONDecodeError, TypeError):
        return False, f"arguments 不是合法 JSON：{str(raw_args)[:120]}", ""

    if args.get("value") != "p42":
        return False, f"工具参数不正确：{json.dumps(args, ensure_ascii=False)[:120]}", ""

    return True, f"工具调用正常（{elapsed}ms）", json.dumps(args, ensure_ascii=False)


def probe_tool_results(client, model: str) -> tuple[bool, str, str]:
    """Does a ``role:"tool"`` message round-trip?

    OpenAI's protocol requires every ``tool_call`` to be answered by a matching
    ``tool`` message. Providers that reject one break the agent loop in a way
    that surfaces much later as "the model stopped making progress".

    Note the deliberate absence of both ``tools=`` and ``tool_choice``: what is
    under test is the ``tool`` role in the history, not the tool schema and not
    choice control. Advertising the schema would invite another tool call and
    leave nothing to read; forcing a choice adds a second constraint that some
    providers reject independently of tool support.
    """
    started = time.time()
    content = ""
    for attempt in range(1, VISION_ATTEMPTS + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "user", "content": "What did the tool return?"},
                    {"role": "assistant", "content": None, "tool_calls": [{
                        "id": "call_probe_1",
                        "type": "function",
                        "function": {"name": "probe_echo", "arguments": '{"value":"x"}'},
                    }]},
                    {"role": "tool", "tool_call_id": "call_probe_1", "content": "echo:x"},
                ],
                # No tool_choice here either. This probe is about whether a `tool`
                # role message round-trips, and pinning or forbidding a choice adds
                # a second, unrelated constraint — one DeepSeek's thinking mode
                # rejects outright.
                max_tokens=CONNECTIVITY_MAX_TOKENS,
                stream=False,
            )
            content = (response.choices[0].message.content or "").strip()
            break
        except Exception as e:  # noqa: BLE001
            if _is_tool_choice_error(str(e)):
                return False, (
                    "该端点在 thinking mode 下拒绝固定 tool_choice，"
                    "无法验证 tool 消息回传"
                ), ""
            if _is_missing_feature(e):
                return False, f"该端点不接受 tool 消息：{_error_text(e)}", ""
            if _is_transient(e) and attempt < VISION_ATTEMPTS:
                time.sleep(TRACE_RETRY_DELAY * attempt)
                continue
            if _is_transient(e):
                return _capability_unknown(
                    f"tool 消息回传探测未能完成（{VISION_ATTEMPTS} 次都失败于端点侧"
                    f"临时故障）：{_error_text(e)}——这不代表该端点不支持 tool 消息"
                )
            return False, _error_text(e), ""

    elapsed = int((time.time() - started) * 1000)
    if not content:
        return False, "回传 tool 结果后没有内容", ""
    return True, f"tool 结果回传正常（{elapsed}ms）", content[:200]


def _is_transient(exc: Exception) -> bool:
    """Whether *exc* looks like a momentary fault rather than a verdict.

    Rate limits and 5xx say nothing about what a model can do — the same
    request usually succeeds seconds later. Retrying them matters because the
    probes share one tight budget and this endpoint is known to be rate
    limited: without this, the first 429 decides the answer for good.

    Deliberately *not* treated as transient: anything that names a missing
    feature. A 400 saying ``image_url is not supported`` is a real verdict and
    retrying it only wastes the operator's time.
    """
    if _is_missing_feature(exc):
        return False
    text = str(exc).lower()
    return any(
        token in text
        for token in (
            "429", "rate limit", "rate_limit", "too many requests",
            "500", "502", "503", "504", "server error", "internal error",
            "bad gateway", "service unavailable", "gateway timeout",
            "timeout", "timed out", "connection reset", "connection aborted",
            "temporarily", "overloaded", "upstream",
        )
    )


def _capability_unknown(detail: str) -> tuple[bool, str, str]:
    """Wrap a "we could not find out" outcome in the standard 3-tuple.

    Every probe returns ``(ok, detail, evidence)``, so the "no conclusion"
    answer has to be spelled with ``ok=False`` — but the *caller* decides what
    to persist, and it reads :attr:`ProbeResult.inconclusive` for that. Keeping
    the wrapping in one place stops a probe from inventing its own wording and
    accidentally reading as a rejection.
    """
    return False, detail, ""


#: Phrases that mark a *detail* string as "no conclusion reached" rather than
#: "the endpoint said no". Probes that decide for themselves go through
#: :func:`_capability_unknown` and are recognisable by these; the orchestrator
#: uses this to set ``inconclusive`` on their results.
#:
#: **Adding a new "could not find out" message means using one of these
#: phrasings.** A message that reads fine but is absent from this list leaves
#: the result marked as a definite failure — which is exactly how the vision
#: probe kept reporting "does not support images" for models that do. The test
#: suite asserts the two stay in step.
_UNKNOWN_MARKERS = ("未能确认", "未能完成", "不能据此判定")


def _transient_detail(detail: str) -> bool:
    """Whether a failed probe's detail says "unverified" rather than "no"."""
    return any(marker in (detail or "") for marker in _UNKNOWN_MARKERS)


#: Minimum area (width x height) the probe image must have.
#:
#: Some upstreams refuse anything below this — one rejected a 1x1 patch with
#: ``Image too small (area=1px), minimum required area: >256px``. The constant
#: exists so the requirement is checkable rather than folklore: a test asserts
#: the shipped image clears it, which is what stops a future "shrink the
#: payload" change from silently reintroducing the false "no vision" verdict.
PROBE_IMAGE_MIN_AREA = 256


def probe_image_size() -> tuple[int, int]:
    """Width and height of the shipped probe image, read from its PNG header.

    Parsed rather than hardcoded: a constant can disagree with the data, and
    the whole failure mode here was the two drifting apart.
    """
    import struct

    raw = base64.b64decode(_PROBE_IMAGE_B64)
    if len(raw) < 24 or raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise ProbeError("探测图片不是合法的 PNG")
    return struct.unpack(">II", raw[16:24])


def _vision_colour(client, model: str, image_b64: str, budget: int) -> str:
    """Ask the model for one image's colour; return its answer or ``""``.

    Extracted so the discriminating second image goes through exactly the same
    request shape as the first. A helper that built a slightly different
    message would make the comparison meaningless — the whole point is that
    only the image differs.
    """
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text",
                     "text": "Reply with the single dominant colour of this image, "
                             "as one word and nothing else."},
                    {"type": "image_url",
                     "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
                ],
            }],
            max_tokens=budget,
            stream=False,
        )
        return (response.choices[0].message.content or "").strip()
    except Exception:  # noqa: BLE001 - a failed second look is "no answer"
        return ""


def probe_vision(client, model: str) -> tuple[bool, str, str]:
    """Can the model accept an image and say what it sees?

    Sent as a real ``image_url`` data part, because a provider can advertise
    vision and still reject the inline data-URI form we depend on.

    Three failure modes must stay apart, because only one of them is a verdict
    about the model:

    * **The endpoint rejected the image *content*.** A 400 naming ``image_url``
      or an unsupported content type says the model cannot take images. Report
      it and stop.
    * **The endpoint rejected the probe's own input** — "Image too small
      (area=1px), minimum required area: >256px". That is a bug in this file,
      never a fact about the model, and is reported as such
      (:func:`_is_probe_input_error`).
    * **We never got an answer.** Rate limit, 5xx, a timeout, or a reasoning
      model that thought past the budget. None of these say anything about the
      model, so they are retried; if they still fail the outcome is
      *inconclusive*, never "does not support images"
      (:func:`_capability_unknown`).

    All three were learned the hard way. The endpoint is rate limited, so a
    single transient rejection used to persist ``vision=false`` for a model
    that answers correctly on every other attempt; and the probe image was once
    a 1x1 pixel that some upstreams refuse, which was misread the same way.
    """
    # The budget covers *both* the chain of thought and the answer. A reasoning
    # model can spend all of it thinking and emit an empty content with
    # finish_reason="length" — measured on deepseek-v4.1-flash at 32 tokens,
    # 2 runs in 6 came back empty. Judging that as "no vision support" is a
    # false negative, and the operator reads it as "this model cannot see my
    # screen" when the model had in fact already read the image.
    budget = VISION_MAX_TOKENS
    last = ""
    for attempt in range(1, VISION_ATTEMPTS + 1):
        started = time.time()
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text",
                         "text": "Reply with the single dominant colour of this image, "
                                 "as one word and nothing else."},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{_PROBE_IMAGE_B64}"},
                        },
                    ],
                }],
                max_tokens=budget,
                stream=False,
            )
        except Exception as e:  # noqa: BLE001
            # Checked before "missing feature" on purpose: an "image too small"
            # rejection carries ``invalid_request_error``, and the missing-
            # feature test sees the word "invalid" family and would call it a
            # missing capability. This is our bug, and it says so.
            if _is_probe_input_error(e):
                return False, (
                    f"探测图片被端点拒绝（{_error_text(e)}）——"
                    f"这是探测图本身不符合该端点的要求，不代表模型不支持图片；"
                    f"请把这条报给开发者"
                ), ""
            if _is_missing_feature(e):
                return False, f"不支持图片输入：{_error_text(e)}", ""
            last = _error_text(e)
            if _is_transient(e) and attempt < VISION_ATTEMPTS:
                time.sleep(TRACE_RETRY_DELAY * attempt)
                continue
            if _is_transient(e):
                return _capability_unknown(
                    f"图片探测未能完成（{VISION_ATTEMPTS} 次都失败于端点侧临时故障）："
                    f"{last}——这不代表该模型不支持图片，建议稍后重试"
                )
            # A hard error that is not about the feature (bad key, unknown
            # model) — an earlier probe normally catches it, but say so plainly.
            return False, last, ""

        elapsed = int((time.time() - started) * 1000)
        message = response.choices[0].message
        content = (message.content or "").strip()
        reasoning = (
            getattr(message, "reasoning_content", None)
            or getattr(message, "reasoning", None)
            or ""
        )
        finish = getattr(response.choices[0], "finish_reason", None)
        last = f"finish_reason={finish!r}，预算 {budget}"

        if content:
            # **Both** patches must be named correctly before vision is claimed.
            #
            # One image is not enough, in either direction. A model that never
            # received the image still guesses, and a guess lands on the right
            # colour often enough to pass — so "it named red" is weak evidence.
            # Answering *two* different images correctly is not, because the
            # answers have to differ, which guessing cannot arrange.
            #
            # Two patches also separate the cases a single one conflates:
            #
            #   * both correct          -> it is reading the image
            #   * same answer to both   -> it is not reading the image at all
            #   * differed, partly wrong-> cannot tell; said so rather than
            #                              guessing which
            #
            # Measured: longcat-2.5-preview-free answered "blue" for a red patch
            # and "Blue"/"Green" for a blue one — unrelated to the input, i.e.
            # genuinely blind, which the one-image probe could only call
            # "unverified".
            first = content
            second = _vision_colour(client, model, _PROBE_IMAGE_B64_ALT, budget)
            evidence = f"红图->{first[:30]!r}；蓝图->{second[:30]!r}"

            named_first = any(w in first.lower() for w in _PROBE_IMAGE_COLOUR_WORDS)
            named_second = any(w in second.lower() for w in _PROBE_IMAGE_ALT_COLOUR_WORDS)
            if named_first and named_second:
                return True, f"图片输入正常（{elapsed}ms）", evidence

            if second and second.strip().lower() == first.strip().lower():
                # Two different images, one answer. Nothing that looks at the
                # image can do that, and it is not a naming quirk — so this is
                # a definite verdict, not an "unverified".
                return False, (
                    f"该模型看不到图片：两张不同颜色的图给出了同一个回答"
                    f"（{first[:40]!r}），说明它没有读到图片内容，只是在猜。"
                    f"请改用「文本模型 + 独立 VLM」，或换一个支持视觉的模型"
                ), evidence

            if not second:
                last = f"第二张图没有得到回答；第一张回答 {first[:30]!r}"
            else:
                last = (f"红图 {first[:24]!r} / 蓝图 {second[:24]!r}"
                        f"，未能两张都说对")
            if attempt < VISION_ATTEMPTS:
                time.sleep(TRACE_RETRY_DELAY * attempt)
                continue
            return _capability_unknown(
                f"图片已送达，但未能确认模型真的看到了图片（{last}）"
            )

        # Empty content after a truncated turn is a budget problem, not a
        # capability one. The retry doubles the budget because the thinking
        # length is nondeterministic — the same request passes on the next try.
        truncated = finish == "length" or bool(reasoning)
        if attempt < VISION_ATTEMPTS:
            budget *= 2
            time.sleep(TRACE_RETRY_DELAY * attempt)
            continue
        if truncated:
            return _capability_unknown(
                f"图片请求的回复被 max_tokens 截断（{last}）—— 该模型的思考过程"
                f"超出了探测额度，不能据此判定它不支持图片输入"
            )
        return _capability_unknown(
            f"图片请求没有返回内容（{last}）—— 未能确认该模型是否支持图片输入"
        )

    return _capability_unknown(f"图片探测未能完成：{last}")


def _finish_reason(response) -> str | None:
    """The first choice's ``finish_reason``, defensively.

    Probes run against arbitrary OpenAI-compatible gateways, so a malformed or
    choice-less response has to read as "unknown" rather than raise inside a
    probe and turn a capability question into a crash.
    """
    try:
        choices = getattr(response, "choices", None) or []
        return getattr(choices[0], "finish_reason", None) if choices else None
    except Exception:  # noqa: BLE001 - diagnostics, never fatal
        return None


def probe_thinking(client, model: str) -> tuple[bool, str, str]:
    """Does the endpoint surface a reasoning trace when asked?

    Detection is lenient on purpose: providers disagree on the field name
    (``reasoning_content`` vs ``reasoning``), and some return reasoning under
    ``content``. We only claim support when something extra shows up.

    Retried on transient faults for the same reason as :func:`probe_vision`:
    this endpoint is rate limited and the result is persisted. A 429 must not
    become "this model has no thinking".
    """
    thinking_budget = 256
    started = time.time()
    response = None
    last = ""
    for attempt in range(1, VISION_ATTEMPTS + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": "Think step by step: what is 17 * 23? Then answer with the number.",
                }],
                extra_body={"thinking": {"type": "enabled"}},
                max_tokens=thinking_budget,
                stream=False,
            )
            break
        except Exception as e:  # noqa: BLE001
            if _is_missing_feature(e):
                return False, f"不接受 thinking 参数：{_error_text(e)}", ""
            last = _error_text(e)
            if _is_transient(e) and attempt < VISION_ATTEMPTS:
                time.sleep(TRACE_RETRY_DELAY * attempt)
                continue
            if _is_transient(e):
                return _capability_unknown(
                    f"思维链探测未能完成（{VISION_ATTEMPTS} 次都失败于端点侧临时故障）："
                    f"{last}——这不代表该模型没有思维链，建议稍后重试"
                )
            # A provider that simply ignores the extra field is fine — the agent
            # works without reasoning traces, it just shows less detail.
            return False, f"{last}（模型可能只是忽略了 thinking 参数）", ""

    elapsed = int((time.time() - started) * 1000)

    message = response.choices[0].message
    reasoning = (
        getattr(message, "reasoning_content", None)
        or getattr(message, "reasoning", None)
        or ""
    )
    content = (getattr(message, "content", None) or "").strip()
    finish = _finish_reason(response)

    if reasoning:
        # Truncated-but-reasoning still proves the capability: the trace itself
        # is the evidence, and the probe asks for more tokens than a bare trace
        # needs. Reported as a pass with the caveat that the final answer was
        # cut off, so the operator is not told "thinking: unsupported" for a
        # model that demonstrably thinks.
        note = "（回复被 max_tokens 截断，但思维链已返回）" if finish == "length" else ""
        return True, f"返回思维链（{elapsed}ms）{note}", str(reasoning)[:300]

    # Some endpoints put the trace in a separate field of the raw response.
    try:
        dumped = response.model_dump()
        for path in ("choices.0.message.reasoning_content",
                     "choices.0.message.reasoning"):
            node: Any = dumped
            for part in path.split("."):
                node = node.get(part) if isinstance(node, dict) else None
            if node:
                return True, f"返回思维链（{elapsed}ms）", str(node)[:300]
    except Exception:  # noqa: BLE001 - best effort only
        pass

    if content:
        # It answered without a trace. That is a real, usable observation, not
        # a failure to observe: this model replies but surfaces no reasoning.
        return False, "有回答但没有独立的思维链字段", content[:200]
    # No answer and no trace, with nothing saying the model rejected anything.
    # Treat it as unverified rather than as "this model cannot think" — the
    # reasoning field is gateway-specific and a flaky response says nothing.
    return _capability_unknown(
        f"思维链探测没有得到可用输出（finish_reason={finish!r}）"
        f"—— 未能确认该模型是否返回思维链"
    )


# ── Orchestration ──────────────────────────────────────────────────────

def run_probes(
    base_url: str,
    api_key: str,
    model: str,
    *,
    include_optional: bool = True,
    timeout: float = PROBE_TIMEOUT,
) -> ProbeReport:
    """Probe one candidate endpoint and report what it can actually do.

    ``connectivity`` gates everything else: when it fails there is no point
    spending five more requests on an endpoint we cannot reach. Tool-call
    support is the one hard requirement — an agent that cannot call tools cannot
    drive a desktop — so it is marked ``required``.
    """
    base_url = normalise_base_url(base_url)
    report = ProbeReport(base_url=base_url, model=model)
    started = time.time()

    if not base_url:
        report.results.append(ProbeResult(
            "connectivity", "连通性", False, "Base URL 不能为空", 0, "required",
        ))
        report.total_ms = 0
        return report
    if not model.strip():
        report.results.append(ProbeResult(
            "connectivity", "连通性", False, "模型 ID 不能为空", 0, "required",
        ))
        report.total_ms = 0
        return report

    try:
        client = _client(api_key, base_url, timeout)
    except Exception as e:  # noqa: BLE001
        report.results.append(ProbeResult(
            "connectivity", "连通性", False, f"客户端初始化失败：{_error_text(e)}", 0, "required",
        ))
        report.total_ms = 0
        return report

    def timed(key: str, label: str, fn, severity: str) -> ProbeResult:
        t0 = time.time()
        try:
            ok, detail, evidence = fn(client, model)
        except Exception as e:  # noqa: BLE001 - one bad probe must not abort the run
            ok, detail, evidence = False, f"{type(e).__name__}: {_error_text(e)}", ""

        # "We could not find out" is recorded for every probe, not only the
        # optional ones. A 429 on the tool-call probe is the same false verdict
        # as a 429 on the vision probe — it would read as "this model cannot
        # call tools" and hard-block setup, sending the operator to hunt for a
        # different model. What differs is only what the wizard does with it:
        # an unverified *required* capability still blocks (setup cannot
        # safely proceed on a guess), but it says why.
        inconclusive = not ok and _transient_detail(detail)
        return ProbeResult(key, label, ok, detail, int((time.time() - t0) * 1000),
                            severity, evidence, False, inconclusive)

    # 1. connectivity — gates everything else
    #
    # Retried, because the one failure that is *not* a real fault is a
    # reasoning model whose chain of thought outgrew the budget. That is
    # nondeterministic: the same endpoint and prompt pass on one attempt and
    # truncate on the next. Retrying turns a coin flip into a reliable answer,
    # and costs nothing for a genuinely broken endpoint, which fails fast on
    # every attempt anyway.
    result = None
    for attempt in range(1, CONNECTIVITY_RETRIES + 1):
        result = timed("connectivity", "连通性",
                       lambda c, m: probe_connectivity(c, m), "required")
        if result.ok:
            if attempt > 1:
                result.detail += f"（第 {attempt} 次尝试通过）"
            break
        if "截断" not in result.detail:
            # Not a budget problem, so retrying cannot help.
            break
    report.results.append(result)

    if not result.ok:
        report.total_ms = result.ms
        # Mark the rest as skipped so the wizard can say "not tested" rather
        # than leaving four unexplained grey rows.
        for key, label, sev in (
            ("response_shape", "返回格式", "required"),
            ("tool_calls", "工具调用", "required"),
            ("tool_results", "工具结果回传", "required"),
            ("vision", "图片输入", "optional"),
            ("thinking", "思维链", "optional"),
        ):
            report.results.append(ProbeResult(key, label, False, "未测试（连通性失败）",
                                              0, sev, "", True))
        return report

    # 2. required capabilities
    report.results.append(timed("response_shape", "返回格式",
                                lambda c, m: probe_response_shape(c, m), "required"))
    report.results.append(timed("tool_calls", "工具调用",
                                lambda c, m: probe_tool_calls(c, m), "required"))

    tool_ok = report.capabilities.get("tool_calls", False)
    if tool_ok:
        report.results.append(timed("tool_results", "工具结果回传",
                                    lambda c, m: probe_tool_results(c, m), "required"))
    else:
        report.results.append(ProbeResult(
            "tool_results", "工具结果回传", False, "未测试（工具调用不支持）",
            0, "required", "", True,
        ))

    if not include_optional:
        for key, label in (("vision", "图片输入"), ("thinking", "思维链")):
            report.results.append(ProbeResult(key, label, False, "未测试",
                                              0, "optional", "", True))
        report.total_ms = int((time.time() - started) * 1000)
        return report

    # 3. optional capabilities
    report.results.append(timed("vision", "图片输入",
                                lambda c, m: probe_vision(c, m), "optional"))
    report.results.append(timed("thinking", "思维链",
                                lambda c, m: probe_thinking(c, m), "optional"))

    report.total_ms = int((time.time() - started) * 1000)
    return report


# ── Settings reconciliation ────────────────────────────────────────────

def suggested_settings(api_key: str, base_url: str, model: str,
                       report: ProbeReport) -> dict[str, Any]:
    """What the settings should become, given what the endpoint can do.

    Only the three vision/thinking switches move, and only where the probe
    contradicted the configured value. Everything the operator typed about
    names and URLs is left exactly as entered.
    """
    caps = report.capabilities
    out: dict[str, Any] = {
        "LLM_BASE_URL": base_url,
        "LLM_MODEL": model,
    }
    if not base_url:
        out.pop("LLM_BASE_URL")
    if not model:
        out.pop("LLM_MODEL")

    # Only a *definite* answer moves the vision mode. ``out`` used to start at
    # "text_vlm", so an inconclusive probe — which reads as falsy — downgraded
    # a working multimodal setup to text_vlm. That is the same class of bug as
    # persisting vision=false: it lets a transient fault overwrite a correct
    # configuration. Leaving the key out preserves what the operator has.
    if caps.get("vision") is True:
        # Vision works, so inline screenshots are possible — but only if no
        # separate VLM is configured, otherwise that endpoint is the better path.
        from . import config

        has_vlm = bool((config.VLM_API_KEY or config.VLM_AUTH_KEY) and config.VLM_API_URL)
        out["VISION_MODE"] = "text_vlm" if has_vlm else "multimodal"
    elif caps.get("vision") is False:
        out["VISION_MODE"] = "text_vlm"

    if caps.get("thinking") is True:
        out["LLM_CAPABILITY"] = "thinking"
    elif caps.get("thinking") is False:
        out["LLM_CAPABILITY"] = "plain"

    if api_key.strip():
        out["LLM_API_KEY"] = api_key

    # Persist what was measured. Without this the capability reporters keep
    # guessing from the model id, which is how a model that demonstrably accepts
    # images ended up labelled vision-capable=False in the console.
    #
    # **Only a definite answer is written.** ``caps`` is three-state, and a
    # ``None`` means the probe never established anything — a rate-limited or
    # 5xx'd attempt. Writing ``False`` for that is how a transient fault turned
    # into a permanent "this model cannot see images": the flag is read back on
    # every later run, so the wrong answer outlived the request that caused it.
    # Leaving the key out preserves whatever was measured before, which for a
    # model that has ever passed is the correct ``True``.
    for cap_key, setting in (("vision", "LLM_PROBED_VISION"),
                             ("thinking", "LLM_PROBED_THINKING")):
        value = caps.get(cap_key)
        if value is not None:
            out[setting] = bool(value)

    return out


def reconcile(report: ProbeReport, intended: dict[str, Any]) -> list[dict[str, Any]]:
    """Compare what the operator asked for against what the endpoint can do.

    Returns one entry per conflict. Each carries a ``fixable`` flag: a
    ``vision`` mismatch is a wrong guess the wizard can correct by flipping a
    switch, while a missing ``tool_calls`` capability is a hard stop with no
    override — the agent is useless without it, and pretending otherwise just
    moves the failure to the first mission.
    """
    caps = report.capabilities
    conflicts: list[dict[str, Any]] = []

    def add(key: str, label: str, chosen: Any, actual: Any, suggestion: Any,
            explain: str, fixable: bool = True, severity: str = "warning") -> None:
        conflicts.append({
            "key": key,
            "label": label,
            "chosen": chosen,
            "actual": actual,
            "suggestion": suggestion,
            "explain": explain,
            "fixable": fixable,
            "severity": severity,
        })

    # Every required capability has to be represented here. A report can be
    # blocked without any conflict being raised — that leaves the wizard
    # saying "无法继续" while listing nothing actionable, which is a dead end.
    if not caps.get("tool_calls", False) and report.capability_unknown("tool_calls"):
        # Ran, endpoint failed transiently. Not a verdict — and blocking here
        # is what made a rate-limited probe look like an unusable model.
        detail = report.get("tool_calls")
        add("LLM_CAPABILITY", "工具调用", "必需能力", "无法验证",
            None,
            "探测未能确认工具调用能力：端点侧出现临时故障（限流或 5xx），已自动重试多次。"
            "这不代表模型不支持工具调用。建议稍后重新运行「运行能力测试」；"
            "若确认该模型支持工具调用（文档说明，或此前用过），可直接保存后跑一次任务验证。"
            f"探测原始信息：{detail.detail if detail else ''}",
            fixable=False, severity="warning")
    elif not caps.get("tool_calls", False):
        detail = (report.get("tool_calls") or ProbeResult("tool_calls", "", False))
        # Distinguish "no tool support" (fatal) from "no forced tool_choice"
        # (harmless — the agent never forces a choice). Conflating them sends
        # the operator hunting for a different model when they have a working
        # one.
        if "tool_choice" in (detail.detail or ""):
            add("LLM_CAPABILITY", "工具调用", "必需能力", "无法验证",
                None,
                "该端点在 thinking mode 下拒绝固定 tool_choice，探测无法确认工具调用能力。"
                "注意：Computer Use Agent 运行时**不会**固定 tool_choice，"
                "所以这更可能是探测方式的问题而非模型不支持工具。"
                f"建议：若模型文档说明 thinking mode 支持 tool calls，可强制继续。"
                f"探测原始信息：{detail.detail}",
                fixable=False, severity="blocking")
        else:
            add("LLM_CAPABILITY", "工具调用", "必需能力", "不支持",
                None,
                "该模型无法输出 tool_call。Computer Use Agent 完全依赖工具调用来操作"
                "鼠标键盘，没有它整个代理无法工作。请更换模型，或确认 Base URL 指向的是"
                f"支持工具调用的端点。探测原始信息：{detail.detail}",
                fixable=False, severity="blocking")

    if not caps.get("response_shape", False):
        shape = report.get("response_shape") or ProbeResult("response_shape", "", False)
        add("RESPONSE_SHAPE", "返回格式", "标准响应格式", "不支持",
            None,
            "该端点无法按 OpenAI 协议返回可用的响应（非流式 JSON 或 SSE 流式）。"
            "代理每一轮对话都依赖它，通常意味着中间有网关改写了响应体，"
            f"或该端点不兼容本协议。探测原始信息：{shape.detail}",
            fixable=False, severity="blocking")

    if not caps.get("tool_results", False):
        tr = report.get("tool_results") or ProbeResult("tool_results", "", False)
        # Only meaningful when tool calling itself worked; otherwise the
        # tool_calls conflict already explains the problem.
        if caps.get("tool_calls", False):
            add("TOOL_RESULTS", "工具结果回传", "标准 tool 消息", "不支持",
                None,
                "该端点不接受 role=\"tool\" 的消息。OpenAI 协议要求每个 tool_call "
                "都必须配一条 tool 结果消息，缺了它整个工具循环会中断。"
                f"探测原始信息：{tr.detail}",
                fixable=False, severity="blocking")

    vision_on = (intended.get("VISION_MODE") or "auto").lower()
    wants_vision = vision_on in ("multimodal", "inline")
    has_vision = bool(caps.get("vision"))
    vision_unknown = report.capability_unknown("vision")

    if wants_vision and not has_vision and vision_unknown:
        # Ran, got no answer. Saying "this model does not accept images" here is
        # a claim the evidence does not support — the previous wording did, and
        # it sent operators to reconfigure a setup that was already correct.
        vdetail = (report.get("vision") or ProbeResult("vision", "", False)).detail
        add("VISION_MODE", "图片输入", "multimodal（主模型直接看屏幕）", "无法验证",
            None,
            "探测未能确认主模型是否接受图片输入：端点侧出现临时故障（限流或 5xx），"
            "已自动重试多次仍未得到有效回复。这不代表模型不支持图片。"
            "建议稍后重新运行「运行能力测试」；若确认该模型支持图片，可点「强制保留」"
            f"后直接跑一次任务验证。探测原始信息：{vdetail}")
    elif wants_vision and not has_vision:
        add("VISION_MODE", "图片输入", "multimodal（主模型直接看屏幕）", "不支持",
            "text_vlm",
            "你选择了让主模型直接接收屏幕截图，但探测发现该模型不接受图片输入。"
            "任务运行时会在每次截图时报错。建议改用「文本模型 + 独立 VLM」；"
            "如果这是误判（例如模型有多个版本），也可以强制保留该设置。"
            "提示：探测只发了文案里没写颜色的图片并要求一个单词的颜色回答。")
    elif not wants_vision and has_vision and vision_on == "auto":
        # Not a conflict — auto already resolves correctly. Only worth noting.
        pass

    capability = (intended.get("LLM_CAPABILITY") or "auto").strip().lower()
    wants_thinking = capability == "thinking"
    has_thinking = bool(caps.get("thinking"))

    if wants_thinking and not has_thinking:
        add("LLM_CAPABILITY", "思维链", "thinking（发送 reasoning_effort）", "无思维链返回",
            "plain",
            "你要求发送思维链参数，但该模型没有返回任何推理内容。"
            "继续这样设置不会报错，只是看不到思考过程；如果该端点直接拒绝该参数，"
            "每一轮对话都会失败。建议改为 plain，或强制保留。")

    if (intended.get("VISION_MODE") or "auto").lower() == "text_vlm":
        from . import config

        has_vlm = bool((config.VLM_API_KEY or config.VLM_AUTH_KEY) and config.VLM_API_URL)
        main_has_vision = bool(caps.get("vision"))
        if not has_vlm and not main_has_vision:
            add("VISION_MODE", "视觉链路", "text_vlm（需要独立 VLM）",
                "未配置 VLM，且主模型不支持图片", None,
                "当前既没有配置独立 VLM，主模型也看不到图片，代理将只能依赖 OCR 和"
                "对象检测来理解屏幕。请在下一步配置 VLM，或改用支持视觉的主模型。",
                fixable=False, severity="blocking")

    return conflicts


def apply_intent(api_key: str, base_url: str, model: str,
                 report: ProbeReport, overrides: dict[str, bool] | None = None) -> dict[str, Any]:
    """Final settings to persist, honouring the operator's forced overrides.

    ``overrides`` maps a conflict key to ``True`` when the operator chose to keep
    their original setting despite the probe. Keys the operator did not touch
    fall back to the suggestion.
    """
    overrides = overrides or {}
    settings = suggested_settings(api_key, base_url, model, report)

    for conflict_key, forced in overrides.items():
        if not forced:
            continue
        if conflict_key == "VISION_MODE":
            settings["VISION_MODE"] = "multimodal"
        elif conflict_key == "LLM_CAPABILITY":
            settings["LLM_CAPABILITY"] = "thinking"

    # A blocking conflict is one where no setting helps. Handing the operator a
    # "forced" configuration that looks valid but cannot run would be worse than
    # refusing — the endpoint has to change instead.
    if report.blocked:
        raise ValueError(
            "该模型缺少必需能力，无法通过设置绕过；请更换模型或端点"
        )
    return settings