"""Inline vision: attach screenshots directly to the main LLM's messages.

When Vision Mode resolves to ``multimodal``, screenshots loop straight back
into the main model's own conversation as image_url parts, instead of making
a separate round trip through a dedicated VLM endpoint.
"""

from __future__ import annotations

from typing import Any

from . import config


def capture_screen_b64(max_edge: int | None = None, quality: int = 85) -> str:
    """Capture the agent's view of the screen as base64 JPEG.

    Raises ``RuntimeError`` on failure.
    """
    from . import desktop

    try:
        # region=work_region() is what makes a partitioned workspace coherent:
        # the model sees only the rectangle it may act on, and every coordinate
        # in that image starts at its own top-left corner.
        screenshot = desktop.screenshot(region=desktop.work_region())
    except Exception as e:
        raise RuntimeError(f"failed to capture screen: {e}") from e

    if max_edge is None:
        max_edge = config.INLINE_IMAGE_MAX_EDGE

    if max_edge and max_edge > 0:
        try:
            from PIL import Image  # type: ignore

            width, height = screenshot.size
            if max(width, height) > max_edge:
                scale = max_edge / float(max(width, height))
                screenshot = screenshot.resize(
                    (max(1, int(width * scale)), max(1, int(height * scale))),
                    Image.LANCZOS,  # type: ignore[attr-defined]
                )
        except Exception:
            pass

    import base64
    import io

    buffer = io.BytesIO()
    try:
        image = screenshot.convert("RGB") if screenshot.mode != "RGB" else screenshot
        image.save(buffer, format="JPEG", quality=quality, optimize=True)
    except Exception:
        screenshot.save(buffer, format="PNG")

    return base64.b64encode(buffer.getvalue()).decode("ascii")


def make_image_message(img_b64: str, prompt: str = "", mime: str = "image/jpeg") -> dict[str, Any]:
    """Build a user message carrying an image as an image_url part.

    ``mime`` matters: the data URL has to describe what the bytes actually are,
    and a PNG announced as JPEG is rejected by some providers outright. Callers
    with an arbitrary payload should pass the real type — see
    ``multimodal.normalize_b64``, which sniffs it.
    """
    content: list[dict[str, Any]] = []
    if prompt:
        content.append({"type": "text", "text": prompt})
    content.append({
        "type": "image_url",
        "image_url": {"url": f"data:{mime};base64,{img_b64}"},
    })
    return {"role": "user", "content": content}


def inject_screenshot(
    messages: list[dict],
    prompt: str = "Here is a screenshot of the current screen. Use it to decide what to do next.",
) -> str:
    """Capture the agent's view and append it to *messages* as a user message.

    Returns a short confirmation string used as the tool result.
    """
    img_b64 = capture_screen_b64()
    messages.append(make_image_message(img_b64, _with_workspace_note(prompt)))
    return (
        "Screenshot captured and attached to the conversation. "
        "You can now see the screen content directly. " + _workspace_note()
    )


def _workspace_note() -> str:
    """Operator-facing reminder of the coordinate space, or '' in primary mode.

    Worth the extra tokens: in region mode the image is a crop, so a model that
    assumes it is looking at the full desktop will aim at the wrong pixels —
    and the crop is a *window onto* the operator's real desktop, not a
    separate screen, so the error is silent from its point of view.
    """
    from . import config

    if config.work_mode() != "region":
        return ""
    width, height = (config.WORK_REGION_WIDTH, config.WORK_REGION_HEIGHT)
    return (
        f" Note: this image is your entire working area ({width}x{height}), "
        f"a region of a larger screen that a person is using at the same time. "
        f"Coordinates start at (0,0) at the top-left of this image, and anything "
        f"outside 0..{max(0, width - 1)} / 0..{max(0, height - 1)} will be "
        f"clamped back into it. Do not try to reach outside it."
    )


def _with_workspace_note(prompt: str) -> str:
    """Prefix the caller's prompt with the coordinate-space caveat."""
    note = _workspace_note()
    if not note:
        return prompt
    return prompt + note


def attach_image(messages: list[dict], img_b64: str, prompt: str, mime: str = "image/jpeg") -> str:
    """Append an already-encoded *image* to *messages* as a user message.

    The public entry point for callers that supply their own image — the
    screenshot tools go through :func:`inject_screenshot` because they capture
    it themselves, but the VLM tools may receive a picture from the model.
    Returns the confirmation string used as the tool result.
    """
    messages.append(make_image_message(img_b64, _with_workspace_note(prompt), mime))
    return (
        "Image attached to the conversation. You can now see it directly. "
        + _workspace_note()
    )


def is_inline_mode() -> bool:
    """Whether screenshots are attached to the main model's own messages."""
    return config.is_multimodal_main_model()
