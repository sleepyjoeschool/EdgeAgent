"""Prefix-matching cache accounting, mirroring DeepSeek's KV cache.

Why this exists
---------------

The upstream reports ``prompt_cache_hit_tokens``, but it does not always do
so — a non-streaming reply from some relays omits it, and the streaming path
we actually use drops it entirely unless the endpoint appends a usage chunk.
When it is missing the panel would have to show a blank, so we compute the
same number locally from the only thing that determines it: **the prompt
prefix that has been sent before, recently**.

The rule, taken from the DeepSeek context-caching documentation
(https://api-docs.deepseek.com/guides/kv_cache):

* A cache hit requires the request to **fully match a cache prefix unit**.
  Matching is on the **front** of the prompt — the documentation's examples
  are all "request 2 extends request 1", never "they share a middle".
* Each request persists a unit at the end of the user input. So the unit a
  later request can hit is the *whole* previous prompt (its rendered form),
  not an arbitrary sub-slice.
* Units expire. The docs say "usually within a few hours to a few days" for
  eviction, and the operator's own instruction for this panel is a
  **10-minute** window. We take the conservative number: a hit we cannot
  prove recent is not claimed as one.

So: keep the rendered prompts we have sent recently, and for a new prompt
report the longest prefix shared with any of them, capped at that one's
length. That is exactly "the previous unit is fully contained at the front
of the new request".

Why compare *rendered* prompts
------------------------------

Role markers, the BOS token and the generation header are part of what the
model hashes. Two requests with identical user text but a different leading
system prompt share **zero** cached prefix in reality, and comparing the raw
``messages`` arrays would miss that. The caller renders with the same
encoder used for counting, so the comparison is on the same bytes the model
saw.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Iterable

from .tokencalc_bridge import CACHE_WINDOW_SECONDS


@dataclass
class CacheLookup:
    """Result of matching one prompt against the recent history."""

    #: Tokens billed at the cache-hit price.
    cached_tokens: int = 0
    #: Total prompt tokens (cached + fresh).
    total_tokens: int = 0
    #: Where the number came from, so the UI can be honest about it.
    #: ``"upstream"`` | ``"prefix"`` | ``"none"``
    source: str = "none"
    #: Which earlier prompt supplied the prefix, for the statistics page.
    matched_chars: int = 0

    @property
    def fresh_tokens(self) -> int:
        return max(self.total_tokens - self.cached_tokens, 0)

    def as_dict(self) -> dict:
        return {
            "cached_tokens": self.cached_tokens,
            "fresh_tokens": self.fresh_tokens,
            "total_tokens": self.total_tokens,
            "source": self.source,
            "matched_chars": self.matched_chars,
        }


@dataclass
class _Entry:
    """One prompt we have sent, with the time it went out."""

    prompt: str
    tokens: int
    at: float
    #: Token ids of the prompt, when the caller could supply them cheaply.
    #: Matching on ids is exact; matching on characters would call two
    #: different token sequences equal when a boundary shifts.
    ids: tuple[int, ...] | None = None


class PrefixCacheTracker:
    """Remembers recent prompts per conversation and matches new ones.

    One tracker per conversation, so two sessions running at once cannot
    credit each other's prefixes. (In practice CUA runs one mission at a
    time, but a session switched mid-flight would otherwise match across the
    switch and report a cache hit that the upstream never made.)
    """

    #: How many past prompts to keep. The DeepSeek docs describe units at
    #: request boundaries, so the useful candidates are the last few requests
    #: of this conversation; keeping more only costs memory.
    max_entries = 8

    def __init__(self, window_seconds: float = CACHE_WINDOW_SECONDS) -> None:
        self.window = float(window_seconds)
        self._entries: list[_Entry] = []
        self._lock = threading.Lock()

    # -- recording ---------------------------------------------------------

    def remember(self, prompt: str, tokens: int,
                 ids: Iterable[int] | None = None) -> None:
        """Record a prompt that was just sent upstream."""
        if not prompt:
            return
        entry = _Entry(
            prompt=prompt,
            tokens=int(tokens),
            at=time.time(),
            ids=tuple(ids) if ids is not None else None,
        )
        with self._lock:
            self._entries.append(entry)
            if len(self._entries) > self.max_entries:
                # Drop the oldest. The window already makes most of these
                # unusable, so this is housekeeping rather than eviction.
                self._entries = self._entries[-self.max_entries:]

    # -- matching ----------------------------------------------------------

    def _live_entries(self) -> list[_Entry]:
        cutoff = time.time() - self.window
        return [e for e in self._entries if e.at >= cutoff]

    def match(self, prompt: str, total_tokens: int,
              ids: Iterable[int] | None = None) -> CacheLookup:
        """Longest prefix of *prompt* that a recent request already sent.

        ``total_tokens`` is the exact count of *this* prompt, kept so the
        caller gets a consistent total back without a second tokenizer pass.

        The winner is the **longest** fully-matching candidate, not the one
        with the most tokens: a shorter unit that happens to tokenize densely
        must not outrank a longer prefix, because the model's cache is keyed
        on depth, not on token count.
        """
        lookup = CacheLookup(total_tokens=int(total_tokens), source="none")
        if not prompt or total_tokens <= 0:
            return lookup

        candidates = self._live_entries()
        if not candidates:
            return lookup

        new_ids = tuple(ids) if ids is not None else None
        best_depth = 0        # characters of the winning match
        best_tokens = 0

        for entry in candidates:
            # A candidate longer than the new prompt cannot be contained in
            # it, so it can never be a hit — skip before doing any work.
            if len(entry.prompt) > len(prompt):
                continue

            if new_ids is not None and entry.ids is not None:
                shared = _common_prefix_len(new_ids, entry.ids)
                # The unit is the *whole* previous prompt; a partial overlap
                # is not a persisted unit, and claiming it would overstate the
                # hit. So a candidate counts only when it is fully consumed.
                if shared < len(entry.ids):
                    continue
                depth = len(entry.prompt)
            else:
                # Character fallback. The matched characters are exactly the
                # candidate's own prompt when it is fully contained, and the
                # candidate's *own* token count is then the honest figure —
                # not a ratio scaled off the new prompt, which would credit
                # the hit with tokens the candidate never actually had.
                length = _common_prefix_chars(prompt, entry.prompt)
                if length != len(entry.prompt):
                    continue
                depth = length

            if depth > best_depth:
                best_depth = depth
                best_tokens = entry.tokens

        if best_tokens <= 0:
            return lookup

        # Never report more cached than exists: a rounding artefact must not
        # produce a negative "fresh" count.
        best_tokens = min(best_tokens, total_tokens)
        return CacheLookup(
            cached_tokens=best_tokens,
            total_tokens=int(total_tokens),
            source="prefix",
            matched_chars=best_depth,
        )

    def reset(self) -> None:
        with self._lock:
            self._entries.clear()


def _common_prefix_chars(a: str, b: str) -> int:
    """Length of the shared leading substring, in characters."""
    limit = min(len(a), len(b))
    i = 0
    # Compare in chunks: a character loop on a 100k-token prompt is the one
    # place this feature could show up as latency.
    step = 4096
    while i < limit:
        end = min(i + step, limit)
        if a[i:end] != b[i:end]:
            # Inside the differing chunk, narrow to the exact split.
            j = i
            while j < end and a[j] == b[j]:
                j += 1
            return j
        i = end
    return limit


def _common_prefix_len(a: tuple[int, ...], b: tuple[int, ...]) -> int:
    """Length of the shared leading run of two token-id sequences."""
    limit = min(len(a), len(b))
    i = 0
    while i < limit and a[i] == b[i]:
        i += 1
    return i


# ── Tracker registry ────────────────────────────────────────────────────
# One tracker per conversation id. Bounded, because session ids accumulate
# for the lifetime of the process.
_TRACKERS: dict[str, PrefixCacheTracker] = {}
_TRACKERS_LOCK = threading.Lock()
_MAX_TRACKERS = 32


def tracker_for(session_id: str | None) -> PrefixCacheTracker:
    """The tracker for one conversation, created on first use."""
    key = str(session_id or "")
    with _TRACKERS_LOCK:
        tracker = _TRACKERS.get(key)
        if tracker is None:
            if len(_TRACKERS) >= _MAX_TRACKERS:
                # Drop the least recently used. Trackers are cheap, but an
                # unbounded map keyed by session id is a leak.
                oldest = min(_TRACKERS, key=lambda k: _trackers_age(k))
                _TRACKERS.pop(oldest, None)
            tracker = PrefixCacheTracker()
            _TRACKERS[key] = tracker
        return tracker


def _trackers_age(key: str) -> float:
    tracker = _TRACKERS.get(key)
    if not tracker:
        return 0.0
    entries = tracker._entries  # noqa: SLF001 - internal by design
    return entries[-1].at if entries else 0.0


def forget_tracker(session_id: str | None) -> None:
    """Drop a conversation's tracker (used when a session is deleted)."""
    with _TRACKERS_LOCK:
        _TRACKERS.pop(str(session_id or ""), None)
