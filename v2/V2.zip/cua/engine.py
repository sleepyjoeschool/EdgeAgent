"""The one and only agent loop.

Architecture carried over from the reference implementation, which got it
right enough to be worth keeping:

**Outer loop (steps).** One step completes ONE logical operation. When it
finishes, every intermediate message — thinking, tool calls, tool results —
is discarded, leaving only ``system + original request + step summaries``.
This is what keeps a 50-step mission from blowing the context window, and
the price is that the model must write summaries good enough to steer the
next step. Nothing about that trade-off changed here.

**Inner loop (rounds).** One LLM call = one round. Tool calls coming back are
dispatched immediately and their results appended as tool messages; the loop
exits when the model produces content without calling tools, or when it
produces content alongside domain tool calls (its step summary).

What *is* different here:

* There is exactly one loop. The reference re-implemented it in ``main.py``,
  ``gui.py`` and ``web_panel.py``, which drifted apart (the web copy advertised
  ``DeleteSkillResult`` without implementing it). This module emits events; a
  front-end only renders them.
* Cancellation, pause and human approval are injected through ``Runtime``
  instead of being hardcoded to stdin / tkinter.
* Streaming extras are resolved per model instead of always being sent.
"""

from __future__ import annotations

import difflib
import itertools
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import httpx

from . import config, llm_client, modes, tool_loader
from . import token_cache, token_usage, tokencalc_bridge
from .context import ToolContext
from .events import (
    ERROR, MESSAGE, NOTICE, RUN_DONE, RUN_START, STATUS,
    STEP_START, STEP_SUMMARY, THINKING, TOKEN_USAGE, TOOL_CALL, TOOL_RESULT,
    EventSink, make, null_sink,
)
from .executors import META_TOOLS, dispatch
from .runtime import Aborted, Runtime

# Marker the model writes to signal the mission is finished.
TASK_COMPLETE_MARKER = "TASK_COMPLETE"

# Injected after every step that did not declare itself finished.
CONTINUE_PROMPT = (
    "Continue with the next logical operation for the original task. "
    "If all steps are complete, reply with 'TASK_COMPLETE' "
    "followed by a summary of what was accomplished."
)

STUCK_RECOVERY_MSG = (
    "[Agent Message] Something went wrong resulting in the execution "
    "being stuck and being interrupted. Continue what you were doing."
)

INTERRUPTED_MSG = (
    "There was an error that caused the execution to be interrupted. "
    "Please continue with your previous task."
)

UUID_PREFIX = "[UUID:"
UUID_SUFFIX = "]"

# Per-step context-management state, reset on every outer iteration.
StepState = dict[str, Any]


@dataclass
class RunOutcome:
    """Result of one mission, for whoever started it."""

    finished: bool
    reason: str = ""
    steps: int = 0
    elapsed: float = 0.0
    final_summary: str = ""
    summaries: list[str] = field(default_factory=list)


class AgentEngine:
    """Runs a natural-language task to completion against the real desktop."""

    def __init__(
        self,
        emit: EventSink = null_sink,
        runtime: Runtime | None = None,
        client=None,
        model: str | None = None,
        agent_mode: str | None = None,
        workspace: str | None = None,
        session_id: str | None = None,
    ) -> None:
        self.emit = emit
        self.runtime = runtime or Runtime()
        self._client = client
        # Per-mission overrides wired from the WebUI composer / landing page.
        self._model = model or None
        self._agent_mode = modes.normalize(agent_mode)
        self._workspace = workspace or ""
        # Conversation identity for providers that route and cache per session
        # (currently OpenCode). Passed in rather than generated here because it
        # has to stay stable across missions of the same session — a new id per
        # run turns every turn into a cold cache hit.
        self._session_id = session_id or None
        #: Which step the current request belongs to. Set by the step loop and
        #: read by the token measurement, which is called from inside a stream
        #: several frames down.
        self._step_no = 0

    # ── Public API ──────────────────────────────────────────────────────
    def run(self, task: str, max_steps: int | None = None,
            messages: list[dict] | None = None) -> RunOutcome:
        """Execute *task* across however many steps it takes.

        ``messages`` continues an existing session. It is used **in place**,
        not copied: the outer loop already rewrites its own history through
        ``messages[:] = ...`` and appends to it, so the caller's list — which
        is the session's stored context — tracks the run as it goes. That is
        the whole mechanism behind "open an old session and carry on": the
        context comes back in, and it leaves already updated.

        Without ``messages`` the context is built fresh, which is what a new
        session wants.
        """
        started = time.time()
        # ``None`` means unbounded: the loop below then counts forever instead
        # of over a range, so a mission only ends when the model declares it
        # done, the stuck detector trips, or the operator stops it.
        limit = config.resolve_max_steps(max_steps)
        task = (task or "").strip()
        if not task:
            return RunOutcome(False, reason="empty task", elapsed=0.0)

        missing = config.validate_llm_credentials()
        if missing:
            self._emit(ERROR, message=missing, fatal=True)
            return RunOutcome(False, reason="credentials missing", elapsed=0.0)

        if self._client is None:
            try:
                self._client = llm_client.build_llm_client(self._session_id)
            except Exception as e:  # noqa: BLE001 - startup diag, not a crash
                message = f"could not build the LLM client: {type(e).__name__}: {e}"
                self._emit(ERROR, message=message, fatal=True)
                return RunOutcome(False, reason=message, elapsed=0.0)

        self._emit(
            RUN_START,
            task=task,
            mode="step" if self.runtime.step_mode else "auto",
            max_steps=limit,
            agent_mode=self._agent_mode,
            workspace=self._workspace,
            model=self._model or config.LLM_MODEL,
        )
        self._emit(STATUS, state="running")

        fresh = [
            {"role": "system", "content": tool_loader.system_prompt(
                modes.prompt_addendum(self._agent_mode),
            )},
            {"role": "user", "content": task},
        ]
        if messages is None:
            messages = fresh
        elif not messages:
            # A session created moments ago has an empty list. Filling it *in
            # place* rather than rebinding matters: the caller holds that list
            # and expects the loop to keep mutating it, so a fresh binding
            # here would leave the session with no context at all.
            messages.extend(fresh)
        else:
            # Continuing: the system prompt is already in there, along with
            # whatever the loop decided to keep of earlier steps. Only this
            # new request is added — re-seeding a system prompt here would
            # silently demote everything the session had already learned.
            messages.append({"role": "user", "content": task})

        ctx = ToolContext(
            runtime=self.runtime,
            messages=messages,
            emit=self.emit,
            mission_id=uuid.uuid4().hex[:8],
            agent_mode=self._agent_mode,
        )
        # Expose the mission-scoped workspace so any executor that touches the
        # filesystem can sandbox its paths to that directory.
        self.runtime.workspace = self._workspace

        summaries: list[str] = []
        final_summary = ""
        finished = False
        # With no ceiling the loop cannot fall out on its own, so the fallback
        # reason should not claim a limit was hit.
        reason = "max steps reached" if limit else "stopped"
        steps_done = 0

        try:
            # ``limit`` is None when the ceiling is disabled. Counting without
            # a range is the only representation that cannot be accidentally
            # reached — a large sentinel would still eventually run out, and
            # the operator asked for no ceiling at all.
            for step_num in range(1, limit + 1) if limit else itertools.count(1):
                self.runtime.check_stop()
                self.runtime.gate()
                self.runtime.gate_step(step_num)

                steps_done = step_num
                # Read by _measure_tokens, which runs several frames deeper
                # (stream -> measure) and has no other way to learn which step
                # it is recording against.
                self._step_no = step_num
                self._emit(STEP_START, step=step_num, max_steps=limit or 0)

                state = self._fresh_step_state()
                content = self._run_step(messages, state, ctx)

                if content is None:
                    self._emit(NOTICE, text=f"Step {step_num} produced no usable output.", level="warn")
                    messages.append({"role": "user", "content": INTERRUPTED_MSG})
                    continue

                final_summary = content
                self._emit(STEP_SUMMARY, step=step_num, text=content)
                stripped = content.strip()
                summaries.append(stripped)

                if stripped.startswith(TASK_COMPLETE_MARKER):
                    finished = True
                    reason = "task complete"
                    break

                if self._detect_stuck(summaries):
                    self._emit(
                        NOTICE,
                        text="Stopped: three consecutive step summaries were "
                             "near-identical, which means the agent was looping.",
                        level="warn",
                    )
                    reason = "stuck"
                    break

                # The crux of the architecture: throw away everything except
                # the summaries before starting the next step.
                messages[:] = _strip_to_summaries(messages, task)
                messages.append({"role": "user", "content": CONTINUE_PROMPT})

        except Aborted:
            reason = "aborted"
            self._emit(NOTICE, text="Mission aborted by operator.", level="warn")
        except Exception as e:  # noqa: BLE001 - one bad step must not kill the server
            reason = f"error: {type(e).__name__}: {e}"
            self._emit(ERROR, message=reason, fatal=False)
        finally:
            self._emit(STATUS, state="idle")

        elapsed = time.time() - started
        self._emit(
            RUN_DONE,
            reason=reason,
            steps=steps_done,
            elapsed=round(elapsed, 2),
            finished=finished,
        )
        return RunOutcome(
            finished=finished,
            reason=reason,
            steps=steps_done,
            elapsed=elapsed,
            final_summary=final_summary,
            summaries=summaries,
        )

    # ── Step internals ──────────────────────────────────────────────────
    def _fresh_step_state(self) -> StepState:
        """Reset everything that must not leak between steps.

        Tool definitions in particular are dropped: the model has to call
        ``LoadSkillCategory`` again each step, which keeps the request schema
        small and forces it to re-plan against the current summary.
        """
        entry = tool_loader.load_entry_point()
        tools: list[dict] = list(entry.get("tools", []))
        try:
            # ``basic`` rides along in every step, so in CIL mode the clipboard
            # pair has to be filtered out of it here as well as at dispatch —
            # advertising a tool the mode refuses would only invite a call.
            tools.extend(
                tool for tool in tool_loader.load_category_tools("basic")
                if modes.tool_allowed(tool["function"]["name"], self._agent_mode)
            )
        except Exception:
            pass  # basic tools are a nicety, not a requirement

        return {
            "tools": tools,
            "loaded_categories": set(),
            "registry": {},
            "deleted_ids": set(),
        }

    def _run_step(self, messages: list[dict], state: StepState, ctx: ToolContext) -> str | None:
        """Run one step's internal tool-call loop. Returns the step summary."""
        last_chunk = time.time()
        last_tool = time.time()
        work_done = False
        empty_retries = 0
        rounds = int(config.MAX_INTERNAL_ROUNDS)

        for _round in range(rounds):
            self.runtime.check_stop()
            self.runtime.gate()

            payload = _filter_deleted(messages, state["deleted_ids"])
            try:
                content, tool_calls, reasoning = self._stream(payload, state["tools"])
            except Aborted:
                raise
            except (httpx.ReadError, httpx.ReadTimeout, httpx.RemoteProtocolError) as e:
                now = time.time()
                stalled = (
                    now - last_chunk > config.WATCHDOG_CHUNK_TIMEOUT
                    and now - last_tool > config.WATCHDOG_TOOL_TIMEOUT
                )
                if not stalled:
                    raise RuntimeError(f"LLM stream failed: {e}") from e
                self._emit(NOTICE, text="LLM stream stalled — nudging the agent.", level="warn")
                messages.append({"role": "user", "content": STUCK_RECOVERY_MSG})
                last_chunk = last_tool = time.time()
                continue
            except Exception as e:
                raise RuntimeError(f"LLM request failed: {type(e).__name__}: {e}") from e

            last_chunk = time.time()
            if reasoning:
                self._emit(THINKING, text=reasoning)

            if not tool_calls:
                if content.strip():
                    messages.append({"role": "assistant", "content": content})
                    return content
                empty_retries += 1
                if empty_retries > 1:
                    return None
                messages.append({"role": "user", "content": INTERRUPTED_MSG})
                continue

            assistant_msg: dict = {
                "role": "assistant",
                "content": None,
                "tool_calls": tool_calls,
            }
            if reasoning:
                assistant_msg["reasoning_content"] = reasoning
            messages.append(assistant_msg)

            for call in tool_calls:
                self.runtime.check_stop()
                name = call["function"]["name"]
                arguments = _safe_json(call["function"]["arguments"])
                self._emit(TOOL_CALL, id=call["id"], name=name, arguments=arguments)

                started = time.time()
                result = self._invoke(name, arguments, state, ctx)
                last_tool = time.time()

                failed = result.startswith("Error:") or result.startswith("SAFETY BLOCK")
                skill_uuid = None
                if name not in META_TOOLS:
                    work_done = True
                    skill_uuid = uuid.uuid4().hex
                    state["registry"][skill_uuid] = {
                        "tool_call_id": call["id"],
                        "function": name,
                        "timestamp": time.time(),
                    }
                    result = f"{UUID_PREFIX}{skill_uuid}{UUID_SUFFIX}\n{result}"

                self._emit(
                    TOOL_RESULT,
                    id=call["id"],
                    name=name,
                    ok=not failed,
                    result=result,
                    uuid=skill_uuid,
                    seconds=round(time.time() - started, 2),
                )
                messages.append({
                    "role": "tool",
                    "tool_call_id": call["id"],
                    "content": result,
                })

            if content:
                messages.append({"role": "assistant", "content": content})
                # Content alongside domain tool calls is this step's summary.
                # Content alongside *only* meta tools is planning chatter, so
                # keep looping and let it call the real tools next round.
                if work_done:
                    return content

        self._emit(NOTICE, text=f"Step exceeded {rounds} internal rounds.", level="warn")
        return None

    def _invoke(
        self,
        name: str,
        arguments: dict,
        state: StepState,
        ctx: ToolContext,
    ) -> str:
        """Execute one tool call, meta tools included."""
        try:
            if name == "LoadSkillCategory":
                return self._meta_load(arguments, state)
            if name == "ListSkillResults":
                return self._meta_list(state)
            if name == "DeleteSkillResult":
                return self._meta_delete(arguments, state)
            return dispatch(name, arguments, ctx)
        except Aborted:
            raise
        except Exception as e:  # noqa: BLE001 - tool failures are data, not crashes
            return f"Error: {name} raised {type(e).__name__}: {e}"

    # ── Streaming ───────────────────────────────────────────────────────
    def _stream(self, messages: list[dict], tools: list[dict]):
        """Stream one completion. Returns ``(content, tool_calls, reasoning)``.

        Also measures this round-trip's token usage. The endpoint's own
        ``usage`` is preferred when the stream carries it; otherwise the
        prompt is counted with the vendored tokenizer, and the output is
        counted the same way. Both are recorded against the session so the
        statistics page and the composer's running total have something real
        to show rather than nothing.
        """
        client = self._client or llm_client.build_llm_client(self._session_id)
        started = time.time()
        response = client.chat.completions.create(
            **llm_client.completion_kwargs(messages, tools, stream=True, model=self._model)
        )

        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        chunks: dict[int, dict] = {}
        saw_choice = False
        #: Whatever ``usage`` the endpoint volunteers. Many relays attach it to
        #: a final choice-less chunk, which is exactly the frame the old loop
        #: skipped — the numbers were arriving and being thrown away.
        upstream_usage: dict | None = None

        for chunk in response:
            if self.runtime.should_stop():
                response.close() if hasattr(response, "close") else None
                raise Aborted("mission aborted while streaming")

            # Read usage before looking at choices: the chunk carrying it often
            # has an empty (or absent) ``choices`` list, so anything that
            # short-circuits on that would never see it.
            usage = getattr(chunk, "usage", None)
            if usage is not None:
                upstream_usage = _usage_to_dict(usage)

            choices = getattr(chunk, "choices", None) or []
            if not choices:
                # Not every chunk carries a choice, and the ones that do not
                # are perfectly normal: the usage-only tail chunk that many
                # OpenAI-compatible endpoints append, keep-alive frames, and
                # some gateways' final "done" event. Indexing choices[0]
                # blindly turned all of them into
                # "LLM request failed: IndexError: list index out of range"
                # on step 1 of every mission against such an endpoint — the
                # reply itself had streamed fine.
                continue
            saw_choice = True
            delta = choices[0].delta
            if delta is None:
                continue

            reasoning = getattr(delta, "reasoning_content", None)
            if reasoning:
                reasoning_parts.append(reasoning)

            for call_delta in getattr(delta, "tool_calls", None) or []:
                index = call_delta.index
                entry = chunks.setdefault(index, {
                    "id": call_delta.id or "",
                    "function": {"name": "", "arguments": ""},
                })
                if call_delta.id:
                    entry["id"] = call_delta.id
                if call_delta.function:
                    if call_delta.function.name:
                        entry["function"]["name"] += call_delta.function.name
                    if call_delta.function.arguments:
                        entry["function"]["arguments"] += call_delta.function.arguments

            if delta.content:
                content_parts.append(delta.content)
                self._emit(MESSAGE, text=delta.content)

        if not saw_choice:
            # The stream opened, stayed open, and produced nothing. Say what
            # that means instead of letting the empty reply be mistaken for a
            # model that simply chose not to answer — which would otherwise
            # send the step into the "no usable output" retry loop and then
            # quietly end the mission.
            raise RuntimeError(
                "LLM stream produced no choice chunks at all — the endpoint "
                "accepted the request but returned an empty completion "
                "(check the model id, and whether this endpoint supports "
                "streaming)"
            )

        tool_calls = [
            {
                "id": chunks[i]["id"],
                "type": "function",
                "function": {
                    "name": chunks[i]["function"]["name"],
                    "arguments": chunks[i]["function"]["arguments"],
                },
            }
            for i in sorted(chunks)
        ]
        content_text = "".join(content_parts)
        reasoning_text = "".join(reasoning_parts)

        self._measure_tokens(
            messages=messages,
            content=content_text,
            reasoning=reasoning_text,
            upstream_usage=upstream_usage,
            seconds=time.time() - started,
        )
        return content_text, tool_calls, reasoning_text

    # ── Token accounting ────────────────────────────────────────────────

    def _measure_tokens(self, *, messages: list[dict], content: str,
                        reasoning: str, upstream_usage: dict | None,
                        seconds: float) -> None:
        """Record one request's token usage, then tell the panel about it.

        Never raises. This runs inside the streaming path, and a measurement
        that fails must not be able to end a mission — the numbers come from
        the endpoint we already called, so the worst case is that we show
        nothing for this round.
        """
        model = self._model or config.LLM_MODEL
        model_key = tokencalc_bridge.resolve(model)

        # The panel hides the counter entirely for a model it cannot measure,
        # so there is no reason to pay for a tokenizer pass here.
        if model_key is None:
            token_usage.record(
                session_id=self._session_id, model=model, step=self._step_no,
                input_tokens=None, cached_tokens=0, output_tokens=None,
                seconds=seconds,
            )
            return

        try:
            self._measure_measured(
                model=model, model_key=model_key, messages=messages,
                content=content, reasoning=reasoning,
                upstream_usage=upstream_usage, seconds=seconds,
            )
        except Exception as e:  # noqa: BLE001 - bookkeeping, not the mission
            self._emit(NOTICE, text=f"Token measurement failed: {e}", level="warn")

    def _measure_measured(self, *, model: str, model_key: str,
                          messages: list[dict], content: str, reasoning: str,
                          upstream_usage: dict | None, seconds: float) -> None:
        tracker = token_cache.tracker_for(self._session_id)

        # 1. Input tokens: the prompt as the model will see it.
        #
        # Rendered once and reused for both the count and the cache match, so
        # the two cannot disagree about what was sent.
        prompt = tokencalc_bridge.render_prompt(messages, model)
        counted = tokencalc_bridge.count_messages(messages, model)

        input_tokens = None
        input_source = ""
        if upstream_usage and upstream_usage.get("prompt_tokens") is not None:
            input_tokens = int(upstream_usage["prompt_tokens"])
            input_source = "upstream"
        elif counted is not None:
            input_tokens = int(counted)
            input_source = "tokenizer"

        # 2. Cached input.
        #
        # The endpoint's own figure is authoritative when present — it is the
        # number the bill is computed from. Otherwise match against the recent
        # prompt history (see cua/token_cache.py for the rule).
        cached_tokens = 0
        cache_source = ""
        upstream_cached = _upstream_cached(upstream_usage)
        if upstream_cached is not None:
            cached_tokens = int(upstream_cached)
            cache_source = "upstream"
        elif input_tokens is not None:
            lookup = tracker.match(prompt or "", input_tokens)
            cached_tokens = lookup.cached_tokens
            cache_source = lookup.source

        # 3. Output tokens.
        output_tokens = None
        output_source = ""
        if upstream_usage and upstream_usage.get("completion_tokens") is not None:
            output_tokens = int(upstream_usage["completion_tokens"])
            output_source = "upstream"
        else:
            # The reasoning trace is part of what the model generated and is
            # billed as output, so it is counted too — leaving it out would
            # understate a thinking model by most of its answer.
            text = content or ""
            if reasoning:
                text = f"{reasoning}\n{text}" if text else reasoning
            local = tokencalc_bridge.count_text(text, model)
            if local is not None:
                output_tokens = int(local)
                output_source = "tokenizer"

        token_usage.record(
            session_id=self._session_id, model=model, step=self._step_no,
            input_tokens=input_tokens, cached_tokens=cached_tokens,
            output_tokens=output_tokens, seconds=seconds,
            input_source=input_source, cache_source=cache_source,
            output_source=output_source,
        )

        # 4. Remember this prompt so the *next* round can hit its prefix.
        if prompt and input_tokens:
            tracker.remember(prompt, input_tokens)

        self._emit(
            TOKEN_USAGE,
            step=self._step_no,
            model=model,
            model_key=model_key,
            input_tokens=input_tokens,
            cached_tokens=cached_tokens,
            output_tokens=output_tokens,
            seconds=round(seconds, 2),
            input_source=input_source,
            cache_source=cache_source,
            output_source=output_source,
            session_total=token_usage.session_total_for(self._session_id),
        )

    # ── Meta tools ──────────────────────────────────────────────────────
    def _meta_load(self, arguments: dict, state: StepState) -> str:
        category = (arguments.get("category") or "").strip()
        if not category:
            return "Error: category must not be empty"
        if not modes.category_allowed(category, self._agent_mode):
            # Refused here *and* at dispatch. Loading is the polite half —
            # it keeps the schema clean — but the model can name a tool it
            # never loaded, so the call-time check is the one that holds.
            return modes.desktop_only_reason(category)
        try:
            tools = tool_loader.load_category_tools(category)
        except ValueError as e:
            return str(e)
        except Exception as e:
            return f"Error: could not load category '{category}' — {e}"

        names = [tool["function"]["name"] for tool in tools]
        if category in state["loaded_categories"]:
            return (
                f"Category '{category}' is already loaded. "
                f"Available: {', '.join(names)}"
            )
        state["loaded_categories"].add(category)
        state["tools"].extend(tools)
        description = tool_loader.get_category_description(category)
        return (
            f"Loaded category '{category}': {description}\n"
            f"Available functions: {', '.join(names)}"
        )

    @staticmethod
    def _meta_list(state: StepState) -> str:
        registry = state["registry"]
        deleted = state["deleted_ids"]
        lines = [
            f"  {uid} | {info['function']} | {time.strftime('%H:%M:%S', time.localtime(info['timestamp']))}"
            for uid, info in registry.items()
            if info["tool_call_id"] not in deleted
        ]
        if not lines:
            return "No skill execution results in context."
        return "UUID | Function | Time\n" + "\n".join(lines)

    @staticmethod
    def _meta_delete(arguments: dict, state: StepState) -> str:
        registry = state["registry"]
        deleted = state["deleted_ids"]
        uuids = arguments.get("uuids") or []
        if not uuids:
            return "Error: uuids must be a non-empty list"

        removed: list[str] = []
        missing: list[str] = []
        already: list[str] = []
        for uid in uuids:
            info = registry.get(uid)
            if info is None:
                missing.append(uid)
            elif info["tool_call_id"] in deleted:
                already.append(uid)
            else:
                deleted.add(info["tool_call_id"])
                removed.append(uid)

        parts = []
        if removed:
            parts.append(f"Deleted {len(removed)} result(s): {', '.join(removed)}")
        if missing:
            parts.append(f"UUID(s) not found: {', '.join(missing)}")
        if already:
            parts.append(f"Already deleted: {', '.join(already)}")
        return "\n".join(parts) if parts else "No results matched the given UUIDs."

    # ── Helpers ─────────────────────────────────────────────────────────
    def _detect_stuck(self, summaries: list[str]) -> bool:
        if len(summaries) < 3:
            return False
        a, b, c = summaries[-3:]
        threshold = float(config.STUCK_SIMILARITY)
        return (
            difflib.SequenceMatcher(None, a, b).ratio() > threshold
            and difflib.SequenceMatcher(None, b, c).ratio() > threshold
            and difflib.SequenceMatcher(None, a, c).ratio() > threshold
        )

    def _emit(self, event_type: str, **payload: Any) -> None:
        try:
            self.emit(make(event_type, **payload))
        except Exception:
            # A broken sink must never take the mission down with it.
            pass


# ── Context management helpers ──────────────────────────────────────────

def _strip_to_summaries(messages: list[dict], original_request: str) -> list[dict]:
    """Compress history down to system + request + summaries (+ image turns)."""
    clean: list[dict] = [messages[0]]
    clean.append({"role": "user", "content": original_request})

    for message in messages[2:]:
        if (
            message.get("role") == "assistant"
            and message.get("content")
            and not message.get("tool_calls")
        ):
            clean.append({"role": "assistant", "content": message["content"]})
        elif _carries_image(message):
            # Screenshots attached inline would otherwise be dropped, quietly
            # blinding a multimodal agent after step one.
            clean.append(message)
    return clean


def _carries_image(message: dict) -> bool:
    if message.get("role") != "user":
        return False
    content = message.get("content")
    if not isinstance(content, list):
        return False
    return any(
        isinstance(part, dict) and part.get("type") == "image_url"
        for part in content
    )


def _filter_deleted(messages: list[dict], deleted_ids: set[str]) -> list[dict]:
    """Remove deleted tool results before sending, rather than after.

    OpenAI's protocol requires every tool_call to be answered by a matching
    tool message, so both sides of the pair have to go together — along with
    any assistant message left empty by their removal.
    """
    if not deleted_ids:
        return messages

    filtered: list[dict] = []
    for message in messages:
        if message.get("role") == "tool":
            if message.get("tool_call_id") in deleted_ids:
                continue
        elif message.get("role") == "assistant" and message.get("tool_calls"):
            remaining = [
                call for call in message["tool_calls"]
                if call.get("id") not in deleted_ids
            ]
            if not remaining and not message.get("content"):
                continue
            message = {**message, "tool_calls": remaining}
        filtered.append(message)
    return filtered


def _safe_json(raw: str) -> dict:
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _usage_to_dict(usage: Any) -> dict:
    """Normalise an SDK usage object into a plain dict.

    The OpenAI SDK hands back a pydantic model; some relays hand back a dict,
    and a few send a shape with only some of the fields. All three are
    accepted, because the alternative — assuming one — is a measurement that
    silently reads zero on exactly the endpoint the operator happens to use.

    ``prompt_tokens_details`` is flattened on the way through: the cached
    count lives one level down there, and every consumer wants it beside the
    totals rather than nested.
    """
    if usage is None:
        return {}
    if isinstance(usage, dict):
        data = dict(usage)
    else:
        for attr in ("model_dump", "to_dict", "dict"):
            fn = getattr(usage, attr, None)
            if callable(fn):
                try:
                    data = dict(fn())
                    break
                except Exception:  # noqa: BLE001 - try the next accessor
                    continue
        else:
            data = {
                key: getattr(usage, key, None)
                for key in ("prompt_tokens", "completion_tokens", "total_tokens",
                            "prompt_tokens_details", "prompt_cache_hit_tokens",
                            "prompt_cache_miss_tokens")
            }
    details = data.get("prompt_tokens_details")
    if details is not None and not isinstance(details, dict):
        # This branch is the one that matters in production: the OpenAI SDK
        # returns a pydantic model, so the nested details arrive as an object
        # too. Leaving it un-converted made _upstream_cached miss the field
        # entirely and silently report a zero cache hit on every request —
        # the numbers were on the wire and were being dropped here.
        for attr in ("model_dump", "to_dict", "dict"):
            fn = getattr(details, attr, None)
            if callable(fn):
                try:
                    details = dict(fn())
                    break
                except Exception:  # noqa: BLE001 - try the next accessor
                    continue
        else:
            # A plain object with the attribute exposed directly (a stub, or
            # a relay's simple namespace). Read the one field we need.
            value = getattr(details, "cached_tokens", None)
            details = {"cached_tokens": value} if value is not None else None
    if isinstance(details, dict):
        data["prompt_tokens_details"] = details
    elif "prompt_tokens_details" in data:
        # Never leave a non-dict in place: downstream code tests for a mapping
        # and would otherwise take a branch that cannot succeed.
        data.pop("prompt_tokens_details", None)
    return data


def _upstream_cached(usage: dict | None) -> int | None:
    """The endpoint's cache-hit token count, however it chose to report it.

    Two spellings are in the wild for the same number, and which one arrives
    depends on the provider:
      * ``prompt_tokens_details.cached_tokens`` — the OpenAI-compatible shape
      * ``prompt_cache_hit_tokens`` — DeepSeek's own field
    """
    if not usage:
        return None
    details = usage.get("prompt_tokens_details")
    if isinstance(details, dict):
        value = details.get("cached_tokens")
        if value is not None:
            try:
                return int(value)
            except (TypeError, ValueError):
                pass
    value = usage.get("prompt_cache_hit_tokens")
    if value is not None:
        try:
            return int(value)
        except (TypeError, ValueError):
            pass
    return None
