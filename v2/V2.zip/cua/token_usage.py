"""Token usage ledger: per-request records, per-run and per-session totals.

Kept separate from the cache tracker (which answers "how much of *this*
prompt was already seen") because the two have different lifetimes: the
tracker only needs the recent past to match against, while the ledger is the
history the statistics page reads.

Only the four models with an exact tokenizer produce records. A request on
any other model is counted and reported as unsupported, so the page can say
"this model is not measured" rather than showing a zero that looks like a
real measurement.
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from . import config
from .tokencalc_bridge import count_text, label as model_label, resolve

#: Where the ledger is persisted. Next to the session files, so a frozen
#: build keeps it beside the exe like everything else the operator owns.
_LEDGER_NAME = "token_usage.json"

#: Cap on records kept per session. A long mission makes one record per
#: model round-trip, and the file is rewritten on flush; this keeps both the
#: memory and the write bounded. The oldest records are dropped, and the
#: totals they contributed to are kept separately so the running sum does not
#: change when history is trimmed.
MAX_RECORDS_PER_SESSION = 400

#: How long to wait between disk flushes. One request per model round-trip
#: would mean a full-file rewrite every few seconds during a mission.
FLUSH_INTERVAL_SECONDS = 5.0


@dataclass
class UsageRecord:
    """One model round-trip."""

    ts: float
    model: str                  # the configured model id
    model_key: str              # resolved tokencalc key ("" when unsupported)
    step: int = 0
    #: Prompt tokens. ``input_tokens`` is the total; ``cached_tokens`` is the
    #: part that matched a recent prefix, billed at the cache price.
    input_tokens: int = 0
    cached_tokens: int = 0
    output_tokens: int = 0
    #: ``"upstream"`` when the endpoint reported usage, ``"tokenizer"`` when
    #: we counted locally, ``"prefix"`` for a locally matched cache figure.
    input_source: str = ""
    cache_source: str = ""
    output_source: str = ""
    #: Wall-clock duration of the call, for the statistics table.
    seconds: float = 0.0

    @property
    def fresh_tokens(self) -> int:
        return max(self.input_tokens - self.cached_tokens, 0)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def as_dict(self) -> dict:
        d = asdict(self)
        d["fresh_tokens"] = self.fresh_tokens
        d["total_tokens"] = self.total_tokens
        return d


@dataclass
class SessionTotals:
    """Running sums for one conversation, independent of retained records."""

    requests: int = 0
    input_tokens: int = 0
    cached_tokens: int = 0
    output_tokens: int = 0
    unsupported_requests: int = 0
    first_at: float = 0.0
    last_at: float = 0.0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def fresh_tokens(self) -> int:
        return max(self.input_tokens - self.cached_tokens, 0)

    def as_dict(self) -> dict:
        return {
            "requests": self.requests,
            "input_tokens": self.input_tokens,
            "cached_tokens": self.cached_tokens,
            "fresh_tokens": self.fresh_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "unsupported_requests": self.unsupported_requests,
            "first_at": self.first_at,
            "last_at": self.last_at,
        }


@dataclass
class _Session:
    totals: SessionTotals = field(default_factory=SessionTotals)
    records: list[UsageRecord] = field(default_factory=list)


_lock = threading.Lock()
_sessions: dict[str, _Session] = {}
_dirty = False
_last_flush = 0.0


def _path() -> Path:
    """Ledger file location, resolved at call time.

    Deliberately not a module-level constant: the tests redirect
    ``config.session_dir`` to a scratch directory, and a path captured at
    import time would ignore that and write to the operator's real file.
    """
    try:
        return config.session_dir().with_name(_LEDGER_NAME)
    except Exception:  # noqa: BLE001 - never break a mission over bookkeeping
        return config.ROOT_DIR / "cua" / _LEDGER_NAME


def record(*, session_id: str | None, model: str, step: int,
           input_tokens: int | None, cached_tokens: int,
           output_tokens: int | None, seconds: float,
           input_source: str = "", cache_source: str = "",
           output_source: str = "") -> None:
    """Append one request's usage and update the running totals.

    ``None`` for a token field means "could not be measured" — distinct from
    zero, which is a real count. The record keeps the distinction so the page
    does not present an unmeasured request as a measured zero.
    """
    key = resolve(model) or ""
    measured = input_tokens is not None and output_tokens is not None

    entry = UsageRecord(
        ts=time.time(),
        model=str(model or ""),
        model_key=key,
        step=int(step or 0),
        input_tokens=int(input_tokens or 0),
        cached_tokens=int(cached_tokens or 0),
        output_tokens=int(output_tokens or 0),
        input_source=input_source,
        cache_source=cache_source,
        output_source=output_source,
        seconds=round(float(seconds or 0.0), 3),
    )

    sid = str(session_id or "")
    with _lock:
        global _dirty
        session = _sessions.setdefault(sid, _Session())
        totals = session.totals
        totals.requests += 1
        if measured and key:
            totals.input_tokens += entry.input_tokens
            totals.cached_tokens += entry.cached_tokens
            totals.output_tokens += entry.output_tokens
        else:
            totals.unsupported_requests += 1
        now = entry.ts
        totals.first_at = totals.first_at or now
        totals.last_at = now

        session.records.append(entry)
        if len(session.records) > MAX_RECORDS_PER_SESSION:
            session.records = session.records[-MAX_RECORDS_PER_SESSION:]
        _dirty = True
    maybe_flush()


def session_total_for(session_id: str | None) -> dict:
    """Just the running totals — cheap enough to attach to every event.

    The panel shows a live counter while a mission runs, and it must not have
    to fetch the whole statistics snapshot on every step to update one number.
    """
    sid = str(session_id or "")
    with _lock:
        session = _sessions.get(sid)
        totals = session.totals if session else SessionTotals()
        return {
            "requests": totals.requests,
            "input_tokens": totals.input_tokens,
            "cached_tokens": totals.cached_tokens,
            "output_tokens": totals.output_tokens,
            "total_tokens": totals.total_tokens,
        }


def session_summary(session_id: str | None) -> dict:
    """Totals + recent records for one conversation, as JSON-ready dicts."""
    sid = str(session_id or "")
    with _lock:
        session = _sessions.get(sid)
        if session is None:
            return {
                "session_id": sid,
                "totals": SessionTotals().as_dict(),
                "records": [],
                "supported": False,
            }
        return {
            "session_id": sid,
            "totals": session.totals.as_dict(),
            "records": [r.as_dict() for r in session.records[-60:]][::-1],
            "supported": True,
        }


def all_sessions_summary(limit: int = 20) -> list[dict]:
    """Every tracked conversation with its totals, newest activity first."""
    with _lock:
        rows = []
        for sid, session in _sessions.items():
            totals = session.totals.as_dict()
            totals["session_id"] = sid
            rows.append(totals)
    rows.sort(key=lambda r: r.get("last_at") or 0, reverse=True)
    return rows[: max(int(limit), 1)]


def snapshot() -> dict:
    """Everything the statistics page needs, in one call."""
    with _lock:
        sessions = []
        grand = SessionTotals()
        for sid, session in _sessions.items():
            totals = session.totals
            entry = totals.as_dict()
            entry["session_id"] = sid
            sessions.append(entry)
            grand.requests += totals.requests
            grand.input_tokens += totals.input_tokens
            grand.cached_tokens += totals.cached_tokens
            grand.output_tokens += totals.output_tokens
            grand.unsupported_requests += totals.unsupported_requests
            grand.first_at = grand.first_at or totals.first_at
            grand.last_at = max(grand.last_at, totals.last_at)
    sessions.sort(key=lambda r: r.get("last_at") or 0, reverse=True)

    # Per-model roll-up, so the page can show which model is costing the most
    # without the client having to fold the sessions itself.
    by_model: dict[str, dict] = {}
    with _lock:
        for session in _sessions.values():
            for rec in session.records:
                if not rec.model_key:
                    continue
                row = by_model.setdefault(rec.model_key, {
                    "model_key": rec.model_key,
                    "label": model_label(rec.model_key),
                    "requests": 0,
                    "input_tokens": 0,
                    "cached_tokens": 0,
                    "output_tokens": 0,
                })
                row["requests"] += 1
                row["input_tokens"] += rec.input_tokens
                row["cached_tokens"] += rec.cached_tokens
                row["output_tokens"] += rec.output_tokens
    for row in by_model.values():
        row["fresh_tokens"] = max(row["input_tokens"] - row["cached_tokens"], 0)
        row["total_tokens"] = row["input_tokens"] + row["output_tokens"]

    return {
        "totals": grand.as_dict(),
        "sessions": sessions,
        "by_model": sorted(by_model.values(),
                           key=lambda r: r["total_tokens"], reverse=True),
    }


def clear() -> None:
    """Forget every recorded number (used by the statistics page)."""
    global _dirty
    with _lock:
        _sessions.clear()
        _dirty = True
    flush(force=True)


# ── Persistence ─────────────────────────────────────────────────────────

def maybe_flush() -> None:
    """Write to disk if enough time has passed since the last write."""
    global _last_flush
    now = time.time()
    if now - _last_flush < FLUSH_INTERVAL_SECONDS:
        return
    _last_flush = now
    flush()


def flush(force: bool = False) -> None:
    """Persist the ledger. Failures are swallowed on purpose.

    This is a statistics file. A read-only volume or a full disk must not be
    able to fail the mission that is being measured.
    """
    global _dirty
    with _lock:
        if not _dirty and not force:
            return
        payload = {
            "version": 1,
            "sessions": {
                sid: {
                    "totals": asdict(session.totals),
                    "records": [asdict(r) for r in session.records],
                }
                for sid, session in _sessions.items()
            },
        }
        _dirty = False
    try:
        path = _path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        temp.replace(path)
    except OSError:
        pass


def load() -> None:
    """Read a previous run's ledger back into memory."""
    try:
        raw = _path().read_text(encoding="utf-8")
    except (OSError, ValueError):
        return
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return
    if not isinstance(payload, dict):
        return
    sessions = payload.get("sessions")
    if not isinstance(sessions, dict):
        return
    with _lock:
        for sid, blob in sessions.items():
            if not isinstance(blob, dict):
                continue
            totals = SessionTotals()
            for field_name in ("requests", "input_tokens", "cached_tokens",
                               "output_tokens", "unsupported_requests"):
                try:
                    setattr(totals, field_name, int(blob.get("totals", {}).get(field_name) or 0))
                except (TypeError, ValueError):
                    pass
            for field_name in ("first_at", "last_at"):
                try:
                    setattr(totals, field_name, float(blob.get("totals", {}).get(field_name) or 0.0))
                except (TypeError, ValueError):
                    pass
            records: list[UsageRecord] = []
            for item in (blob.get("records") or [])[-(MAX_RECORDS_PER_SESSION):]:
                if not isinstance(item, dict):
                    continue
                known = {f for f in UsageRecord.__dataclass_fields__}
                records.append(UsageRecord(**{k: v for k, v in item.items() if k in known
                                              and (k in ("ts", "model", "model_key", "step")
                                                   or isinstance(v, (int, float, str)))}))
            _sessions[str(sid)] = _Session(totals=totals, records=records)
