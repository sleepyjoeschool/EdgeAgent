"""Runtime control surface shared by the agent core and its front-ends.

The core asks this object three questions on every loop:

* ``should_stop()``  — has the operator aborted the mission?
* ``gate()``         — block here while the operator has paused execution
* ``approve(...)``   — a risky action needs a human decision

Headless runs use the permissive default implementation; the WebUI installs
a subclass backed by browser interaction.
"""

from __future__ import annotations

import threading
import time
import uuid
from typing import Any, Callable

from . import config


class Denied(Exception):
    """Raised inside a tool executor when the operator rejects an action."""


class Aborted(Exception):
    """Raised inside the agent loop when the operator aborts the mission."""


class Runtime:
    """Default (headless) control policy."""

    def __init__(self) -> None:
        self._abort = threading.Event()
        self._pause = threading.Event()
        self._step_gate = threading.Event()
        self.step_mode = False
        # Set by the WebUI when the operator grants Full Access for a mission:
        # shell commands are then auto-approved without a human in the loop.
        self.full_access = False
        # Directory the operator picked in the composer. Executors read it to
        # scope their work — see executors/shell.py, which runs commands here
        # and refuses paths that point outside.
        #
        # Declared here rather than assigned dynamically by the WebUI: a bare
        # attribute assignment would work in exactly the one code path that
        # sets it and raise AttributeError in the headless run that does not,
        # which is the kind of failure that only shows up in production.
        self.workspace: str = ""

    # ── Lifecycle ──────────────────────────────────────────────────────
    def abort(self) -> None:
        self._abort.set()
        self._pause.clear()
        self.release_step()

    def resume_from_abort(self) -> None:
        self._abort.clear()

    def pause(self) -> None:
        self._pause.set()

    def resume(self) -> None:
        self._pause.clear()
        self.release_step()

    @property
    def paused(self) -> bool:
        return self._pause.is_set()

    def release_step(self) -> None:
        """Allow a mission parked in step mode to run exactly one more step."""
        self._step_gate.set()

    def should_stop(self) -> bool:
        return self._abort.is_set()

    def check_stop(self) -> None:
        if self.should_stop():
            raise Aborted("mission aborted by operator")

    def gate(self) -> None:
        """Block while paused, and never return into an aborted mission.

        The abort check is deliberately outside the pause loop. ``abort()``
        clears ``_pause`` as well as setting ``_abort``, so the loop condition
        goes false the moment an operator aborts while paused — the body never
        runs again and the old form's ``raise`` was unreachable. The caller's
        ``check_stop()`` sits *before* this call, so it had already been passed
        for the turn: the gate returned normally and the engine ran one more
        whole step after "stop" was pressed.

        Re-checking unconditionally also covers the plain running case, where
        an abort that lands between the caller's check and here would otherwise
        be missed until the next step boundary.
        """
        while self._pause.is_set():
            if self._abort.is_set():
                raise Aborted("mission aborted while paused")
            time.sleep(0.1)
        if self._abort.is_set():
            raise Aborted("mission aborted by operator")

    def gate_step(self, step: int) -> None:
        """In step mode, wait for the operator to authorise another step.

        The abort re-check after the loop is not redundant, for the same reason
        as in :meth:`gate`: ``abort()`` sets ``_step_gate`` as well as
        ``_abort``, so the loop condition goes false the instant an operator
        aborts while a step is pending — the in-loop ``raise`` is then
        unreachable and this returned normally, letting the engine run the step
        the operator had just cancelled.
        """
        if not self.step_mode:
            return
        # ``resume()`` sets the step gate as well as clearing the pause, so a
        # stale allowance from a previous pause must not leak through as an
        # instant pass here — clearing first is what makes each step wait.
        self._step_gate.clear()
        while not self._step_gate.is_set():
            if self._abort.is_set():
                raise Aborted("mission aborted while waiting for next step")
            time.sleep(0.1)
        if self._abort.is_set():
            raise Aborted("mission aborted by operator")

    # ── Approvals ──────────────────────────────────────────────────────
    def approve(self, request: dict) -> bool:
        """Resolve a risky-action request.

        Headless policy falls back to ``config.HEADLESS_DANGER_POLICY``.
        Subclasses override to bridge to a real human.
        """
        policy = (config.HEADLESS_DANGER_POLICY or "deny").strip().lower()
        return policy == "allow"

    def ask_text(self, request: dict) -> str | None:
        """Ask the operator for a free-text answer (HumanInput tool)."""
        return None


class CallbackRuntime(Runtime):
    """Runtime whose approval traffic is routed through callbacks.

    The WebUI supplies callables that push an SSE event and wait on an
    ``threading.Event`` filled by the browser's reply.
    """

    def __init__(
        self,
        approval_hook: Callable[[dict], bool] | None = None,
        text_hook: Callable[[dict], str | None] | None = None,
    ) -> None:
        super().__init__()
        self._approval_hook = approval_hook
        self._text_hook = text_hook

    def approve(self, request: dict) -> bool:
        if self._approval_hook is None:
            return super().approve(request)
        return bool(self._approval_hook(request))

    def ask_text(self, request: dict) -> str | None:
        if self._text_hook is None:
            return super().ask_text(request)
        return self._text_hook(request)


def new_request_id() -> str:
    return uuid.uuid4().hex[:12]


def build_shell_request(
    shell_code: str,
    risk: str,
    parts: list[dict] | None = None,
) -> dict:
    """Assemble the payload shown in a dangerous-command confirmation."""
    return {
        "id": new_request_id(),
        "kind": "shell",
        "title": "Potentially dangerous shell command",
        "command": shell_code,
        "risk": risk,
        "parts": parts or [],
        "timeout": config.APPROVAL_TIMEOUT,
    }


def build_human_request(message: str, kind: str = "human_operation") -> dict:
    """Assemble the payload for a human-in-the-loop interaction."""
    return {
        "id": new_request_id(),
        "kind": kind,
        "title": "Agent needs human assistance",
        "message": message,
        "timeout": config.APPROVAL_TIMEOUT,
    }


def render_request(request: dict) -> str:
    """Human-readable summary embedded in tool results when denied."""
    if request.get("kind") == "shell":
        return f"{request.get('risk', '')}"
    return str(request.get("message", ""))
