"""Multimodal (VLM) transport layer.

A thin provider abstraction so the vision half of the agent is swappable
without touching the executors. Supported providers:

``openai_compatible``  OpenAI / Qwen-VL / GLM-4V / Kimi / SiliconFlow /
                       OpenRouter / Ollama / LM Studio / vLLM ...
``anthropic``          Anthropic Messages API
``gemini``             Google Generative Language API
``legacy``             Private Qwen-VL bridge ``{AuthKey, ImgBase64, PromptString}``
``auto``               Inferred from the configured URL
"""

from __future__ import annotations

import base64
import io
import re
from typing import Any

import httpx

from . import config


class VLMError(Exception):
    """Raised for a well-understood multimodal backend failure."""


def has_pil() -> bool:
    try:
        from PIL import Image  # noqa: F401

        return True
    except Exception:
        return False


# ── Image helpers ───────────────────────────────────────────────────────

def pil_to_b64(image, max_edge: int | None = None, quality: int = 85) -> tuple[str, str]:
    """Encode a PIL image as base64 JPEG. Returns ``(b64, mime_type)``."""
    try:
        from PIL import Image  # type: ignore
    except Exception as e:
        raise VLMError("Pillow is unavailable — cannot encode the image") from e

    if max_edge is None:
        max_edge = config.VLM_MAX_IMAGE_EDGE

    if max_edge and max_edge > 0:
        width, height = image.size
        if max(width, height) > max_edge:
            scale = max_edge / float(max(width, height))
            image = image.resize(
                (max(1, int(width * scale)), max(1, int(height * scale))),
                Image.LANCZOS,  # type: ignore[attr-defined]
            )

    if image.mode != "RGB":
        image = image.convert("RGB")

    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=quality, optimize=True)
    return base64.b64encode(buffer.getvalue()).decode("ascii"), "image/jpeg"


def normalize_b64(img_b64: str, max_edge: int | None = None) -> tuple[str, str]:
    """Accept raw base64 or a data URL; down-scale when Pillow is present."""
    if not img_b64:
        raise VLMError("image is empty")

    data = img_b64
    mime = "image/jpeg"
    match = re.match(r"data:(image/[\w.+-]+);base64,(.*)", img_b64, re.S)
    if match:
        mime = match.group(1)
        data = match.group(2)

    if not has_pil() or not config.VLM_MAX_IMAGE_EDGE:
        return data.strip(), mime

    from PIL import Image  # type: ignore

    try:
        image = Image.open(io.BytesIO(base64.b64decode(data)))
    except Exception:
        return data.strip(), mime  # not decodable — forward as-is

    return pil_to_b64(image, max_edge=max_edge)


# ── Provider resolution ─────────────────────────────────────────────────

def resolve_provider() -> str:
    provider = (config.VLM_PROVIDER or "auto").strip().lower()
    if provider != "auto":
        return provider

    url = (config.VLM_API_URL or "").lower()
    if "anthropic" in url:
        return "anthropic"
    if "generativelanguage" in url or "googleapis" in url:
        return "gemini"
    return "openai_compatible"


def _require_key() -> str:
    key = (config.VLM_API_KEY or config.VLM_AUTH_KEY or "").strip()
    if not key:
        raise VLMError(
            "VLM is not configured. Set an API key in Settings → 视觉 → "
            "VLM API Key, or set Vision Mode to 'multimodal' and use a "
            "vision-capable main model — in that mode the main model reads "
            "images itself and no separate VLM is needed."
        )
    return key


def describe() -> str:
    provider = resolve_provider()
    return f"{config.VLM_MODEL or '(no model)'} @ {config.VLM_API_URL or '(no url)'} [{provider}]"


# ── Entry points ────────────────────────────────────────────────────────

def analyze_image(img_b64: str, prompt: str) -> tuple[str, str]:
    """Analyze a base64 image. Returns ``(answer, reasoning)``."""
    data, mime = normalize_b64(img_b64)
    provider = resolve_provider()
    handler = {
        "openai_compatible": _call_openai_compatible,
        "anthropic": _call_anthropic,
        "gemini": _call_gemini,
        "legacy": _call_legacy,
    }.get(provider)
    if handler is None:
        raise VLMError(f"unsupported VLM provider '{provider}'")
    answer, reasoning = handler(data, mime, prompt)
    if not (answer or "").strip():
        raise VLMError("the multimodal backend returned an empty response")
    return answer.strip(), (reasoning or "").strip()


def analyze_pil_image(image, prompt: str) -> tuple[str, str]:
    """Analyze a PIL image (avoids one round trip through base64)."""
    if not has_pil():
        from PIL import Image  # type: ignore  # noqa: F401
    data, mime = pil_to_b64(image)
    provider = resolve_provider()
    handler = {
        "openai_compatible": _call_openai_compatible,
        "anthropic": _call_anthropic,
        "gemini": _call_gemini,
        "legacy": _call_legacy,
    }.get(provider)
    if handler is None:
        raise VLMError(f"unsupported VLM provider '{provider}'")
    answer, reasoning = handler(data, mime, prompt)
    if not (answer or "").strip():
        raise VLMError("the multimodal backend returned an empty response")
    return answer.strip(), (reasoning or "").strip()


# ── Transports ──────────────────────────────────────────────────────────

def _client(timeout: float | None = None) -> httpx.Client:
    return httpx.Client(
        timeout=httpx.Timeout(
            connect=10.0,
            read=float(timeout or config.VLM_TIMEOUT),
            write=30.0,
            pool=10.0,
        ),
        trust_env=False,
    )


def _call_openai_compatible(b64: str, mime: str, prompt: str) -> tuple[str, str]:
    key = _require_key()
    if not (config.VLM_API_URL or "").strip():
        raise VLMError("VLM base URL is not configured")

    base = config.VLM_API_URL.rstrip("/")
    url = base if base.endswith("/chat/completions") else f"{base}/chat/completions"

    messages: list[dict[str, Any]] = []
    if config.VLM_SYSTEM_PROMPT:
        messages.append({"role": "system", "content": config.VLM_SYSTEM_PROMPT})
    messages.append({
        "role": "user",
        "content": [
            {"type": "image_url", "image_url": {
                "url": f"data:{mime};base64,{b64}",
                "detail": config.VLM_IMAGE_DETAIL,
            }},
            {"type": "text", "text": prompt},
        ],
    })

    payload: dict[str, Any] = {
        "model": config.VLM_MODEL,
        "messages": messages,
        "max_tokens": config.VLM_MAX_TOKENS,
        "temperature": config.VLM_TEMPERATURE,
    }

    try:
        with _client() as client:
            response = client.post(
                url,
                json=payload,
                headers={"Authorization": f"Bearer {key}"},
            )
    except httpx.HTTPError as e:
        raise VLMError(f"cannot reach the multimodal endpoint — {e}") from e

    if response.status_code >= 400:
        raise VLMError(
            f"multimodal endpoint returned HTTP {response.status_code}: "
            f"{response.text[:300]}"
        )

    body = response.json()
    try:
        message = body["choices"][0]["message"]
    except (KeyError, IndexError, TypeError) as e:
        raise VLMError(f"unexpected response shape: {str(body)[:300]}") from e

    answer = message.get("content") or ""
    reasoning = message.get("reasoning_content") or message.get("reasoning") or ""
    return answer, reasoning


def _call_anthropic(b64: str, mime: str, prompt: str) -> tuple[str, str]:
    key = _require_key()
    base = (config.VLM_API_URL or "https://api.anthropic.com/v1").rstrip("/")
    url = base if base.endswith("/messages") else f"{base}/messages"

    payload = {
        "model": config.VLM_MODEL,
        "max_tokens": config.VLM_MAX_TOKENS,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image", "source": {
                    "type": "base64", "media_type": mime, "data": b64,
                }},
                {"type": "text", "text": prompt},
            ],
        }],
    }
    headers = {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }

    try:
        with _client() as client:
            response = client.post(url, json=payload, headers=headers)
    except httpx.HTTPError as e:
        raise VLMError(f"cannot reach Anthropic — {e}") from e

    if response.status_code >= 400:
        raise VLMError(f"Anthropic returned HTTP {response.status_code}: {response.text[:300]}")

    content = response.json().get("content", [])
    text = "".join(part.get("text", "") for part in content if part.get("type") == "text")
    thinking = "".join(
        part.get("thinking", "") for part in content if part.get("type") == "thinking"
    )
    return text, thinking


def _call_gemini(b64: str, mime: str, prompt: str) -> tuple[str, str]:
    key = _require_key()
    base = (config.VLM_API_URL or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
    url = f"{base}/models/{config.VLM_MODEL}:generateContent?key={key}"

    payload = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": mime, "data": b64}},
            ]
        }],
        "generationConfig": {
            "maxOutputTokens": config.VLM_MAX_TOKENS,
            "temperature": config.VLM_TEMPERATURE,
        },
    }

    try:
        with _client() as client:
            response = client.post(url, json=payload)
    except httpx.HTTPError as e:
        raise VLMError(f"cannot reach Gemini — {e}") from e

    if response.status_code >= 400:
        raise VLMError(f"Gemini returned HTTP {response.status_code}: {response.text[:300]}")

    body = response.json()
    try:
        parts = body["candidates"][0]["content"]["parts"]
    except (KeyError, IndexError, TypeError) as e:
        raise VLMError(f"unexpected response shape: {str(body)[:300]}") from e
    text = "".join(part.get("text", "") for part in parts)
    return text, ""


def _call_legacy(b64: str, _mime: str, prompt: str) -> tuple[str, str]:
    """Private Qwen-VL bridge protocol."""
    key = _require_key()
    if not (config.VLM_API_URL or "").strip():
        raise VLMError("VLM inference URL is not configured")

    payload = {
        "AuthKey": key,
        "ImgBase64": b64,
        "PromptString": prompt,
    }
    try:
        with _client() as client:
            response = client.post(config.VLM_API_URL, json=payload)
    except httpx.HTTPError as e:
        raise VLMError(f"cannot reach the legacy VLM service — {e}") from e

    if response.status_code >= 400:
        raise VLMError(f"legacy VLM returned HTTP {response.status_code}: {response.text[:300]}")

    try:
        body = response.json()
    except ValueError as e:
        raise VLMError("legacy VLM returned a non-JSON response") from e

    for field in ("Result", "result", "answer", "Answer", "content", "text"):
        value = body.get(field)
        if isinstance(value, str) and value.strip():
            return value, ""
    return str(body), ""


# ── Diagnostics ─────────────────────────────────────────────────────────

def test_connection() -> tuple[bool, str]:
    """Validate the current multimodal configuration.

    Sends a 1x1 pixel image so a working setup costs almost nothing.

    Short-circuits when the main model is reading screenshots itself: this
    endpoint is the *standalone* VLM, which does not participate in that mode,
    and reporting "VLM is not configured" next to a working multimodal setup
    reads as a fault. The failing part — no standalone VLM — is expected there,
    so the honest answer is "not needed", not "not configured".
    """
    if config.is_multimodal_main_model():
        return True, (
            f"当前视觉模式为 multimodal：主模型（{config.LLM_MODEL}）直接读取截图，"
            f"独立 VLM 不参与运行，无需配置。"
        )
    try:
        probe = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8"
            "/58BAwAI/AL+hc2rNAAAAABJRU5ErkJggg=="
        )
        answer, _ = analyze_image(probe, "Reply with the single word: ok")
        preview = answer[:120].replace("\n", " ")
        return True, f"{describe()} -> {preview}"
    except VLMError as e:
        return False, str(e)
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"
